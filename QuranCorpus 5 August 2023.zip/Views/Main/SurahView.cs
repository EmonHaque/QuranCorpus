﻿class SurahView : CardView {
    public override string Icon => Icons.Book;
    EditText query;
    CheckGroup checkGroup;
    ListBox surahNames;
    PageControl pages;
    SurahVM vm;
    
    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new SurahVM();
        DataContext = vm;
        pages = ((App)Application.Current).Pages;
        initializeUI();
        bind();
        surahNames.PreviewMouseRightButtonDown += onRightButtonDown;
        surahNames.MouseRightButtonUp += onRightButtonUp;
    }

    void initializeUI() {
        query = new EditText() {
            Icon = Icons.Search,
            Hint = "Surah (english)",
            IsTrimBottomRequested = true
        };
        checkGroup = new CheckGroup() {
            Icons = new string[] { Icons.NumberAscending, Icons.ClockAscending, Icons.NumberDescending },
            Tips = new string[] { "by chapter number", "by revealation order", "by number of ayah" },
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(0, 0, 0, 5)
        };
        Grid.SetColumn(checkGroup, 1);
        var topGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { query, checkGroup }
        };

        surahNames = new ListBox() {
            FlowDirection = FlowDirection.RightToLeft,
            Margin = new Thickness(5, 0, 0, 0),
            ItemTemplate = new SurahNameTemplate()
        };

        Grid.SetRow(surahNames, 1);
        
        var content = new Grid() { 
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { topGrid, surahNames }
        };
        setContent(content);
    }

    void bind() {
        surahNames.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Surahs)));
        surahNames.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.SelectedSurah)) { 
            Mode = BindingMode.OneWayToSource 
        });
        query.SetBinding(EditText.TextProperty, new Binding(nameof(vm.Query)) {
            Mode = BindingMode.OneWayToSource,
            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
        });
        checkGroup.SetBinding(CheckGroup.SelectedProperty, new Binding(nameof(vm.SelectedOrder)) { Mode = BindingMode.OneWayToSource });
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) => pages.addSurahPage(vm.SelectedSurah.Id);

    void onRightButtonDown(object sender, MouseButtonEventArgs e) => vm.WasRightClicked = true;
}
