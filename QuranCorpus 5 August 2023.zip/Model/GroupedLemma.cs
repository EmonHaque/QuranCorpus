﻿class GroupedLemma {
    public string Root { get; set; }
    public List<IGrouping<string, Lemma>> Lemmas { get; set; }
}
