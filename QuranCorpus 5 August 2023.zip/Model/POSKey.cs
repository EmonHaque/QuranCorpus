﻿class POSKey : Notifiable {
    public string Name { get; set; }
    public string Value { get; set; }
    public int FormCount { get; set; }
}
