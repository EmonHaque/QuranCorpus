﻿class PageContent : ContentControl {

    UIElement current;
    Border border;
    Grid contentGrid;
    bool canBeDropped;

    public PageContent() {
        AllowDrop = true;
        border = new Border() {
            IsHitTestVisible = false,
            Background = Constants.BackgroundDark,
            Opacity = 0
        };
        Grid.SetZIndex(border, 1);

        contentGrid = new Grid() {
            Children = { border }
        };
        Content = contentGrid;
    }

    protected override void OnDragEnter(DragEventArgs e) {
        base.OnDragOver(e);

        canBeDropped = false;
        if (((App)Application.Current).Pages.Count == 4) return;
        var source = e.Data.GetData("source");
        if (source is not Header) return;

        var dataObj = e.Data as DataObject;
        var dragged = dataObj.GetData(typeof(Page)) as Page;
        if (dragged is null) return;

        if (dragged.ChildOf.pages.Count > 1) {
            if(dragged.ChildOf.Position == SplitPosition.None ||
                dragged.ChildOf.Position == SplitPosition.Left ||
                dragged.ChildOf.Position == SplitPosition.Right) {

                canBeDropped = true;
                border.Opacity = 0.75;
                e.Effects = DragDropEffects.Scroll;
            }
        }
        else {
            e.Effects = DragDropEffects.None;
            e.Handled = true;
        }
    }

    protected override void OnDragLeave(DragEventArgs e) {
        base.OnDragLeave(e);
        border.Opacity = 0;
    }

    protected override void OnDrop(DragEventArgs e) {
        base.OnDrop(e);
        border.Opacity = 0;
        if (!canBeDropped) return;

        var dataObj = e.Data as DataObject;
        var page = dataObj.GetData(typeof(Page)) as Page;

        var oldControl = page.ChildOf;
        var newControl = new PageControl(false);

        oldControl.removePage(page);
        newControl.addPage(page);

        var pages = ((App)Application.Current).Pages;
        var count = pages.Count;
        pages.Add(newControl);

        if (count == 1) {
            oldControl.Position = SplitPosition.Right;
            newControl.Position = SplitPosition.Left;
            MainView.tab.AddVertical();
        }
        else {
            if (oldControl.Position == SplitPosition.Left) {
                oldControl.Position = SplitPosition.TopLeft;
                newControl.Position = SplitPosition.BottomLeft;
            }
            else {
                oldControl.Position = SplitPosition.TopRight;
                newControl.Position = SplitPosition.BottomRight;
            }
            MainView.tab.AddHorizontal();
        }
    }

    public void setContent(UIElement content) {
        if (current is not null) {
            contentGrid.Children.Remove(current);
        }
        current = content;
        Grid.SetZIndex(current, 0);
        contentGrid.Children.Add(current);
    }
}
