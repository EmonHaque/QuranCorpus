﻿class POSTemplate : Grid {
    TextBlockEnglish name, value;
    TextBlockEnglish itemsCount, referenceCount;
    public POSTemplate() {
        name = new TextBlockEnglish();
        value = new TextBlockEnglish() { 
            Foreground = Brushes.Gray,
            TextWrapping = TextWrapping.Wrap
        };
        itemsCount = new TextBlockEnglish() { HorizontalAlignment = HorizontalAlignment.Right };
        referenceCount = new TextBlockEnglish() { 
            Foreground = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Right
        };

        SetRow(value, 1);
        SetRow(referenceCount, 1);
        SetColumn(itemsCount, 1);
        SetColumn(referenceCount, 1);

        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition());
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

        Children.Add(name);
        Children.Add(value);
        Children.Add(itemsCount);
        Children.Add(referenceCount);

        itemsCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Key." + nameof(POSKey.FormCount)),
            StringFormat = "N0"
        });
    }

    public override void EndInit() {
        base.EndInit();
        var c = ((KeyValuePair<POSKey, List<POS>>)DataContext);
        name.Text = c.Key.Name;
        value.Text = c.Key.Value;
        referenceCount.Text = c.Value.Sum(x => x.References.Count).ToString("N0");
    }
}
