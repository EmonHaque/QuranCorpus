﻿class CaseView : CardView {
    public override string Header => "Cases";

    TextBlockEnglish count;
    ProgressBar progress;
    ListBox list;
   
    CaseVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new CaseVM();
        DataContext = vm;

        initializeUI();
        bind();
        list.PreviewMouseRightButtonDown += onRightButtonDown;
        list.MouseRightButtonUp += onRightButtonUp;
        IsVisibleChanged += onVisibilityChange;
    }

    void onVisibilityChange(object sender, DependencyPropertyChangedEventArgs e) {
        if (!IsVisible) return;
        if (vm.currentTranscript == App.global.Transcript) return;
        vm.Regroup();
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) {
        if (vm.Selected is null) return;
        ((App)Application.Current).FocusedControl.addCasePage(vm.items);
        if (vm.WasRightClicked) vm.WasRightClicked = false;
    }

    void onRightButtonDown(object sender, MouseButtonEventArgs e) => vm.WasRightClicked = true;

    void initializeUI() {
        progress = new ProgressBar() {
            Height = Constants.ProgressBarHeight,
            FlowDirection = FlowDirection.RightToLeft
        };
        list = new ListBox() { 
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(StringCountTemplate))
            }
        };
        Grid.SetRow(list, 1);

        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { progress, list }
        };
        setContent(grid);

        count = new TextBlockEnglish();
        addActions(new UIElement[] { count });
    }

    void bind() {
        progress.SetBinding(ProgressBar.IsIndeterminateProperty, new Binding(nameof(vm.IsInProgress)));
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Genders)));
        list.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.Selected)){ Mode = BindingMode.OneWayToSource });
        count.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = list,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
    }
}
