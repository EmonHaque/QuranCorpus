﻿class FormsVM : Notifiable {
    //public int currentTranscript;
    int referenceCount;
    POSFormKey selected;
    public POSFormKey Selected {
        get { return selected; }
        set {
            if (value is null) {
                return;
            }
            if (value.Equals(selected)) return;

            selected = value;

            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).FocusedControl.SelectedPage is FormPage page) {
                page.setContent(selected);
            }
        }
    }
    public bool WasRightClicked { get; set; }
    public string Status { get; set; }
    public bool IsInProgress { get; set; }
    public List<POSFormKey> Items { get; set; }

    public FormsVM() {
        IsInProgress = true;
        Task.Run(() => {
            int count = 0;
            var list = new List<POSForm>();
            for (int i = 0; i < App.links.Count; i++) {
                count++;
                if (string.IsNullOrEmpty(App.links[i].Root)) continue;
                referenceCount++;

                var link = App.links[i];
                var index = Convert.ToInt32(link.RootIndex);
                
                var word = new POSForm() {
                    Spellings = new string[] {
                         link.SpellingGroupCorpus.Split('|')[index],
                         link.SpellingGroupSimple.Split('|')[index]
                    },
                    Tag = App.tags[Convert.ToInt32(link.Tags.Split('|')[index])].Name,
                    Root = link.Root.Contains('|') ?
                        string.Join("|", link.Root.Split('|').Select(x => App.roots[Convert.ToInt32(x)])) :
                        App.roots[Convert.ToInt32(link.Root)]
                };
                var details = link.Details.Split(',')[index];
                if (!string.IsNullOrEmpty(details)) {
                    setDetail(details, word);
                }
                else {
                    word.Form = "I";
                    word.Gender = "";
                }

                POSForm match = null;
                if (list.Count > 0) {
                    int half = list.Count / 2;
                    for (int j = 0, k = list.Count - 1; j < half + 1 || k > half; j++, k--) {
                        if (list[j].Spellings[0].Equals(word.Spellings[0]) &&
                            list[j].Spellings[1].Equals(word.Spellings[1]) &&
                            list[j].Tag.Equals(word.Tag) &&
                            list[j].Root.Equals(word.Root) &&
                            list[j].Form.Equals(word.Form) &&
                            list[j].Gender.Equals(word.Gender)) {
                            match = list[j];
                            break;
                        }
                        if (list[k].Spellings[0].Equals(word.Spellings[0]) &&
                            list[k].Spellings[1].Equals(word.Spellings[1]) &&
                            list[k].Tag.Equals(word.Tag) &&
                            list[k].Root.Equals(word.Root) &&
                            list[k].Form.Equals(word.Form) &&
                            list[k].Gender.Equals(word.Gender)) {
                            match = list[k];
                            break;
                        }
                    }
                }
                
                if (match is null) {
                    word.References.Add(link.Reference);
                    list.Add(word);
                }
                else match.References.Add(link.Reference);

                if (count % 1000 == 0) {
                    App.Current.Dispatcher.Invoke(() => {
                        Status = count.ToString("N0") + " of " + App.links.Count.ToString("N0") + " processed";
                        OnPropertyChanged(nameof(Status));
                    });
                }
            }
           
            var groups = list
                .GroupBy(x => x.Form)
                .Select(x => new { x.Key, Value = x.GroupBy(x => x.Tag).ToList() })
                .ToList();
            
            Items = new List<POSFormKey>(new POSFormKey[12]);
            for (int i = 0; i < groups.Count; i++) {
                var key = new POSFormKey() {
                    Form = groups[i].Key
                };
                for (int j = 0; j < groups[i].Value.Count; j++) {
                    key.NoOfTag++;
                    key.Items.Add(groups[i].Value[j].Key, groups[i].Value[j].ToList());
                }

                int index = groups[i].Key switch{
                    "I" => 0,
                    "II" => 1,
                    "III" => 2,
                    "IV" => 3,
                    "V" => 4,
                    "VI" => 5,
                    "VII" => 6,
                    "VIII" => 7,
                    "IX" => 8,
                    "X" => 9,
                    "XI" => 10,
                    "XII" => 11
                };
                Items[index] = key;
            }

            App.Current.Dispatcher.Invoke(() => {
                IsInProgress = false;
                OnPropertyChanged(nameof(IsInProgress));
                OnPropertyChanged(nameof(Items));
            });
            Regroup();
        });
        App.global.PropertyChanged += onTranscriptChanged;
    }

void onTranscriptChanged(object? sender, PropertyChangedEventArgs e) {
    if (!e.PropertyName.Equals(nameof(App.global.Transcript))) return;
    Regroup();
}

public void Regroup() {
        Task.Run(() => {
            int wordCount = 0;
            List<List<Tuple<string, int>>> words = new();
            for (int i = 0; i < Items.Count; i++) {
                List<Tuple<string, int>> noOfWords = new();
                for (int j = 0; j < Items[i].Items.Count; j++) {
                    var values = Items[i].Items.Values.ElementAt(j);
                    var count = values
                        .Select(x => x.Spellings[App.global.Transcript] + x.Root + x.Tag + x.Gender + x.Form)
                        .Distinct()
                        .Count();
                    noOfWords.Add(new Tuple<string, int>(values.First().Tag, count));
                    wordCount += count;
                }
                words.Add(noOfWords);
            }
            App.Current.Dispatcher.Invoke(() => {
                for (int i = 0; i < Items.Count; i++) {
                    Items[i].NoOfWord = words[i];
                    Items[i].OnPropertyChanged(nameof(POSFormKey.NoOfWord));
                }
                Status = referenceCount.ToString("N0") + " reference, " + wordCount.ToString("N0") + " words, " + Items.Count + " forms";
                OnPropertyChanged(nameof(Status));
            });
            //currentTranscript = App.global.Transcript;
        });
    }

    void setDetail(string details, POSForm word) {
        var array = details.Split('|').Select(x => App.details[Convert.ToInt32(x)].Name).ToArray();
        var tag = word.Tag;
        if (App.tagArray.Contains(tag)) {
            for (int i = 0; i < array.Length; i++) {
                if (string.IsNullOrEmpty(array[i])) continue;
                if (array[i].Equals("PCPL") ||
                    array[i].Equals("ACC") ||
                    array[i].Equals("NOM") ||
                    array[i].Equals("GEN") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("ACT")) word.SubTag = "Active Participle";
                else if (array[i].Equals("PASS")) word.SubTag = "Passive Participle";
                else if (array[i].Equals("VN")) word.SubTag = "Verbal Noun";
                else if (array[i].Equals("IN")) word.SubTag = "Noun";
                else if (array[i].Equals("CN")) word.SubTag = "Noun";
                else if (array[i].Equals("IP")) word.SubTag = "Particle";
                else if (array[i].Equals("CP")) word.SubTag = "Particle";
                else if (array[i].StartsWith('(')) word.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else word.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(word.Form)) word.Form = "I";
            if (string.IsNullOrEmpty(word.Gender)) word.Gender = "";
        }
        else if (tag.Equals("V")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUBJ") ||
                    array[i].Equals("JUS") ||
                    array[i].Equals("JUSS") ||
                    array[i].Equals("SP:kaAn") ||
                    array[i].Equals("SP:kaAd") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("IMPF")) word.SubTag = "Imperfect";
                else if (array[i].Equals("PASS")) word.SubTag = "Passive";
                else if (array[i].Equals("IMPV")) word.SubTag = "Imperative";
                else if (array[i].Equals("PERF")) word.SubTag = "Perfect";
                else if (array[i].StartsWith('(')) word.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else word.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(word.Form)) word.Form = "I";
            if (string.IsNullOrEmpty(word.Gender)) word.Gender = "";
        }
    }
}

class POSForm {
    public string Tag { get; set; }
    public string[] Spellings { get; set; }
    public string Root { get; set; }
    public string Form { get; set; }
    public string Gender { get; set; }
    public string SubTag { get; set; }
    public bool IsSorted { get; set; }
    public List<string> References { get; set; }
    public POSForm() {
        References = new();
    }
}

class POSFormKey : Notifiable {
    public string Form { get; set; }
    public int NoOfTag { get; set; }
    public List<Tuple<string, int>> NoOfWord { get; set; }
    public Dictionary<string, List<POSForm>> Items { get; set; }
    public POSFormKey() {
        Items = new Dictionary<string, List<POSForm>>();

    }
}
