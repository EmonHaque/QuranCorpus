﻿class Translators : ActionButton {
    Grid grid;
    Toggle all;
    BiState[] states;
    TextBlockEnglish[] names;
    Popup pop;

    public Translators() : base() {
        all = new Toggle() {
            HorizontalAlignment = HorizontalAlignment.Right,
            OnIcon = Icons.Checked,
            OffIcon = Icons.CloseCircle,
            OnTip = "select all",
            OffTip = "deselect all",
            Command = () => {
                if (all.IsOn) {
                    for (int i = 0; i < states.Length; i++) {
                        states[i].IsTrue = false;
                    }
                }
                else {
                    for (int i = 0; i < states.Length; i++) {
                        states[i].IsTrue = true;
                    }
                }
            }
        };
        Grid.SetColumn(all, 1);
        grid = new Grid() {
            RowDefinitions = {
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition()
            },
            Children = { all }
        };
        states = new BiState[App.global.TranslationDictionary.Count];
        names = new TextBlockEnglish[App.global.TranslationDictionary.Count];

        for (int i = 0; i < App.global.TranslationDictionary.Count; i++) {
            grid.RowDefinitions.Add(new RowDefinition());
            var state = new BiState();
            var currentTranslator = App.global.TranslationDictionary.Keys.ElementAt(i);
            var name = new TextBlockEnglish() {
                Text = App.global.TranslationDictionary.Keys.ElementAt(i),
                Margin = new Thickness(10, 0, 0, 0)
            };
            Grid.SetColumn(name, 1);
            Grid.SetRow(state, i + 1);
            Grid.SetRow(name, i + 1);
            grid.Children.Add(state);
            grid.Children.Add(name);
            states[i] = state;
            names[i] = name;

            if (currentTranslator.Equals(App.global.Translation)) {
                state.IsTrue = true;
                Selected = new string[] { name.Text };
            }
        }

        grid.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));

        pop = new Popup() {
            AllowsTransparency = true,
            PlacementTarget = this,
            VerticalOffset = 5,
            HorizontalOffset = -(grid.DesiredSize.Width + Width),
            StaysOpen = false,
            Child = new Border() {
                BorderThickness = new Thickness(Constants.BottomLineThickness),
                Padding = new Thickness(10),
                CornerRadius = new CornerRadius(5),
                BorderBrush = Brushes.LightGray,
                Background = Constants.Background,
                Child = grid
            }
        };
        pop.Closed += onPopupClosed;

        Icon = Icons.PenTip;
        Command = () => pop.IsOpen = true;
        ToolTip = "Translations";
    }

    void onPopupClosed(object? sender, EventArgs e) {
        var names = new string[states.Length];
        int count = 0;
        for (int i = 0; i < states.Length; i++) {
            if (!states[i].IsTrue) continue;
            names[count] = this.names[i].Text;
            count++;
        }
        Array.Resize(ref names, count);

        count = 0;
        bool isSame = names.Length == Selected.Length;
        if (isSame) {
            foreach (var item in Selected) {
                if (!item.Equals(names[count])) {
                    isSame = false;
                }
            }
        }
        if (isSame) return;
        Selected = names;
    }

    public string[] Selected {
        get { return (string[])GetValue(SelectedProperty); }
        set { SetValue(SelectedProperty, value); }
    }

    public static readonly DependencyProperty SelectedProperty =
        DependencyProperty.Register("Selected", typeof(string[]), typeof(Translators), new PropertyMetadata(null));


}
