﻿class RootWordVM : Notifiable {
    List<GroupedLemma> groups;
    List<Lemma> source;
    CancellationTokenSource terminator;
    Task task;
    public int currentTranscript;

    object selected;
    public object Selected {
        get { return selected; }
        set {
            if (value is null) {
                selected = null;
                return;
            }
            if (value.Equals(selected)) return;

            selected = value;

            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).Pages.SelectedPage is LemmaPage page) {
                page.setContent(selected);
            }
        }
    }
    string query;
    public string Query {
        get { return query; }
        set {
            query = value is null ? "" : value;
            if (task != null && !task.IsCompleted) {
                // will it ever come here?
                // if it does what'll be the state of terminator in the next task?
                // will IsCancellationRequested be true
                terminator.Cancel();
            }
            filter(query);
        }
    }

    public string Covered { get; set; }
    public bool WasRightClicked { get; set; }
    public string Count { get; set; }
    public bool IsInProgress { get; set; }
    public List<LemmaHeader> Lemmas { get; set; }

    public RootWordVM() {
        IsInProgress = true;
        terminator = new CancellationTokenSource();

        var indexMa = ((App)Application.Current).indexMa.ToString();

        Task.Run(() => {
            int count = 0;
            source = new List<Lemma>();
            foreach (var link in App.links) {
                if (string.IsNullOrEmpty(link.Root)) continue;
                count++;
                var tags = link.Tags.Split('|');
                var indices = link.LemmaIndices.Split('|');
                var simple = link.LemmaSimple.Split('|');
                var corpus = link.LemmaCorpus.Split('|');
                // 20:94:2 - yabnaumma has multiple roots
                string root =
                    link.Root.Contains('|') ?
                    string.Join(" | ", link.Root.Split('|').Select(x => App.roots[Convert.ToInt32(x)])) :
                    App.roots[Convert.ToInt32(link.Root)];

                for (int i = 0; i < indices.Length; i++) {
                    if (simple[i].Equals(indexMa)) {
                        /*
                         * bi}osa|maA - root bAs
                         * baEod|maA - root bEd
                         * niEoma|maA - root nEm
                         * kul~amaA|maA - root kll
                         */
                        continue;
                    }
                    var pos = App.tags[Convert.ToInt32(tags[Convert.ToInt32(indices[i])])].Name;
                    var lemmas = new string[] {
                        App.lemmas[Convert.ToInt32(corpus[i])],
                        App.lemmas[Convert.ToInt32(simple[i])]
                    };
                    bool isFound = false;
                    foreach (var item in source) {
                        if (item.Transcripts[0].Equals(lemmas[0]) &&
                            item.Transcripts[1].Equals(lemmas[1]) &&
                            item.POS.Equals(pos) &&
                            item.Root[0].Equals(root)) {
                            isFound = true;
                            item.References.Add(link.Reference);
                            break;
                        }
                    }
                    if (!isFound) {
                        var references = new List<string>() { link.Reference };
                        source.Add(new Lemma() {
                            Transcripts = lemmas,
                            POS = pos,
                            Root = new string[] {root, ""},
                            References = references
                        });
                    }
                }
            }
            groups = source.GroupBy(x => x.Root[0])
            .Select(x => new GroupedLemma {
                Root = x.Key,
                Lemmas = x.GroupBy(x => x.Transcripts[App.global.Transcript]).ToList()
            }).ToList();

            filter("");

            currentTranscript = App.global.Transcript;

            App.Current.Dispatcher.Invoke(() => {
                Covered = count.ToString("N0") + " words covered";
                OnPropertyChanged(nameof(Covered));
            });
        });
    }

    public void Regroup() {
        groups = source.GroupBy(x => x.Root[0])
            .Select(x => new GroupedLemma {
                Root = x.Key,
                Lemmas = x.GroupBy(x => x.Transcripts[App.global.Transcript]).ToList()
            }).ToList();

        filter(query);
        currentTranscript = App.global.Transcript;
    }

    void filter(string query) {
        if (groups is null) return;

        IsInProgress = true;
        OnPropertyChanged(nameof(IsInProgress));

        task = Task.Run(() => {
            int rootCount = 0;
            int formCount = 0;

            var lemmas = new List<LemmaHeader>();

            foreach (var group in groups) {
                if (terminator.IsCancellationRequested) break;
                if (!group.Root.Contains(query)) continue;

                rootCount++;
                var header = new LemmaHeader() { Root = group.Root };
                header.Items = new List<Lemma>();
                foreach (var subGroup in group.Lemmas) {
                    if (terminator.IsCancellationRequested) break;

                    if (subGroup.Count() == 1) {
                        header.Items.Add(subGroup.First());
                        formCount++;
                        continue;
                    }
                    foreach (var item in subGroup) {
                        bool hasFound = false;
                        foreach (var x in header.Items) {
                            if (terminator.IsCancellationRequested) break;

                            if (x.Transcripts[App.global.Transcript].Equals(item.Transcripts[App.global.Transcript])) {
                                hasFound = true;
                                x.Items.Add(item);
                                break;
                            }
                        }
                        if (!hasFound) {
                            header.Items.Insert(0, item);
                            item.Items = new List<Lemma> {
                                new Lemma(item)
                            };
                            formCount++;
                        }
                    }
                }
                lemmas.Add(header);
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    Lemmas = lemmas;
                    Count = $"{formCount.ToString("N0")} lemma in {rootCount.ToString("N0")} root";
                    IsInProgress = false;
                    OnPropertyChanged(nameof(Count));
                    OnPropertyChanged(nameof(IsInProgress));
                    OnPropertyChanged(nameof(Lemmas));
                });
            }
            else {
                App.Current.Dispatcher.Invoke(() => {
                    IsInProgress = false;
                    OnPropertyChanged(nameof(IsInProgress));
                });
            }
        }, terminator.Token);
    }
}
