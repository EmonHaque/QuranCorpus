﻿class POS {
    public bool IsSorted { get; set; }
    public string[] Spellings { get; set; }
    public List<string> References { get; set; }

    public POS() {
        References = new();
    }

    public POS(POS rhs) {
        Spellings = new string[] { rhs.Spellings[0], rhs.Spellings[1] };
        References = new List<string>(rhs.References);
    }
}
