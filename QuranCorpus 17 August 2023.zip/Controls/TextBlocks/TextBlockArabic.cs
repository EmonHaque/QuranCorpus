﻿class TextBlockArabic : TextBlock {

    public TextBlockArabic() {
        FlowDirection = FlowDirection.RightToLeft;
        FontStyle = FontStyles.Normal;

        SetBinding(FontSizeProperty, new Binding() {
            Path = new PropertyPath(nameof(Global.ArabicFontSize)),
            Source = App.global
        });
        SetBinding(FontFamilyProperty, new Binding() {
            Path = new PropertyPath(nameof(Global.ArabicFontFamily)),
            Source = App.global
        });
    }
}
