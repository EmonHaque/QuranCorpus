﻿class RootMatrixView : CardView {
    public override string Icon => Icons.Matrix;

    TagCount tags1, tags2;
    TextBlockEnglish count;
    EditText query;
    ListBox list;
    PageControl pages;
    RootMatrixVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new RootMatrixVM();
        pages = ((App)Application.Current).Pages;
        DataContext = vm;
        initializeUI();
        bind();

        list.PreviewMouseRightButtonDown += onRightButtonDown;
        list.MouseRightButtonUp += onRightButtonUp;
        tags1.SelectionChanged += onTag1SelectionChanged;
        tags2.SelectionChanged += onTag2SelectionChanged;
    }

    void onTag1SelectionChanged(TagCount.TagItem o) {
        tags2.Visibility = o.Name.StartsWith('q') ? Visibility.Collapsed : Visibility.Visible;
        vm.resetSource(o, tags2.Selected);
    }

    void onTag2SelectionChanged(TagCount.TagItem o) {
        vm.resetSource(null, o);
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) {
        pages.addMatrixPage(vm.Selected, vm.roots);
        if (vm.WasRightClicked) {
            vm.WasRightClicked = false;
        }
    }

    void onRightButtonDown(object sender, MouseButtonEventArgs e) => vm.WasRightClicked = true;

    void initializeUI() {
        tags1 = new TagCount() {
            FlowDirection = FlowDirection.LeftToRight,
            Items = vm.tags1
        };
        tags2 = new TagCount() {
            FlowDirection = FlowDirection.LeftToRight,
            Items = vm.tags2
        };
        tags1.Selected = tags1.Items.First();
        tags2.Selected = tags2.Items.First();

        var tagPanel = new StackPanel() {
            Children = { tags1, tags2 }
        };

        query = new EditText() {
            Icon = Icons.Search,
            Hint = "Root (buckwalter)",
            IsTrimBottomRequested = true
        };
        count = new TextBlockEnglish() { 
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(10,0,0,5)
        };
        Grid.SetColumn(count, 1);
        var queryGrid = new Grid() {
            Margin = new Thickness(0,5,0,0),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { query, count }
        };

        list = new ListBox() {
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(RootBoxTemplate))
            }
        };

        Grid.SetRow(queryGrid, 1);
        Grid.SetRow(list, 2);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { tagPanel, queryGrid, list }
        };
        setContent(grid);
    }

    void bind() {
        count.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = list,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Items)));
        list.SetBinding(ListBox.SelectedItemProperty, new Binding() {
            Path = new PropertyPath(nameof(vm.Selected)),
            Mode = BindingMode.OneWayToSource
        });
        query.SetBinding(EditText.TextProperty, new Binding(nameof(vm.Query)) {
            Mode = BindingMode.OneWayToSource,
            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
        });
    }

    class RootBoxTemplate : Grid {
        TextBlockArabic arabic;
        TextBlockEnglish english;

        public RootBoxTemplate() {
            arabic = new TextBlockArabic();
            english = new TextBlockEnglish() {
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Center
            };

            SetColumn(arabic, 1);
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());

            Children.Add(arabic);
            Children.Add(english);
        }
        public override void EndInit() {
            base.EndInit();
            var root = DataContext.ToString();
            arabic.Text = root.toArabic();
            english.Text = root;
        }
    }
}
