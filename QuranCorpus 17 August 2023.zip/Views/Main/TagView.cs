﻿class TagView : CardView {
    public override string Icon => Icons.Tag;
    
    EditText query, tag;
    ActionButton add;
    ProgressBar progress;
    DropListBox dropBox;
    PageControl pages;
    TagVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new TagVM();
        DataContext = vm;
        pages = ((App)Application.Current).Pages;
        initializeUI();
        bind();
    }

    void initializeUI() {
        tag = new EditText() {
            Icon = Icons.Tag,
            Hint = "Name"
        };
        add = new ActionButton() {
            VerticalAlignment = VerticalAlignment.Center,
            Icon = Icons.Plus,
            Command = vm.addTag,
            ToolTip = "add a tag"
        };
        Grid.SetColumn(add, 1);
        var tagGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = GridLength.Auto }
            },
            Children = { tag, add }
        };
        query = new EditText() {
            Icon = Icons.Search,
            Hint = "Search",
            IsTrimBottomRequested = true
        };
        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };
        dropBox = new DropListBox(typeof(DragListBox)) {
            DropAction = vm.onDrop,
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(TagTemplate))
            }
        };
        Grid.SetRow(query, 1);
        Grid.SetRow(progress, 2);
        Grid.SetRow(dropBox, 3);
        var content = new Grid() { 
            RowDefinitions = {
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { tagGrid, query, progress, dropBox }
        };
        setContent(content);

        dropBox.PreviewMouseRightButtonDown += onRightButtonDown;
        dropBox.MouseRightButtonUp += onRightButtonUp;
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) {
        if (vm.SelectedTag is null) return;
        if (vm.SelectedTag.Count == 0) return;
        pages.addTagPage(vm.SelectedTag);
    }

    void onRightButtonDown(object sender, MouseButtonEventArgs e) => vm.WasRightClicked = true;

    void bind() {
        tag.SetBinding(EditText.ErrorProperty, new Binding(nameof(vm.Error)));
        tag.SetBinding(EditText.TextProperty, new Binding(nameof(vm.TagName)));
        query.SetBinding(EditText.TextProperty, new Binding(nameof(vm.Query)) {
            Mode = BindingMode.OneWayToSource,
            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
        });
        progress.SetBinding(ProgressBar.IsIndeterminateProperty, new Binding(nameof(vm.IsInProgress)));
        dropBox.SetBinding(DropListBox.ItemsSourceProperty, new Binding(nameof(vm.Tags)));
        dropBox.SetBinding(DropListBox.SelectedItemProperty, new Binding(nameof(vm.SelectedTag)) { Mode = BindingMode.OneWayToSource });
    }
}
