﻿class TabView : CardView {
    public TabView() {

    }
    public override void OnFirstSight() {
        base.OnFirstSight();
        initializeUI();
    }

    void initializeUI() {
        setContent(((App)Application.Current).Pages);
    }
}
