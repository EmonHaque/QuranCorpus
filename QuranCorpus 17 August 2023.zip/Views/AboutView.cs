﻿class AboutView : CardView {
    public override string Icon => Icons.InfoCircle;

    public override void OnFirstSight() {
        base.OnFirstSight();
        initializeUI();
    }

    void initializeUI() {
        var externalBorder = new Border() {
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
            BorderBrush = Brushes.LightGray,
            Child = new TextBlockEnglish() {
                Text = "External resources",
                FontWeight = FontWeights.Bold
            }
        };
        
        var corpusLink = new Hyperlink() {
            NavigateUri = new Uri("http://corpus.quran.com"),
            TextDecorations = null,
            Inlines = {
                new Run("The Quranic Arabic Corpus"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };
        var corpusBlock = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
               new Run("Transcriptions, word segmentations, roots, lemmas and gramatical tags have been taken from the \"Quranic Arabic Corpus (Version 0.4)\". Visit "),
               corpusLink,
               new Run(" for more information. Transliterations, word by word translations, morphological explanations, buckwalter character maps have also been parsed from their site. All their data can be found in the Resource/Corpus folder in ninr plain text files and an additional indexing \"link.txt\" file has been added there. Each of those nine files contains unique list and in the \"link.txt\" indices of those lists are stored. Some lemmas end with the character '2' in their Version 0.4 text file and that ending character '2' has been removed.")
            }
        };

        var tanzilLink = new Hyperlink() {
            NavigateUri = new Uri("https://tanzil.net"),
            TextDecorations = null,
            Inlines = {
                new Run("Tanzil"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };
        var tanzilBlock = new TextBlockEnglish() {
            Margin = new Thickness(0, 10, 0, 0),
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
                new Run("English translations (1) Saheeh International, (2) A. J. Arberry, (3) Mohammed Marmaduke William Pickthall, (4) Muhammad Sarwar, (5) Mohammad Habib Shakir and (6) Abdullah Yusuf Ali have been taken from "),
                tanzilLink,
                new Run(". All their plain text files are in Resource/Tanzil folder.")
            }
        };

        var arabicFontLink = new Hyperlink() {
            NavigateUri = new Uri("https://arabicfonts.net/"),
            TextDecorations = null,
            Inlines = {
                new Run("Arabic Fonts"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };
        var arabicFontBlock = new TextBlockEnglish() {
            Margin = new Thickness(0, 10, 0, 0),
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
                new Run("Some or all Arabic fonts (1) Al Qalam Quran Majeed Web Regular, (2) Amiri Quran Regular, (3) Scheherazade Regular, (4) KFGQPC Uthman Taha Naskh Regular (5) KFGQPC Uthmanic Script HAFS Regular and (6) me quran have been taken from "),
                arabicFontLink,
                new Run(".")
            }
        };

        var materialDesignLink = new Hyperlink() {
            NavigateUri = new Uri("https://materialdesignicons.com/"),
            TextDecorations = null,
            Inlines = {
                new Run("Material Design"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };
        var materialDesignBlock = new TextBlockEnglish() {
            Margin = new Thickness(0, 10, 0, 0),
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
                new Run("All svg icons have been taken from "),
                materialDesignLink,
                new Run(" and are embedded in the application.")
            }
        };

        var microsoftBlock = new TextBlockEnglish() {
            Margin = new Thickness(0, 10, 0, 0),
            Text = "It's a .net 7 WPF application built with Visual Studio 2022 Community Edition on Windows 11."
        };

        var usageBorder = new Border() {
            Margin = new Thickness(0, 10, 0, 0),
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
            BorderBrush = Brushes.LightGray,
            Child = new TextBlockEnglish() {
                Text = "Usage",
                FontWeight = FontWeights.Bold
            }
        };
        var usageBlock = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
                new Run("In the Home Page, there're two panels, left panel is for pages and the right one is to show nine views. In between those panels, there're nine icons to change view on the right panel. First one, selected by default, is Surah View. When you right click a Surah, a page is added in the left panel and when you left click a Surah, Surah page will be updated if it is focused or selected."),
                new LineBreak(),
                new LineBreak(),
                new Run("Second view is Word view and it's three subviews. By default, words/sentences that's root are shown in the first sub view  and you can change these sub views by clicking the three icons in the bottom. When you right click on a branch or leaf of the tree, a page will be added in the left panel and when you left click, page will be updated if it's a lemma page and selected. The second sub view is for words without root and grouped by lemma and the third sub view is for words which don't have either. Same left/right click functionalities are available for these subviews. There're 77,429 words in \"Quranic Arabic Corpus\" and all words of the Quran are covered in these three sub views."),
                new LineBreak(),
                new LineBreak(),
                new Run("There're 1,642 distinct roots in \"Quranic Arabic Corpus\" and there's one word that's 2 roots. I've listed that, 20:94:2 - yabnaumma, separately with '|' so altogether 1643 roots are shown. There're 4,648 unique Root-Lemma pairs in \"Quranic Arabic Corpus\" and the one, with 2 roots, have 2 more reference so altogether number of lemma's become 4,650 in the first sub view. There're 175 distinct lemmas for words which don't have root of which 2 ends with character 2, \"maE2\" and \"<i*aA2\", that '2' has been removed, altogether 173 lemmas are shown in the second sub view. There're 152 words that don't have root or lemma. These numbers will vary if you switch to simple transcript in global settings."),
                new LineBreak(),
                new LineBreak(),
                new Run("There are few words which have been spelled out in the same way but segmented differently and in the third view, those words have been listed. Same left right click functionality is available to open or update a Segment Page. In the bottom of the segment page, word reference and probable meanings have been listed. To get into the context, double click the reference/meaning in the list, it'll take you to that ayah of surah."),
                new LineBreak(),
                new LineBreak(),
                new Run("The fourth one is Tag View. You can give a name and create Tag, eg. Musa tag for listing all verses related to Musa. You can select one or more verses from Surah or flat list of Lemma pages only and drag selected Ayah(s) on top of your tag and drop to get those added in your tag. Similar left/right clicking functionalities are there to open and update Tag page. You can reorder verses by dragging and dropping verses in Tag page and can remove by right clicking on verse. Tags are created in a separate Tag folder in the Resource folder of the application. To save your tags, store that folder somewhere else before updating code or application."),
                new LineBreak(),
                new LineBreak(),
                 new Run("The fifth view is for inna, kada, kana and their sisters. You can right click on a list item in those three sub views to open a match page. The sixth view groups words and particles by Tag. The seventh view groups words which have root in form I through XII. Word that doesn't have a form has been grouped into I. The eighth view presents words with same root in a matrix, highlights duplicate spellings and if you double click a word in the matrix, it'll take you to MorphPage and if you double click on meaning in MorphPage, it'll take you to the surah. Same left and right click fucntionality is available to add or update POSPage, FormPage and MatrixPage. Last view is global settings for font, font size, translations and script. Corpus transcript is the unmodified script in the \"Quranic Arabic Corpus\" and the Simple, uthmanic-simple, has been taken from tanzil.net. Tanzil has 4 more words than corpus, see 2:181 ba'da ma, 8:6 ba'da ma, 13:37 ba'da ma and 37:130 il yas. These 4 words have been combined to match the corpus segmentation and some diacritics have ben added for removed, eg. damma from hamza in ulaika has been removed, a kesra has been added when words end with alif maksura but pronounced as ya."),
                new LineBreak(),
                new LineBreak(),
                new Run("By hovering over a word in Surah or Tag page you can see relevant information, parsed from the \"Quranic Arabic Corpus\". When you double click a word, a Match page with matching words will be added in the left panel. You can group those matching verses by Tag/Parts of Speech, Spelling variation and Surah. On the top right corner it'll display the mode of searching. First it searches by root, if there's no root it goes with lemma and if neither exist, it goes with the literal. Probable meaning of the word, parsed from \"Quranic Arabic Corpus\", is displayed on third column from the left and when you hover over the arabic, a tooltip will pop up to display the translation, selected in settings view. When you doble click a verse - it will take you to that Surah to read in context."),
                new LineBreak(),
                new LineBreak(),
                new Run("In Surah or Tag page, there's a Pentip icon for selecting more than one translation for that page. In Surah view, there're two search icons, one for searching locally, ie. in that surah, and the other for finding in entire Quran. If you click the global search, a search page will be added in the left panel. Only arabic search is supported and spelling has to be exactly like what's rendered. To copy a word you can hold down left control button on keyboard and left mouse click to select a word. If you want to select multiple words - select a word first, hold down left control and left shift keys of keyboard together and left mouse click on another word in the same ayah - it'll select all words in between, right mouse click and click \"copy word(s)\" in the context menu. If you've only one ayah selected and some word(s) in that ayah are also selected,  right click will let you copy words. If you've multiple ayahs selected - it'll let you copy all selected ayahs. To copy a single ayah - make sure no word is selected in that ayah. To deselect word(s), hold down left control button of keyboard and left mouse click on any selected word - it'll clear selection. There's a go to box in Surah page where you can enter an ayah number and hit enter to bring that ayah of that surah into view or you can enter a surah no and ayah no, separated by colon, to go there."),
                new LineBreak(),
                new LineBreak(),
                new Run("I haven't tested the application thoroughly so there could be some anomalies. There're two global exception handler - one to trap UI exceptions and the other for trapping exceptions in Tasks. You can add, edit code for your own research and education. If you face any issue in understanding code, contact me at emon-haque@hotmail.com for help.")
            }
        };

        Grid.SetRow(corpusBlock, 1);
        Grid.SetRow(tanzilBlock, 2);
        Grid.SetRow(arabicFontBlock, 3);
        Grid.SetRow(materialDesignBlock, 4);
        Grid.SetRow(microsoftBlock, 5);
        Grid.SetRow(usageBorder, 6);
        Grid.SetRow(usageBlock, 7);
        var scroll = new ScrollViewer() {
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Content = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto }
                },
                Children = {
                    externalBorder,
                    corpusBlock,
                    tanzilBlock,
                    arabicFontBlock,
                    microsoftBlock,
                    materialDesignBlock,
                    usageBorder,
                    usageBlock
                }
            }
        };
        setContent(scroll);

        corpusLink.RequestNavigate += onWebRequested;
        tanzilLink.RequestNavigate += onWebRequested;
        arabicFontLink.RequestNavigate += onWebRequested;
        materialDesignLink.RequestNavigate += onWebRequested;
    }

    void onWebRequested(object sender, RequestNavigateEventArgs e) {
        Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri) { UseShellExecute = true });
    }
}
