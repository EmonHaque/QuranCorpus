﻿class SegmentsView : CardView {
    public override string Icon => Icons.Segments;
    public override bool OverridesToolTip => true;
    public override UIElement Tip => getTip();

    Run count;
    ProgressBar progress;
    ListBox segmentsList;
    SegmentsVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new SegmentsVM();
        DataContext = vm;
        initializeUI();
        bind();
    }

    void initializeUI() {
        count = new Run();
        var text = new TextBlockEnglish() {
            HorizontalAlignment = HorizontalAlignment.Right,
            Inlines = {
                count,
                new Run(" words differ in segmentation")
            }
        };
        progress = new ProgressBar() {
            Height = Constants.ProgressBarHeight,
            FlowDirection = FlowDirection.RightToLeft
        };
        segmentsList = new ListBox() {
            FlowDirection = FlowDirection.RightToLeft,
            Margin = new Thickness(5, 5, 0, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(SegmentTemplate))
            }
        };
        segmentsList.PreviewMouseRightButtonDown += onRightButtonDown;
        segmentsList.MouseRightButtonUp += onRightButtonUp;

        Grid.SetRow(text, 1);
        Grid.SetRow(segmentsList, 2);
        var content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, text, segmentsList }
        };
        setContent(content);
    }

    void bind() {
        progress.SetBinding(ProgressBar.IsIndeterminateProperty, new Binding(nameof(vm.IsInProgress)));
        count.SetBinding(Run.TextProperty, new Binding() { 
            Path = new PropertyPath("Items.Count"),
            Source = segmentsList,
            Mode = BindingMode.OneWay
        });
        segmentsList.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.Selected)) {
            Mode = BindingMode.OneWayToSource
        });
        segmentsList.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Segments)));
        
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) {
        if (vm.Selected is null) return;
        ((App)Application.Current).FocusedControl.addSegmentPage(vm.Selected);
        if (vm.WasRightClicked) vm.WasRightClicked = false;
    }

    void onRightButtonDown(object sender, MouseButtonEventArgs e) => vm.WasRightClicked = true;

    Grid getTip() {
        var header = new TextBlockEnglish() {
            Text = "Segment difference",
            FontWeight = FontWeights.Bold
        };
        var separator = new Rectangle() {
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var description = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Text = "See words which have been segmented differently."
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(description, 2);
        return new Grid() {
            MaxWidth = 200,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(10) },
                new RowDefinition()
            },
            Children = { header, separator, description }
        };
    }
}
