﻿class OthersView : CardView {
    public override string Header => "Others";

    OthersVM vm;
    TextBlockEnglish count;
    ProgressBar progress;
    ListBox list;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new OthersVM();
        DataContext = vm;
        initializeUI();
        bind();
        list.PreviewMouseRightButtonDown += onRightButtonDown;
        list.MouseRightButtonUp += onRightButtonUp;
        IsVisibleChanged += onVisibilityChange;
    }

    void initializeUI() {
        progress = new ProgressBar() {
            Height = 1.5,
            FlowDirection = FlowDirection.RightToLeft
        };
        list = new ListBox() {
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = {
                            new Setter(GroupItem.TemplateProperty, new VerbAndOthersGroupTemplate())
                        }
                    }
                }
            },
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(NumberTemplate))
            }
        };
        list.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        list.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
        list.SetValue(ScrollViewer.CanContentScrollProperty, false);
        Grid.SetRow(list, 1);

        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { progress, list }
        };
        setContent(grid);

        count = new TextBlockEnglish();
        addActions(new UIElement[] { count });
    }

    void bind() {
        progress.SetBinding(ProgressBar.IsIndeterminateProperty, new Binding(nameof(vm.IsInProgress)));
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Items)));
        list.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.Selected)) { Mode = BindingMode.OneWayToSource });
        count.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = list,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
    }

    void onRightButtonDown(object sender, MouseButtonEventArgs e) => vm.WasRightClicked = true;

    void onRightButtonUp(object sender, MouseButtonEventArgs e) {
        e.Handled = true;
        if (vm.Selected is null) return;
        ((App)Application.Current).FocusedControl.addNotVerbPage(vm.filtered);
        if (vm.WasRightClicked) vm.WasRightClicked = false;
    }

    void onVisibilityChange(object sender, DependencyPropertyChangedEventArgs e) {
        if (!IsVisible) return;
        if (vm.currentTranscript == App.global.Transcript) return;
        vm.Regroup();
    }

    class NumberTemplate : Grid {
        TextBlockEnglish name, count;
        public NumberTemplate() {
            name = new TextBlockEnglish();
            count = new TextBlockEnglish();
            SetColumn(count, 1);
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

            Children.Add(name);
            Children.Add(count);

            name.SetBinding(TextBlockEnglish.TextProperty, new Binding(nameof(NotVerbGroup.Number)));
            count.SetBinding(TextBlockEnglish.TextProperty, new Binding(nameof(NotVerbGroup.Count)) { StringFormat = "N0" });
        }
    }
}
