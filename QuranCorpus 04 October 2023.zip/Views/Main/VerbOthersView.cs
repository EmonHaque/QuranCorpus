﻿class VerbOthersView : View {
    public override string Icon => Icons.AlphaV;
    public override bool OverridesToolTip => true;
    public override UIElement Tip => getTip();
    public override FrameworkElement container => grid;

    Grid grid;

    public VerbOthersView() {
        grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(){ Height = new GridLength(1.5, GridUnitType.Star)}
            }
        };
        AddVisualChild(grid);
    }

    public override void OnFirstSight() {
        base.OnFirstSight();
        var verbs = new VerbView();
        var others = new OthersView();

        Grid.SetRow(others, 1);
        grid.Children.Add(verbs);
        grid.Children.Add(others);

        verbs.OnFirstSight();
        others.OnFirstSight();
    }

    Grid getTip() {
        var header = new TextBlockEnglish() {
            Text = "Verb and Others",
            FontWeight = FontWeights.Bold
        };
        var separator = new Rectangle() {
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var description = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Text = "See verbs and other words with root."
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(description, 2);
        return new Grid() {
            MaxWidth = 200,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(10) },
                new RowDefinition()
            },
            Children = { header, separator, description }
        };
    }
}

