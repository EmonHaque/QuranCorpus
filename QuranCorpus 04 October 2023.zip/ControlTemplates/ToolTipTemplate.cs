﻿public class ToolTipTemplate : ControlTemplate
{
    public ToolTipTemplate() {
        TargetType = typeof(ToolTip);
        var border = new FrameworkElementFactory(typeof(Border));
        var content = new FrameworkElementFactory(typeof(ContentPresenter));
       
        border.SetValue(Border.CornerRadiusProperty, new CornerRadius(3));
        border.SetValue(Border.PaddingProperty, new Thickness(5));
        border.SetValue(Border.BorderThicknessProperty, new Thickness(Constants.BottomLineThickness));
        border.SetValue(Border.BorderBrushProperty, Brushes.LightGray);
        border.SetValue(Border.BackgroundProperty, Constants.Background);
        border.SetValue(TextElement.ForegroundProperty, Brushes.LightGray);
        border.AppendChild(content);

        VisualTree = border;
    }
}
