﻿class Lemma {
    public string POS { get; set; }
    public string[] Root { get; set; }
    public string[] Transcripts { get; set; }
    public List<string> References { get; set; }
    public List<Lemma> Items { get; set; }

    public Lemma() { }
    public Lemma(Lemma other) {
        POS = other.POS;
        Root = new string[] { other.Root[0], other.Root[1] };
        Transcripts = new string[] { other.Transcripts[0], other.Transcripts[1] };
        References = new List<string>(other.References);
        
    }
}
