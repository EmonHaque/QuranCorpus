﻿class Form {
    public string Root { get; set; }
    public string Detail { get; set; }
    public string[] Spellings { get; set; }
    public string Tag { get; set; }
}
