﻿public class Link {
    public string Reference { get; set; }
    public string SegmentsCorpus { get; set; }
    public string SegmentsSimple { get; set; }
    public string Tags { get; set; }
    public string Details { get; set; }
    public string LemmaCorpus { get; set; }
    public string LemmaSimple { get; set; }
    public string LemmaIndices { get; set; }
    public string Transliteration { get; set; }
    public string Meaning { get; set; }
    public string Explanation { get; set; }
    public string Root { get; set; }
    public string SpellingGroupCorpus { get; set; }
    public string SpellingGroupSimple { get; set; }
    public string RootIndex { get; set; }
}
