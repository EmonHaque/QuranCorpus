﻿class MorphListTemplate : Grid {
    TextBlockArabic arabic;
    TextBlockEnglish explanation, count;

    public MorphListTemplate() {
        arabic = new TextBlockArabic();
        explanation = new TextBlockEnglish() {
            Margin = new Thickness(10, 0, 10, 0),
            FlowDirection = FlowDirection.LeftToRight,
            TextWrapping = TextWrapping.Wrap,
            VerticalAlignment = VerticalAlignment.Center
        };
        count = new TextBlockEnglish() {
            Foreground = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Right
        };

        SetColumn(explanation, 1);
        SetColumn(count, 2);

        ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col1" });
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col3" });

        Children.Add(arabic);
        Children.Add(explanation);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var c = (Morph)DataContext;
        StringBuilder builder = new();
        explanation.Text = c.Explanation;
        count.Text = c.Count.ToString();

        var segments = c.Segments[App.global.Transcript].Split('|');
        int index = 0;
        int pronCount, otherCount;
        pronCount = otherCount = 0;
        string lastPos = "";
        foreach (var segment in segments) {
            segment.toArabic(segments, builder);
            var run = new Run(builder.ToString());
            builder.Clear();

            var tag = App.tags[Convert.ToInt32(c.Tags[index])].Name;
            switch (tag) {
                case "DET": run.Foreground = Foregrounds.DET_Brush; break;
                case "V": run.Foreground = Foregrounds.V_Brush; break;
                case "N":
                case "PN":
                case "ADJ": run.Foreground = Foregrounds.N_PN_ADJ_Brush; break;
                case "REL":
                case "DEM": run.Foreground = Foregrounds.DEM_REL_Brush; break;
                case "P": run.Foreground = Foregrounds.P_Brush; break;
                case "CONJ": run.Foreground = Foregrounds.CONJ_Brush; break;
                case "INTG": run.Foreground = Foregrounds.INTG_Brush; break;
                case "NEG": run.Foreground = Foregrounds.NEG_Brush; break;
                case "PRON":
                    if (lastPos.Equals("PRON")) pronCount++;
                    if (pronCount == 1) run.Foreground = Foregrounds.PRON1_Brush;
                    else if (pronCount == 2) run.Foreground = Foregrounds.PRON2_Brush;
                    else run.Foreground = Foregrounds.PRON3_Brush;
                    break;
                default:
                    if (!Foregrounds.Defined.Contains(lastPos)) otherCount++;
                    if (otherCount == 1) run.Foreground = Foregrounds.OTHER1_Brush;
                    else if (otherCount == 2) run.Foreground = Foregrounds.OTHER2_Brush;
                    else run.Foreground = Foregrounds.OTHER3_Brush;
                    break;
            }
            lastPos = tag;
            arabic.Inlines.Add(run);
            index++;
        }
    }
}
