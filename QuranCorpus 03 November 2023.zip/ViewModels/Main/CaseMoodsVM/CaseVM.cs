﻿class CaseVM : Notifiable {
    public int currentTranscript;
    List<ErabWordPrimary> words;
    List<ErabWord> source;
    string[] tagArray = { "N", "PN", "ADJ" };

    public List<ErabWord> items;
    Tuple<string, int> selected;
    public Tuple<string, int> Selected {
        get { return selected; }
        set {
            if (value is null) {
                return;
            }
            if (value.Equals(selected)) return;

            selected = value;
            items = source.Where(x => x.Gender.Equals(value.Item1)).ToList();

            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }

            if (((App)Application.Current).FocusedControl.SelectedPage is CasePage page) {
                page.setContent(items);
            }
        }
    }
    public bool WasRightClicked { get; set; }
    public bool IsInProgress { get; set; }
    public List<Tuple<string, int>> Genders { get; set; }

    public CaseVM() {
        IsInProgress = true;
        Task.Run(() => {
            words = new List<ErabWordPrimary>();
            for (int i = 0; i < App.links.Count; i++) {
                var t = App.links[i].Tags.Split('|').Select(x => App.tags[Convert.ToInt32(x)].Name).ToArray();
                bool hasIt = false;
                bool hasDet = false;
                int index = 0;
                for (int j = 0; j < t.Length; j++) {
                    if (t[j].Equals("DET")) hasDet = true;

                    if (!tagArray.Contains(t[j])) continue;
                    hasIt = true;
                    index = j;
                    break;
                }
                if (!hasIt) continue;

                var corpus = App.links[i].SegmentsCorpus.Split('|');
                var simple = App.links[i].SegmentsSimple.Split('|');

                if (App.links[i].Root.Contains('|')) {
                    var roots = App.links[i].Root.Split('|');
                    foreach (var root in roots) {
                        var w = new ErabWordPrimary() {
                            Reference = App.links[i].Reference,
                            Spellings = new string[] {
                                App.spellings[Convert.ToInt32(App.links[i].SpellingGroupCorpus.Split('|')[index])],
                                App.spellings[Convert.ToInt32(App.links[i].SpellingGroupSimple.Split('|')[index])]
                            },
                            Segments = new string[] {
                                App.segments[Convert.ToInt32(corpus[index])],
                                App.segments[Convert.ToInt32(simple[index])]
                            },
                            Root = App.roots[Convert.ToInt32(root)],
                            HasDet = hasDet
                        };
                        setDetail(App.links[i].Details.Split(',')[index], w);
                        words.Add(w);
                        index++;
                    }
                }
                else {
                    var w = new ErabWordPrimary() {
                        Reference = App.links[i].Reference,
                        Spellings = new string[] {
                            App.spellings[Convert.ToInt32(App.links[i].SpellingGroupCorpus.Split('|')[index])],
                            App.spellings[Convert.ToInt32(App.links[i].SpellingGroupSimple.Split('|')[index])]
                        },
                        Segments = new string[] {
                            App.segments[Convert.ToInt32(corpus[index])],
                            App.segments[Convert.ToInt32(simple[index])]
                        },
                        Root = string.IsNullOrEmpty(App.links[i].Root) ? "" : App.roots[Convert.ToInt32(App.links[i].Root)],
                        HasDet = hasDet
                    };
                    setDetail(App.links[i].Details.Split(',')[index], w);
                    words.Add(w);
                }
            }
            Regroup();
        });
    }

    public void Regroup() {
        if (!IsInProgress) {
            IsInProgress = true;
            Genders = null;
            OnPropertyChanged(nameof(IsInProgress));
            OnPropertyChanged(nameof(Genders));
        }
        Task.Run(() => {
            var x = words
                .GroupBy(x => x.Root)
                .Select(x => new { x.Key, Value = x.GroupBy(x => x.Spellings[App.global.Transcript]).ToList() })
                .Select(x => new {
                    x.Key,
                    Value = x.Value.GroupBy(x => x.GroupBy(x => new { x.Gender, x.Erab }).ToList()).ToList()
                })
                .ToList();

            source = new List<ErabWord>();
            foreach (var root in x) {
                foreach (var spelling in root.Value) {
                    foreach (var item in spelling.Key) {
                        if (item.Key.Erab.Equals("Genitive")) {
                            foreach (var word in item) {
                                var match = source.Where(
                                    x => x.Gender.Equals(word.Gender) &&
                                    x.Root.Equals(word.Root) &&
                                    x.Spelling.Equals(word.Spellings[App.global.Transcript])).ToList();

                                if (match.Count == 0) {
                                    var w = new ErabWord() {
                                        Root = word.Root,
                                        Gender = word.Gender,
                                        Spelling = word.Spellings[App.global.Transcript]
                                    };
                                    w.References.Add(word.Reference);
                                    source.Add(w);
                                    if (word.HasDet) w.DGenitive = word.Segments[App.global.Transcript];
                                    else w.IGenitive = word.Segments[App.global.Transcript];
                                }
                                else {
                                    ErabWord w = null;
                                    bool hasIt = false;
                                    if (word.HasDet) {
                                        for (int i = 0; i < match.Count; i++) {
                                            if (string.IsNullOrEmpty(match[i].DGenitive)) {
                                                hasIt = true;
                                                match[i].DGenitive = word.Segments[App.global.Transcript];
                                                w = match[i];
                                                break;
                                            }
                                            if (!word.Segments[App.global.Transcript].Equals(match[i].DGenitive)) continue;
                                            hasIt = true;
                                            w = match[i];
                                            break;
                                        }
                                    }
                                    else {
                                        for (int i = 0; i < match.Count; i++) {
                                            if (string.IsNullOrEmpty(match[i].IGenitive)) {
                                                hasIt = true;
                                                match[i].IGenitive = word.Segments[App.global.Transcript];
                                                w = match[i];
                                                break;
                                            }
                                            if (!word.Segments[App.global.Transcript].Equals(match[i].IGenitive)) continue;
                                            hasIt = true;
                                            w = match[i];
                                            break;
                                        }
                                    }
                                    if (!hasIt) {
                                        w = new ErabWord() {
                                            Root = word.Root,
                                            Gender = word.Gender,
                                            Spelling = word.Spellings[App.global.Transcript]
                                        };
                                        if (word.HasDet) w.DGenitive = word.Segments[App.global.Transcript];
                                        else w.IGenitive = word.Segments[App.global.Transcript];
                                        w.References.Add(word.Reference);
                                        source.Add(w);
                                    }
                                    else w.References.Add(word.Reference);
                                }
                            }
                        }
                        else if (item.Key.Erab.Equals("Nominative")) {
                            foreach (var word in item) {
                                var match = source.Where(
                                    x => x.Gender.Equals(word.Gender) &&
                                    x.Root.Equals(word.Root) &&
                                    x.Spelling.Equals(word.Spellings[App.global.Transcript])).ToList();

                                if (match.Count == 0) {
                                    var w = new ErabWord() {
                                        Root = word.Root,
                                        Gender = word.Gender,
                                        Spelling = word.Spellings[App.global.Transcript]
                                    };
                                    w.References.Add(word.Reference);
                                    source.Add(w);
                                    if (word.HasDet) w.DNominative = word.Segments[App.global.Transcript];
                                    else w.INominative = word.Segments[App.global.Transcript];
                                }
                                else {
                                    ErabWord w = null;
                                    bool hasIt = false;
                                    if (word.HasDet) {
                                        for (int i = 0; i < match.Count; i++) {
                                            if (string.IsNullOrEmpty(match[i].DNominative)) {
                                                hasIt = true;
                                                match[i].DNominative = word.Segments[App.global.Transcript];
                                                w = match[i];
                                                break;
                                            }
                                            if (!word.Segments[App.global.Transcript].Equals(match[i].DNominative)) continue;
                                            hasIt = true;
                                            w = match[i];
                                            break;
                                        }
                                    }
                                    else {
                                        for (int i = 0; i < match.Count; i++) {
                                            if (string.IsNullOrEmpty(match[i].INominative)) {
                                                hasIt = true;
                                                match[i].INominative = word.Segments[App.global.Transcript];
                                                w = match[i];
                                                break;
                                            }
                                            if (!word.Segments[App.global.Transcript].Equals(match[i].INominative)) continue;
                                            hasIt = true;
                                            w = match[i];
                                            break;
                                        }

                                    }
                                    if (!hasIt) {
                                        w = new ErabWord() {
                                            Root = word.Root,
                                            Gender = word.Gender,
                                            Spelling = word.Spellings[App.global.Transcript]
                                        };
                                        if (word.HasDet) w.DNominative = word.Segments[App.global.Transcript];
                                        else w.INominative = word.Segments[App.global.Transcript];
                                        w.References.Add(word.Reference);
                                        source.Add(w);
                                    }
                                    else w.References.Add(word.Reference);
                                }
                            }
                        }
                        else {
                            foreach (var word in item) {
                                var match = source.Where(
                                     x => x.Gender.Equals(word.Gender) &&
                                     x.Root.Equals(word.Root) &&
                                     x.Spelling.Equals(word.Spellings[App.global.Transcript])).ToList();

                                if (match.Count == 0) {
                                    var w = new ErabWord() {
                                        Root = word.Root,
                                        Gender = word.Gender,
                                        Spelling = word.Spellings[App.global.Transcript]
                                    };
                                    w.References.Add(word.Reference);
                                    source.Add(w);
                                    if (word.HasDet) w.DAccusative = word.Segments[App.global.Transcript];
                                    else w.IAccusative = word.Segments[App.global.Transcript];
                                }
                                else {
                                    ErabWord w = null;
                                    bool hasIt = false;
                                    if (word.HasDet) {
                                        for (int i = 0; i < match.Count; i++) {
                                            if (string.IsNullOrEmpty(match[i].DAccusative)) {
                                                hasIt = true;
                                                match[i].DAccusative = word.Segments[App.global.Transcript];
                                                w = match[i];
                                                break;
                                            }
                                            if (!word.Segments[App.global.Transcript].Equals(match[i].DAccusative)) continue;
                                            hasIt = true;
                                            w = match[i];
                                            break;
                                        }
                                    }
                                    else {
                                        for (int i = 0; i < match.Count; i++) {
                                            if (string.IsNullOrEmpty(match[i].IAccusative)) {
                                                hasIt = true;
                                                match[i].IAccusative = word.Segments[App.global.Transcript];
                                                w = match[i];
                                                break;
                                            }
                                            if (!word.Segments[App.global.Transcript].Equals(match[i].IAccusative)) continue;
                                            hasIt = true;
                                            w = match[i];
                                            break;
                                        }
                                    }
                                    if (!hasIt) {
                                        w = new ErabWord() {
                                            Root = word.Root,
                                            Gender = word.Gender,
                                            Spelling = word.Spellings[App.global.Transcript]
                                        };
                                        if (word.HasDet) w.DAccusative = word.Segments[App.global.Transcript];
                                        else w.IAccusative = word.Segments[App.global.Transcript];
                                        source.Add(w);
                                    }
                                    w.References.Add(word.Reference);
                                }
                            }
                        }
                    }
                }
            }

            currentTranscript = App.global.Transcript;
            IsInProgress = false;
            Genders =
                source.GroupBy(x => x.Gender)
                .Select(x => new Tuple<string, int>(x.Key, x.Count()))
                .ToList();

            App.Current.Dispatcher.Invoke(() => {
                OnPropertyChanged(nameof(Genders));
                OnPropertyChanged(nameof(IsInProgress));
            });
        });
    }

    void setDetail(string detail, ErabWordPrimary word) {
        if (string.IsNullOrEmpty(detail)) {
            word.Gender = "Undefined";
            word.Erab = "";
            return;
        }
        var array = detail.Split('|').Select(x => App.details[Convert.ToInt32(x)]).ToArray();

        for (int i = 0; i < array.Length; i++) {
            if (string.IsNullOrEmpty(array[i].Name)) continue;
            if (array[i].Name.Equals("ACT") ||
                array[i].Name.Equals("PASS") ||
                array[i].Name.Equals("VN") ||
                array[i].Name.Equals("IN") ||
                array[i].Name.Equals("CN") ||
                array[i].Name.Equals("IP") ||
                array[i].Name.Equals("CP") ||
                array[i].Name.StartsWith("(") ||
                array[i].Name.Equals("PCPL") ||
                array[i].Name.Equals("INDEF")) continue;

            if (array[i].Name.Equals("ACC")) word.Erab = "Accusative";
            else if (array[i].Name.Equals("GEN")) word.Erab = "Genitive";
            else if (array[i].Name.Equals("NOM")) word.Erab = "Nominative";
            else word.Gender = Helper.getGender(array[i].Name).Name;
        }

        if (string.IsNullOrEmpty(word.Gender)) word.Gender = "Undefined";
    }
}
