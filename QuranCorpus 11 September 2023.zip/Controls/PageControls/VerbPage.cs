﻿class VerbPage : Page {
    string selectedForm;
    string indexMa;
    StringBuilder builder = new();
    List<Verb> source, simpleSource, currentSource;
    List<IGrouping<string, Verb>> tenseGroups, formGroups;

    CancellationTokenSource terminator;
    Grid content;
    ProgressBar progress;
    TagCount tenses, forms;
    ListBox list;
    Run morphCount, morphTotal;
    TextBlockEnglish meaningCount;
    ListBox morphList, listMeaning;

    Verb selected;
    public Verb Selected {
        get { return selected; }
        set { selected = value; listMorph(); }
    }

    public override PageType Type => PageType.Verb;
    public override UIElement Content => content;

    public VerbPage() {
        indexMa = "|" + ((App)Application.Current).indexMa;
        terminator = new CancellationTokenSource();
        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };
        tenses = new TagCount() {
            Margin = new Thickness(0, 0, 0, 5),
            FlowDirection = FlowDirection.LeftToRight
        };
        forms = new TagCount() {
            Margin = new Thickness(0, 0, 0, 5),
            FlowDirection = FlowDirection.LeftToRight
        };
        var toggle = new Toggle() {
            VerticalAlignment = VerticalAlignment.Top,
            Margin = new Thickness(5, 5, 0, 0),
            OnIcon = Icons.DoorClose,
            OffIcon = Icons.DoorOpen,
            OnTip = "hide left panel",
            OffTip = "show left panel",
            Command = () => {
                var col = content.ColumnDefinitions[1];
                col.Width = col.Width.Value == 0 ? new GridLength(1, GridUnitType.Star) : new GridLength(0);
            }
        };
        Grid.SetColumn(toggle, 1);
        Grid.SetColumnSpan(forms, 2);
        Grid.SetRow(forms, 1);
        var tagStack = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { toggle, tenses, forms }
        };

        list = new ListBox() {
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(ListTemplate))
            }
        };
        list.SetValue(Grid.IsSharedSizeScopeProperty, true);
        list.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        list.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
        list.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(Selected)) { Source = this });

        var morphView = getRightGrid();

        Grid.SetColumnSpan(progress, 2);
        Grid.SetRowSpan(morphView, 2);
        Grid.SetColumn(morphView, 1);
        Grid.SetRow(morphView, 1);
        Grid.SetRow(tagStack, 1);
        Grid.SetRow(list, 2);
        content = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(),
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, tagStack, list, morphView }
        };

        tenses.SelectionChanged += onTenseSelectionChanged;
        forms.SelectionChanged += onFormSelectionChanged;
        morphList.SelectionChanged += onMorphSelectionChanged;
        listMeaning.MouseDoubleClick += onMeaningDoubleClick;
        App.global.PropertyChanged += onTranscriptChanged;
    }

    Grid getRightGrid() {
        morphCount = new Run();
        morphTotal = new Run();
        var morphCountBlock = new TextBlockEnglish() {
            IsHitTestVisible = false,
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center,
            Inlines = { morphTotal, new Run(" in "), morphCount }
        };
        meaningCount = new TextBlockEnglish() {
            IsHitTestVisible = false,
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Left
        };

        morphList = new ListBox() {
            Margin = new Thickness(0, 5, 0, 0),
            FlowDirection = FlowDirection.RightToLeft,
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MorphListTemplate))
            },
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()),
                        }
                    }
                }}
        };
        var separatorHorizontal = new Rectangle() {
            VerticalAlignment = VerticalAlignment.Bottom,
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };

        var separatorVertical = new Rectangle() {
            Margin = new Thickness(5, 0, 5, 0),
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        var splitter = new GridSplitter() {
            ResizeDirection = GridResizeDirection.Rows,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Template = new SplitterTemplate()
        };

        morphList.SetValue(Grid.IsSharedSizeScopeProperty, true);
        morphList.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        morphList.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        listMeaning = new ListBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 0, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MeaningListTemplate))
            }
        };
        listMeaning.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMeaning.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        listMeaning.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        Grid.SetRow(morphList, 1);
        Grid.SetRow(meaningCount, 2);
        Grid.SetRow(separatorHorizontal, 2);
        Grid.SetRow(splitter, 2);
        Grid.SetRow(listMeaning, 3);

        Grid.SetColumn(morphCountBlock, 1);
        Grid.SetColumn(morphList, 1);
        Grid.SetColumn(meaningCount, 1);
        Grid.SetColumn(separatorHorizontal, 1);
        Grid.SetColumn(splitter, 1);
        Grid.SetColumn(listMeaning, 1);

        Grid.SetRowSpan(separatorVertical, 4);

        morphCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = morphList,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        meaningCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMeaning,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });

        return new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition()
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(2, GridUnitType.Star) },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { morphCountBlock , morphList, separatorHorizontal, splitter, meaningCount, listMeaning, separatorVertical }
        };
    }

    public VerbPage(List<Verb> source) : this() => setTags(source);

    public void setContent(List<Verb> source) => setTags(source);

    void setTags(List<Verb> source) {
        this.source = source;
        string header = "";
        var first = source.First();
        switch (first.Person) {
            case "First": header = "1"; break;
            case "Second": header = "2"; break;
            case "Third": header = "3"; break;
        }
        switch (first.Gender) {
            case "Masculine": header += "M"; break;
            case "Feminine": header += "F"; break;
        }
        switch (first.Number) {
            case "Singular": header += "S"; break;
            case "Dual": header += "D"; break;
            case "Plural": header += "P"; break;
        }
        HeaderText = header;
        progress.IsIndeterminate = true;

        Task.Run(() => {
            selectedForm = null;
            if (App.global.Transcript == 1) {
                simpleSource = new List<Verb>();
                for (int i = 0; i < source.Count; i++) {
                    if (terminator.IsCancellationRequested) break;

                    var match = simpleSource.FirstOrDefault(x => string.Join("", x.Simple).Equals(string.Join("", source[i].Simple)));
                    if (match is null) simpleSource.Add(new Verb(source[i]));
                    else match.References.AddRange(source[i].References);
                }
                currentSource = simpleSource;
            }
            else currentSource = source;

            if (!terminator.IsCancellationRequested) {
                tenseGroups = currentSource.GroupBy(x => x.Tense).ToList();
                App.Current.Dispatcher.Invoke(() => {
                    tenses.Items = tenseGroups.Select(x => new TagCount.TagItem() { Name = x.Key, Count = x.Count() }).ToList();
                    tenses.Selected = tenses.Items.First();
                    onTenseSelectionChanged(tenses.Selected);
                    progress.IsIndeterminate = false;
                });
            }

        }, terminator.Token);
    }

    void onTenseSelectionChanged(TagCount.TagItem item) {
        formGroups = tenseGroups
            .First(x => x.Key.Equals(item.Name))
            .GroupBy(x => x.Form).ToList();
        forms.Items = formGroups
            .OrderBy(x => x.Key, new RomanComparator())
            .Select(x => new TagCount.TagItem() {
                Name = x.Key,
                Count = x.Count()
            })
            .ToList();
        forms.Selected = selectedForm is null ? forms.Items.First() : forms.Items.First(x => x.Name.Equals(selectedForm));
        onFormSelectionChanged(forms.Selected);
    }

    void onFormSelectionChanged(TagCount.TagItem item) {
        if (App.global.Transcript == 0) {
            list.ItemsSource = formGroups.First(x => x.Key.Equals(item.Name)).OrderBy(x => x.Root).ToList();
        }
        else {
            var filtered = formGroups.First(x => x.Key.Equals(item.Name)).ToList();
            List<Verb> items = new();
            for (int i = 0; i < filtered.Count; i++) {
                var match = items.FirstOrDefault(x => x.Simple.Equals(filtered[i].Simple));
                if (match is null) items.Add(filtered[i]);
                else match.References.AddRange(filtered[i].References);
            }
            list.ItemsSource = items.OrderBy(x => x.Root);
        }
    }

    void onTranscriptChanged(object? sender, PropertyChangedEventArgs e) {
        if (!e.PropertyName.Equals(nameof(App.global.Transcript))) return;

        var selectedTense = tenses.Selected.Name;
        selectedForm = forms.Selected.Name;

        if (App.global.Transcript == 0) currentSource = source;
        else {
            if (simpleSource is null) {
                simpleSource = new List<Verb>();
                for (int i = 0; i < source.Count; i++) {
                    if (terminator.IsCancellationRequested) break;

                    var match = simpleSource.FirstOrDefault(x => string.Join("", x.Simple).Equals(string.Join("", source[i].Simple)));
                    if (match is null) {
                        simpleSource.Add(new Verb(source[i]));
                    }
                    else match.References.AddRange(source[i].References);
                }
            }
            currentSource = simpleSource;
        }
        tenseGroups = currentSource.GroupBy(x => x.Tense).ToList();
        tenses.Items = tenseGroups.Select(x => new TagCount.TagItem() { Name = x.Key, Count = x.Count() }).ToList();
        tenses.Selected = tenses.Items.First(x => x.Name.Equals(selectedTense));
        onTenseSelectionChanged(tenses.Selected);

        selectedForm = null;
    }

    void listMorph() {
        if (selected is null) {
            return;
        }
        progress.IsIndeterminate = true;
        Task.Run(() => {
            var morphs = new List<Morph>();

            var iterator = App.links.GetEnumerator();
            iterator.MoveNext();

            if (!selected.IsSorted) {
                selected.References.Sort(new SurahAyahWordNoComparator());
                selected.IsSorted = true;
            }


            for (int i = 0; i < selected.References.Count; i++) {
                if (terminator.IsCancellationRequested) break;
                while (!iterator.Current.Reference.Equals(selected.References[i])) iterator.MoveNext();
                morphs.Add(getMorph(iterator.Current));
            }

            iterator.Dispose();

            var listSource = morphs.GroupBy(x => new { Word = x.Segments[1], x.Explanation })
              .Select(x => new Morph() {
                  Segments = x.First().Segments,
                  Count = x.Count(),
                  Tags = x.First().Tags,
                  Explanation = x.Key.Explanation,
                  References = x.SelectMany(x => x.References).ToList()
              })
              .OrderByDescending(x => x.Count)
              .ToList();

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    morphList.ItemsSource = listSource;
                    morphTotal.Text = listSource.Sum(x => x.Count).ToString();
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);

    }

    void onMorphSelectionChanged(object sender, SelectionChangedEventArgs e) {
        if (morphList.SelectedItem is null) {
            listMeaning.ItemsSource = null;
            return;
        }
        listMeaning.ItemsSource = ((Morph)morphList.SelectedItem).References;
    }

    void onMeaningDoubleClick(object sender, MouseButtonEventArgs e) {
        if (listMeaning.SelectedItem is null) return; // can be null?
        var item = (Tuple<string, string, string>)listMeaning.SelectedItem;
        ((App)Application.Current).FocusedControl.addSurahPage(item.Item1);
    }

    Morph getMorph(Link item) {
        string tag = "";
        string[] tags;
        string details = "";

        details = item.Details.Split(',')[Convert.ToInt32(item.RootIndex)];
        details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
        int lIndex;
        if (item.LemmaSimple.EndsWith(indexMa)) {
            // in 8 cases it ends with maA
            lIndex = 0;
        }
        else lIndex = Convert.ToInt32(item.LemmaIndices);

        tags = item.Tags.Split('|');
        tag = App.tags[Convert.ToInt32(tags[lIndex])].Name;


        Morph t = new() {
            Tag = tag,
            Tags = tags,
            Segments = Helper.getSegments(item),
            Spellings = getSpellings(item)
        };
        builder.Clear();
        item.explain(builder);

        t.Explanation = builder.ToString();
        t.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));

        var array = details.Split('|');

        for (int i = 0; i < array.Length; i++) {
            if (array[i].Equals("SUBJ") ||
                array[i].Equals("JUS") ||
                array[i].Equals("JUSS") ||
                array[i].Equals("SP:kaAn") ||
                array[i].Equals("SP:kaAd") ||
                array[i].Equals("INDEF")) continue;

            if (array[i].Equals("IMPF")) t.SubTag = "Imperfect";
            else if (array[i].Equals("PASS")) t.SubTag = "Passive";
            else if (array[i].Equals("IMPV")) t.SubTag = "Imperative";
            else if (array[i].Equals("PERF")) t.SubTag = "Perfect";
            else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
            else t.Gender = Helper.getGender(array[i]).Name;
        }
        if (string.IsNullOrEmpty(t.Form)) t.Form = "I";


        return t;

        string[] getSpellings(Link item) {
            int lIndex;
            if (item.LemmaSimple.EndsWith(indexMa)) {
                // in 8 cases it ends with maA
                lIndex = 0;
            }
            else {
                if (string.IsNullOrEmpty(item.LemmaIndices)) {
                    return new string[] {
                    item.SpellingGroupCorpus,
                    item.SpellingGroupSimple
                };
                }

                lIndex = Convert.ToInt32(item.LemmaIndices);
            }
            return new string[] {
                item.SpellingGroupCorpus.Split('|')[lIndex],
                item.SpellingGroupSimple.Split('|')[lIndex]
            };
        }
    }

    protected override void unload() {
        tenses.SelectionChanged -= onTenseSelectionChanged;
        forms.SelectionChanged -= onFormSelectionChanged;
        App.global.PropertyChanged -= onTranscriptChanged;
        morphList.SelectionChanged -= onMorphSelectionChanged;
        listMeaning.MouseDoubleClick -= onMeaningDoubleClick;
        terminator.Cancel();
        terminator.Dispose();
        base.unload();
    }

    class ListTemplate : Grid {
        TextBlockArabic verb, root;
        TextBlockEnglish count;
        StackPanel iconStack;

        public ListTemplate() {
            verb = new TextBlockArabic();
            root = new TextBlockArabic() { Foreground = Brushes.Gray };
            iconStack = new StackPanel() {
                Orientation = Orientation.Horizontal,
                Margin = new Thickness(5, 0, 5, 0),
                FlowDirection = FlowDirection.LeftToRight,
                VerticalAlignment = VerticalAlignment.Center,
            };
            count = new TextBlockEnglish() { VerticalAlignment = VerticalAlignment.Center };

            SetColumn(root, 1);
            SetColumn(iconStack, 2);
            SetColumn(count, 3);

            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col3" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col4" });

            Children.Add(verb);
            Children.Add(root);
            Children.Add(iconStack);
            Children.Add(count);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Verb)DataContext;
            if (c.Simple.Length > 1) {
                if (App.global.Transcript == 0) {
                    verb.Inlines.Add(c.Corpus[0].toArabic());
                    verb.Inlines.Add(new Run(c.Corpus[1].toArabic()) { Foreground = Brushes.Coral });
                }
                else {
                    verb.Inlines.Add(c.Simple[0].toArabic());
                    verb.Inlines.Add(new Run(c.Simple[1].toArabic()) { Foreground = Brushes.Coral });
                }
            }
            else verb.Text = App.global.Transcript == 0 ? c.Corpus[0].toArabic() : c.Simple[0].toArabic();

            if (!string.IsNullOrEmpty(c.Mood)) {
                var icon = c.Mood switch {
                    "Indicative" => Helper.getIcon(Icons.ArrowLeft, Brushes.Gray),
                    "Subjunctive" => Helper.getIcon(Icons.ArrowTopLeft, Brushes.Gray),
                    "Jussive" => Helper.getIcon(Icons.CircleOutline, Brushes.Gray),
                };
                icon.ToolTip = c.Mood;
                icon.Margin = new Thickness(2.5, 0, 2.5, 0);
                iconStack.Children.Add(icon);
            }
            if (!string.IsNullOrEmpty(c.Voice)) {
                var icon = Helper.getIcon(Icons.ArrowURightTop, Brushes.Gray);
                icon.ToolTip = c.Voice;
                icon.Margin = new Thickness(2.5, 0, 2.5, 0);
                iconStack.Children.Add(icon);
            }

            root.Text = c.Root.toArabic();
            count.Text = c.References.Count.ToString("N0");
        }
    }

    class RomanComparator : Comparer<string> {
        public override int Compare(string? x, string? y) {
            return getRomanInt(x) - getRomanInt(y);
        }
        int getRomanInt(string x) {
            return x switch {
                "I" => 0,
                "II" => 1,
                "III" => 2,
                "IV" => 3,
                "V" => 4,
                "VI" => 5,
                "VII" => 6,
                "VIII" => 7,
                "IX" => 8,
                "X" => 9,
                "XI" => 10,
                "XII" => 11
            };
        }
    }
}
