﻿
class AboutView : CardView {
    public override string Icon => Icons.InfoCircle;
    public override UIElement Tip => new TextBlockEnglish() {
        Text = "About",
        Foreground = Constants.Foreground
    };

    public override void OnFirstSight() {
        base.OnFirstSight();

        #region Hyperlinks
        var corpusLink = new Hyperlink() {
            NavigateUri = new Uri("http://corpus.quran.com"),
            Inlines = { new Run("The Quranic Arabic Corpus") }
        };
        var mustafaLink = new Hyperlink() {
            NavigateUri = new Uri("https://github.com/mustafa0x/quran-morphology"),
            Inlines = { new Run("GitHub") }
        };
        var tanzilLink = new Hyperlink() {
            NavigateUri = new Uri("https://tanzil.net"),
            Inlines = { new Run("Tanzil") }
        };
        var hablullahLink = new Hyperlink() {
            NavigateUri = new Uri("https://github.com/hablullah/data-quran"),
            Inlines = { new Run("GitHub") }
        };
        var quranComLink = new Hyperlink() {
            NavigateUri = new Uri("https://quran.com/1:1/tafsirs/en-tafisr-ibn-kathir"),
            Inlines = { new Run("Quran.com") }
        };
        var kfgqpcLink = new Hyperlink() {
            NavigateUri = new Uri("https://qurancomplex.gov.sa/en/"),
            Inlines = { new Run("KFGQPC") }
        };

        var hadithsLink = new Hyperlink() {
            NavigateUri = new Uri("https://github.com/ShathaTm/LK-Hadith-Corpus"),
            Inlines = { new Run("GitHub") }
        };
        var arabicFontLink = new Hyperlink() {
            NavigateUri = new Uri("https://arabicfonts.net/"),
            Inlines = { new Run("Arabic Fonts") }
        };
        var materialDesignLink = new Hyperlink() {
            NavigateUri = new Uri("https://materialdesignicons.com/"),
            Inlines = { new Run("Material Design") }
        };
        var appRepoLink = new Hyperlink() {
            NavigateUri = new Uri("https://github.com/EmonHaque/QuranCorpus"),
            Inlines = { new Run("GitHub") }
        };
        #endregion

        var box = new RichEnglishTextBox() {
            IsDocumentEnabled = true,
            Resources = {
                {
                    typeof(Hyperlink), new Style() {
                        Setters = {
                            new Setter(Hyperlink.TextDecorationsProperty, null),
                            new Setter(Hyperlink.ForegroundProperty, Brushes.SkyBlue),
                            new Setter(Hyperlink.FontWeightProperty, FontWeights.Bold),
                            new EventSetter(Hyperlink.RequestNavigateEvent, new RequestNavigateEventHandler((s, e) => Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri) { UseShellExecute = true })))
                        }
                    }
                } }
        };

        var blocks = box.Document.Blocks;

        blocks.Add(new Paragraph() {
            Margin = new Thickness(0, 0, 0, 5),
            Foreground = Brushes.Gray,
            FontWeight = FontWeights.Black,
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
            BorderBrush = Constants.Foreground,
            Inlines = { new Run("External resource") }
        });
        blocks.Add(new Paragraph() {
            Margin = new Thickness(0),
            Inlines = {
                new Run("Transcriptions, word segmentations, roots, lemmas and gramatical tags have been taken from the \"Quranic Arabic Corpus (Version 0.4)\". Visit "),
                corpusLink,
                new Run(" for more information. Transliterations, word by word translations, morphological explanations, buckwalter character maps have also been parsed from their site. All their data can be found in the Resources/Corpus folder in nine plain text files and an additional indexing \"link.txt\" file has been added there. Each of those nine files contains unique list and in the \"link.txt\" indices of those lists are stored. Some lemmas end with the character '2' in their Version 0.4 text file and that ending character '2' has been removed.")
            }
        });
        blocks.Add(new Paragraph(new Floater(getNewRootTable())));
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("Mustafa has done some work on \"Quranic Arabic Corpus (Version 0.4)\", segmented some words further and added some roots. You can see his work on "),
                mustafaLink,
                new Run(". Some of the roots he added has been incorporated and a few more I've added, you can see those in the table on the right. To see all the references, copy reference from First occurence column and paste that in go to box in"),
                new Run(" SurahPage"){ Foreground = Brushes.SkyBlue },
                new Run(", hit enter and double click the word or you can copy the \"newRoots.txt\" in Resource folder and paste it somewhere to see all the reference. Some of the roots I've added could be wrong. For example - harut, marut, talut, jalut, tabut, yakut could be tagut pattern where the root is T-g-y or these could be kafur pattern where the root is k-f-r.")
            }
        });
        blocks.Add(new Paragraph(new Run("The word nahnu in 2:102:31 has been classified as dual instead of plural and na in 18:38:2 has been removed so 18:38:1 has become lakinna instead of lakin plus na. ba'damA in 2:181, 8:6 and 13:37 has been split into two words. 15:7:1-2 (law + ma), 27:20:4-5 (ma + liya) and 36:22:1-2 (wama + liya) have been merged. Pronoun alif in 2:186:11 has been removed and merged into daEa and faillam in 11:14:1 has become fa + in + lam. In total 8,965 new segments have been added:")));
        blocks.Add(new List() {
            MarkerStyle = TextMarkerStyle.Circle,
            ListItems = {
                new ListItem(new Paragraph(new Run("572 'ta', at the end of third person feminine singular perfect and perfect passive verbs, has been separated and classified as subject pronoun, go to Pronoun View and right click 3FS to see those."))),
                new ListItem(new Paragraph(new Run("7,965 can be seen under SUFF tag in POS View. With simple script you'll see 25 suffix listed on the left and each of those, except the long _ta and _Y (alif maksura), has one explanation. _ta and _Y have two explanation. To see the explanation select a leaf word in the middle. These explanation could be wrong."))),
                new ListItem(new Paragraph(new Run("342 can be seen under BRID tag in POS View, each of those 3 phonetic bridges has one explanation and these could be wrong. For example - the ya in kibriyah probably is not a phonetic bridge, it probably has been used to make it noun or adjective. ahlihim and ahliyhim sound same but one has ya and the other doesn't."))),
                new ListItem(new Paragraph(new Run("70 can be seen under root 'ywm'. iz from yawmaiz and yawmiiz has been separated and yawm has been classified as noun, genitive when it's yawmi-iz and accusative when it's yawma-iz. You can see those under root 'ywm' in Words View."))),
                new ListItem(new Paragraph(new Run("1 can be seen under root 'Hyn'. iz from hinaiz has been separated."))),
                new ListItem(new Paragraph(new Run("14 can be seen under root 'kll'. maA from kullama has been separated."))),
                new ListItem(new Paragraph(new Run("1 can be seen under root 'nEm'. maA from niyimma has been separated.")))
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("To see one of the words with longest segments in the popup, enter 5:44:14 in the go to box of "),
                new Run("SurahPage"){ Foreground = Brushes.SkyBlue },
                new Run(" and hover over the word. Corpus transcripts has been modified and the modified version is almost identical to KFGQPC Version 2.2 Uthmanic Hafs script. The following characters have been replaced:")
            }
        });
        blocks.Add(new List() {
            MarkerStyle = TextMarkerStyle.Circle,
            ListItems = {
                new ListItem(new Paragraph(new Run("\u0657 0657 (inverted damma) with 064B (fathatan)"))),
                new ListItem(new Paragraph(new Run("\u065E 065E (fatha with two dots) with 064C (dammatan), and"))),
                new ListItem(new Paragraph(new Run("\u0656 0656 (subscript alif) with 064D (kasratan)")))
            }
        });
        blocks.Add(new Paragraph(new Run("KFGQPC Uthmanic Hafs v2.2 font has special mechanism to convert those characters into another set of fathatan, dammatan and kasratan. The following characters have been ignored:")));
        blocks.Add(new List() {
            MarkerStyle = TextMarkerStyle.Circle,
            ListItems = {
                new ListItem(new Paragraph(new Run("\u00A0 00A0 (no-break space)"))),
                new ListItem(new Paragraph(new Run("\u06DB 06DB (small high three dots)"))),
                new ListItem(new Paragraph(new Run("\u06D6 06D6 (small high ligature sad with lam with alef maksura)"))),
                new ListItem(new Paragraph(new Run("\u06D7 06D7 (small high ligature qaf with lam with alef maksura)"))),
                new ListItem(new Paragraph(new Run("\u06DA 06DA (small high jeem)"))),
                new ListItem(new Paragraph(new Run("\u06DE 06DE (start of rub el hizb)"))),
                new ListItem(new Paragraph(new Run("\u06D8 06D8 (small high meem initial form)"))),
                new ListItem(new Paragraph(new Run("\u06E4 06E4 (small high madda), and"))),
                new ListItem(new Paragraph(new Run("\u06E9 06E9 (place of sajdah)")))
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("other than those you get KFGQPC Version 2.2 Uthmanic Hafs script when you select KFGQPC transcript in"),
                new Run(" Settings view."){Foreground = Brushes.SkyBlue},
                new Run(" The primary difference between \"Quranic Arabic Corpus (Version 0.4)\" and KFGQPC Version 2.2 Uthmanic Hafs is alif maksura in place of ya. For example - there's no preposition 'fi' with alif maksura in KFGQPC Version 2.2 Uthmanic Hafs.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("There're 16 english translations available in "),
                tanzilLink,
                new Run(" as of 03 September 2023. All their plain text files are in Resources/Tanzil folder.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("Tafsir ibn kathir has been downloaded from "),
                hablullahLink,
                new Run(" and it, probably, downloads data from "),
                quranComLink,
                new Run(". Surah 105, Al-Feel, doesn't have separate tafsir, it displayed tafsir of Surah 104, Al-Humazah in Quran.com on 04 September 2023. Verses 7-8 of Surah 60, Al-Mumtahanah, and verses 17-28 of Surah 68, Al-Qalam, don't have english. The en-ibn-kathir-qurancom.md file has been renamed to .txt, fews lins at the beginning has been removed and modified file is in Resources/Tafsir folder.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("All eight recitations/readings have been downloaded from "),
                kfgqpcLink,
                new Run(" website. Under the Fonts menu there's a sub menu for \"The ten modes of Qur'anic reading\" and there's eight digitized version available as of 23 November 2023. Each reading comes in a MS Word Document along with a font and the word documents have been parsed with \"DocumentFormat.OpenXml 2.20\" nuget package. Bazzi, Hafs, Qunbul and Shuba includes bismillah as a separate verse of Surah Al Fatiha so it's there as a separate verse in .txt files in \"Resources/KFGQPC/Recitations\" folder. Bismillah has been removed from all other surah. Surah number, name and verse counts are in \"Resources/KFGQPC/Surah\" folder and all of their fonts are in \"Resources/KFGQPC/Fonts\" folder.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("All hadiths have been taken from "),
                hadithsLink,
                new Run(". There's an important note on these hadiths in their GitHub page, read that. According to their GitHub page, these csv files contains 39,038 hadith. I've used TextFieldParser of Microsoft.VisualBasic.FileIO to parse all those csv files and according to my count, there're 33,959 hadith with one hadith number, 123 hadith with 2 numbers, 5 hadith with 3 numbers and 1 hadith with 4 numbers so in total there're 34,224 hadith numbers in 34,088 hadith. Hadith with multiple hadith numbers have been found only in bukhari.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("Some or all Arabic fonts (1) Al Qalam Quran Majeed Web Regular, (2) Amiri Quran Regular, (3) Scheherazade Regular, (4) KFGQPC Uthman Taha Naskh Regular (5) KFGQPC Uthmanic Script HAFS Regular (6) me quran, (7) Lateef and (8) Droid Naskh have been taken from "),
                arabicFontLink,
                new Run(".")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("All svg icons have been taken from "),
                materialDesignLink,
                new Run(" and are embedded in the application.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("It's a .net 8 WPF application built with Visual Studio 2022 Community Edition on Windows 11. Visit "),
                appRepoLink,
                new Run(" to download the project.")
            }
        });
        setContent(new ScrollViewer() {
            Template = new ScrollViewerTemplate(),
            Content = box
        });
    }

    Table getNewRootTable() {
        var table = new Table() {
            BorderBrush = Constants.Foreground,
            TextAlignment = TextAlignment.Center,
            CellSpacing = 0,
            Columns = {
                new TableColumn() { Width = new GridLength(75) },
                new TableColumn() { Width = new GridLength(100) },
                new TableColumn() { Width = new GridLength(100) },
                new TableColumn() { Width = new GridLength(100) },
                new TableColumn() { Width = new GridLength(75) },
                new TableColumn() { Width = new GridLength(150) }
            }
        };
        var headerFooterStyle = new Style() {
            Setters = {
                new Setter(TableCell.PaddingProperty, new Thickness(0, 2.5, 0, 2.5)),
                new Setter(TableCell.FontWeightProperty, FontWeights.SemiBold),
                new Setter(TableCell.BorderThicknessProperty, new Thickness(0, Constants.BottomLineThickness, 0, Constants.BottomLineThickness)),
                new Setter(TableCell.BorderBrushProperty, Constants.Foreground)
            }
        };
        var rows = new TableRowGroup() {
            Rows = {
                new TableRow() {
                    Background = Constants.BackgroundDark,
                    Cells = {
                        new TableCell(new Paragraph(new Run("Sl."))),
                        new TableCell(new Paragraph(new Run("Occurence"))),
                        new TableCell(new Paragraph(new Run("Lemma"))),
                        new TableCell(new Paragraph(new Run("Root"))),
                        new TableCell(new Paragraph(new Run("Tag"))),
                        new TableCell(new Paragraph(new Run("First occurence")))
                    },
                    Resources = { { typeof(TableCell), headerFooterStyle } }
                }
            }
        };

        var arFontFamilyBinding = new Binding(nameof(App.global.ArabicFontFamily)) { Source = App.global };
        var arFontSizeBinding = new Binding(nameof(App.global.ArabicFontSize)) { Source = App.global };
        var enFontSizeBinding = new Binding(nameof(App.global.EnglishFontSize)) { Source = App.global };
        var cellPaddingConverter = new CellPaddingConverter();

        var newRoots = System.IO.File.ReadAllLines("Resources/newRoots.txt").ToList();
        int totalOccurences = 0;
        for (int i = 0; i < newRoots.Count; i++) {
            var cols = newRoots[i].Split('\t');
            var reference =
                cols[4].Contains(',') ?
                cols[4].Substring(0, cols[4].IndexOf(',')) :
                cols[4];
            int occurences = Convert.ToInt32(cols[0]);
            totalOccurences += occurences;

            var slCell = new TableCell(new Paragraph(new Run((i + 1).ToString())));
            var countCell = new TableCell(new Paragraph(new Run(occurences.ToString("N0"))));
            var tagCell = new TableCell(new Paragraph(new Run(cols[3])));
            var refCell = new TableCell(new Paragraph(new Run(reference)));

            // you cannot center align TableCell content vertically, so
            // multibind dependencies, measure and add pad
            var root = cols[2].toRoot();
            var binding = new MultiBinding() {
                Bindings = { arFontFamilyBinding, arFontSizeBinding, enFontSizeBinding },
                Converter = cellPaddingConverter,
                ConverterParameter = root
            };

            slCell.SetBinding(TableCell.PaddingProperty, binding);
            countCell.SetBinding(TableCell.PaddingProperty, binding);
            tagCell.SetBinding(TableCell.PaddingProperty, binding);
            refCell.SetBinding(TableCell.PaddingProperty, binding);

            rows.Rows.Add(new TableRow() {
                Background = i % 2 == 0 ? null : Constants.BackgroundDark,
                Cells = {
                    slCell,
                    countCell,
                    new TableCell(new Paragraph(new ArabicRun(cols[1].toArabic()))),
                    new TableCell(new Paragraph(new ArabicRun(root))),
                    tagCell,
                    refCell
                }
            });
        }
        rows.Rows.Add(new TableRow() {
            Background = Constants.BackgroundDark,
            Cells = {
                new TableCell(new Paragraph(new Run("Total"))),
                new TableCell(new Paragraph(new Run(totalOccurences.ToString("N0")))),
                new TableCell(){ ColumnSpan = 4 }
            },
            Resources = { { typeof(TableCell), headerFooterStyle } }
        });
        table.RowGroups.Add(rows);
        return table;
    }

    class ArabicRun : Run {
        public ArabicRun(string content) {
            Text = content;
            FlowDirection = FlowDirection.RightToLeft;
            FontStyle = FontStyles.Normal;

            SetBinding(FontSizeProperty, new Binding() {
                Path = new PropertyPath(nameof(Global.ArabicFontSize)),
                Source = App.global
            });
            SetBinding(FontFamilyProperty, new Binding() {
                Path = new PropertyPath(nameof(Global.ArabicFontFamily)),
                Source = App.global
            });
        }
    }

    class CellPaddingConverter : IMultiValueConverter {
        TextBlockArabic ar = new();
        TextBlockEnglish en = new();

        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture) {
            ar.Text = parameter.ToString();
            en.Text = "X";
            ar.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
            en.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));
            return new Thickness(0, (ar.DesiredSize.Height - en.DesiredSize.Height) / 2, 0, 0);
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture) {
            throw new NotImplementedException();
        }
    }
}
