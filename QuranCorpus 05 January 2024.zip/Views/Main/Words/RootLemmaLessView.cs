﻿class RootLemmaLessView : CardView {
    public override string Icon => Icons.SeedOff;
    public override bool OverridesToolTip => true;
    public override FrameworkElement Tip => getTip();

    WaterBox query;
    BuckwalterPopup buckwalterPop;
    Run count;
    TextBlockEnglish coveredBlock;
    PageListBox list;
    Toggle sort;
    RootLemmaLessVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new RootLemmaLessVM();
        DataContext = vm;
        initializeUI();
        bind();
        IsVisibleChanged += onVisibilityChange;
        query.KeyUp += onQuery;
    }

    void onVisibilityChange(object sender, DependencyPropertyChangedEventArgs e) {
        if (!IsVisible) return;
        if (vm.currentTranscript == App.global.Transcript) return;
        vm.Regroup();
    }

    void onQuery(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        vm.Filter(query.Text.Trim());
    }

    void initializeUI() {
        coveredBlock = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            TextAlignment = TextAlignment.Right
        };
        query = new WaterBox() {
            Margin = new Thickness(0, 0, 5, 0),
            Icon = Icons.Search,
            Hint = "buckwalter"
        };
        buckwalterPop = new BuckwalterPopup();
        sort = new Toggle() {
            Margin = new Thickness(5, 0, 0, 0),
            OnIcon = Icons.NumberDescending,
            OffIcon = Icons.NumberAscending,
            OnTip = "descending",
            OffTip = "ascending",
            Command = () => vm.Sort()
        };

        Grid.SetColumn(buckwalterPop, 1);
        Grid.SetColumn(sort, 2);

        var queryGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { query, buckwalterPop, sort }
        };
        count = new Run();
        var countBlock = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            TextAlignment = TextAlignment.Right,
            Inlines = {
                count,
                new Run(" words without root or lemma")
            }
        };
        list = new PageListBox() {
            Context = vm,
            FlowDirection = FlowDirection.RightToLeft,
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(RLFreeTemplate))
            }
        };

        Grid.SetRow(queryGrid, 1);
        Grid.SetRow(countBlock, 2);
        Grid.SetRow(list, 3);
        var content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { coveredBlock, queryGrid, countBlock, list }
        };
        setContent(content);
    }

    void bind() {
        coveredBlock.SetBinding(TextBlockEnglish.TextProperty, new Binding(nameof(vm.Covered)));
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Items)));
        count.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Mode = BindingMode.OneWay, 
            Source = list
        });
    }

    Grid getTip() {
        var header = new TextBlockEnglish() {
            Text = "Free",
            FontWeight = FontWeights.Bold
        };
        var separator = new Rectangle() {
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var description = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Text = "See words without root or lemma."
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(description, 2);
        return new Grid() {
            MaxWidth = 200,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(10) },
                new RowDefinition()
            },
            Children = { header, separator, description }
        };
    }
}
