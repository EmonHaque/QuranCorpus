﻿class RootLemmaTemplate : HierarchicalDataTemplate {
    public RootLemmaTemplate() {
        ItemsSource = new Binding(nameof(LemmaHeader.Items));
        ItemTemplate = new LemmaTemplate();
        VisualTree = new FrameworkElementFactory(typeof(GroupGrid));
    }
}

class GroupGrid : Grid {
    TextBlockArabic arabic;
    TextBlockEnglish buckwalter, count;

    public GroupGrid() {
        arabic = new TextBlockArabic();
        buckwalter = new TextBlockEnglish() {
            Margin = new Thickness(5, 0, 15, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        count = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center,
            Foreground = Brushes.Gray
        };

        SetColumn(buckwalter, 1);
        SetColumn(count, 2);

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

        Children.Add(arabic);
        Children.Add(buckwalter);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var header = (LemmaHeader)DataContext;
        int total = 0;
        foreach (Lemma item in header.Items) {
            if (item.Items != null) total += item.Items.Sum(x => x.References.Count);
            else total += item.References.Count;
        }
        count.Text = total.ToString("N0") + " in " + header.Items.Count.ToString("N0");

        string text = "";
        foreach (var character in header.Root) {
            if (character == '|') text += '|'; // 20:94:2 - yabnaumma hass multiple roots splitted by " | "
            else if (character == ' ') text += ' '; // 20:94:2 - yabnaumma hass multiple roots splitted by " | "
            else text += (char)uint.Parse(App.characters.First(x => x.English == character).Arabic, NumberStyles.HexNumber);
        }
        arabic.Text = text;
        buckwalter.Text = header.Root;
    }
}

class LemmaGrid : Grid {
    TextBlockArabic arabic;
    TextBlockEnglish pos, count;

    public LemmaGrid() {
        arabic = new TextBlockArabic();
        pos = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center,
            TextWrapping = TextWrapping.Wrap
        };
        count = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center
        };

        SetColumn(pos, 1);
        SetColumn(count, 2);

        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(70) });

        Children.Add(arabic);
        Children.Add(pos);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var lemma = (Lemma)DataContext;
        if (lemma.Items != null) {
            var cou = lemma.Items.Sum(x => x.References.Count);
            count.Text = cou.ToString("N0") + " in " + lemma.Items.Count.ToString("N0");

            var distinct = lemma.Items.Select(x => x.POS).Distinct();
            pos.Text = string.Join(" | ", distinct);
        }
        else {
            count.Text = lemma.References.Count.ToString("N0");
            pos.Text = lemma.POS;
        }
        /* 
        * this check is because LemmaVM groups items based on Transcript and one Transcripts
        * remains null, because some spelling completely vanish or reappear depending on the 
        * Transcript you choose, and it doesn't update underlying set until you go back to 
        * LemmaView after changing the Transcript. When you change Transcript and then 
        * change Arabic font, TextBlockArabic is triggered for font change and calls this function
        */
        int index = App.global.Transcript;
        if (lemma.Transcripts[App.global.Transcript] is null) {
            index = index == 1 ? 0 : 1;
        }
        arabic.Text = lemma.Transcripts[index].toArabic();
    }
}

class LemmaSubGrid : Grid {
    TextBlockArabic arabic;
    TextBlockEnglish pos, count;

    public LemmaSubGrid() {
        arabic = new TextBlockArabic();
        pos = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center
        };
        count = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center
        };

        SetColumn(pos, 1);
        SetColumn(count, 2);

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(70) });

        Children.Add(arabic);
        Children.Add(pos);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var lemma = (Lemma)DataContext;
        count.Text = lemma.References.Count.ToString("N0");
        arabic.Text = lemma.Transcripts[App.global.Transcript].toArabic();
        pos.Text = lemma.POS;
    }
}

class LemmaTemplate : HierarchicalDataTemplate {
    public LemmaTemplate() {
        VisualTree = new FrameworkElementFactory(typeof(LemmaGrid));
        ItemsSource = new Binding(nameof(Lemma.Items));
        ItemTemplate = new DataTemplate() {
            VisualTree = new FrameworkElementFactory(typeof(LemmaSubGrid))
        };
    }
}