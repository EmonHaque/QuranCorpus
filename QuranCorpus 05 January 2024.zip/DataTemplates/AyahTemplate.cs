﻿class AyahTemplate : DataTemplate {
    public AyahTemplate() {
        VisualTree = new FrameworkElementFactory(typeof(Verse));
    }

    class Verse : VerseGrid {
        protected override void setAyaNumbers() {
            englishAyahNo.Text = ayah.AyahNo;
            arabicAyahNo.Text = ayah.AyahNo.toArabicNo();
        }

        protected override void hookListener() => ((IHighlight)page).Highlighted += onWordHighlighted;

        protected override void unhookListener() => ((IHighlight)page).Highlighted -= onWordHighlighted;

        void onWordHighlighted(string reference) {
            var parts = reference.Split(':');
            if (!ayah.AyahNo.Equals(parts[1])) return;
            for (int i = 0; i < arabic.Children.Count; i++) {
                var panel = (StackPanel)arabic.Children[i];
                var block = (TextBlockArabic)panel.Children[0];
                var word = (Word)block.Tag;
                panel.Background =
                    word.Reference.Equals(reference) ?
                    highlightBrush :
                    null;
            }
        }
    }
}

class AyahSearchTemplate : DataTemplate {
    public AyahSearchTemplate() {
        VisualTree = new FrameworkElementFactory(typeof(VerseGrid));
    }
}

class AyahTemplateDragDrop : DataTemplate {
    public AyahTemplateDragDrop() {
        VisualTree = new FrameworkElementFactory(typeof(Verse));
    }

    class Verse : VerseGrid {
        Border dragTop, dragBottom;

        protected override void addChildren() {
            dragTop = new Border();
            dragBottom = new Border();

            SetRow(arabicGrid, 1);
            SetRow(englishGrid, 2);
            SetRow(dragBottom, 3);

            RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1.5) });
            RowDefinitions.Add(new RowDefinition());
            RowDefinitions.Add(new RowDefinition());
            RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1.5) });

            Children.Add(dragTop);
            Children.Add(arabicGrid);
            Children.Add(englishGrid);
            Children.Add(dragBottom);
        }

        protected override void OnDragEnter(DragEventArgs e) {
            base.OnDragEnter(e);
            var source = e.Data.GetData("source");
            if (source is DragDropListBox) {
                Background = Brushes.Black;
                Opacity = 0.5;
            }

        }

        protected override void OnDragOver(DragEventArgs e) {
            base.OnDragOver(e);
            var source = e.Data.GetData("source");
            if (source is not DragDropListBox) return;
            // handle if it's fired for this;
            var point = e.GetPosition(this);
            var mid = ActualHeight / 2;

            if (point.Y < mid) {
                dragBottom.Background = null;
                dragTop.Background = Brushes.Red;
            }
            else {
                dragTop.Background = null;
                dragBottom.Background = Brushes.Red;
            }
        }

        protected override void OnDragLeave(DragEventArgs e) {
            base.OnDragLeave(e);
            Background = null;
            Opacity = 1;
            dragTop.Background = null;
            dragBottom.Background = null;
        }

        protected override void OnDrop(DragEventArgs e) {
            base.OnDragOver(e);
            Background = null;
            Opacity = 1;
        }
    }
}

class VerseGrid : Grid {
    protected ISwitch page;
    protected Ayah ayah;
    protected Run englishAyahNo;
    protected Brush highlightBrush;
    protected WrapPanel arabic;
    protected TextBlockArabicListen arabicAyahNo;
    protected Grid arabicGrid, englishGrid;

    TextBlockEnglish meaning, explanation;
    Brush transliterationBrush;
    StackPanel english;
    ItemsControl segments;
    Popup pop;
    DependencyPropertyDescriptor fontDescriptor;

    public VerseGrid() {
        Background = Brushes.Transparent;
        highlightBrush = Brushes.Brown;
        transliterationBrush = Brushes.Beige;
        arabicAyahNo = new TextBlockArabicListen();
        arabic = new WrapPanel();
        Grid.SetColumn(arabic, 1);
        arabicGrid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition() { Width = GridLength.Auto },
                    new ColumnDefinition()
                },
            Children = { arabicAyahNo, arabic }
        };

        englishAyahNo = new Run();
        var englishAyahNoBlock = new TextBlockEnglish() {
            Inlines = { englishAyahNo, new Run(") ") }
        };
        english = new StackPanel();
        Grid.SetColumn(english, 1);

        englishGrid = new Grid() {
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition()
                },
            Children = { englishAyahNoBlock, english }
        };

        addChildren();

        meaning = new TextBlockEnglish() {
            Foreground = Constants.Foreground,
            FontWeight = FontWeights.Bold
        };
        segments = new ItemsControl() {
            Margin = new Thickness(0, 5, 0, 5),
            Padding = new Thickness(0, 5, 0, 5),
            BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, Constants.BottomLineThickness),
            BorderBrush = Brushes.LightGray,
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(PartitionGrid))
            }
        };
        segments.SetValue(Grid.IsSharedSizeScopeProperty, true);
        explanation = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Foreground = Constants.Foreground
        };
        Grid.SetRow(segments, 1);
        Grid.SetRow(explanation, 2);

        pop = new Popup() {
            AllowsTransparency = true,
            Placement = PlacementMode.Mouse,
            HorizontalOffset = 20,
            VerticalOffset = 20,
            MinWidth = 200,
            MaxWidth = 350,
            Child = new Border() {
                Padding = new Thickness(10),
                CornerRadius = new CornerRadius(5),
                BorderBrush = Brushes.LightGray,
                BorderThickness = new Thickness(Constants.BottomLineThickness),
                Background = Constants.Background,
                Child = new Grid() {
                    RowDefinitions = {
                        new RowDefinition(){ Height = GridLength.Auto},
                        new RowDefinition(){ Height = GridLength.Auto},
                        new RowDefinition()
                    },
                    Children = {
                        meaning,
                        segments,
                        explanation
                    }
                }
            }
        };

        Loaded += onLoaded;
        Unloaded += onUnloaded;
        fontDescriptor = DependencyPropertyDescriptor.FromProperty(TextBlockArabic.FontFamilyProperty, typeof(TextBlockArabic));
        fontDescriptor.AddValueChanged(arabicAyahNo, onFontChanged);
    }

    public override void EndInit() {
        base.EndInit();
        ayah = (Ayah)DataContext;

        setInterfaces();
        setAyaNumbers();

        if (!(App.global.ArabicFont.Equals("KFGQPC Uthmanic HAFS") ||
                App.global.ArabicFont.Equals("me quran"))) {
            arabicAyahNo.Text += ")";
        }
        StringBuilder builder = new();

        for (int i = 0; i < ayah.Words.Count; i++) {
            var stack = new StackPanel() {
                Resources = {
                        {
                            typeof(TextBlockEnglish), new Style() {
                                Setters = {
                                    new Setter(TextBlockEnglish.HorizontalAlignmentProperty, HorizontalAlignment.Center),
                                    new Setter(TextBlockEnglish.PaddingProperty, new Thickness(5,0,5,0)),
                                    new Setter(TextBlockEnglish.FlowDirectionProperty, FlowDirection.LeftToRight),
                                }
                            }
                        },
                        {
                            typeof(TextBlockArabicListen), new Style() {
                                Setters = {
                                    new Setter(TextBlockArabicListen.HorizontalAlignmentProperty, HorizontalAlignment.Center),
                                    new Setter(TextBlockArabicListen.PaddingProperty, new Thickness(5,0,5,0)),
                                }
                            }
                        },
                    }
            };
            var word = ayah.Words[i];
            var block = new TextBlockArabicListen() { Tag = word };
            var segments = word.Segments[App.global.Transcript].Split('|');

            for (int j = 0; j < segments.Length; j++) {
                segments[j].toArabic(segments, builder);
                var run = new Run(builder.ToString());
                block.Inlines.Add(run);
                builder.Clear();
            }
            if (page.HasColor) colorize(block);
            if (word.IsHighlighted) stack.Background = highlightBrush;
            stack.Children.Add(block);

            if (page.HasTransliteration) {
                stack.Children.Add(new TextBlockEnglish() {
                    Foreground = transliterationBrush,
                    Text = ayah.Words[i].Transliteration
                });
            }

            if (page.HasWordByWordTranslation) {
                stack.Children.Add(new TextBlockEnglish() { Text = ayah.Words[i].Meaning });
            }

            arabic.Children.Add(stack);
        }
        addTranslation();
    }

    protected virtual void addChildren() {
        SetRow(englishGrid, 1);
        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition());
        Children.Add(arabicGrid);
        Children.Add(englishGrid);
    }

    protected virtual void setAyaNumbers() {
        englishAyahNo.Text = ayah.SurahNo + ":" + ayah.AyahNo;
        arabicAyahNo.Text = ayah.SurahNo.toArabicNo() + ":" + ayah.AyahNo.toArabicNo();
    }

    protected virtual void setInterfaces() {
        var box = Helper.FindParentOfType<ListBox>(this);

        if (box is null) {
            var tree = Helper.FindParentOfType<TreeView>(this);
            page = (ISwitch)tree.DataContext;
        }
        else page = (ISwitch)box.DataContext;
    }

    protected virtual void hookListener() { }

    protected virtual void unhookListener() { }

    void onLoaded(object sender, RoutedEventArgs e) {
        for (int i = 0; i < arabic.Children.Count; i++) {
            var item = (StackPanel)arabic.Children[i];
            item.MouseEnter += onMouseEnter;
            item.MouseLeave += onMouseLeave;
            item.PreviewMouseLeftButtonDown += onLeftButtonDown;
        }
        ayah.PropertyChanged += onTranslationChange;
        page.ColorChanged += onColoredChanged;
        page.TransliterationChanged += onTransliterationChanged;
        page.WordByWordTranslationChanged += onWordByWordTranslationChanged;
        hookListener();
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        for (int i = 0; i < arabic.Children.Count; i++) {
            var item = (StackPanel)arabic.Children[i];
            item.MouseEnter -= onMouseEnter;
            item.MouseLeave -= onMouseLeave;
            item.PreviewMouseLeftButtonDown -= onLeftButtonDown;
        }
        ayah.PropertyChanged -= onTranslationChange;
        page.ColorChanged -= onColoredChanged;
        page.TransliterationChanged -= onTransliterationChanged;
        page.WordByWordTranslationChanged -= onWordByWordTranslationChanged;
        unhookListener();
        pop.IsOpen = false;
    }

    void onColoredChanged() {
        if (page.HasColor) {
            for (int i = 0; i < arabic.Children.Count; i++) {
                var stack = (StackPanel)arabic.Children[i];
                var block = (TextBlockArabicListen)stack.Children[0];
                colorize(block);
            }
        }
        else {
            for (int i = 0; i < arabic.Children.Count; i++) {
                var stack = (StackPanel)arabic.Children[i];
                var block = (TextBlockArabicListen)stack.Children[0];
                for (int j = 0; j < block.Inlines.Count; j++) {
                    var run = block.Inlines.ElementAt(j);
                    run.Foreground = Constants.Foreground;
                }
            }
        }
    }

    void onTransliterationChanged() {
        if (page.HasTransliteration) {
            for (int i = 0; i < arabic.Children.Count; i++) {
                var stack = (StackPanel)arabic.Children[i];
                var word = (Word)((TextBlockArabicListen)stack.Children[0]).Tag;
                stack.Children.Insert(1, new TextBlockEnglish() {
                    Text = word.Transliteration,
                    Foreground = transliterationBrush
                });
            }
        }
        else {
            for (int i = 0; i < arabic.Children.Count; i++) {
                var stack = (StackPanel)arabic.Children[i];
                stack.Children.RemoveAt(1);
            }
        }
    }

    void onWordByWordTranslationChanged() {
        int index = page.HasTransliteration ? 2 : 1;
        if (page.HasWordByWordTranslation) {
            for (int i = 0; i < arabic.Children.Count; i++) {
                var stack = (StackPanel)arabic.Children[i];
                var word = (Word)((TextBlockArabicListen)stack.Children[0]).Tag;
                stack.Children.Insert(index, new TextBlockEnglish() { Text = word.Meaning });
            }
        }
        else {
            for (int i = 0; i < arabic.Children.Count; i++) {
                var stack = (StackPanel)arabic.Children[i];
                stack.Children.RemoveAt(index);
            }
        }
    }

    void onTranslationChange(object? sender, PropertyChangedEventArgs e) {
        english.Children.Clear();
        addTranslation();
    }

    void onFontChanged(object? sender, EventArgs e) {
        if (App.global.ArabicFont.Equals("KFGQPC Uthmanic HAFS") ||
            App.global.ArabicFont.Equals("me quran")) {
            if (arabicAyahNo.Text.EndsWith(')')) {
                arabicAyahNo.Text = arabicAyahNo.Text.Remove(arabicAyahNo.Text.Length - 1);
            }
        }
        else {
            if (!arabicAyahNo.Text.EndsWith(')')) {
                arabicAyahNo.Text += ')';
            }
        }
    }

    void addTranslation() {
        var list = App.global.TranslationDictionary.Keys.ToList();

        if (ayah.Translations is null) {
            englishGrid.Visibility = Visibility.Collapsed;
        }
        else {
            englishGrid.Visibility = Visibility.Visible;

            if (ayah.Translations.Length == 1) {
                english.Children.Add(new HiEnglishBlock() {
                    TextWrapping = TextWrapping.Wrap,
                    Margin = new Thickness(0, 0, 0, 10),
                    Text = ayah.Translations[0].Content,
                    Query = page.Query
                });
            }
            else {
                for (int i = 0; i < ayah.Translations.Length; i++) {
                    var item = ayah.Translations[i];
                    var name = new Run(list[item.TranslatorId] + ": ") {
                        FontWeight = FontWeights.Bold,
                        Foreground = Brushes.Gray
                    };
                    var content = new Run(item.Content) { Foreground = Constants.Foreground };

                    english.Children.Add(new HiEnglishBlock() {
                        TextWrapping = TextWrapping.Wrap,
                        Margin = new Thickness(0, 0, 0, 10),
                        Inlines = { name, content },
                        Query = page.Query
                    });
                }
            }
        }
    }

    void colorize(TextBlockArabicListen block) {
        var tags = ((Word)block.Tag).Tags.Split('|');
        string lastPos = "";
        int pronCount = 0, otherCount = 0;

        for (int j = 0; j < block.Inlines.Count; j++) {
            var run = block.Inlines.ElementAt(j);
            var tag = App.tags[Convert.ToInt32(tags[j])].Name;
            switch (tag) {
                case "DET": run.Foreground = Foregrounds.DET_Brush; break;
                case "V": run.Foreground = Foregrounds.V_Brush; break;
                case "N":
                case "PN":
                case "ADJ": run.Foreground = Foregrounds.N_PN_ADJ_Brush; break;
                case "REL":
                case "DEM": run.Foreground = Foregrounds.DEM_REL_Brush; break;
                case "P": run.Foreground = Foregrounds.P_Brush; break;
                case "CONJ": run.Foreground = Foregrounds.CONJ_Brush; break;
                case "INTG": run.Foreground = Foregrounds.INTG_Brush; break;
                case "NEG": run.Foreground = Foregrounds.NEG_Brush; break;
                case "PRON":
                    if (lastPos.Equals("PRON")) pronCount++;
                    if (pronCount == 1) run.Foreground = Foregrounds.PRON1_Brush;
                    else if (pronCount == 2) run.Foreground = Foregrounds.PRON2_Brush;
                    else run.Foreground = Foregrounds.PRON3_Brush;
                    break;
                default:
                    if (!Foregrounds.Defined.Contains(lastPos)) otherCount++;
                    if (otherCount == 1) run.Foreground = Foregrounds.OTHER1_Brush;
                    else if (otherCount == 2) run.Foreground = Foregrounds.OTHER2_Brush;
                    else run.Foreground = Foregrounds.OTHER3_Brush;
                    break;
            }
            lastPos = tag;
        }
    }

    void onMouseLeave(object sender, MouseEventArgs e) {
        var panel = (StackPanel)sender;
        var word = (Word)((TextBlock)panel.Children[0]).Tag;
        panel.Background = word.IsHighlighted ? highlightBrush : null;
        panel.Opacity = 1;

        if (!page.IsHoverPopupEnabled) return;
        if (pop.IsOpen) pop.IsOpen = false;
    }

    void onMouseEnter(object sender, MouseEventArgs e) {
        if (Keyboard.IsKeyDown(Key.LeftCtrl)) return;

        var panel = (StackPanel)sender;
        panel.Background = Constants.Background;

        if (!page.IsHoverPopupEnabled) return;

        var word = (Word)((TextBlock)panel.Children[0]).Tag;
        List<Partitions> partitions = new();

        var tags = word.Tags.Split('|');
        var spellings = word.Spellings[App.global.Transcript].Split('|');
        var lemmas = word.Lemmas[App.global.Transcript].Split('|');
        var lemmaIndices = word.LemmaIndices.Split('|');
        bool hasDet = false;

        for (int i = 0; i < tags.Length; i++) {
            var name = App.tags[Convert.ToInt32(tags[i])].Name;
            var part = new Partitions() { Tag = name };
            if (name.Equals("DET")) hasDet = true;

            string lemma = "";
            bool hasLemma = false;
            for (int j = 0; j < lemmaIndices.Length; j++) {
                if (string.IsNullOrEmpty(lemmaIndices[j])) continue;
                if (Convert.ToInt32(lemmaIndices[j]) != i) continue;
                lemma = App.lemmas[Convert.ToInt32(lemmas[j])];
                hasLemma = true;
                break;
            }

            if (hasLemma) part.Lemma = lemma.toArabic();
            part.Transcription = App.spellings[Convert.ToInt32(spellings[i])].toArabic();
            partitions.Add(part);
        }

        StringBuilder builder = new();
        if (tags.Length == 1 && App.tags[Convert.ToInt32(tags[0])].Name.Equals("INL")) {
            builder
                .Append(App.tags[Convert.ToInt32(tags[0])].Value)
                .Append('.');
        }
        else word.explain(builder, tags, hasDet);

        segments.ItemsSource = partitions;
        meaning.Text = word.Transliteration + '\n' + word.Meaning;
        explanation.Text = builder.ToString();
        pop.IsOpen = true;
    }

    void onLeftButtonDown(object sender, MouseButtonEventArgs e) {
        if (Keyboard.IsKeyDown(Key.LeftCtrl)) {
            if (e.ClickCount == 2) return;
            e.Handled = true;

            var panel = (StackPanel)sender;
            var word = (Word)((TextBlock)panel.Children[0]).Tag;
            var currentIndex = ayah.Words.IndexOf(word);

            if (Keyboard.IsKeyDown(Key.LeftShift)) {
                int firstIndex = -1;
                for (int i = 0; i < ayah.Words.Count; i++) {
                    if (!ayah.Words[i].IsHighlighted) continue;
                    firstIndex = i;
                    break;
                }
                if (firstIndex == currentIndex) {
                    if (ayah.Words[currentIndex].IsHighlighted) {
                        ayah.Words[currentIndex].IsHighlighted = false;
                        ((StackPanel)arabic.Children[currentIndex]).Background = null;
                    }
                    else {
                        ayah.Words[currentIndex].IsHighlighted = true;
                        ((StackPanel)arabic.Children[currentIndex]).Background = highlightBrush;
                    }
                }
                else {
                    if (firstIndex == -1) {
                        ayah.Words[currentIndex].IsHighlighted = true;
                        ((StackPanel)arabic.Children[currentIndex]).Background = highlightBrush;
                    }
                    else if (firstIndex > currentIndex) {
                        for (int i = currentIndex; i < firstIndex + 1; i++) {
                            ayah.Words[i].IsHighlighted = true;
                            ((StackPanel)arabic.Children[i]).Background = highlightBrush;
                        }
                    }
                    else {
                        for (int i = firstIndex; i < currentIndex + 1; i++) {
                            ayah.Words[i].IsHighlighted = true;
                            ((StackPanel)arabic.Children[i]).Background = highlightBrush;
                        }
                    }
                }
            }
            else {
                word.IsHighlighted = !word.IsHighlighted;
                for (int i = 0; i < ayah.Words.Count; i++) {
                    if (i == currentIndex) continue;
                    if (ayah.Words[i].IsHighlighted) {
                        ayah.Words[i].IsHighlighted = false;
                        ((StackPanel)arabic.Children[i]).Background = null;
                    }
                }
            }
        }
        else {
            if (e.ClickCount != 2) return;
            e.Handled = true;
            if (pop.IsOpen) pop.IsOpen = false;

            var panel = (StackPanel)sender;
            var word = (Word)((TextBlock)panel.Children[0]).Tag;
           
            panel.Background = word.IsHighlighted ? highlightBrush : null;
            panel.Opacity = 1;

            ((App)Application.Current).FocusedControl.addMatchPage(word);
        }
    }
}

class Partitions {
    public string Transcription { get; set; }
    public string Lemma { get; set; }
    public string Tag { get; set; }
}

class PartitionGrid : Grid {
    TextBlockArabic transcript, lemma;
    TextBlock tag;
    public PartitionGrid() {
        transcript = new TextBlockArabic() {
            Margin = new Thickness(20, 0, 20, 0)
        };
        lemma = new TextBlockArabic();
        tag = new TextBlock() { VerticalAlignment = VerticalAlignment.Center };

        Grid.SetColumn(transcript, 1);
        Grid.SetColumn(tag, 2);
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col2" });
        ColumnDefinitions.Add(new ColumnDefinition());
        Children.Add(lemma);
        Children.Add(transcript);
        Children.Add(tag);

        transcript.SetBinding(TextBlockArabic.TextProperty, new Binding(nameof(Partitions.Transcription)));
        lemma.SetBinding(TextBlockArabic.TextProperty, new Binding(nameof(Partitions.Lemma)));
        tag.SetBinding(TextBlock.TextProperty, new Binding(nameof(Partitions.Tag)));
    }
}