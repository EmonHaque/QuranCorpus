﻿class TabView : CardView {
    Grid grid, leftGrid, rightGrid;

    public override void OnFirstSight() {
        base.OnFirstSight();
        initializeUI();
    }

    void initializeUI() {
        grid = new Grid() { Children = { ((App)Application.Current).FocusedControl } };
        setContent(grid);

        leftGrid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ MinHeight = 300 },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ MinHeight = 300 },
            }
        };
        rightGrid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ MinHeight = 300 },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ MinHeight = 300 },
            }
        };
        Grid.SetColumn(rightGrid, 2);
    }

    public void AddHorizontal() {
        leftGrid.Children.Clear();
        rightGrid.Children.Clear();
        grid.Children.Clear();
        grid.ColumnDefinitions.Clear();

        grid.ColumnDefinitions.Add(new ColumnDefinition() { MinWidth = 300 });
        grid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        grid.ColumnDefinitions.Add(new ColumnDefinition() { MinWidth = 300 });

        var verticalSeparator = new Rectangle() {
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        var verticalSplitter = new GridSplitter() {
            ResizeDirection = GridResizeDirection.Columns,
            ResizeBehavior = GridResizeBehavior.PreviousAndNext,
            Template = new SplitterTemplate()
        };
        Grid.SetColumn(verticalSeparator, 1);
        Grid.SetColumn(verticalSplitter, 1);
        Grid.SetRowSpan(verticalSeparator, 3);
        Grid.SetRowSpan(verticalSplitter, 3);

        grid.Children.Add(verticalSeparator);
        grid.Children.Add(verticalSplitter);

        var pages = ((App)Application.Current).Pages;
        foreach (var page in pages) {
            page.ClearValue(Grid.ColumnProperty);
            page.ClearValue(Grid.RowProperty);

            if (page.Position == SplitPosition.TopRight) {
                grid.Children.Add(rightGrid);

                var separator = new Rectangle() {
                    Height = Constants.BottomLineThickness,
                    Fill = Brushes.Gray,
                    HorizontalAlignment = HorizontalAlignment.Stretch
                };
                var splitter = new GridSplitter() {
                    ResizeDirection = GridResizeDirection.Rows,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    ResizeBehavior = GridResizeBehavior.PreviousAndNext,
                    Template = new SplitterTemplate()
                };

                Grid.SetRow(separator, 1);
                Grid.SetRow(splitter, 1);

                rightGrid.Children.Add(page);
                rightGrid.Children.Add(separator);
                rightGrid.Children.Add(splitter);
            }
            else if (page.Position == SplitPosition.BottomRight) {
                Grid.SetRow(page, 2);
                rightGrid.Children.Add(page);
            }
            else if (page.Position == SplitPosition.TopLeft) {
                grid.Children.Add(leftGrid);

                var separator = new Rectangle() {
                    Height = Constants.BottomLineThickness,
                    Fill = Brushes.Gray,
                    HorizontalAlignment = HorizontalAlignment.Stretch
                };
                var splitter = new GridSplitter() {
                    ResizeDirection = GridResizeDirection.Rows,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    ResizeBehavior = GridResizeBehavior.PreviousAndNext,
                    Template = new SplitterTemplate()
                };
                Grid.SetRow(separator, 1);
                Grid.SetRow(splitter, 1);

                leftGrid.Children.Add(page);
                leftGrid.Children.Add(separator);
                leftGrid.Children.Add(splitter);
            }
            else if (page.Position == SplitPosition.BottomLeft) {
                Grid.SetRow(page, 2);
                leftGrid.Children.Add(page);
            }
            else if (page.Position == SplitPosition.Left) {
                Grid.SetColumn(page, 0);
                grid.Children.Add(page);
            }
            else if (page.Position == SplitPosition.Right) {
                Grid.SetColumn(page, 2);
                grid.Children.Add(page);
            }
        }
    }

    public void AddVertical() {
        rightGrid.Children.Clear();
        leftGrid.Children.Clear();
        grid.Children.Clear();
        grid.ColumnDefinitions.Clear();

        grid.ColumnDefinitions.Add(new ColumnDefinition() { MinWidth = 300 });
        grid.ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        grid.ColumnDefinitions.Add(new ColumnDefinition() { MinWidth = 300 });

        var separator = new Rectangle() {
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        var splitter = new GridSplitter() {
            ResizeDirection = GridResizeDirection.Columns,
            ResizeBehavior = GridResizeBehavior.PreviousAndNext,
            Template = new SplitterTemplate()
        };

        Grid.SetColumn(separator, 1);
        Grid.SetColumn(splitter, 1);
        grid.Children.Add(separator);
        grid.Children.Add(splitter);

        var pages = ((App)Application.Current).Pages;
       
        foreach (var page in pages) {
            page.ClearValue(Grid.ColumnProperty);
            page.ClearValue(Grid.RowProperty);

            if (page.Position == SplitPosition.Right) Grid.SetColumn(page, 2);

            grid.Children.Add(page);
        }
    }

    public void Default() {
        grid.ColumnDefinitions.Clear();
        grid.Children.Clear();
        var current = ((App)Application.Current).FocusedControl;
        current.ClearValue(Grid.ColumnProperty);
        grid.Children.Add(current);
    }
}
