﻿public class RootPanel : Panel
{
    double navWidth = 24;
    int selectedIndex, newIndex;
    bool isAnimating;
    Grid navContainer;
    StackPanel windowActions;
    Border navBorder, moveWindow, actionsBorder;
    ActionButton maximizeOrRestore;
    List<RootView> containers;
    List<TransitButton> buttons;
    DoubleAnimation getIn, getOut;
    TextBlock title;
    Size size;

    public RootPanel() {
        ClipToBounds = true;
        containers = new List<RootView>();
        buttons = new List<TransitButton>();
        addWindowActions();
        title = new TextBlock() {
            Text = Constants.AppTitle,
            FontWeight = FontWeights.Bold,
            FontSize = 16,
            VerticalAlignment = VerticalAlignment.Bottom,
            LayoutTransform = new RotateTransform(-90),
            Margin = new Thickness(0, 0, 0, 10)
        };
        Grid.SetRow(title, 1);
        navContainer = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { actionsBorder, title }
        };
        navBorder = new Border() {
            Background = Constants.Background,
            Width = navWidth,
            Child = navContainer,
            CornerRadius = new CornerRadius(0, 5, 5, 0)
        };
        SetZIndex(navBorder, 1);
        Children.Add(navBorder);

        var duration = TimeSpan.FromSeconds(1);
        var ease = new CubicEase() { EasingMode = EasingMode.EaseInOut };
        getIn = new DoubleAnimation() {
            To = 0,
            Duration = duration,
            EasingFunction = ease
        };
        getOut = new DoubleAnimation() {
            Duration = duration,
            EasingFunction = ease
        };

        Loaded += onLoaded;
        getOut.Completed += resetViewsVisibility;
        moveWindow.MouseMove += move;
        moveWindow.MouseLeftButtonDown += maxOrRestore;
        actionsBorder.MouseEnter += showWindowActions;
        actionsBorder.MouseLeave += hideWindowActions;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        int row = 2;
        foreach (TransitButton button in buttons) {
            navContainer.RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            Grid.SetRow(button, row++);
            navContainer.Children.Add(button);
        }
        SetZIndex(navBorder, 2);
        title.Height = title.ActualWidth;
    }
    void hideWindowActions(object sender, MouseEventArgs e) {
        windowActions.Visibility = Visibility.Hidden;
    }
    void showWindowActions(object sender, MouseEventArgs e) {
        windowActions.Visibility = Visibility.Visible;
    }
    void maxOrRestore(object sender, MouseButtonEventArgs e) {
        if (e.ClickCount == 2) resize();
    }
    void move(object sender, MouseEventArgs e) {
        if (e.LeftButton == MouseButtonState.Pressed)
            Application.Current.MainWindow.DragMove();
    }
    void resize() {
        if (Application.Current.MainWindow.WindowState == WindowState.Maximized) {
            Application.Current.MainWindow.ResizeMode = ResizeMode.CanResizeWithGrip;
            Application.Current.MainWindow.WindowState = WindowState.Normal;
            maximizeOrRestore.Icon = Icons.Maximize;
            maximizeOrRestore.ToolTip = "maximize";
        }
        else {
            Application.Current.MainWindow.ResizeMode = ResizeMode.NoResize;
            Application.Current.MainWindow.WindowState = WindowState.Maximized;
            maximizeOrRestore.Icon = Icons.Restore;
            maximizeOrRestore.ToolTip = "restore";
        }
    }
    void addWindowActions() {
        moveWindow = new Border() {
            Background = Brushes.Transparent,
            Margin = new Thickness(2, 0, 2, 0),
            Padding = new Thickness(0, 5, 0, 5),
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
            BorderBrush = new SolidColorBrush(Color.FromRgb(100, 100, 100)),
            ToolTip = "move",
            Child = new Path() {
                Width = 12,
                Height = 12,
                Fill = Brushes.LightGray,
                Stretch = Stretch.Uniform,
                Data = Geometry.Parse(Icons.Anchor)
            }
        };

        var close = new ActionButton() {
            ToolTip = "close",
            Margin = new Thickness(0, 7, 0, 7),
            Icon = Icons.CloseCircle,
            Command = Application.Current.Shutdown
        };
        maximizeOrRestore = new ActionButton() {
            Width = 10,
            Height = 10,
            ToolTip = "maximize",
            Icon = Icons.Maximize,
            Command = resize
        };
        var minimize = new ActionButton() {
            ToolTip = "minimize",
            Margin = new Thickness(0, 7, 0, 0),
            Icon = Icons.Minimize,
            Command = () => Application.Current.MainWindow.WindowState = WindowState.Minimized
        };
        windowActions = new StackPanel() {
            Children = { moveWindow, close, maximizeOrRestore, minimize },
            Visibility = Visibility.Hidden
        };
        actionsBorder = new Border() {
            Background = Brushes.Transparent,
            Child = windowActions
        };
    }
    void resetViewsVisibility(object sender, EventArgs e) {
        containers[selectedIndex].Element.Visibility = Visibility.Hidden;
        selectedIndex = newIndex;
        isAnimating = buttons[selectedIndex].isActing = false;
    }
    void go(int o) {
        var index = o;
        var oldIndex = selectedIndex;
        if (!isAnimating && index != oldIndex) {
            isAnimating = true;
            buttons[index].isActing = true;
            buttons[index].IsSelected = true;
            buttons[selectedIndex].IsSelected = false;

            newIndex = index;

            if (newIndex > oldIndex) {
                getIn.From = navWidth - size.Width;
                getOut.To = size.Width - navWidth;
            }
            else {
                getIn.From = size.Width;
                getOut.To = -size.Width;
            }
            containers[oldIndex].Element.RenderTransform.BeginAnimation(TranslateTransform.XProperty, getOut);
            containers[newIndex].Element.RenderTransform.BeginAnimation(TranslateTransform.XProperty, getIn);
            containers[newIndex].Element.Visibility = Visibility.Visible;

            if (newIndex == 0) return;

            if (!containers[newIndex].IsSeen) {
                if (containers[newIndex].Element is View v) {
                    if (v is CardView) v.OnFirstSight();
                    else {
                        var cards = Helper.FindVisualChildren<View>(v);
                        foreach (var view in cards) {
                            if (view.Visibility == Visibility.Visible) {
                                view.OnFirstSight();
                            }
                        }
                    }
                    containers[newIndex].IsSeen = true;
                }
                else if (containers[newIndex].Element is ViewContainer vc) {
                    var selected = vc.SelectedView;
                    selected.OnFirstSight();
                    if (selected is not CardView) {
                        var cards = Helper.FindVisualChildren<View>(selected);
                        foreach (var view in cards) {
                            if (view.Visibility == Visibility.Visible) {
                                view.OnFirstSight();
                            }
                        }
                    }
                    containers[newIndex].IsSeen = true;
                }
            }
        }
    }
    protected override Size ArrangeOverride(Size finalSize) {
        size = finalSize;
        foreach (RootView item in containers) {
            item.Element.Width = finalSize.Width - navWidth;
           
            item.Element.Height = finalSize.Height;
            item.Element.Measure(finalSize);
            item.Element.Arrange(new Rect(new Point(0, 0), item.Element.DesiredSize));
            if (!containers.ElementAt(selectedIndex).Equals(item))
                item.Element.Visibility = Visibility.Hidden;
        }
        navBorder.Height = finalSize.Height;
        navBorder.Measure(finalSize);
        navBorder.Arrange(new Rect(new Point(finalSize.Width - navWidth, 0), navBorder.DesiredSize));

        return finalSize;
    }
    protected override void OnVisualChildrenChanged(DependencyObject visualAdded, DependencyObject visualRemoved) {
        if (visualAdded is not (ViewContainer or View)) {
            base.OnVisualChildrenChanged(visualAdded, visualRemoved);
            return;
        }
        var element = (FrameworkElement)visualAdded;
        element.RenderTransform = new TranslateTransform(0, 0);
        containers.Add(new RootView() {
            Element = element,
            IsSeen = false
        });
        SetZIndex(element, 0);

        if (visualAdded is INotify) {
            buttons.Add(new TransitButtonNumber(20) {
                Margin = new Thickness(0, 5, 0, 5),
                Command = go,
                index = buttons.Count,
                IsSelected = buttons.Count == 0,
                Notifier = visualAdded as INotify
            });
        }
        else {
            var view = (IHaveIcon)visualAdded;
            buttons.Add(new TransitButtonPath(14) {
                Margin = new Thickness(0, 5, 0, 5),
                Icon = view.Icon,
                ToolTip = view.OverridesToolTip ? new ToolTip() {
                    OverridesDefaultStyle = true,
                    Template = new ToolTipTemplate(),
                    Content = view.Tip
                } : view.Tip,
                Command = go,
                index = buttons.Count,
                IsSelected = buttons.Count == 0
            });
        }

        if (!buttons.Last().IsSelected) return;
        if (element is View) {
            element.InvalidateMeasure();
            element.InvalidateArrange();
            var cards = Helper.FindVisualChildren<View>(visualAdded);
            if(cards.Count () == 0) {
                (element as View).OnFirstSight();
            }
            else {
                foreach (var view in cards) {
                    if (view.Visibility == Visibility.Visible) {
                        view.OnFirstSight();
                    }
                }
            }
            
        }
        else {
            var cards = Helper.FindVisualChildren<View>(element);
            foreach (var view in cards) {
                if (view.Visibility == Visibility.Visible) {
                    view.OnFirstSight();
                }
            }
        }
    }
}
