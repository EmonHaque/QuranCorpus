﻿class TafsirPage : Page {
    int currentSurah;
    Grid content, leftGrid;
    ProgressBar progress;
    WaterBox query;
    ListBox verseBox;
    StackPanel tafsirPanel;
    ScrollViewer tafsirScroll;
    List<Tafsir> explanation;
    ICollectionView verseView;
    CancellationTokenSource terminator;

    public override PageType Type => PageType.Tafsir;
    public override UIElement Content => content;

    public TafsirPage() {
        explanation = new List<Tafsir>();
        terminator = new CancellationTokenSource();
        progress = new ProgressBar() { 
            FlowDirection = FlowDirection.RightToLeft,
            Height = Constants.ProgressBarHeight 
        };
        query = new WaterBox() {
            Margin = new Thickness(0, 0, 5, 0),
            Icon = Icons.Search,
            Hint = "Verse"
        };
        var count = new TextBlockEnglish() { HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(count, 1);
        var queryGrid = new Grid() {
            Margin = new Thickness(0, 0, 0, 5),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = GridLength.Auto }
            },
            Children = { query, count }
        };
        verseBox = new ListBox() {
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(VerseTemplate))
            }
        };
        verseBox.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        verseBox.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
        count.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Mode = BindingMode.OneWay,
            Source = verseBox
        });
        var verticalSeparator = new Rectangle() {
            Margin = new Thickness(5, 0, 2.5, 0),
            HorizontalAlignment = HorizontalAlignment.Right,
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        Grid.SetRow(verseBox, 1);
        Grid.SetColumn(verticalSeparator, 1);
        Grid.SetRowSpan(verticalSeparator, 2);
        leftGrid = new Grid() {
            RowDefinitions = {
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = GridLength.Auto}
            },
            Children = { queryGrid, verseBox, verticalSeparator }
        };

        tafsirPanel = new StackPanel();
        tafsirPanel.Resources.Add(typeof(TextBlockEnglish), new Style() {
            Setters = {
                    new Setter(TextBlockEnglish.TextWrappingProperty, TextWrapping.Wrap),
                    new Setter(TextBlockEnglish.MarginProperty, new Thickness(0,5,0,5))
                }
        });
        tafsirPanel.Resources.Add(typeof(TextBlockArabic), new Style() {
            Setters = {
                    new Setter(TextBlockEnglish.FlowDirectionProperty, FlowDirection.RightToLeft),
                    new Setter(TextBlockArabic.TextWrappingProperty, TextWrapping.Wrap),
                    new Setter(TextBlockArabic.MarginProperty, new Thickness(0,5,0,5))
                }
        });
        tafsirScroll = new ScrollViewer() {
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Padding = new Thickness(2.5, 0, 5, 0),
            Content = tafsirPanel
        };

        Grid.SetRow(leftGrid, 1);
        Grid.SetRow(tafsirScroll, 1);
        Grid.SetColumn(tafsirScroll, 1);
        Grid.SetColumnSpan(progress, 2);
        content = new Grid() {
            FlowDirection = FlowDirection.LeftToRight,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = new GridLength(150) },
                new ColumnDefinition()
            },
            Children = { progress, leftGrid, tafsirScroll }
        };

        verseBox.SelectionChanged += onVerseSelectionChanged;
        query.KeyUp += onQueryKeyUp;
    }

    public TafsirPage(int surahNo) : this() => updateUI(surahNo);

    public void setContent(int surahNo) => updateUI(surahNo);

    void updateUI(int surahNo) {
        if (surahNo == currentSurah) return;

        currentSurah = surahNo;
        HeaderText = surahNo + ") " + App.surahs.First(x => x.Id == surahNo).Transliteration + " | " + "Tafsir";
        verseBox.SelectedItem = null;
        progress.IsIndeterminate = true;

        Task.Run(() => {
            var tafs = System.IO.File.ReadLines("Resources/Tafsir/en-ibn-kathir-qurancom.txt");
            var rator = tafs.GetEnumerator();
            explanation.Clear();
            
            int no = surahNo == 105 ? 104 : surahNo;
            int count = 0;
            int ayahNo = 0;
            int surahIndex = 0;
            int sum = App.surahs[surahIndex].Verses;

            while (true) {
                if (terminator.IsCancellationRequested) break;

                rator.MoveNext();
                if (rator.Current is null) break;
                if (string.IsNullOrEmpty(rator.Current)) continue;

                if (rator.Current.StartsWith("# ")) {
                    count++;
                    if (count > sum) {
                        surahIndex++;
                        sum += App.surahs[surahIndex].Verses;
                        ayahNo = 1;
                    }
                    else ayahNo++;
                    continue;
                }
                if (App.surahs[surahIndex].Id < no) continue;
                if (App.surahs[surahIndex].Id > no) break;

                if (rator.Current.Equals("<!-- TODO:MISSING -->")) {
                    explanation.Last().Ayahs += (", " + ayahNo.ToString());
                }
                else {
                    int surah = App.surahs[surahIndex].Id;
                    var ayahStr = ayahNo.ToString();

                    if (explanation.Count == 0) explanation.Add(new Tafsir(surah, ayahStr));
                    else {
                        var last = explanation.Last();
                        if (last.SurahNo == surah) {
                            var ayahs = last.Ayahs.Split(",", StringSplitOptions.TrimEntries);
                            if (!ayahs.Contains(ayahStr)) {
                                explanation.Add(new Tafsir(surah, ayahStr));
                            }
                        }
                        else explanation.Add(new Tafsir(surah, ayahStr));
                    }
                    var line = new TafsirLine();
                    var text = rator.Current.Replace("\\", "").Replace("`", "'");
                    if (text.StartsWith("«") || text.EndsWith("»")) {
                        line.Content = text.Replace("«", "").Replace("»", "");
                        line.IsArabic = true;
                    }
                    else if (text.StartsWith("###")) {
                        line.Content = text.Substring(3);
                        line.IsBold = true;
                    }
                    else if (text.StartsWith("##")) {
                        line.Content = text.Substring(2);
                        line.IsBold = true;
                    }
                    else {
                        line.IsArabic = true;
                        var length = text.Length > 10 ? 10 : text.Length;
                        for (int j = 0; j < length; j++) {
                            var ch = text[j];
                            if ((ch >= 'A' && ch <= 'Z') ||
                                (ch >= 'a' && ch <= 'z') ||
                                (ch >= '0' && ch <= '9')) {
                                line.IsArabic = false;
                                break;
                            }
                        }
                        if (!line.IsArabic) {
                            text = text.Replace("()", "");
                        }
                        line.Content = text;
                    }
                    explanation.Last().Lines.Add(line);
                }
            }

            rator.Dispose();

            if (!terminator.IsCancellationRequested) {
                if (surahNo == 105) {
                    string ayahs = "";
                    for (int i = 0; i < App.surahs[104].Verses; i++) {
                        ayahs += (i + 1) + ", ";
                    }
                    ayahs = ayahs.Remove(ayahs.LastIndexOf(", "));
                    explanation[0].Ayahs = ayahs;
                }

                var source = explanation.Select(x => x.Ayahs).ToList();
                App.Current.Dispatcher.Invoke(() => {
                    if (source.Count == 1) {
                        content.ColumnDefinitions[0].Width = new GridLength(0);
                        query.Text = "";
                    }
                    else {
                        content.ColumnDefinitions[0].Width = new GridLength(150);
                    }
                    verseView = CollectionViewSource.GetDefaultView(source);
                    verseView.Filter = filter;
                    verseBox.ItemsSource = verseView;
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    void onVerseSelectionChanged(object sender, SelectionChangedEventArgs e) {
        tafsirPanel.Children.Clear();
        if (verseBox.SelectedItem is null) return;

        var items = explanation.First(x => x.Ayahs.Equals(verseBox.SelectedItem));

        for (int i = 0; i < items.Lines.Count; i++) {
            if (items.Lines[i].IsArabic) {
                tafsirPanel.Children.Add(new TextBlockArabic() { Text = items.Lines[i].Content });
            }
            else {
                var english = new TextBlockEnglish() { Text = items.Lines[i].Content };
                if (items.Lines[i].IsBold) {
                    english.Foreground = Brushes.Gray;
                    english.FontWeight = FontWeights.Bold;
                }
                tafsirPanel.Children.Add(english);
            }
        }

        tafsirScroll.ScrollToTop();
    }

    void onQueryKeyUp(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        verseView.Refresh();
    }

    bool filter(object o) {
        if (string.IsNullOrEmpty(query.Text)) return true;
        var verses = o.ToString().Split(',', StringSplitOptions.TrimEntries);
        return verses.Contains(query.Text);
    }

    protected override void unload() {
        verseBox.SelectionChanged -= onVerseSelectionChanged;
        query.KeyUp -= onQueryKeyUp;
        terminator.Cancel();
        terminator.Dispose();
        base.unload();
    }

    class VerseTemplate : TextBlockEnglish {
        public VerseTemplate() {
            TextWrapping = TextWrapping.Wrap;
            SetBinding(TextProperty, new Binding());
        }
    }
}