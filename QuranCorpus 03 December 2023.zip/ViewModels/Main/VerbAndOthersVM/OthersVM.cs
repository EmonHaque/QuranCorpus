﻿class OthersVM : Notifiable {
    List<NotVerb> source;
    List<NotVerbGroup> items;
    List<Tuple<int, int>> counts;

    public List<NotVerb> filtered;
    public int currentTranscript;

    NotVerbGroup selected;
    public NotVerbGroup Selected {
        get { return selected; }
        set {
            if (value is null) return;
            if (!value.Equals(selected)) {
                selected = value;
                filtered = value.SubTag.Contains(",") ? source.Where(
                    x => string.IsNullOrEmpty(x.SubTag) &&
                    x.Gender.Equals(value.Gender) &&
                    x.Number.Equals(value.Number))
                .ToList() :
                source.Where(
                    x => x.SubTag.Equals(value.SubTag) &&
                    x.Gender.Equals(value.Gender) &&
                    x.Number.Equals(value.Number))
                .ToList();
            }
            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).FocusedControl.SelectedPage is NotVerbPage verbPage) {
                verbPage.setContent(filtered);
            }
        }
    }
    public bool WasRightClicked { get; set; }
    public bool IsInProgress { get; set; }
    public int Total { get; set; }
    public ICollectionView Items { get; set; }

    public OthersVM() {
        IsInProgress = true;
        Task.Run(() => {
            var verbTag = App.tags.IndexOf(App.tags.First(x => x.Name.Equals("V"))).ToString();
            source = new List<NotVerb>();

            for (int i = 0; i < App.links.Count; i++) {
                var link = App.links[i];
                if (string.IsNullOrEmpty(link.Root)) continue;
                var ts = link.Tags.Split('|');
                if (ts.Contains(verbTag)) continue;

                var index = Convert.ToInt32(link.RootIndex);
                if (link.Root.Contains('|')) {
                    var roots = link.Root.Split('|');
                    for (int j = 0; j < roots.Length; j++) {
                        var simple = link.SegmentsSimple.Split('|')[index];
                        var corpus = link.SegmentsCorpus.Split('|')[index];

                        simple = App.segments[Convert.ToInt32(simple)];
                        corpus = App.segments[Convert.ToInt32(corpus)];

                        if (simple[1] == '~') simple = simple.Remove(1, 1);
                        if (corpus[1] == '~') corpus = corpus.Remove(1, 1);

                        if (simple.StartsWith("_#")) simple = simple.Replace("_#", "'");
                        if (corpus.StartsWith("_#")) corpus = corpus.Replace("_#", "'");

                        var exp = link.Explanation.Split('|')[index];
                        var det = link.Details.Split(',')[index];

                        var gender = "Undefined";
                        if (!string.IsNullOrEmpty(exp)) {
                            var explanation = App.explanations[Convert.ToInt32(exp)];
                            if (explanation.Contains("masculine")) gender = "Masculine";
                            else if (explanation.Contains("feminine")) gender = "Feminine";
                        }

                        var word = new NotVerb() {
                            Tag = App.tags[Convert.ToInt32(ts[index])].Name,
                            Segments = new string[] { corpus, simple },
                            Root = App.roots[Convert.ToInt32(roots[j])],
                            Gender = gender,
                            SubTag = "",
                            Form = "I",
                            Number = "Undefined"
                        };

                        setDetail(det, word);

                        var match = source.FirstOrDefault(
                            x => x.Number.Equals(word.Number) &&
                            x.Segments[0].Equals(word.Segments[0]) &&
                            x.Segments[1].Equals(word.Segments[1]) &&
                            x.Case.Equals(word.Case) &&
                            x.Gender.Equals(word.Gender) &&
                            x.Form.Equals(word.Form) &&
                            x.SubTag.Equals(word.SubTag) &&
                            x.Root.Equals(word.Root));

                        if (match is null) {
                            word.References.Add(link.Reference);
                            source.Add(word);
                        }
                        else match.References.Add(link.Reference);
                        index++;
                    }
                }
                else {
                    var simple = link.SegmentsSimple.Split('|')[index];
                    var corpus = link.SegmentsCorpus.Split('|')[index];

                    simple = App.segments[Convert.ToInt32(simple)];
                    corpus = App.segments[Convert.ToInt32(corpus)];

                    if (simple[1] == '~') simple = simple.Remove(1, 1);
                    if (corpus[1] == '~') corpus = corpus.Remove(1, 1);

                    if (simple.StartsWith("_#")) simple = simple.Replace("_#", "'");
                    if (corpus.StartsWith("_#")) corpus = corpus.Replace("_#", "'");

                    var exp = link.Explanation.Split('|')[index];
                    var det = link.Details.Split(',')[index];

                    var gender = "Undefined";
                    if (!string.IsNullOrEmpty(exp)) {
                        var explanation = App.explanations[Convert.ToInt32(exp)];
                        if (explanation.Contains("masculine")) gender = "Masculine";
                        else if (explanation.Contains("feminine")) gender = "Feminine";
                    }

                    var word = new NotVerb() {
                        Tag = App.tags[Convert.ToInt32(ts[index])].Name,
                        Segments = new string[] { corpus, simple },
                        Root = App.roots[Convert.ToInt32(link.Root)],
                        Gender = gender,
                        Case = "",
                        SubTag = "",
                        Form = "I",
                        Number = "Undefined"
                    };

                    setDetail(det, word);

                    var match = source.FirstOrDefault(
                        x => x.Number.Equals(word.Number) &&
                        x.Segments[0].Equals(word.Segments[0]) &&
                        x.Segments[1].Equals(word.Segments[1]) &&
                        x.Case.Equals(word.Case) &&
                        x.Gender.Equals(word.Gender) &&
                        x.Form.Equals(word.Form) &&
                        x.SubTag.Equals(word.SubTag) &&
                        x.Root.Equals(word.Root));

                    if (match is null) {
                        word.References.Add(link.Reference);
                        source.Add(word);
                    }
                    else match.References.Add(link.Reference);
                }
            }

            var group = source
                .GroupBy(x => x.SubTag)
                .Select(x => new {
                    x.Key,
                    Value = x.GroupBy(x => x.Gender)
                        .Select(x => new {
                            x.Key,
                            Value = x.GroupBy(x => x.Number).ToList()
                        }).ToList()
                }).ToList();

            counts = new List<Tuple<int, int>>();
            items = new List<NotVerbGroup>();
            var groupName = "";
            foreach (var subTag in group) {
                if (string.IsNullOrEmpty(subTag.Key)) {
                    groupName = string.Join(", ", subTag.Value.SelectMany(x => x.Value.SelectMany(x => x)).Select(x => x.Tag).Distinct());
                }
                foreach (var gender in subTag.Value) {
                    foreach (var number in gender.Value) {
                        var count = new Tuple<int, int>(number.Count(), number.GroupBy(x => new { s = x.Segments[1], x.Case }).Count());
                        counts.Add(count);
                        items.Add(new NotVerbGroup() {
                            SubTag = string.IsNullOrEmpty(subTag.Key) ? groupName : subTag.Key,
                            Number = number.Key,
                            Gender = gender.Key
                        });
                    }
                }
            }
            
            App.Current.Dispatcher.Invoke(() => {
                Regroup();
                Items = CollectionViewSource.GetDefaultView(items);
                Items.GroupDescriptions.Add(new PropertyGroupDescription(nameof(NotVerbGroup.SubTag)));
                Items.GroupDescriptions.Add(new PropertyGroupDescription(nameof(NotVerbGroup.Gender)));
                IsInProgress = false;
                OnPropertyChanged(nameof(Items));
                OnPropertyChanged(nameof(IsInProgress));
            });
        });
    }

    void setDetail(string detail, NotVerb word) {
        if (string.IsNullOrEmpty(detail)) return;

        var array = detail.Split('|').Select(x => App.details[Convert.ToInt32(x)]).ToArray();
        for (int i = 0; i < array.Length; i++) {
            if (string.IsNullOrEmpty(array[i].Name)) continue;
            if (array[i].Equals("PCPL") ||
                array[i].Name.Equals("IN") ||
                array[i].Name.Equals("CN") ||
                array[i].Name.Equals("IP") ||
                array[i].Name.Equals("CP") ||
                array[i].Equals("INDEF")) continue;

            if (array[i].Name.Equals("ACT")) word.SubTag = "Active Participle";
            else if (array[i].Name.Equals("PASS")) word.SubTag = "Passive Participle";
            else if (array[i].Name.Equals("VN")) word.SubTag = "Verbal Noun";
            else if (array[i].Name.Equals("ACC")) word.Case = "Accusative";
            else if (array[i].Name.Equals("GEN")) word.Case = "Genitive";
            else if (array[i].Name.Equals("NOM")) word.Case = "Nominative";
            else if (array[i].Name.StartsWith('(')) word.Form = Helper.getForm(array[i].Name).Name.Replace("(", "").Replace(")", "");
            else {
                string value = "";
                switch (array[i].Name) {
                    case "P":
                    case "2D":
                    case "3D":
                    case "M":
                    case "MS":
                    case "MD":
                    case "2MD":
                    case "3MD":
                    case "MP":
                    case "2MS":
                    case "2MP":
                    case "3MS":
                    case "3MP":
                    case "1S":
                    case "1P":
                    case "F":
                    case "FS":
                    case "FP":
                    case "2FS":
                    case "FD":
                    case "2FD":
                    case "3FD":
                    case "3FS":
                    case "2FP":
                    case "3FP":
                        var d = App.details.First(x => x.Name.Equals(array[i].Name));
                        value = d.Value;
                        break;
                }

                if (value.Contains("singular")) word.Number = "Singular";
                else if (value.Contains("dual")) word.Number = "Dual";
                else if (value.Contains("plural")) word.Number = "Plural";
            }
        }
    }

    public void Regroup() {
        Total = 0;
        if (App.global.Transcript == 0) {
            for (int i = 0; i < items.Count; i++) {
                Total += counts[i].Item1;
                items[i].Count = counts[i].Item1;
                items[i].OnPropertyChanged(nameof(NotVerbGroup.Count));
            }
        }
        else {
            for (int i = 0; i < items.Count; i++) {
                Total += counts[i].Item2;
                items[i].Count = counts[i].Item2;
                items[i].OnPropertyChanged(nameof(NotVerbGroup.Count));
            }
        }
        currentTranscript = App.global.Transcript;
        OnPropertyChanged(nameof(Total));
    }
}

class NotVerbGroup : Notifiable {
    public string SubTag { get; set; }
    public string Number { get; set; }
    public string Gender { get; set; }
    public int Count { get; set; }
}
