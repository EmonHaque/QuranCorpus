﻿public interface IHaveIcon
{
    string Icon { get; }
}

