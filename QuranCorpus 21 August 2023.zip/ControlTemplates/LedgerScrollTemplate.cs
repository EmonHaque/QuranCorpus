﻿public class LedgerScrollTemplate : ControlTemplate
{
    public LedgerScrollTemplate(bool canContentScroll = true) {
        TargetType = typeof(ScrollViewer);
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var vScroll = new FrameworkElementFactory(typeof(ScrollBar)) { Name = "PART_VerticalScrollBar" };
        var content = new FrameworkElementFactory(typeof(ScrollContentPresenter));

        col2.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.ScrollBarThickness));
        vScroll.SetValue(Grid.ColumnProperty, 1);

        vScroll.SetValue(ScrollBar.ViewportSizeProperty, new TemplateBindingExtension(ScrollViewer.ViewportHeightProperty));
        vScroll.SetBinding(ScrollBar.ValueProperty, new Binding() {
            Path = new PropertyPath(nameof(ScrollViewer.VerticalOffset)),
            RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent),
            Mode = BindingMode.OneWay
        });
        vScroll.SetBinding(ScrollBar.MaximumProperty, new Binding() {
            Path = new PropertyPath(nameof(ScrollViewer.ScrollableHeight)),
            RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent),
            Mode = BindingMode.OneWay
        });
        vScroll.SetBinding(ScrollBar.VisibilityProperty, new Binding() {
            Path = new PropertyPath(nameof(ScrollViewer.ComputedVerticalScrollBarVisibility)),
            RelativeSource = new RelativeSource(RelativeSourceMode.TemplatedParent),
            Mode = BindingMode.OneWay
        });
        content.SetValue(ScrollContentPresenter.MarginProperty, new Thickness(0, 0, Constants.ScrollPresenterMargin, 0));
        content.SetValue(ScrollContentPresenter.CanContentScrollProperty, canContentScroll);

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(content);
        grid.AppendChild(vScroll);
        VisualTree = grid;
    }
}
