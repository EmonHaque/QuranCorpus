﻿class LemmaVM : Notifiable {
    CancellationTokenSource terminator;
    Task task;
    List<Lemma> filtered, source;
    public int currentTranscript;

    object selected;
    public object Selected {
        get { return selected; }
        set {
            if (value is null) {
                selected = null;
                return;
            }
            //if (value is not Lemma lemma) return;
            //if (lemma.Items is not null) return;
            if (value.Equals(selected)) return;

            selected = value;

            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).Pages.SelectedPage is LemmaPage page) {
                page.setContent(selected);
            }
        }
    }
    string query;
    public string Query {
        get { return query; }
        set {
            query = value;
            if (task != null && !task.IsCompleted) {
                // will it ever come here?
                // if it does what'll be the state of terminator in the next task?
                // will IsCancellationRequested be true
                terminator.Cancel();
            }
            filter(query);
        }
    }
    public string Covered { get; set; }
    public bool WasRightClicked { get; set; }
    public string Count { get; set; }
    public bool IsInProgress { get; set; }
    public List<Lemma> Lemmas { get; set; }

    public LemmaVM() {
        terminator = new CancellationTokenSource();
        filtered = new List<Lemma>();
        
        Task.Run(() => {
            int count = 0;
            source = new List<Lemma>();
            foreach (var link in App.links) {
                if (!string.IsNullOrEmpty(link.Root)) continue;
                if (string.IsNullOrEmpty(link.LemmaCorpus)) continue;
                count++;

                var tags = link.Tags.Split('|');
                var indices = link.LemmaIndices.Split('|');
                var corpusLemmas = link.LemmaCorpus.Split('|');
                var simpleLemmas = link.LemmaSimple.Split('|');
                var corpusSegments = link.SegmentsCorpus.Split('|');
                var simpleSegments = link.SegmentsSimple.Split('|');

                for (int i = 0; i < indices.Length; i++) {
                    int index = Convert.ToInt32(indices[i]);
                    var pos = App.tags[Convert.ToInt32(tags[index])].Name;
                    var corpusLemma = App.lemmas[Convert.ToInt32(corpusLemmas[i])];
                    var simpleLemma = App.lemmas[Convert.ToInt32(simpleLemmas[i])];
                    var corpus = App.segments[Convert.ToInt32(corpusSegments[index])];
                    var simple = App.segments[Convert.ToInt32(simpleSegments[index])];

                    var references = new List<string>() { link.Reference };
                    source.Add(new Lemma() {
                        Transcripts = new string[] { corpus, simple },
                        Root = new string[] { corpusLemma, simpleLemma },
                        POS = pos,
                        References = references
                    });
                }
            }
            var groups = source.GroupBy(x => x.Root[App.global.Transcript]).ToList();
           
            foreach (var group in groups) {
                if (group.Count() == 1) {
                    filtered.Add(new Lemma(group.ElementAt(0)));
                    continue;
                }
                var transcripts = new string[2];
                transcripts[App.global.Transcript] = group.Key;

                var le = new Lemma() { Transcripts = transcripts };
                le.Items = new List<Lemma>();
                foreach (var item in group) {
                    var match = le.Items.FirstOrDefault(x => x.Transcripts[App.global.Transcript].Equals(item.Transcripts[App.global.Transcript]));
                    if (match is null) {
                        le.Items.Add(new Lemma(item));
                    }
                    else {
                        match.References.AddRange(item.References);
                    }
                }
                if(le.Items.Count == 1) {
                    filtered.Add(le.Items[0]);
                }
                else {
                    le.POS = string.Join("|", le.Items.Select(x => x.POS).Distinct());
                    filtered.Add(le);
                }
            }
            currentTranscript = App.global.Transcript;
            filter("");
            App.Current.Dispatcher.Invoke(() => {
                Covered = count.ToString("N0") + " words covered";
                OnPropertyChanged(nameof(Covered));
            });
        });
    }

    public void Regroup() {
        filtered.Clear();
        var groups = source.GroupBy(x => x.Root[App.global.Transcript]).ToList();

        foreach (var group in groups) {
            if (group.Count() == 1) {
                filtered.Add(new Lemma(group.ElementAt(0)));
                continue;
            }
            var transcripts = new string[2];
            transcripts[App.global.Transcript] = group.Key;

            var le = new Lemma() { Transcripts = transcripts };
            le.Items = new List<Lemma>();
            foreach (var item in group) {
                var match = le.Items.FirstOrDefault(x => x.Transcripts[App.global.Transcript].Equals(item.Transcripts[App.global.Transcript]));
                if (match is null) {
                    le.Items.Add(new Lemma(item));
                }
                else {
                    match.References.AddRange(item.References);
                }
            }
            if (le.Items.Count == 1) {
                filtered.Add(le.Items[0]);
            }
            else {
                le.POS = string.Join("|", le.Items.Select(x => x.POS).Distinct());
                filtered.Add(le);
            }
        }

        filter(query);
    }

    void filter(string query) {
        IsInProgress = true;
        OnPropertyChanged(nameof(IsInProgress));

        task = Task.Run(() => {
            int rootCount = 0;
            int formCount = 0;
            List<Lemma> list = new();

            if (string.IsNullOrEmpty(query)) {
                for (int i = 0; i < filtered.Count; i++) {
                    rootCount++;
                    formCount += filtered[i].Items is null ? 1 : filtered[i].Items.Count;
                    list.Add(filtered[i]);
                }
            }
            else {
                list = new List<Lemma>();
                var lower = query.ToLower();
                for (int i = 0; i < filtered.Count; i++) {
                    if (terminator.IsCancellationRequested) break;
                    if (!filtered[i].POS.ToLower().Contains(lower)) continue;

                    list.Add(filtered[i]);
                    rootCount++;
                    formCount += filtered[i].Items is null ? 1 : filtered[i].Items.Count;
                }
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    Count = $"{formCount.ToString("N0")} spelling in {rootCount.ToString("N0")} lemma";
                    IsInProgress = false;
                    Lemmas = list;
                    OnPropertyChanged(nameof(Count));
                    OnPropertyChanged(nameof(IsInProgress));
                    OnPropertyChanged(nameof(Lemmas));
                });
            }
            else {
                App.Current.Dispatcher.Invoke(() => {
                    IsInProgress = false;
                    OnPropertyChanged(nameof(IsInProgress));
                });
            }
        }, terminator.Token);
    }
}