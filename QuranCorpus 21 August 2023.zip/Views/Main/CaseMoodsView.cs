﻿class CaseMoodsView : View {
    public override string Icon => Icons.TrendingUp;
    public override FrameworkElement container => grid;
    Grid grid;

    public CaseMoodsView() {
        grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(){ Height = new GridLength(1.3, GridUnitType.Star)}
            }
        };
        AddVisualChild(grid);
    }

    public override void OnFirstSight() {
        base.OnFirstSight();
        var cases = new CaseView();
        var moods = new MoodView();

        Grid.SetRow(moods, 1);
        grid.Children.Add(cases);
        grid.Children.Add(moods);

        cases.OnFirstSight();
        moods.OnFirstSight();
    }
}
