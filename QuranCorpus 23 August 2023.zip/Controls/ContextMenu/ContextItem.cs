﻿class ContextItem {
    public string Icon { get; set; }
    public string Text { get; set; }
    public Action Command { get; set; }
}
