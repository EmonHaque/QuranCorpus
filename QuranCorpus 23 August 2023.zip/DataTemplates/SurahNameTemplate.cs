﻿class SurahName : Grid {
    Surah name;
    Run english, englishNo, verses, place, order;
    TextBlockEnglish placeBlock;
    TextBlockArabic arabicNo, arabic;
    DependencyPropertyDescriptor fontDescriptor;

    public SurahName() {
        english = new Run();
        englishNo = new Run();
        verses = new Run();
        place = new Run();
        order = new Run() { Foreground = Brushes.LightGray };    

        arabicNo = new TextBlockArabic();
        arabic = new TextBlockArabic() { Margin = new Thickness(5,0,0,0) };
        var arabicName = new StackPanel() {
            Orientation = Orientation.Horizontal,
            Children = { arabicNo, arabic }
        };
        var versesBlock = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center,
            Foreground = Brushes.Gray,
            Inlines = { verses, new Run(" ayah")}
        };
        var arabicPanel = new DockPanel() {
            Children = { arabicName, versesBlock }
        };
        var englishBlock = new TextBlockEnglish() {
            Inlines = { englishNo, new Run(") "), english }
        };
        placeBlock = new TextBlockEnglish() { 
            Inlines = { place, new Run(" "), order },
            Foreground = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Right
        };
        var englishPanel = new DockPanel() {
            FlowDirection = FlowDirection.LeftToRight,
            Children = { englishBlock, placeBlock }
        };

        SetRow(englishPanel, 1);
        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition());
        Children.Add(arabicPanel);
        Children.Add(englishPanel);

        Loaded += onLoaded;
        Unloaded += onUnloaded;
        fontDescriptor = DependencyPropertyDescriptor.FromProperty(Run.FontFamilyProperty, typeof(Run));
    }

    public override void EndInit() {
        base.EndInit();
        name = (Surah)DataContext;
        var id = name.Id.ToString();
        arabicNo.Text = id.toArabicNo();
        englishNo.Text = id;
        english.Text = name.Transliteration;
        english.ToolTip = name.Meaning;
        verses.Text = name.Verses.ToString();
        place.Text = name.Place;
        order.Text = name.Order.ToString();

        if (!(App.global.ArabicFont.Equals("KFGQPC Uthmanic HAFS") ||
                App.global.ArabicFont.Equals("me quran"))) {
            arabicNo.Text += ')';
        }
        arabic.Text = 
            App.global.Transcript == 0 ? 
            name.Full.toArabic() : 
            name.Simple.toArabic();

        App.global.PropertyChanged += onTranscriptChanged;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        fontDescriptor.AddValueChanged(arabicNo, onFontChanged);
    }

    void onTranscriptChanged(object? sender, PropertyChangedEventArgs e) {
        if (!e.PropertyName.Equals(nameof(App.global.Transcript))) return;
        arabic.Text =
            App.global.Transcript == 0 ?
            name.Full.toArabic() :
            name.Simple.toArabic();
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        fontDescriptor.RemoveValueChanged(arabicNo, onFontChanged);
    }

    void onFontChanged(object? sender, EventArgs e) {
        if (App.global.ArabicFont.Equals("KFGQPC Uthmanic HAFS") ||
            App.global.ArabicFont.Equals("me quran")) {
            if (arabicNo.Text.EndsWith(')')) {
                arabicNo.Text = arabicNo.Text.Remove(arabicNo.Text.Length - 1);
            }
        }
        else {
            if (!arabicNo.Text.EndsWith(')')) {
                arabicNo.Text += ')';
            }
        }
    }
}
class SurahNameTemplate : DataTemplate {
    public SurahNameTemplate() {
        VisualTree = new FrameworkElementFactory(typeof(SurahName));
    }
}
