﻿using System.Windows.Documents;
using System.Windows.Navigation;

class AboutView : CardView {
    public override string Icon => Icons.InfoCircle;

    public override void OnFirstSight() {
        base.OnFirstSight();
        initializeUI();
    }

    void initializeUI() {
        var externalBorder = new Border() {
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
            BorderBrush = Brushes.LightGray,
            Child = new TextBlockEnglish() {
                Text = "External resources",
                FontWeight = FontWeights.Bold
            }
        };
        
        var corpusLink = new Hyperlink() {
            NavigateUri = new Uri("http://corpus.quran.com"),
            TextDecorations = null,
            Inlines = {
                new Run("The Quranic Arabic Corpus"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };
        var corpusBlock = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
               new Run("Transcriptions, word segmentations, roots, lemmas and gramatical tags have been taken from the \"Quranic Arabic Corpus (Version 0.4)\". Visit "),
               corpusLink,
               new Run(" for more information. Transliterations, word by word translations, morphological explanations, buckwalter character maps have also been parsed from their site. All their data can be found in the Resource/Corpus folder in eight plain text files and an additional indexing \"link.txt\" file has been added there. Each of those eight files contains unique list and in the \"link.txt\" indices of those lists are stored. Some characters from their transcriptions have been removed during rendering, eg. damma removed when it's followed by waw. See 'toArabic(...)' extension methods for the detail of removal. Some lemmas end with the character '2' in their Version 0.4 text file and that ending character '2' has been removed.")
            }
        };

        var tanzilLink = new Hyperlink() {
            NavigateUri = new Uri("https://tanzil.net"),
            TextDecorations = null,
            Inlines = {
                new Run("Tanzil"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };
        var tanzilBlock = new TextBlockEnglish() {
            Margin = new Thickness(0, 10, 0, 0),
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
                new Run("English translations (1) Saheeh International, (2) A. J. Arberry, (3) Mohammed Marmaduke William Pickthall, (4) Muhammad Sarwar, (5) Mohammad Habib Shakir and (6) Abdullah Yusuf Ali have been taken from "),
                tanzilLink,
                new Run(". All their plain text files are in Resource/Tanzil folder.")
            }
        };

        var arabicFontLink = new Hyperlink() {
            NavigateUri = new Uri("https://arabicfonts.net/"),
            TextDecorations = null,
            Inlines = {
                new Run("Arabic Fonts"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };
        var arabicFontBlock = new TextBlockEnglish() {
            Margin = new Thickness(0, 10, 0, 0),
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
                new Run("Some or all Arabic fonts (1) Al Qalam Quran Majeed Web Regular, (2) Amiri Quran Regular, (3) Scheherazade Regular, (4) KFGQPC Uthman Taha Naskh Regular (5) KFGQPC Uthmanic Script HAFS Regular and (6) me quran have been taken from "),
                arabicFontLink,
                new Run(".")
            }
        };

        var materialDesignLink = new Hyperlink() {
            NavigateUri = new Uri("https://materialdesignicons.com/"),
            TextDecorations = null,
            Inlines = {
                new Run("Material Design"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };
        var materialDesignBlock = new TextBlockEnglish() {
            Margin = new Thickness(0, 10, 0, 0),
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
                new Run("All svg icons have been taken from "),
                materialDesignLink,
                new Run(" and are embedded in the application.")
            }
        };

        var microsoftBlock = new TextBlockEnglish() {
            Margin = new Thickness(0, 10, 0, 0),
            Text = "It's a .net 7 WPF application built with Visual Studio 2022 Community Edition on Windows 11."
        };

        var usageBorder = new Border() {
            Margin = new Thickness(0, 10, 0, 0),
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
            BorderBrush = Brushes.LightGray,
            Child = new TextBlockEnglish() {
                Text = "Usage",
                FontWeight = FontWeights.Bold
            }
        };
        var usageBlock = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
                new Run("In the Home Page, there're two panels, left panel is for pages and the right one is to show five views. In between those panels, there're five icons to change view on the right panel. First one, selected by default, is Surah View. When you right click a Surah, a page is added in the left panel and when you left click a Surah, Surah page will be updated if it is focused or selected."),
                new LineBreak(),
                new LineBreak(),
                new Run("Second view is Root and Lemma view. When you right click on a leaf of the tree, a page will be added in the left panel and when you left click, page will be updated if it's a lemma page and selected. There're few words which don't have a root or lemma in the \"Quranic Arabic Corpus (Version 0.4)\", these are listed in the third view. Same left/right click functionalities for that page as well."),
                new LineBreak(),
                new LineBreak(),
                new Run("There are few words which have been spelled out in the same way but segmented differently and in the fourth view, those words have been listed. Same left right click functionality is available to open or update a Segment Page. In the bottom of the segment page, word reference and probable meanings have been listed. To get into the context, double click the reference/meaning in the list, it'll take you to that ayah of surah."),
                new LineBreak(),
                new LineBreak(),
                new Run("The fifth one is Tag View. You can give a name and create Tag, eg. Musa tag for listing all verses related to Musa. You can select one or more verses from Surah or Lemma pages only and drag selected Ayah(s) on top of your tag and drop to get those added in your tag. Similar left/right clicking functionalities are there to open and update Tag page. You can reorder verses by dragging and dropping verses in Tag page and can remove by right clicking on verse. Last view is global settings for font, font size and translations. Tags are created in a separate Tag folder in the Resource folder of the application. To save your tags, store that folder somewhere else before updating code or application."),
                new LineBreak(),
                new LineBreak(),
                new Run("By hovering over a word in Surah or Tag page you can see relevant information, parsed from the \"Quranic Arabic Corpus\". When you double click a word, a Match page with matching words will be added in the left panel. You can group those matching verses by Tag/Parts of Speech, Spelling variation and Surah. On the top right corner it'll display the mode of searching. First it searches by root, if there's no root it goes with lemma and if neither exist, it goes with the literal. Probable meaning of the word, parsed from \"Quranic Arabic Corpus\", is displayed on third column from the left and when you hover over the arabic, a tooltip will pop up to display the translation, selected in settings view. When you doble click a verse - it will take you to that Surah to read in context."),
                new LineBreak(),
                new LineBreak(),
                new Run("In Surah or Tag page, there's a Pentip icon for selecting more than one translation for that page. In Surah view, there're two search icons, one for searching locally, ie. in that surah, and the other for finding in entire Quran. If you click the global search, a search page will be added in the left panel. Only arabic search is supported and spelling has to be exactly like what's rendered. You can right click and copy arabic and trim with backspace. There's a go to box in Surah page where you can enter an ayah number and hit enter to bring that ayah into view"),
                new LineBreak(),
                new LineBreak(),
                new Run("I haven't tested the application thoroughly so there could be some anomalies and there's no global exception handler so far. You can add, edit code for your own research and education. If you face any issue in understanding code, contact me at emon-haque@hotmail.com for help.")
            }
        };

        Grid.SetRow(corpusBlock, 1);
        Grid.SetRow(tanzilBlock, 2);
        Grid.SetRow(arabicFontBlock, 3);
        Grid.SetRow(materialDesignBlock, 4);
        Grid.SetRow(microsoftBlock, 5);
        Grid.SetRow(usageBorder, 6);
        Grid.SetRow(usageBlock, 7);
        var scroll = new ScrollViewer() {
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Content = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto }
                },
                Children = {
                    externalBorder,
                    corpusBlock,
                    tanzilBlock,
                    arabicFontBlock,
                    microsoftBlock,
                    materialDesignBlock,
                    usageBorder,
                    usageBlock
                }
            }
        };
        setContent(scroll);

        corpusLink.RequestNavigate += onWebRequested;
        tanzilLink.RequestNavigate += onWebRequested;
        arabicFontLink.RequestNavigate += onWebRequested;
        materialDesignLink.RequestNavigate += onWebRequested;
    }

    void onWebRequested(object sender, RequestNavigateEventArgs e) {
        Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri) { UseShellExecute = true });
    }
}
