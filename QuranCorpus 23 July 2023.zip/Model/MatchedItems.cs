﻿class MatchedItems {
    public string Header { get; set; }
    public List<Match> Items { get; set; }
}
