﻿class SearchPage : Page {
    public override PageType Type => PageType.Search;
    public override UIElement Content => content;

    Grid content;
    EditText queryBox;
    TextBlock count;
    Translators translators;
    ProgressBar progress;
    ListBox ayahListBox;
    DependencyPropertyDescriptor translatorDescriptor;
    string[] selectedTranslators;
    List<Ayah> ayahs;
    int matchCount;
    CancellationTokenSource terminator;

    public SearchPage() {
        HeaderText = "Search " + ((App)(Application.Current)).Pages.searchPageCount;
        terminator = new CancellationTokenSource();
        queryBox = new EditText() {
            Hint = "Search (arabic)",
            Icon = Icons.Search,
            IsArabic = true,
            IsTrimBottomRequested = true
        };
        count = new TextBlock() {
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(10, 0, 10, 5)
        };
        translators = new Translators() {
            FlowDirection = FlowDirection.LeftToRight,
            HorizontalAlignment = HorizontalAlignment.Left,
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(0, 0, 0, 7)
        };
        Grid.SetColumn(count, 1);
        Grid.SetColumn(translators, 2);
        var toolGrid = new Grid() {
            Margin = new Thickness(0, 0, 0, 10),
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { queryBox, count, translators }
        };
        ayahListBox = new ListBox() {
            FlowDirection = FlowDirection.RightToLeft,
            ItemTemplate = new AyahTemplateDragDrop()
        };
        ayahListBox.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        ayahListBox.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };
        Grid.SetRow(toolGrid, 1);
        Grid.SetRow(ayahListBox, 2);
        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, toolGrid, ayahListBox }
        };
        translatorDescriptor = DependencyPropertyDescriptor.FromProperty(Translators.SelectedProperty, typeof(Translators));
        translatorDescriptor.AddValueChanged(translators, onTranslationChanged);

        queryBox.KeyUp += onQuery;
        ayahListBox.MouseDoubleClick += onDoubleClick;
        selectedTranslators = translators.Selected;
    }

    void onDoubleClick(object sender, MouseButtonEventArgs e) {
        
        if (e.ChangedButton != MouseButton.Left) return;

        var match = (Ayah)ayahListBox.SelectedItem; // null check?
        ((App)Application.Current).Pages.addSurahPage(match.SurahNo + ":" + match.AyahNo + ":");
    }

    void onTranslationChanged(object? sender, EventArgs e) {
        selectedTranslators = translators.Selected;
        if (ayahs is null) return;
        if (selectedTranslators.Length == 0) {
            for (int i = 0; i < ayahs.Count; i++) {
                ayahs[i].Translations = null;
                ayahs[i].OnPropertyChanged(nameof(Ayah.Translations));
            }
            return;
        }
        
        var iterators = new IEnumerator<string>[selectedTranslators.Length];
        var translatorIds = new int[selectedTranslators.Length];
        var liranslatorsName = App.global.TranslationDictionary.Keys.ToList();

        int index = 0;
        foreach (var item in selectedTranslators) {
            var file = App.global.TranslationDictionary[item];
            var lines = System.IO.File.ReadLines("Resources/Tanzil/" + file);
            var iterator = lines.GetEnumerator();
            iterator.MoveNext();
            iterators[index] = iterator;
            translatorIds[index] = liranslatorsName.IndexOf(item);
            index++;
        }

        for (int i = 0; i < ayahs.Count; i++) {
            var translations = new Translations[iterators.Length];

            for (int j = 0; j < iterators.Length; j++) {
                var reference = ayahs[i].SurahNo + "|" + ayahs[i].AyahNo + "|";
                while (!iterators[j].Current.StartsWith(reference)) iterators[j].MoveNext();
       
                translations[j] = new Translations() {
                    TranslatorId = translatorIds[j],
                    Content = iterators[j].Current.Substring(reference.Length)
                };
            }
            ayahs[i].Translations = translations;
            ayahs[i].OnPropertyChanged(nameof(Ayah.Translations));
        }
        foreach (var iterator in iterators) iterator.Dispose();
    }

    void onQuery(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        if (string.IsNullOrWhiteSpace(queryBox.Text)) return;

        var query = queryBox.Text.Trim();
        progress.IsIndeterminate = true;
        matchCount = 0;
        Task.Run(() => {
            ayahs = getAyahs(query);
            App.Current.Dispatcher.Invoke(() => {
                count.Text = matchCount.ToString("N0") + " matches in " + ayahs.Count.ToString("N0") + " ayahs";
                ayahListBox.ItemsSource = ayahs;
                progress.IsIndeterminate = false;
            });
        }, terminator.Token);
    }

    List<Ayah> getAyahs(string query) {
        var list = new List<Ayah>();

        IEnumerator<string>[] iterators = null;
        int[] translatorIds = null;

        if (selectedTranslators.Length > 0) {
            iterators = new IEnumerator<string>[selectedTranslators.Length];
            translatorIds = new int[selectedTranslators.Length];
            var translatorNames = App.global.TranslationDictionary.Keys.ToList();

            int index = 0;
            foreach (var item in selectedTranslators) {
                var file = App.global.TranslationDictionary[item];
                var lines = System.IO.File.ReadLines("Resources/Tanzil/" + file);
                var iterator = lines.GetEnumerator();
                iterator.MoveNext();
                iterators[index] = iterator;
                translatorIds[index] = translatorNames.IndexOf(item);
                index++;
            }
        }

        var linkIterator = App.links.GetEnumerator();
        linkIterator.MoveNext();

        StringBuilder builder = new();
        int linkIndex = 0;

        while (linkIndex < App.links.Count) {
            if (terminator.IsCancellationRequested) break;

            var item = linkIterator.Current;
            var ayah = item.Reference.Substring(0, item.Reference.LastIndexOf(':') + 1);
            List<Word> tempWords = new();

            while (linkIterator.Current.Reference.StartsWith(ayah)) {
                var segments = item.Segments.Split('|');
                for (int i = 0; i < segments.Length; i++) {
                    segments[i].toArabic(segments, builder);
                }
                builder.Append(' ');

                tempWords.Add(new Word() {
                    Reference = item.Reference,
                    Transliteration = App.transliterations[Convert.ToInt32(item.Transliteration)],
                    Tags = item.Tags,
                    Segments = item.Segments,
                    Lemmas = item.Lemmas,
                    LemmaIndices = item.LemmaIndices,
                    Meaning = App.meanings[Convert.ToInt32(item.Meaning)],
                    Explanation = App.explanations[Convert.ToInt32(item.Explanation)]
                });
                linkIterator.MoveNext();
                item = linkIterator.Current;
                linkIndex++;
                if (linkIndex == App.links.Count) break;
            }
            
            ayah = builder.ToString();
            builder.Clear();

            if (ayah.Contains(query)) {
                var parts = tempWords[0].Reference.Split(':');
                list.Add(new Ayah() {
                    SurahNo = parts[0],
                    AyahNo = parts[1],
                    Words = tempWords
                });
                if (selectedTranslators.Length > 0) {
                    var reference = parts[0] + "|" + parts[1] + "|";
                    var translations = new Translations[iterators.Length];
                    for (int j = 0; j < iterators.Length; j++) {
                        while (!iterators[j].Current.StartsWith(reference)) iterators[j].MoveNext();
                        translations[j] = new Translations() {
                            TranslatorId = translatorIds[j],
                            Content = iterators[j].Current.Substring(reference.Length)
                        };
                    }
                    list[list.Count - 1].Translations = translations;
                }

                parts = query.Split(' ');
                var words = ayah.Split(' ');
                int count = 0;

                if (parts.Length > 1) {
                    while (count < words.Length) {
                        while (!words[count].EndsWith(parts[0], StringComparison.Ordinal)) {
                            count++;
                            if (count == words.Length) break;
                        }
                        if (count == words.Length) break;

                        int index = count + 1;
                        int length = count + parts.Length - 1;
                        bool isMatch = true;
                        int partIndex = 1;
                        for (int j = index; j < length; j++) {
                            if (words[j].Equals(parts[partIndex++])) continue;
                            isMatch = false;
                            break;
                        }
                        if (isMatch) {
                            if (words[length].StartsWith(parts[parts.Length - 1], StringComparison.Ordinal)) {
                                length++;
                                for (int j = count; j < length; j++) {
                                    tempWords[j].IsHighlighted = true;
                                }
                                matchCount++;
                            }
                        }
                        count += parts.Length;
                    }
                }
                else {
                    for (int j = 0; j < words.Length; j++) {
                        if (!words[j].Contains(query)) continue;
                        tempWords[j].IsHighlighted = true;
                        matchCount++;
                    }
                }
            }
        }

        if(iterators is not null) {
            foreach (var iterator in iterators) iterator.Dispose();
        }
        
        linkIterator.Dispose();
        return list;
    }

    protected override void unload() {
        queryBox.KeyUp -= onQuery;
        ayahListBox.MouseDoubleClick -= onDoubleClick;
        translatorDescriptor.RemoveValueChanged(translators, onTranslationChanged);
        base.unload();
    }
}
