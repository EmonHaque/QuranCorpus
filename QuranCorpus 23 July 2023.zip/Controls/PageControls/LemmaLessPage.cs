﻿class LemmaLessPage : Page {
    public override PageType Type => PageType.LemmaLess;
    public override UIElement Content => content;

    Grid content;
    ProgressBar progress;
    DragListBox ayahListBox;
    CancellationTokenSource terminator;

    List<Match> matches;

    public LemmaLessPage() {
        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };
        ayahListBox = new DragListBox() {
            ItemTemplate = new MatchTemplate()
        };
        ayahListBox.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        Grid.SetRow(ayahListBox, 1);

        content = new Grid() {
            RowDefinitions = {
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, ayahListBox }
        };
        terminator = new CancellationTokenSource();
        ayahListBox.MouseDoubleClick += onDoubleLick;
    }

    public LemmaLessPage(RootLemmaFree lemma) : this() {
        setHeader(lemma);
        Task.Run(() => {
            matches = getMatches(lemma);
            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    ayahListBox.ItemsSource = matches;
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    public void setContent(RootLemmaFree lemma) {
        setHeader(lemma);
        Task.Run(() => {
            matches = getMatches(lemma);
            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    ayahListBox.ItemsSource = matches;
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    void setHeader(RootLemmaFree lemma) {
        HeaderText = "(" + lemma.References.Count.ToString("N0") + ") " + lemma.Content;
        progress.IsIndeterminate = true;
    }

    List<Match> getMatches(RootLemmaFree lemma) {
        var matches = new List<Match>();
        var fileName = App.global.TranslationDictionary[App.global.Translation];
        var lines = System.IO.File.ReadLines("Resources/Tanzil/" + fileName);
        var iterator = lines.GetEnumerator();
        iterator.MoveNext();
        string line = iterator.Current;

        var linkIterator = App.links.GetEnumerator();
        linkIterator.MoveNext();
        var item = linkIterator.Current;

        foreach (var reference in lemma.References) {
            if (terminator.IsCancellationRequested) break;

            var ayahNo = reference.Substring(0, reference.LastIndexOf(':') + 1);
            var wordNo = reference.Substring(reference.LastIndexOf(':'));
            var ayahTxt = ayahNo.Substring(0, ayahNo.Length - 1).Replace(':', '|');

            if (!line.StartsWith(ayahTxt)) {
                while (!iterator.Current.StartsWith(ayahTxt)) iterator.MoveNext();
                line = iterator.Current;
            }

            var no = Convert.ToInt32(wordNo.Substring(1));
            int count = 1;

            bool hasLeading = no != 1;
            bool hasTrailing = false;
            bool fromBeginning = no == 1;

            if (!item.Reference.Equals(reference)) {
                while (!linkIterator.Current.Reference.StartsWith(reference)) linkIterator.MoveNext();
                item = linkIterator.Current;
            }

            List<Word> words = new();
            var index = App.links.IndexOf(item);
            int startIndex = index - no + 1;

            if (hasLeading && no < 6) {
                index = startIndex;
                fromBeginning = true;
            }

            while (true) {
                words.Add(new Word() {
                    Reference = App.links[index].Reference,
                    Segments = App.links[index].Segments
                });
                index++;
                if (index == App.links.Count) {
                    hasTrailing = false;
                    break;
                }
                count++;
                if (count > 10) {
                    hasTrailing = App.links[index].Reference.StartsWith(ayahNo);
                    break;
                }

                if (!App.links[index].Reference.StartsWith(ayahNo)) {
                    if (!fromBeginning) {
                        var lastIndex = index - words.Count;
                        index = lastIndex - 10 + words.Count;
                        if (index < startIndex) {
                            index = startIndex;
                            hasLeading = false;
                        }
                        count = 0;
                        while (index < lastIndex) {
                            words.Insert(count, new Word() {
                                Reference = App.links[index].Reference,
                                Segments = App.links[index].Segments
                            });
                            count++;
                            index++;
                        }
                    }
                    break;
                }
            }

            if (!fromBeginning && hasLeading) words.Insert(0, new Word() { Segments = "..." });
            if (hasTrailing) words.Add(new Word() { Segments = "..." });

            matches.Add(new Match() {
                Reference = reference,
                WordNo = wordNo,
                Transliteration = App.transliterations[Convert.ToInt32(item.Transliteration)],
                Meaning = App.meanings[Convert.ToInt32(item.Meaning)],
                Tag = item.Tags,
                Words = words,
                Translation = line
            });
        }

        iterator.Dispose();
        return matches;
    }

    void onDoubleLick(object sender, MouseButtonEventArgs e) {
        if (e.ChangedButton != MouseButton.Left) return;
        var selected = (Match)ayahListBox.SelectedItem;
        ((App)Application.Current).Pages.addSurahPage(selected.Reference);
    }

    protected override void unload() {
        ayahListBox.MouseDoubleClick -= onDoubleLick;
        terminator.Cancel();
        terminator.Dispose();
        base.unload();
    }
}
