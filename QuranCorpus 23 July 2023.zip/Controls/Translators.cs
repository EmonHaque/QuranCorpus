﻿class Translators : ActionButton {
    Grid grid;
    BiState[] states;
    TextBlockEnglish[] names;
    Popup pop;

    public Translators() : base() {
        grid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition()
            }
        };
        states = new BiState[App.global.TranslationDictionary.Count];
        names = new TextBlockEnglish[App.global.TranslationDictionary.Count];

        for (int i = 0; i < App.global.TranslationDictionary.Count; i++) {
            grid.RowDefinitions.Add(new RowDefinition());
            var state = new BiState();
            var currentTranslator = App.global.TranslationDictionary.Keys.ElementAt(i);
            var name = new TextBlockEnglish() {
                Text = App.global.TranslationDictionary.Keys.ElementAt(i),
                Margin = new Thickness(10, 0, 0, 0)
            };
            Grid.SetColumn(name, 1);
            Grid.SetRow(state, i);
            Grid.SetRow(name, i);
            grid.Children.Add(state);
            grid.Children.Add(name);
            states[i] = state;
            names[i] = name;

            if (currentTranslator.Equals(App.global.Translation)) {
                state.IsTrue = true;
                Selected = new string[] { name.Text };
            }
        }

        grid.Measure(new Size(double.PositiveInfinity, double.PositiveInfinity));

        pop = new Popup() {
            AllowsTransparency = true,
            PlacementTarget = this,
            VerticalOffset = 5,
            HorizontalOffset = -(grid.DesiredSize.Width + Width),
            StaysOpen = false,
            Child = new Border() {
                BorderThickness = new Thickness(Constants.BottomLineThickness),
                Padding = new Thickness(10),
                CornerRadius = new CornerRadius(5),
                BorderBrush = Brushes.LightGray,
                Background = Constants.Background,
                Child = grid
            }
        };
        pop.Closed += onPopupClosed;

        Icon = Icons.PenTip;
        Command = () => pop.IsOpen = true;
        ToolTip = "Translations";
    }

    void onPopupClosed(object? sender, EventArgs e) {
        var names = new string[states.Length];
        int count = 0;
        for (int i = 0; i < states.Length; i++) {
            if (!states[i].IsTrue) continue;
            names[count] = this.names[i].Text;
            count++;
        }
        Array.Resize(ref names, count);

        count = 0;
        bool isSame = names.Length == Selected.Length;
        if (isSame) {
            foreach (var item in Selected) {
                if (!item.Equals(names[count])) {
                    isSame = false;
                }
            }
        }
        if (isSame) return;
        Selected = names;
    }

    public string[] Selected {
        get { return (string[])GetValue(SelectedProperty); }
        set { SetValue(SelectedProperty, value); }
    }

    public static readonly DependencyProperty SelectedProperty =
        DependencyProperty.Register("Selected", typeof(string[]), typeof(Translators), new PropertyMetadata(null));


}
