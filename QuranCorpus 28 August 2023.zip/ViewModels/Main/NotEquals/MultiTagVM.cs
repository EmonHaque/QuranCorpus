﻿class MultiTagVM : Notifiable {
    public int currentTranscript;
    List<Tuple<string, string[], string>> source;
    List<MultiTag> nounsAndAdjectives, others;
    int selectedCheck;
    public int SelectedCheck {
        get => selectedCheck;
        set {
            selectedCheck = value;
            if (others is null) return;
            Items = CollectionViewSource.GetDefaultView(value == 0 ? others : nounsAndAdjectives);
            Items.Filter = filter;
            OnPropertyChanged(nameof(Items));
        }
    }
    string query;
    public string Query {
        get { return query; }
        set { 
            query = value;
            Items.Refresh();
        }
    }

    public MultiTag Selected { get; set; }
    public bool WasRightClicked { get; set; }
    public ICollectionView Items { get; set; }

    public MultiTagVM() {
        Task.Run(() => {
            source = new List<Tuple<string, string[], string>>();

            for (int i = 0; i < App.links.Count; i++) {
                var link = App.links[i];
                var ts = link.Tags.Split('|');
                var cs = link.SpellingGroupCorpus.Split('|');
                var ss = link.SpellingGroupSimple.Split('|');
                for (int j = 0; j < ts.Length; j++) {
                    source.Add(new Tuple<string, string[], string>(
                        App.tags[Convert.ToInt32(ts[j])].Name,
                        new string[] {
                            App.spellings[Convert.ToInt32(cs[j])],
                            App.spellings[Convert.ToInt32(ss[j])]
                        },
                        link.Reference));
                }
            }
            Regroup();
        });
    }

    public void Regroup() {
        Task.Run(() => {
            var groups = source
                .GroupBy(x => x.Item2[App.global.Transcript])
                .Select(x => new {
                    x.Key,
                    Value = x.GroupBy(x => x.Item1).Where(x => x.Count() > 1).ToList()
                })
                .Where(x => x.Value.Count > 1)
                .Select(x => new {
                    x.Key,
                    Value = x.Value.Select(x => new {
                        x.Key,
                        Value = x.Select(x => x.Item3).ToList()
                    }).ToList()
                }).ToList();

            var x = groups.Where(
                x => x.Value.Count == 2 &&
                (x.Value[0].Key.Equals("N") || x.Value[0].Key.Equals("ADJ")) &&
                x.Value[1].Key.Equals("N") || x.Value[1].Key.Equals("ADJ"))
                .ToList();

            var y = groups.Except(x).ToList();

            nounsAndAdjectives = x.Select(x => new MultiTag() {
                Spelling = x.Key,
                Tags = string.Join(", ", x.Value.Select(x => x.Key)),
                References = x.Value.SelectMany(x => x.Value).ToList()
            }).ToList();

            others = y.Select(x => new MultiTag() {
                Spelling = x.Key,
                Tags = string.Join(", ", x.Value.Select(x => x.Key)),
                References = x.Value.SelectMany(x => x.Value).ToList()
            }).ToList();

            currentTranscript = App.global.Transcript;

            App.Current.Dispatcher.Invoke(() => {
                Items = CollectionViewSource.GetDefaultView(SelectedCheck == 0 ? others : nounsAndAdjectives);
                Items.Filter = filter;
                OnPropertyChanged(nameof(Items));
            });
        });
    }

    bool filter (object o) {
        if (string.IsNullOrEmpty(Query)) return true;
        var tag = (MultiTag)o;
        return tag.Spelling.Contains(Query);
    }
}