﻿class PronounVM : Notifiable {
    List<Conjugated> source;
    public List<Conjugated> filtered;

    string selected;
    public string Selected {
        get { return selected; }
        set {
            if (value is null) {
                return;
            }
            if (value.Equals(selected)) return;

            selected = value;
            filtered = source.Where(x => x.Person.Equals(value)).ToList();

            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }

            if (((App)Application.Current).Pages.SelectedPage is PronounPage page) {
                page.setContent(filtered);
            }
        }
    }
    public List<string> Items { get; set; }
    public bool WasRightClicked { get; set; }
    public bool IsInProgress { get; set; }

    public PronounVM() {
        IsInProgress = true;

        Task.Run(() => {
            source = new List<Conjugated>();
            var pronIndex = App.tags.IndexOf(App.tags.First(x => x.Name.Equals("PRON"))).ToString();

            for (int i = 0; i < App.links.Count; i++) {
                var tas = App.links[i].Tags.Split('|');
                if (tas.Length == 1) continue;

                for (int index = 0; index < tas.Length; index++) {
                    if (!tas[index].Equals(pronIndex)) continue;

                    var link = App.links[i];
                    string pronounForm = "";
                    string pronounDetail = "";
                    var detailArray = link.Details.Split(',')[index].Split('|');
                    if (detailArray.Length > 1) {
                        pronounDetail = App.details[Convert.ToInt32(detailArray[0])].Value;
                        pronounForm = App.details[Convert.ToInt32(detailArray[1])].Name;
                    }
                    else pronounForm = App.details[Convert.ToInt32(detailArray[0])].Name;

                    var corpus = link.SpellingGroupCorpus.Split('|');
                    var simple = link.SpellingGroupSimple.Split('|');

                    var word = new Conjugated() {
                        Person = pronounForm,
                        As = pronounDetail,
                        To = App.tags[Convert.ToInt32(tas[index - 1])].Name,
                        Word = new string[] {
                            App.spellings[Convert.ToInt32(corpus[index - 1])],
                            App.spellings[Convert.ToInt32(simple[index - 1])]
                        },
                        Pronoun = new string[] {
                            App.spellings[Convert.ToInt32(corpus[index])],
                            App.spellings[Convert.ToInt32(simple[index])]
                        }
                    };
                    var match = source.FirstOrDefault(
                        x => x.Person.Equals(word.Person) &&
                        x.To.Equals(word.To) &&
                        x.Word[0].Equals(word.Word[0]) &&
                        x.Word[1].Equals(word.Word[1]) &&
                        x.Pronoun[0].Equals(word.Pronoun[0]) &&
                        x.Pronoun[1].Equals(word.Pronoun[1]));

                    if (match is null) {
                        source.Add(word);
                        word.References.Add(link.Reference);
                    }
                    else match.References.Add(link.Reference);
                }
            }

            Items = source.Select(x => x.Person).Distinct().ToList();
            IsInProgress = false;

            App.Current.Dispatcher.Invoke(() => {
                OnPropertyChanged(nameof(Items));
                OnPropertyChanged(nameof(IsInProgress));
            });
        });
    }
}
