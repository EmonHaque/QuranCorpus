﻿class TextBlockEnglish : TextBlock {

    public TextBlockEnglish()
    {
        SetBinding(FontSizeProperty, new Binding() {
            Path = new PropertyPath(nameof(Global.EnglishFontSize)),
            Source = App.global,
            Mode = BindingMode.TwoWay
        });
    }
}
