﻿class Global : Notifiable {
    double arabicFontSize;
    public double ArabicFontSize {
        get { return arabicFontSize; }
        set { arabicFontSize = value; OnPropertyChanged(nameof(ArabicFontSize)); }
    }

    double englishFontSize;
    public double EnglishFontSize {
        get { return englishFontSize; }
        set { englishFontSize = value; OnPropertyChanged(nameof(EnglishFontSize)); }
    }
    string arabicFont;
    public string ArabicFont {
        get { return arabicFont; }
        set {
            if (value is null) return;
            arabicFont = value;
            ArabicFontFamily = new FontFamily(System.IO.Path.GetFullPath("Resources/Fonts/#") + FontDictionary[ArabicFont]);
            OnPropertyChanged(nameof(ArabicFontFamily));
        }
    }
    int transcript;
    public int Transcript {
        get { return transcript; }
        set { 
            transcript = value == -1 ? 0 : value; 
            OnPropertyChanged(nameof(Transcript)); }
    }

    public string Translation { get; set; }
    public FontFamily ArabicFontFamily { get; set; }
    public Dictionary<string, string> FontDictionary { get; set; }
    public Dictionary<string, string> TranslationDictionary { get; set; }
    public Dictionary<int, string> TranscriptDictionary { get; set; }
    
    public Global() {
        FontDictionary = new Dictionary<string, string>() {
            { "Al Qalam Quran Majeed", "Al Qalam Quran Majeed Web Regular" },
            { "Amiri Quran", "Amiri Quran"},
            { "KFGQPC Uthmanic HAFS", "KFGQPC Uthmanic Script HAFS" },
            { "KFGQPC Uthmanic Taha Naskh", "KFGQPC Uthman Taha Naskh Regular" },
            { "Scheherazade", "Scheherazade" },
            { "me quran", "me_quran" },
            { "Lateef", "Lateef" },
            { "Droid Naskh", "Droid Arabic Naskh" }
        };
        TranslationDictionary = new Dictionary<string, string>() {
            { "Saheeh International", "en.sahih.txt" },
            { "A. J. Arberry", "en.arberry.txt" },
            { "Mohammed Marmaduke William Pickthall", "en.pickthall.txt" },
            { "Muhammad Sarwar", "en.sarwar.txt" },
            { "Mohammad Habib Shakir", "en.shakir.txt" },
            { "Abdullah Yusuf Ali", "en.yusufali.txt" }
        };
        TranscriptDictionary = new Dictionary<int, string>() {
            { 0, "Corpus" },
            { 1, "Simple" },
        };
    }
}
