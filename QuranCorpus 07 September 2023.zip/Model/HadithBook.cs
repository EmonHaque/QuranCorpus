﻿class HadithBook {
    public int Id { get; set; } 
    public string TitleArabic { get; set; }
    public string AuthorArabic { get; set; }
    public string TitleEnglish { get; set; }
    public string AuthorEnglish { get; set; }
}

class HadithChapter {
    public int Id { get; set; }
    public double Chapter { get; set; }
    public string Arabic { get; set; }
    public string English { get; set; }
}

class HadithSection {
    public int Id { get; set; }
    public string Section { get; set; }
    public string Arabic { get; set; }
    public string English { get; set; }
}

class HadithContent {
    public int Book { get; set; }
    public string Number { get; set; }
    public double Chapter { get; set; }
    public double Section { get; set; }
    public string ArabicIsnad { get; set; }
    public string EnglishIsnad { get; set; }
    public string ArabicMatan { get; set; }
    public string EnglishMatan { get; set; }
    public string ArabicGrade { get; set; }
    public string EnglishGrade { get; set; }
    public string ArabicComment { get; set; }
}