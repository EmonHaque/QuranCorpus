﻿class TextBoxEnglish : TextBox {
    ContextPopup context;

    public TextBoxEnglish() {
        ContextMenu = null;
        Background = Brushes.Transparent;
        BorderThickness = new Thickness(0);
        SelectionBrush = new SolidColorBrush(Color.FromArgb(150, 0, 0, 0));
        IsReadOnly = true;

        SetBinding(FontSizeProperty, new Binding() {
            Path = new PropertyPath(nameof(Global.EnglishFontSize)),
            Source = App.global
        });
        context = new ContextPopup(new List<ContextItem>() {
            new ContextItem(){ Icon = Icons.Copy, Text = "copy", Command =  () => ApplicationCommands.Copy.Execute(null, null) }
        });
    }

    protected override void OnMouseRightButtonUp(MouseButtonEventArgs e) {
        base.OnMouseRightButtonUp(e);
        context.IsOpen = true;
    }
}
