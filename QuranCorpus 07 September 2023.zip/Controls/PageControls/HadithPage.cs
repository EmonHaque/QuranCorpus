﻿class HadithPage : Page {
    List<HadithContent> source;
    Run listCount, hadithCount;
    Grid content, leftGrid;
    ProgressBar progress;
    ListBox listBox;
    ItemsControl hadithBox;
    CancellationTokenSource terminator;

    public override PageType Type => PageType.Hadith;
    public override UIElement Content => content;

    public HadithPage() {
        terminator = new CancellationTokenSource();
        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };

        listCount = new Run();
        hadithCount = new Run();
        var counts = new TextBlockEnglish() { 
            Margin = new Thickness(Constants.ScrollBarThickness, 0, 0, 0),
            FlowDirection = FlowDirection.LeftToRight,
            HorizontalAlignment = HorizontalAlignment.Left,
            Inlines = { hadithCount, listCount } 
        };
        listBox = new ListBox() {
            Margin = new Thickness(0, 5, 0, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(ChapterTemplate))
            }
        };
        listBox.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        listBox.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        var verticalSeparator = new Rectangle() {
            Margin = new Thickness(2.5, 0, 2.5, 0),
            HorizontalAlignment = HorizontalAlignment.Right,
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        Grid.SetColumn(counts, 1);
        Grid.SetColumn(listBox, 1);
        Grid.SetRow(listBox, 1);
        Grid.SetRowSpan(verticalSeparator, 2);
        leftGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){Width = GridLength.Auto },
                new ColumnDefinition()
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { counts, listBox, verticalSeparator }
        };

        var toggle = new Toggle() {
            HorizontalAlignment = HorizontalAlignment.Right,
            OnIcon = Icons.DoorClose,
            OffIcon = Icons.DoorOpen,
            OnTip = "hide left panel",
            OffTip = "show left panel",
            Command = () => {
                var col = content.ColumnDefinitions[1];
                col.Width = col.Width.Value == 0 ? new GridLength(300) : new GridLength(0);
            }
        };

        hadithBox = new ItemsControl() {
            Margin = new Thickness(0, 5, 0, 0),
            HorizontalContentAlignment = HorizontalAlignment.Stretch,
            Template = new ScrollableItemsControlTemplate(),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(HadithTemplate))
            },
            ItemsPanel = new ItemsControlPanelTemplate()
        };
        hadithBox.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
        Grid.SetRow(hadithBox, 1);
        var rightGrid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { toggle, hadithBox }
        };

        Grid.SetColumnSpan(progress, 2);
        Grid.SetColumn(leftGrid, 1);
        Grid.SetRow(leftGrid, 1);
        Grid.SetRow(rightGrid, 1);

        content = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(300) }
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, rightGrid, leftGrid }
        };

        listBox.SelectionChanged += onSelectionChanged;
    }

    public HadithPage(HadithBook book) : this() => updateUI(book);

    public void setContent(HadithBook book) => updateUI(book);

    public void updateUI(HadithBook book) {
        HeaderText = book.TitleEnglish;
        progress.IsIndeterminate = true;
        Task.Run(() => {
            if (App.hadithChapters is null) {
                App.hadithChapters =
                    System.IO.File.ReadAllLines("Resources/Hadith/chapters.txt")
                    .Skip(1)
                    .Select(x => x.Split('\t'))
                    .Select(x => new HadithChapter() {
                        Id = Convert.ToInt32(x[0]),
                        Chapter = Convert.ToDouble(x[1]),
                        Arabic = x[2],
                        English = x[3]
                    })
                    .ToList();
                App.hadithSections =
                     System.IO.File.ReadAllLines("Resources/Hadith/sections.txt")
                    .Skip(1)
                    .Select(x => x.Split('\t'))
                    .Select(x => new HadithSection() {
                        Id = Convert.ToInt32(x[0]),
                        Section = x[1],
                        Arabic = x[2],
                        English = x[3]
                    })
                    .ToList();
            }

            var id = book.Id.ToString();
            source = new List<HadithContent>();

            var file = System.IO.File.ReadLines("Resources/Hadith/contents.txt");
            var iterator = file.GetEnumerator();
            iterator.MoveNext();

            while (!iterator.Current.StartsWith(id)) iterator.MoveNext();
            while (iterator.Current.StartsWith(id)) {
                if (terminator.IsCancellationRequested) break;

                var parts = iterator.Current.Split('\t');
                source.Add(new HadithContent() {
                    Book = Convert.ToInt32(parts[0]),
                    Number = parts[1],
                    Chapter = Convert.ToDouble(parts[2]),
                    Section = Convert.ToDouble(parts[3]),
                    ArabicIsnad = parts[4],
                    EnglishIsnad = parts[5],
                    ArabicMatan = parts[6],
                    EnglishMatan = parts[7],
                    ArabicGrade = parts[8],
                    EnglishGrade = parts[9],
                    ArabicComment = parts[10]
                });

                iterator.MoveNext();
                if (iterator.Current is null) break;
            }
            iterator.Dispose();

            var chapters = source
                .GroupBy(x => x.Chapter)
                .Select(x => new {
                    Id = App.hadithChapters.First(y => y.Id == x.Key).Chapter,
                    Value = x,
                    x.Key
                })
                .OrderBy(x => x.Id)
                .Select(x => new Tuple<double, List<HadithContent>>(x.Key, x.Value.Select(x => x).ToList()))
                .ToList();

            App.Current.Dispatcher.Invoke(() => {
                listCount.Text = chapters.Count.ToString() + " chapters";
                hadithCount.Text = source.Count.ToString("N0") + " hadith in ";
                listBox.ItemsSource = chapters;
                progress.IsIndeterminate = false;
            });
        }, terminator.Token);
    }

    void onSelectionChanged(object sender, SelectionChangedEventArgs e) {
        if (listBox.SelectedItem is null) return;
        var group = (Tuple<double, List<HadithContent>>)listBox.SelectedItem;
        hadithBox.ItemsSource = group.Item2;
    }

    protected override void unload() {
        listBox.SelectionChanged -= onSelectionChanged;
        base.unload();
    }

    class ChapterTemplate : Grid {
        TextBlockArabic arabic;
        TextBlockEnglish english, count;

        public ChapterTemplate() {
            FlowDirection = FlowDirection.LeftToRight;
            arabic = new TextBlockArabic() { TextWrapping = TextWrapping.Wrap };
            english = new TextBlockEnglish() { TextWrapping = TextWrapping.Wrap };
            count = new TextBlockEnglish() { VerticalAlignment = VerticalAlignment.Bottom };
            SetColumnSpan(arabic, 2);
            SetRow(english, 1);
            SetRow(count, 1);
            SetColumn(count, 1);
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            RowDefinitions.Add(new RowDefinition());
            RowDefinitions.Add(new RowDefinition());
            Children.Add(arabic);
            Children.Add(english);
            Children.Add(count);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Tuple<double, List<HadithContent>>)DataContext;
            var chapter = App.hadithChapters.First(x => x.Id == c.Item1);
            arabic.Text = chapter.Arabic;
            english.Text = chapter.English;
            count.Text = c.Item2.Count.ToString("N0");
        }
    }

    class HadithTemplate : Border {
        TextBoxArabic arIsnad, arMatan, arGrade, arSection, comment;
        TextBoxEnglish enIsnad, enMatan, enGrade, enSection;

        public HadithTemplate() {
            Padding = new Thickness(0, 2.5, 0, 2.5);
            BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, Constants.BottomLineThickness);

            arSection = new TextBoxArabic() {
                Foreground = Brushes.Wheat,
                TextWrapping = TextWrapping.Wrap
            };
            enSection = new TextBoxEnglish() {
                FlowDirection = FlowDirection.LeftToRight,
                VerticalContentAlignment = VerticalAlignment.Center,
                Foreground = Brushes.Wheat,
                TextWrapping = TextWrapping.Wrap
            };
            
            arIsnad = new TextBoxArabic() {
                Foreground = Brushes.Gray,
                TextWrapping = TextWrapping.Wrap 
            };
            arMatan = new TextBoxArabic() { TextWrapping = TextWrapping.Wrap };
            arGrade = new TextBoxArabic() {
                Foreground = Brushes.LightSkyBlue,
                TextWrapping = TextWrapping.Wrap 
            };
            comment = new TextBoxArabic() {
                Foreground = Brushes.Gray,
                TextWrapping = TextWrapping.Wrap 
            };

            enIsnad = new TextBoxEnglish() { 
                Foreground = Brushes.Gray,
                TextWrapping = TextWrapping.Wrap,
                FlowDirection = FlowDirection.LeftToRight
            };
            enMatan = new TextBoxEnglish() {
                TextWrapping = TextWrapping.Wrap,
                FlowDirection = FlowDirection.LeftToRight
            };
            enGrade = new TextBoxEnglish() {
                Foreground = Brushes.LightSkyBlue,
                TextWrapping = TextWrapping.Wrap,
                FlowDirection = FlowDirection.LeftToRight,
                VerticalContentAlignment = VerticalAlignment.Center
            };

            Grid.SetColumn(enSection, 1);
            Grid.SetColumn(enIsnad, 1);
            Grid.SetColumn(enMatan, 1);
            Grid.SetColumn(enGrade, 1);

            Grid.SetRow(arIsnad, 1);
            Grid.SetRow(arMatan, 2);
            Grid.SetRow(arGrade, 3);
            Grid.SetRow(enIsnad, 1);
            Grid.SetRow(enMatan, 2);
            Grid.SetRow(enGrade, 3);
            Grid.SetRow(comment, 4);

            Grid.SetColumnSpan(comment, 2);

            Child = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition()
                },
                RowDefinitions = {
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition(),
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition() { Height = GridLength.Auto }
                },
                Children = { arSection, enSection, arIsnad, arMatan, arGrade, enIsnad, enMatan, enGrade }
            };
        }

        public override void EndInit() {
            base.EndInit();
            var c = (HadithContent)DataContext;
            arIsnad.Text = c.ArabicIsnad;
            arMatan.Text = c.ArabicMatan;
            arGrade.Text = c.ArabicGrade;

            enIsnad.Text = c.EnglishIsnad;
            enMatan.Text = c.EnglishMatan;
            enGrade.Text = c.EnglishGrade + "\nHadith no. " + c.Number;

            var s = App.hadithSections.First(x => x.Id == c.Section);
            enSection.Text = s.English;
            arSection.Text = s.Arabic;

            enSection.Visibility = s.English.Equals("nan") ? Visibility.Collapsed : Visibility.Visible;
            arSection.Visibility = s.Arabic.Equals("nan") ? Visibility.Collapsed : Visibility.Visible;

            if (string.IsNullOrEmpty(c.ArabicComment)) {
                comment.Visibility = Visibility.Collapsed;
            }
            else {
                comment.Text = c.ArabicComment;
                comment.Visibility = Visibility.Visible;
            }
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            base.OnMouseEnter(e);
            BorderBrush = Brushes.LightGray;
            Background = Constants.BackgroundDark; // transparent background of TextBoxes doesn't work?
        }

        protected override void OnMouseLeave(MouseEventArgs e) {
            base.OnMouseLeave(e);
            BorderBrush = Brushes.Transparent;
            Background = null;
        }
    }
}
