﻿class RootMatrixView : CardView {
    public override string Icon => Icons.Matrix;
    public override bool OverridesToolTip => true;
    public override UIElement Tip => getTip();

    TagCount tags1, tags2;
    TextBlockEnglish count;
    WaterBox query;
    BuckwalterPopup buckwalterPop;
    ListBox list;
    RootMatrixVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new RootMatrixVM();
        DataContext = vm;
        initializeUI();
        bind();

        list.PreviewMouseRightButtonDown += onRightButtonDown;
        list.MouseRightButtonUp += onRightButtonUp;
        tags1.SelectionChanged += onTag1SelectionChanged;
        tags2.SelectionChanged += onTag2SelectionChanged;
    }

    void onTag1SelectionChanged(TagCount.TagItem o) {
        tags2.Visibility = o.Name.StartsWith('q') ? Visibility.Collapsed : Visibility.Visible;
        vm.resetSource(o, tags2.Selected);
    }

    void onTag2SelectionChanged(TagCount.TagItem o) {
        vm.resetSource(null, o);
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) {
        e.Handled = true;
        if (vm.Selected is null) return;
        ((App)Application.Current).FocusedControl.addRootMatrixPage(vm.Selected, vm.roots);
        if (vm.WasRightClicked) {
            vm.WasRightClicked = false;
        }
    }

    void onRightButtonDown(object sender, MouseButtonEventArgs e) => vm.WasRightClicked = true;

    void initializeUI() {
        tags1 = new TagCount() {
            FlowDirection = FlowDirection.LeftToRight,
            Items = vm.tags1
        };
        tags2 = new TagCount() {
            FlowDirection = FlowDirection.LeftToRight,
            Items = vm.tags2
        };
        tags1.Selected = tags1.Items.First();
        tags2.Selected = tags2.Items.First();

        var tagPanel = new StackPanel() {
            Children = { tags1, tags2 }
        };

        query = new WaterBox() {
            Icon = Icons.Search,
            Hint = "Root (buckwalter)"
        };
        buckwalterPop = new BuckwalterPopup();
        count = new TextBlockEnglish() { Margin = new Thickness(5,0,0,0)};

        Grid.SetColumn(buckwalterPop, 1);
        Grid.SetColumn(count, 2);
        var queryGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { query, buckwalterPop, count }
        };

        list = new ListBox() {
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(RootBoxTemplate))
            }
        };

        Grid.SetRow(queryGrid, 1);
        Grid.SetRow(list, 2);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { tagPanel, queryGrid, list }
        };
        setContent(grid);
    }

    void bind() {
        count.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = list,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Items)));
        list.SetBinding(ListBox.SelectedItemProperty, new Binding() {
            Path = new PropertyPath(nameof(vm.Selected)),
            Mode = BindingMode.OneWayToSource
        });
        query.SetBinding(WaterBox.TextProperty, new Binding(nameof(vm.Query)) {
            Mode = BindingMode.OneWayToSource
        });
    }

    Grid getTip() {
        var header = new TextBlockEnglish() {
            Text = "Matrix",
            FontWeight = FontWeights.Bold
        };
        var separator = new Rectangle() {
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var description = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Text = "See words with root in different forms and parts of speech tag."
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(description, 2);
        return new Grid() {
            MaxWidth = 200,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(10) },
                new RowDefinition()
            },
            Children = { header, separator, description }
        };
    }

    class RootBoxTemplate : Grid {
        TextBlockArabic arabic;
        TextBlockEnglish english;

        public RootBoxTemplate() {
            arabic = new TextBlockArabic();
            english = new TextBlockEnglish() {
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Center
            };

            SetColumn(arabic, 1);
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());

            Children.Add(arabic);
            Children.Add(english);
        }
        public override void EndInit() {
            base.EndInit();
            var root = DataContext.ToString();
            arabic.Text = root.toArabic();
            english.Text = root;
        }
    }
}
