﻿class HadithView : CardView {
    public override string Icon => Icons.Dice6;
    public override bool OverridesToolTip => true;
    public override UIElement Tip => getTip();

    public override void OnFirstSight() {
        base.OnFirstSight();
        initializeUI();
    }

    void initializeUI() {
        var books = 
            System.IO.File.ReadAllLines("Resources/Hadith/books.txt")
            .Skip(1)
            .Select(x => x.Split('\t'))
            .Select(x => new HadithBook() {
                Id = Convert.ToInt32(x[0]),
                TitleArabic = x[1],
                TitleEnglish = x[2],
                AuthorArabic = x[3],
                AuthorEnglish = x[4]
            })
            .ToList();

        var grid = new Grid();
        for (int i = 0; i < books.Count; i++) {
            var book = new BookBorder(books[i]);
            book.LeftClick += onLeftClick;
            book.RightClick += onRightClick;
            grid.RowDefinitions.Add(new RowDefinition());
            Grid.SetRow(book, i);
            grid.Children.Add(book);
        }
        var scroll = new ScrollViewer() {
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Content = grid
        };
        setContent(scroll);
    }

    void onLeftClick(HadithBook book) {
        if (((App)Application.Current).FocusedControl.SelectedPage is not HadithPage page) return;
        page.setContent(book);
    }

    void onRightClick(HadithBook book) {
        ((App)Application.Current).FocusedControl.addHadithPage(book);
    }

    Grid getTip() {
        var header = new TextBlockEnglish() {
            Text = "Hadiths",
            FontWeight = FontWeights.Bold
        };
        var separator = new Rectangle() {
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var description = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Text = "See the six hadith books."
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(description, 2);
        return new Grid() {
            MaxWidth = 200,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(10) },
                new RowDefinition()
            },
            Children = { header, separator, description }
        };
    }

    class BookBorder : Border {
        HadithBook book;

        public event Action<HadithBook> LeftClick, RightClick;

        public BookBorder(HadithBook book) {
            this.book = book;
            Padding = new Thickness(5);
            BorderThickness = new Thickness(Constants.BottomLineThickness);
            CornerRadius = new CornerRadius(5);
            Child = new StackPanel() {
                Children = {
                    new TextBlockArabic() { Text = book.TitleArabic, TextWrapping = TextWrapping.Wrap },
                    new TextBlockEnglish() { Text = book.TitleEnglish, TextWrapping = TextWrapping.Wrap },
                    new TextBlockArabic() { Text = book.AuthorArabic, TextWrapping = TextWrapping.Wrap },
                    new TextBlockEnglish() { Text = book.AuthorEnglish, TextWrapping = TextWrapping.Wrap }
                }
            };
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            base.OnMouseEnter(e);
            BorderBrush = Brushes.LightGray;
        }

        protected override void OnMouseLeave(MouseEventArgs e) {
            base.OnMouseLeave(e);
            BorderBrush = Brushes.Transparent;
        }

        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
            base.OnMouseLeftButtonUp(e);
            LeftClick?.Invoke(book);
        }

        protected override void OnMouseRightButtonUp(MouseButtonEventArgs e) {
            base.OnMouseRightButtonUp(e);
            RightClick?.Invoke(book);
        }
    }
}
