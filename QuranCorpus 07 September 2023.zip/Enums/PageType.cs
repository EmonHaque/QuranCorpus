﻿enum PageType {
    Surah,
    Match,
    Lemma,
    LemmaLess,
    Segment,
    Tag,
    POS,
    Form,
    RootMatrix,
    PronounMatrix,
    Morph,
    Case,
    Mood,
    Pronoun,
    Tafsir,
    Hadith,
    Search
}

