﻿class TagPage : Page, ISwitch {
    public override PageType Type => PageType.Tag;
    public override UIElement Content => content;

    public bool IsHoverPopupEnabled { get; set; }
    public bool HasColor { get; set; }
    public event Action IsColored;
    public TagItem selectedTag;

    string[] selectedTranslators;
    Grid content;
    ProgressBar progress;
    Toggle popToggle, colorToggle;
    Translators translators;
    MultiState groupState;
    DependencyPropertyDescriptor translatorDescriptor, groupStateDescriptor;
    DragDropListBox ayahListBox;
    TreeView tree;
    Copier copier;

    List<Ayah> orderedList;
    List<IGrouping<string, Ayah>> groups;
    List<string> references;
    CancellationTokenSource terminator;

    public TagPage() {
        terminator = new CancellationTokenSource();
        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };
        groupState = new MultiState() {
            Icons = new string[] { Icons.Group, Icons.Ungroup },
            IsIconInfront = true,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(7, 0, 0, 0)
        };
        popToggle = new Toggle() {
            Margin = new Thickness(7, 2.5, 0, 0),
            VerticalAlignment = VerticalAlignment.Center,
            OnIcon = Icons.EyeOff,
            OffIcon = Icons.Eye,
            OnTip = "enable popup on hover",
            OffTip = "disable popup on hover",
            Command = () => IsHoverPopupEnabled = !IsHoverPopupEnabled
        };
        colorToggle = new Toggle() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(7, 2.5, 0, 0),
            VerticalAlignment = VerticalAlignment.Center,
            OnIcon = Icons.BrushOff,
            OffIcon = Icons.Brush,
            OnTip = "color segments",
            OffTip = "remove color",
            Command = () => {
                HasColor = !HasColor;
                IsColored?.Invoke();
            }
        };
        translators = new Translators() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(7, 2.5, 0, 0),
            HorizontalAlignment = HorizontalAlignment.Left,
            VerticalAlignment = VerticalAlignment.Center
        };
       
        Grid.SetColumn(colorToggle, 1);
        Grid.SetColumn(popToggle, 2);
        Grid.SetColumn(groupState, 3);
        var toolGrid = new Grid() {
            Margin = new Thickness(5, 0, 0, 10),
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { translators, groupState, popToggle, colorToggle }
        };
        ayahListBox = new DragDropListBox() {
            DataContext = this,
            FlowDirection = FlowDirection.RightToLeft,
            DropAction = onDrop,
            ItemTemplate = new AyahTemplateDragDrop()
        };
        ayahListBox.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        ayahListBox.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
        tree = new TreeView() {
            DataContext = this,
            FlowDirection = FlowDirection.LeftToRight,
            Visibility = Visibility.Hidden,
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            // if you set HorizontalScrollBarVisibilityProperty here and disable the 
                            // tree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
                            // it will mess up when scrollbar appears and disappears
                            //new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()),
                        }
                    }
                }
            }
        };
        tree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        tree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true);

        Grid.SetRow(toolGrid, 1);
        Grid.SetRow(ayahListBox, 2);
        Grid.SetRow(tree, 2);
        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { progress, toolGrid, ayahListBox, tree }
        };

        copier = new Copier(ayahListBox, progress, terminator);
        copier.addAction(new ContextItem() { Icon = Icons.TagRemove, Text = "remove selected", Command = removeAyahs });

        translatorDescriptor = DependencyPropertyDescriptor.FromProperty(Translators.SelectedProperty, typeof(Translators));
        translatorDescriptor.AddValueChanged(translators, onTranslationChanged);
        groupStateDescriptor = DependencyPropertyDescriptor.FromProperty(MultiState.StateProperty, typeof(MultiState));
        groupStateDescriptor.AddValueChanged(groupState, onGroupStateChanged);

        selectedTranslators = translators.Selected;

        ayahListBox.MouseDoubleClick += onDoubleClick;
        tree.MouseDoubleClick += onDoubleClick;
        TabView.Split += onSplit;
    }

    public TagPage(TagItem item) : this() {
        selectedTag = item;
        progress.IsIndeterminate = true;
        Task.Run(() => {
            orderedList = getAyahs(item);
            groups = orderedList.GroupBy(x => x.SurahNo).ToList();
            App.Current.Dispatcher.Invoke(updatePage);
        }, terminator.Token);
    }

    public void setContent(TagItem item) {
        selectedTag = item;
        progress.IsIndeterminate = true;
        Task.Run(() => {
            orderedList = getAyahs(item);
            groups = orderedList.GroupBy(x => x.SurahNo).ToList();
            App.Current.Dispatcher.Invoke(updatePage);

        }, terminator.Token);
    }

    public void updatePage() {
        orderedList = getAyahs(selectedTag);
        ayahListBox.ItemsSource = getAyahsInOriginalOrder();
        createTree();
        HeaderText = selectedTag.Name + " (" + selectedTag.Count.ToString("N0") + ")";
        groupState.IsEnabled = true;
        translators.IsEnabled = true;
        progress.IsIndeterminate = false;
    }

    List<Ayah> getAyahs(TagItem tag) {
        var list = new List<Ayah>();
        var links = new List<Link>();

        references = System.IO.File.ReadAllLines("Resources/Tags/" + tag.Name + ".txt").ToList();
        if (references.Count == 0) {
            return new List<Ayah>();
        }

        var orderedReferences = references.OrderBy(x => x, new AyahComparator()).ToList();

        var linkIterator = App.links.GetEnumerator();
        linkIterator.MoveNext();

        foreach (var item in orderedReferences) {
            while (!linkIterator.Current.Reference.StartsWith(item + ':')) linkIterator.MoveNext();
            while (linkIterator.Current.Reference.StartsWith(item + ':')) {
                links.Add(linkIterator.Current);
                linkIterator.MoveNext();
            }
        }
        linkIterator.Dispose();

        var groups = links.GroupBy(x => x.Reference.Substring(0, x.Reference.LastIndexOf(':'))).ToList();

        IEnumerator<string>[] iterators = null;
        int[] translatorIds = null;
        List<string> liranslatorsName = null;

        if (selectedTranslators.Length > 0) {
            iterators = new IEnumerator<string>[selectedTranslators.Length];
            translatorIds = new int[selectedTranslators.Length];
            liranslatorsName = App.global.TranslationDictionary.Keys.ToList();

            var ayahNo = orderedReferences[0].Replace(':', '|') + '|';

            int index = 0;
            foreach (var item in selectedTranslators) {
                var file = App.global.TranslationDictionary[item];
                var lines = System.IO.File.ReadLines("Resources/Tanzil/" + file);
                var iterator = lines.GetEnumerator();
                iterator.MoveNext();
                while (!iterator.Current.StartsWith(ayahNo)) iterator.MoveNext();
                iterators[index] = iterator;
                translatorIds[index] = liranslatorsName.IndexOf(item);
                index++;
            }
        }

        if (selectedTranslators.Length > 0) {
            for (int i = 0; i < orderedReferences.Count; i++) {
                var translations = new Translation[iterators.Length];
                var reference = orderedReferences[i].Replace(':', '|') + '|';

                for (int j = 0; j < iterators.Length; j++) {
                    while (!iterators[j].Current.StartsWith(reference)) iterators[j].MoveNext();

                    translations[j] = new Translation() {
                        TranslatorId = translatorIds[j],
                        Content = iterators[j].Current.Substring(reference.Length)
                    };

                }
                var words = new List<Word>();
                var group = groups[i];
                foreach (var item in group) {
                    words.Add(new Word() {
                        Reference = item.Reference,
                        Transliteration = App.transliterations[Convert.ToInt32(item.Transliteration)],
                        Tags = item.Tags,
                        Segments = Helper.getSegments(item),
                        Lemmas = Helper.getLemmas(item),
                        LemmaIndices = item.LemmaIndices,
                        Spellings = Helper.getSpellings(item),
                        Meaning = App.meanings[Convert.ToInt32(item.Meaning)],
                        Explanation = item.Explanation,
                        Root = item.Root,
                        RootIndex = item.RootIndex,
                        Details = item.Details
                    });
                }
                var parts = group.Key.Split(':');
                list.Add(new Ayah() {
                    SurahNo = parts[0],
                    AyahNo = parts[1],
                    Translations = translations,
                    Words = words
                });

            }
            foreach (var iterator in iterators) iterator.Dispose();
        }
        else {
            for (int i = 0; i < orderedReferences.Count; i++) {
                var words = new List<Word>();
                var group = groups[i];
                foreach (var item in group) {
                    words.Add(new Word() {
                        Reference = item.Reference,
                        Transliteration = App.transliterations[Convert.ToInt32(item.Transliteration)],
                        Tags = item.Tags,
                        Segments = Helper.getSegments(item),
                        Lemmas = Helper.getLemmas(item),
                        LemmaIndices = item.LemmaIndices,
                        Spellings = Helper.getSpellings(item),
                        Meaning = App.meanings[Convert.ToInt32(item.Meaning)],
                        Explanation = item.Explanation,
                        Root = item.Root,
                        RootIndex = item.RootIndex,
                        Details = item.Details
                    });
                }
                var parts = group.Key.Split(':');

                list.Add(new Ayah() {
                    SurahNo = parts[0],
                    AyahNo = parts[1],
                    Words = words
                });
            }
        }

        return list;
    }

    List<Ayah> getAyahsInOriginalOrder() {
        return references.Join(
                 orderedList,
                 line => line,
                 ayah => ayah.SurahNo + ":" + ayah.AyahNo,
                 (line, ayah) => ayah).ToList();
    }

    void onTranslationChanged(object? sender, EventArgs e) {
        selectedTranslators = translators.Selected;
        updateTranslation();
    }

    void onGroupStateChanged(object? sender, EventArgs e) {
        if (groupState.State == 1) {
            ayahListBox.Visibility = Visibility.Hidden;
            tree.Visibility = Visibility.Visible;
        }
        else {
            tree.Visibility = Visibility.Hidden;
            ayahListBox.Visibility = Visibility.Visible;
        }
    }

    void createTree() {
        tree.Items.Clear();
        int count = 0;
        foreach (var group in groups) {
            count++;
            var surahName = App.surahs.First(x => x.Id == Convert.ToInt32(group.Key)).Transliteration;
            var items = group.ToList();
            var branch = new TreeViewItem() {
                Header = new Tuple<string, string>(group.Key + ") " + surahName, items.Count.ToString()),
                HeaderTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(TagGroupTemplate))
                },
                ItemTemplate = new AyahTemplateDragDrop(),
                ItemsSource = items
            };
            tree.Items.Add(branch);
        }
        groupState.Texts = new string[] { "Group by " + count + " surah", "Ungroup " + count + " surah" };
    }

    void updateTranslation() {
        if (selectedTranslators.Length == 0) {
            for (int i = 0; i < orderedList.Count; i++) {
                orderedList[i].Translations = null;
                orderedList[i].OnPropertyChanged(nameof(Ayah.Translations));
            }
            return;
        }

        //it'll read all selected files always

        var iterators = new IEnumerator<string>[selectedTranslators.Length];
        var translatorIds = new int[selectedTranslators.Length];
        var liranslatorsName = App.global.TranslationDictionary.Keys.ToList();

        int index = 0;
        foreach (var item in selectedTranslators) {
            var file = App.global.TranslationDictionary[item];
            var lines = System.IO.File.ReadLines("Resources/Tanzil/" + file);
            var iterator = lines.GetEnumerator();
            iterator.MoveNext();
            while (!iterator.Current.StartsWith(orderedList[0].SurahNo + "|" + orderedList[0].AyahNo + "|")) iterator.MoveNext();
            iterators[index] = iterator;
            translatorIds[index] = liranslatorsName.IndexOf(item);
            index++;
        }

        for (int i = 0; i < orderedList.Count; i++) {
            var translations = new Translation[iterators.Length];
            var reference = orderedList[i].SurahNo + "|" + orderedList[i].AyahNo + "|";
            for (int j = 0; j < iterators.Length; j++) {
                while (!iterators[j].Current.StartsWith(reference)) iterators[j].MoveNext();

                translations[j] = new Translation() {
                    TranslatorId = translatorIds[j],
                    Content = iterators[j].Current.Substring(reference.Length)
                };
            }
            orderedList[i].Translations = translations;
            orderedList[i].OnPropertyChanged(nameof(Ayah.Translations));
        }

        foreach (var iterator in iterators) iterator.Dispose();

        //if (ayahListBox.SelectedItem != null) {
        //    ayahListBox.ScrollIntoView(ayahListBox.SelectedItem);
        //}
    }

    void onDrop(object on, IList items, bool before) {
        var list = getAyahsInOriginalOrder();
        for (int i = 0; i < items.Count; i++) {
            list.Remove((Ayah)items[i]);
        }
        var index = list.IndexOf((Ayah)on);
        if (!before) index++;
        for (int i = 0; i < items.Count; i++) {
            list.Insert(index, (Ayah)items[i]);
            index++;
        }
        references = list.Select(x => x.SurahNo + ":" + x.AyahNo).ToList();
        System.IO.File.WriteAllLines("Resources/Tags/" + selectedTag.Name + ".txt", references);
        updatePage();
    }

    void onDoubleClick(object sender, MouseButtonEventArgs e) {
        if (e.ChangedButton != MouseButton.Left) return;
        Ayah selected =
            groupState.State == 1 ?
            tree.SelectedItem as Ayah :
            (Ayah)ayahListBox.SelectedItem;

        if (selected is null) return;
        ((App)Application.Current).FocusedControl.addSurahPage(selected.SurahNo + ":" + selected.AyahNo + ":");
    }

    void onSplit() => ayahListBox.Items.Refresh();

    void removeAyahs() {
        if (ayahListBox.SelectedItems.Count == 0) return;
        List<string> list = new();
        foreach (Ayah item in ayahListBox.ItemsSource) {
            if (ayahListBox.SelectedItems.Contains(item)) {
                continue;
            }
            list.Add(item.SurahNo + ":" + item.AyahNo);
        }
        references = list;
        System.IO.File.WriteAllLines("Resources/Tags/" + selectedTag.Name + ".txt", references);
        selectedTag.Count = references.Count;
        selectedTag.OnPropertyChanged(nameof(TagItem.Count));
        if(references.Count == 0) {
            groupState.Texts = new string[] { "Group by 0 surah", "Ungroup 0 surah" };
            HeaderText = selectedTag.Name + " (0)";
            tree.Items.Clear();
            ayahListBox.ItemsSource = null;
            groupState.IsEnabled = false;
            translators.IsEnabled = false;
        }
        else updatePage();
    }

    protected override void unload() {
        ayahListBox.MouseDoubleClick -= onDoubleClick;
        TabView.Split -= onSplit;
        translatorDescriptor.RemoveValueChanged(translators, onTranslationChanged);
        groupStateDescriptor.RemoveValueChanged(groupState, onGroupStateChanged);
        terminator.Cancel();
        terminator.Dispose();
        copier.unload();
        base.unload();
    }

    class AyahComparator : IComparer<string> {
        public int Compare(string? x, string? y) {
            int index1 = x.IndexOf(':');
            int index2 = y.IndexOf(':');
            var firstSurah = Convert.ToInt32(x.Substring(0, index1));
            var secondSurah = Convert.ToInt32(y.Substring(0, index2));

            if (firstSurah > secondSurah) return 1;
            else if (firstSurah < secondSurah) return -1;
            else {
                var firstAyah = Convert.ToInt32(x.Substring(index1 + 1));
                var secondAyah = Convert.ToInt32(y.Substring(index2 + 1));
                if (firstAyah == secondAyah) return 0;
                else if (firstAyah > secondAyah) return 1;
                return -1;
            }
        }
    }
}
