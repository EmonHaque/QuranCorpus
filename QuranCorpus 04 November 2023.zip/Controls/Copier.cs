﻿class Copier {
    ContextPopup ayahContext, wordContext;
    ListBox ayahListBox;
    ProgressBar progress;
    CancellationTokenSource terminator;

    public Copier(ListBox ayahListBox, ProgressBar progress, CancellationTokenSource terminator) {
        this.ayahListBox = ayahListBox;
        this.progress = progress;
        this.terminator = terminator;

        ayahContext = new ContextPopup(new List<ContextItem>() {
            new ContextItem(){ Icon = Icons.CopyArabic, Text = "copy arabic", Command = copyArabic },
            new ContextItem(){ Icon = Icons.CopyEnglish, Text = "copy english", Command = copyEnglish },
            new ContextItem(){ Icon = Icons.Copy, Text = "copy both", Command = copyBoth },
        });

        wordContext = new ContextPopup(new List<ContextItem>() {
            new ContextItem(){ Icon = Icons.CopyArabic, Text = "copy word(s)", Command = copyWord }
        });

        ayahListBox.MouseRightButtonUp += onRightMouseUp;
    }

    public void unload() => ayahListBox.MouseRightButtonUp -= onRightMouseUp;

    public void addAction(ContextItem item) => ayahContext.addAction(item);

    void onRightMouseUp(object sender, MouseButtonEventArgs e) {
        if (ayahListBox.SelectedItems.Count == 0) return;
        bool wordsSelected = false;
        if (ayahListBox.SelectedItems.Count == 1) {
            var ayah = (Ayah)ayahListBox.SelectedItem;
            for (int i = 0; i < ayah.Words.Count; i++) {
                if (!ayah.Words[i].IsHighlighted) continue;
                wordsSelected = true;
                break;
            }
        }
        if (wordsSelected) wordContext.IsOpen = true;
        else ayahContext.IsOpen = true;
    }

    void copyWord() {
        var ayah = (Ayah)ayahListBox.SelectedItem;
        var builder = new StringBuilder();
        for (int i = 0; i < ayah.Words.Count; i++) {
            if (!ayah.Words[i].IsHighlighted) continue;
            ayah.Words[i].Segments[App.global.Transcript].Split('|').toArabic(builder);
            builder.Append(" ");
        }
        builder.Remove(builder.Length - 1, 1);
        Clipboard.SetDataObject(builder.ToString(), true);
    }

    void copyArabic() {
        var selected = ayahListBox.SelectedItems.Cast<Ayah>();
        progress.IsIndeterminate = true;

        Task.Run(() => {
            var builder = new StringBuilder();
            foreach (Ayah ayah in selected) {
                if (terminator.IsCancellationRequested) break; // want to check in nested loops?

                builder
                .Append(ayah.SurahNo.toArabicNo())
                .Append(':')
                .Append(ayah.AyahNo.toArabicNo())
                .Append(" - ");

                foreach (var word in ayah.Words) {
                    word.Segments[App.global.Transcript].Split('|').toArabic(builder);
                    builder.Append(" ");
                }
                builder.AppendLine();

                if (!terminator.IsCancellationRequested) {
                    App.Current.Dispatcher.Invoke(() => {
                        Clipboard.SetDataObject(builder.ToString(), true);
                        progress.IsIndeterminate = false;
                    });
                }
            }
        }, terminator.Token);
    }

    void copyEnglish() {
        var selected = ayahListBox.SelectedItems.Cast<Ayah>();
        progress.IsIndeterminate = true;

        Task.Run(() => {
            var builder = new StringBuilder();
            foreach (Ayah ayah in selected) {
                if (terminator.IsCancellationRequested) break; // want to check in nested loops?
                builder
                .Append(ayah.SurahNo)
                .Append(':')
                .Append(ayah.AyahNo + " - ");

                if (ayah.Translations.Length == 1) {
                    builder.Append(ayah.Translations[0].Content)
                    .AppendLine();
                }
                else {
                    var translatorNames = App.global.TranslationDictionary.Keys.ToList();
                    for (int i = 0; i < ayah.Translations.Length; i++) {
                        builder.Append(translatorNames[ayah.Translations[i].TranslatorId])
                        .Append(": ")
                        .Append(ayah.Translations[i].Content)
                        .AppendLine();
                    }
                }

                if (!terminator.IsCancellationRequested) {
                    App.Current.Dispatcher.Invoke(() => {
                        Clipboard.SetDataObject(builder.ToString(), true);
                        progress.IsIndeterminate = false;
                    });
                }
            }
        }, terminator.Token);
    }

    void copyBoth() {
        var selected = ayahListBox.SelectedItems.Cast<Ayah>();
        progress.IsIndeterminate = true;

        Task.Run(() => {
            var builder = new StringBuilder();
            foreach (Ayah ayah in selected) {
                if (terminator.IsCancellationRequested) break; // want to check in nested loops?

                builder
                .Append(ayah.SurahNo.toArabicNo())
                .Append(':')
                .Append(ayah.AyahNo.toArabicNo())
                .Append(" - ");

                foreach (var word in ayah.Words) {
                    word.Segments[App.global.Transcript].Split('|').toArabic(builder);
                    builder.Append(" ");
                }
                builder
                .AppendLine()
                .Append(ayah.SurahNo)
                .Append(':')
                .Append(ayah.AyahNo + " - ");


                if (ayah.Translations.Length == 1) {
                    builder.Append(ayah.Translations[0].Content)
                    .AppendLine();
                }
                else {
                    var translatorNames = App.global.TranslationDictionary.Keys.ToList();
                    for (int i = 0; i < ayah.Translations.Length; i++) {
                        builder.Append(translatorNames[ayah.Translations[i].TranslatorId])
                        .Append(": ")
                        .Append(ayah.Translations[i].Content)
                        .AppendLine();
                    }
                }
                if (!terminator.IsCancellationRequested) {
                    App.Current.Dispatcher.Invoke(() => {
                        Clipboard.SetDataObject(builder.ToString(), true);
                        progress.IsIndeterminate = false;
                    });
                }
            }
        }, terminator.Token);
    }
}
