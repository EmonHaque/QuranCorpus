﻿class TagItem : Notifiable {
    public string Name { get; set; }
    public int Count { get; set; }
}
