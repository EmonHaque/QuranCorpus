﻿class MatchGrid : Grid {
    TextBlockEnglish reference, transliteration, meaning, toolTip;
    TextBlockArabicListen arabic;

    public MatchGrid() {
        FlowDirection = FlowDirection.RightToLeft;
        reference = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center
        };
        transliteration = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center
        };
        meaning = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center,
            TextWrapping = TextWrapping.Wrap
        };
        toolTip = new TextBlockEnglish() {
            MaxWidth = 500,
            FlowDirection = FlowDirection.LeftToRight,
            TextWrapping = TextWrapping.Wrap,
            Foreground = Brushes.LightGray,
        };
        arabic = new TextBlockArabicListen() {
            TextWrapping = TextWrapping.Wrap,
            ToolTip = toolTip
        };

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(200) });
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(100) });
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(70) });

        SetColumn(meaning, 1);
        SetColumn(transliteration, 2);
        SetColumn(reference, 3);

        Children.Add(arabic);
        Children.Add(meaning);
        Children.Add(transliteration);
        Children.Add(reference);
    }

    public override void EndInit() {
        base.EndInit();
        var match = (Match)DataContext;
        reference.Text = match.Reference;
        transliteration.Text = match.Transliteration;
        meaning.Text = match.Meaning;
        toolTip.Text = match.Translation.Substring(match.Translation.LastIndexOf('|') + 1);
        arabic.Tag = match.Words;

        StringBuilder builder = new();
        int index = 0;
        foreach (var word in match.Words) {
            if (word.Reference is null) {
                arabic.Inlines.Add(new Run(index == 0 ? "... " : " ..."));
                index++;
            }
            else {
                var segments = word.Segments[App.global.Transcript].Split('|');
                foreach (var segment in segments) segment.toArabic(segments, builder);
                var run = new Run(builder.Append(' ').ToString());
                builder.Clear();
                arabic.Inlines.Add(run);
                if (word.Reference.EndsWith(match.WordNo)) {
                    run.Foreground = Brushes.Coral;
                }
            }
        }
    }
}

class MatchTemplate : DataTemplate {
    public MatchTemplate() {
        VisualTree = new FrameworkElementFactory(typeof(MatchGrid));
    }
}

class MatchHeader : Grid {
    TextBlockEnglish header, count;
    public MatchHeader() {
        header = new TextBlockEnglish();
        count = new TextBlockEnglish();

        SetColumn(count, 1);
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

        Children.Add(header);
        Children.Add(count);
    }
    public override void EndInit() {
        base.EndInit();
        var data = (Tuple<string, string>)DataContext;
        header.Text = data.Item1;
        count.Text = data.Item2;
    }
}

class MatchHeaderTemplate : DataTemplate {
    public MatchHeaderTemplate() {
        VisualTree = new FrameworkElementFactory(typeof(MatchHeader));
    }
}

class MatchHeaderArabic : Grid {
    TextBlockArabic header;
    TextBlockEnglish count;
    public MatchHeaderArabic() {
        header = new TextBlockArabic();
        count = new TextBlockEnglish() { VerticalAlignment = VerticalAlignment.Center };

        SetColumn(count, 1);
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

        Children.Add(header);
        Children.Add(count);
    }
    public override void EndInit() {
        base.EndInit();
        var data = (Tuple<string, string>)DataContext;
        header.Text = data.Item1;
        count.Text = data.Item2;
    }
}


class MatchHeaderArabicTemplate : DataTemplate {
    public MatchHeaderArabicTemplate() {
        VisualTree = new FrameworkElementFactory(typeof(MatchHeaderArabic));
    }
}