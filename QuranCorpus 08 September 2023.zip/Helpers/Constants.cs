﻿public class Constants {
    public static string AppTitle;
    public const double ScrollBarThickness = 8;
    public const double ScrollBarMargin = 2;
    public const double ScrollPresenterMargin = 5;
    public const double HorizontalBarKeyWidth = 150;
    public const double ProgressBarHeight = 1.5;
    public const double LeadgerRightMargin = ScrollBarThickness + ScrollPresenterMargin;
    public const double DateColumnWidth = 70;
    public const double AmountColumnWidth = 80;
    public const double CardMargin = 5;
    public const double TreeExpansionWidth = 20;
    public const string NumberFormat = "#,##0;(#,##0);-    ";
    public const string CannotBeEmpty = "cannot be empty";
    public const string DoesntExist = "does not exist";
    public const string IsntValid = "is not valid";
    public const string MustBePositive = "has to be positive";
    public static Thickness ComboInputBoxMargin = new Thickness(5, 2, 0, 2);
    public static Thickness ControlMargin = new Thickness(5, 10, 5, 10);
    public static Thickness ControlPadding = new Thickness(0, 0, 0, 1);
    public static Thickness VScrollThumbMargin = new Thickness(ScrollBarMargin, 0, ScrollBarMargin, 0);
    public static Thickness HScrollThumbMargin = new Thickness(0, ScrollBarMargin, 0, ScrollBarMargin);
    public static double BottomLineThickness = 0.5;
    public static double SeparatorHeight = 0.75;
    public static double UpHintBy = -18;
    public static double ScaleHintTo = 0.9;
    public static SolidColorBrush Background = new SolidColorBrush(Color.FromRgb(50, 50, 50));
    public static SolidColorBrush BackgroundDark = new SolidColorBrush(Color.FromRgb(55, 55, 55));
}
