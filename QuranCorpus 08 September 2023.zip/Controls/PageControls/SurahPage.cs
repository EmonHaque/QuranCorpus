﻿class SurahPage : Page, ISwitch {
    bool searchModeIsEqual;
    int currentSurah, matchCount;
    string[] selectedTranslators;

    Grid content;
    WaterBox queryBox;
    CheckGroup checkGroup;
    TextBlock gotoBlock, count;
    TextBox gotoBox;
    Translators translators;
    Toggle popToggle, colorToggle;
    DragListBox ayahListBox;
    ProgressBar progress;
    ContextPopup copyAyahContext, copyWordContext;
    MultiState searchState;
    CancellationTokenSource terminator;
    DependencyPropertyDescriptor translatorDescriptor;
    List<Ayah> ayahs;

    public bool IsHoverPopupEnabled { get; set; }
    public bool HasColor { get; set; }
    public event Action IsColored;

    public override PageType Type => PageType.Surah;
    public override UIElement Content => content;

    public SurahPage() {
        terminator = new CancellationTokenSource();
        queryBox = new WaterBox() {
            Hint = "Search (arabic)",
            Icon = Icons.Search,
            IsArabic = true,
            Visibility = Visibility.Collapsed
        };
        checkGroup = new CheckGroup() {
            Icons = new string[] { Icons.Approximate, Icons.Equal },
            Tips = new string[] { "contains", "exact" },
            Margin = new Thickness(10, 0, 0, 0),
            VerticalAlignment = VerticalAlignment.Bottom,
            Visibility = Visibility.Collapsed
        };
        count = new TextBlock() {
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(7, 0, 7, 0)
        };
        gotoBlock = new TextBlock() {
            Text = "go to: ",
            VerticalAlignment = VerticalAlignment.Bottom
        };
        gotoBox = new TextBox() {
            TextAlignment = TextAlignment.Right,
            VerticalContentAlignment = VerticalAlignment.Bottom,
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness)
        };

        searchState = new MultiState() {
            Height = 12,
            Icons = new string[] { Icons.MagnifyPlus, Icons.MagnifyMinus },
            ToolTip = "Local search",
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(0, 0, 7, 0)
        };
        var globalSearch = new ActionButton() {
            Icon = Icons.SearchGlobal,
            ToolTip = "Global search",
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(0, 0, 7, 0),
            Command = () => ((App)Application.Current).FocusedControl.addSearchPage()
        };
        var hadithSearch = new ActionButton() {
            Icon = Icons.AccountSearch,
            ToolTip = "Hadith search",
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(0, 0, 7, 0),
            Command = () => ((App)Application.Current).FocusedControl.addSearchHadithPage()
        };
        popToggle = new Toggle() {
            Margin = new Thickness(0, 0, 7, 0),
            VerticalAlignment = VerticalAlignment.Bottom,
            OnIcon = Icons.EyeOff,
            OffIcon = Icons.Eye,
            OnTip = "enable popup on hover",
            OffTip = "disable popup on hover",
            Command = () => IsHoverPopupEnabled = !IsHoverPopupEnabled
        };
        colorToggle = new Toggle() {
            Margin = new Thickness(0, 0, 7, 0),
            VerticalAlignment = VerticalAlignment.Bottom,
            OnIcon = Icons.BrushOff,
            OffIcon = Icons.Brush,
            OnTip = "color segments",
            OffTip = "remove color",
            Command = () => {
                HasColor = !HasColor;
                IsColored?.Invoke();
            }
        };
        var tafsir = new ActionButton() {
            Margin = new Thickness(0, 0, 7, 0),
            VerticalAlignment = VerticalAlignment.Bottom,
            Icon = Icons.School,
            ToolTip = "Tafsir Ibn Kathir",
            Command = () => ((App)Application.Current).FocusedControl.addTafsirPage(currentSurah)
        };
        translators = new Translators() {
            FlowDirection = FlowDirection.LeftToRight,
            HorizontalAlignment = HorizontalAlignment.Left,
            VerticalAlignment = VerticalAlignment.Bottom
        };
        
        Grid.SetColumn(checkGroup, 1);
        Grid.SetColumn(count, 2);
        Grid.SetColumn(gotoBlock, 3);
        Grid.SetColumn(gotoBox, 4);
        Grid.SetColumn(searchState, 5);
        Grid.SetColumn(globalSearch, 6);
        Grid.SetColumn(hadithSearch, 7);
        Grid.SetColumn(popToggle, 8);
        Grid.SetColumn(colorToggle, 9);
        Grid.SetColumn(tafsir, 10);
        Grid.SetColumn(translators, 11);

        var toolGrid = new Grid() {
            Margin = new Thickness(3, 0, 0, 10),
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width =  GridLength.Auto },
                new ColumnDefinition(){ Width = new GridLength(50) },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { queryBox, checkGroup, gotoBlock, gotoBox, searchState, globalSearch, hadithSearch, count, popToggle, colorToggle, tafsir, translators }
        };
        ayahListBox = new DragListBox() {
            DataContext = this,
            FlowDirection = FlowDirection.RightToLeft,
            ItemTemplate = new AyahTemplate()
        };
        ayahListBox.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        ayahListBox.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };
        Grid.SetRow(toolGrid, 1);
        Grid.SetRow(ayahListBox, 2);
        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, toolGrid, ayahListBox }
        };

        copyAyahContext = new ContextPopup(new List<ContextItem>() {
            new ContextItem(){ Icon = Icons.CopyArabic, Text = "copy arabic", Command = copyArabic },
            new ContextItem(){ Icon = Icons.CopyEnglish, Text = "copy english", Command = copyEnglish },
            new ContextItem(){ Icon = Icons.Copy, Text = "copy both", Command = copyBoth },
        });

        copyWordContext = new ContextPopup(new List<ContextItem>() {
            new ContextItem(){ Icon = Icons.CopyArabic, Text = "copy word(s)", Command = copyWord }
        });

        translatorDescriptor = DependencyPropertyDescriptor.FromProperty(Translators.SelectedProperty, typeof(Translators));
        translatorDescriptor.AddValueChanged(translators, onTranslationChanged);

        queryBox.KeyUp += onQuery;
        ayahListBox.MouseRightButtonUp += onRightMouseUp;
        searchState.MouseLeftButtonUp += onLeftClick;
        gotoBox.KeyUp += onGoto;
        selectedTranslators = translators.Selected;
    }

    public SurahPage(int surahNo) : this() {
        currentSurah = surahNo;
        HeaderText = surahNo + ") " + App.surahs.First(x => x.Id == surahNo).Transliteration;
        progress.IsIndeterminate = true;
        Task.Run(() => {
            ayahs = getAyahs(surahNo);
            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    ayahListBox.ItemsSource = ayahs;
                    count.Text = ayahs.Count + " ayah,";
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    public SurahPage(string reference) : this() => goToSurah(reference);

    public void setContent(int surahNo) {
        currentSurah = surahNo;
        HeaderText = surahNo + ") " + App.surahs.First(x => x.Id == surahNo).Transliteration;
        progress.IsIndeterminate = true;
        Task.Run(() => {
            ayahs = getAyahs(surahNo);
            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    gotoBox.Text = "";
                    ayahListBox.ItemsSource = ayahs;
                    count.Text = ayahs.Count + " ayah,";
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    void onQuery(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;

        if (string.IsNullOrWhiteSpace(queryBox.Text)) {
            if (ayahListBox.ItemsSource.Equals(ayahs)) return;

            for (int i = 0; i < ayahs.Count; i++) {
                for (int j = 0; j < ayahs[i].Words.Count; j++) {
                    ayahs[i].Words[j].IsHighlighted = false;
                }
            }

            count.Text = ayahs.Count.ToString();
            ayahListBox.ItemsSource = ayahs;
            count.Text = ayahs.Count + " ayah,";
            return;
        }
        searchModeIsEqual = checkGroup.Selected == 1;
        var query = queryBox.Text.Trim();
        progress.IsIndeterminate = true;

        Task.Run(() => {
            List<Ayah> newList = new();
            StringBuilder builder = new();
            matchCount = 0;

            for (int i = 0; i < ayahs.Count; i++) {
                if (terminator.IsCancellationRequested) break;
                for (int j = 0; j < ayahs[i].Words.Count; j++) {

                    ayahs[i].Words[j].IsHighlighted = false;

                    var segments = ayahs[i].Words[j].Segments[App.global.Transcript].Split('|');
                    for (int k = 0; k < segments.Length; k++) {
                        segments[k].toArabic(segments, builder);
                    }
                    builder.Append(' ');
                }
                var ayah = builder.ToString();
                builder.Clear();

                if (ayah.Contains(query)) {
                    var parts = query.Split(' ');
                    var words = ayah.Split(' ');
                    int count = 0;

                    if (!searchModeIsEqual) {
                        newList.Add(ayahs[i]);
                        if (parts.Length > 1) {
                            while (count < words.Length) {
                                while (!words[count].EndsWith(parts[0], StringComparison.Ordinal)) {
                                    count++;
                                    if (count == words.Length) break;
                                }
                                if (count == words.Length) break;

                                int index = count + 1;
                                int length = count + parts.Length - 1;
                                bool isMatch = true;
                                int partIndex = 1;
                                for (int j = index; j < length; j++) {
                                    if (words[j].Equals(parts[partIndex++])) continue;
                                    isMatch = false;
                                    break;
                                }
                                if (isMatch) {
                                    if (words[length].StartsWith(parts[parts.Length - 1], StringComparison.Ordinal)) {
                                        length++;
                                        for (int j = count; j < length; j++) {
                                            ayahs[i].Words[j].IsHighlighted = true;
                                        }
                                        matchCount++;
                                    }
                                }
                                count += parts.Length;
                            }
                        }
                        else {
                            for (int j = 0; j < words.Length; j++) {
                                var word = words[j];
                                if (!words[j].Contains(query, StringComparison.Ordinal)) continue;
                                ayahs[i].Words[j].IsHighlighted = true;
                                matchCount++;
                            }
                        }
                    }
                    else {
                        bool isEqual = false;
                        if (parts.Length > 1) {
                            while (count < words.Length) {
                                while (!words[count].Equals(parts[0])) {
                                    count++;
                                    if (count == words.Length) break;
                                }
                                if (count == words.Length) break;

                                int index = count + 1;
                                int length = count + parts.Length - 1;
                                bool isMatch = true;
                                int partIndex = 1;
                                for (int j = index; j < length; j++) {
                                    if (words[j].Equals(parts[partIndex++])) continue;
                                    isMatch = false;
                                    break;
                                }
                                if (isMatch) {
                                    if (words[length].Equals(parts[parts.Length - 1])) {
                                        length++;
                                        for (int j = count; j < length; j++) {
                                            ayahs[i].Words[j].IsHighlighted = true;
                                        }
                                        matchCount++;
                                        isEqual = true;
                                    }
                                }
                                count += parts.Length;
                            }
                        }
                        else {
                            for (int j = 0; j < words.Length; j++) {
                                var word = words[j];
                                if (!words[j].Equals(query)) continue;
                                ayahs[i].Words[j].IsHighlighted = true;
                                matchCount++;
                                isEqual = true;
                            }
                        }

                        if(isEqual) newList.Add(ayahs[i]);
                    }
                }
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    ayahListBox.ItemsSource = newList;
                    count.Text = matchCount.ToString("N0") + " matches in " + newList.Count + " ayah";
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    void onGoto(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        var reference = gotoBox.Text.Trim();
        if (reference.Contains(':')) {
            var parts = reference.Split(':');
            if (parts.Length != 2) return;

            var isParsed = int.TryParse(parts[0], out int surah);
            if (!isParsed) return;
            if (surah < 1 || surah > 114) return;

            isParsed = int.TryParse(parts[1], out int ayah);
            if (!isParsed) return;
            if (ayah < 1 || ayah > App.surahs[surah - 1].Verses) return;

            if (currentSurah == surah) gotoAyah(ayah.ToString());
            else {
                currentSurah = surah;
                goToSurah(reference);
            }
        }
        else {
            var isParsed = int.TryParse(reference, out int ayah);
            if (!isParsed) return;
            if (ayah < 1 || ayah > ayahs.Count) return;
            gotoAyah(ayah.ToString());
        }
    }

    void goToSurah(string reference) {
        var parts = reference.Split(':');
        int surah = Convert.ToInt32(parts[0]);
        int ayah = Convert.ToInt32(parts[1]);
        HeaderText = surah + ") " + App.surahs.First(x => x.Id == surah).Transliteration;
        progress.IsIndeterminate = true;

        Task.Run(() => {
            ayahs = getAyahs(surah);

            if (parts.Length == 3) {
                ayahs.First(x => x.SurahNo.Equals(parts[0]) && x.AyahNo.Equals(parts[1]))
                    .Words.First(x => x.Reference.Equals(reference))
                    .IsHighlighted = true;
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    count.Text = ayahs.Count + " ayah";
                    ayahListBox.ItemsSource = ayahs;
                    ayahListBox.SelectedItem = ayahs[ayah - 1];
                    // to get to the point in ayahListBox first you've to ScrollIntoView
                    // in DispatcherTimer or LayoutUpdated handler and then BringIntoView
                    // otherwise it doesn't work when ScrollUnit.Pixel is set
                    // and all these have to be in an InvokeAsync block
                    // otherwise it doesn't update the layout properly
                    // why is it so?
                    ayahListBox.LayoutUpdated += onLayoutUpdated;
                    //var timer = new DispatcherTimer();
                    //timer.Interval = new TimeSpan(0, 0, 0, 0, 250);
                    //timer.Tick += onTicked;
                    //timer.Start();
                });
            }
        }, terminator.Token);
    }

    void gotoAyah(string ayah) {
        foreach (var item in ayahListBox.Items) {
            if (!((Ayah)item).AyahNo.Equals(ayah)) continue;
            ayahListBox.SelectedItem = item;
            ayahListBox.ScrollIntoView(ayahListBox.SelectedItem);
            break;
        }
    }

    void onLeftClick(object sender, MouseButtonEventArgs e) {
        if (searchState.State == 1) {
            queryBox.Visibility = Visibility.Visible;
            checkGroup.Visibility = Visibility.Visible;
            searchState.ToolTip = "Hide search box";
        }
        else {
            queryBox.Visibility = Visibility.Collapsed;
            checkGroup.Visibility = Visibility.Collapsed;
            searchState.ToolTip = "Local search";
        }
    }

    void onRightMouseUp(object sender, MouseButtonEventArgs e) {
        if (ayahListBox.SelectedItems.Count == 0) return;
        bool wordsSelected = false;
        if (ayahListBox.SelectedItems.Count == 1) {
            var ayah = (Ayah)ayahListBox.SelectedItem;
            for (int i = 0; i < ayah.Words.Count; i++) {
                if (!ayah.Words[i].IsHighlighted) continue;
                wordsSelected = true;
                break;
            }
        }
        if (wordsSelected) copyWordContext.IsOpen = true;
        else copyAyahContext.IsOpen = true;
    }

    void onLayoutUpdated(object? sender, EventArgs e) {
        ayahListBox.LayoutUpdated -= onLayoutUpdated;
        App.Current.Dispatcher.InvokeAsync(() => {
            ayahListBox.ScrollIntoView(ayahListBox.SelectedItem);
            var panel = Helper.FindVisualChild<VirtualizingStackPanel>(ayahListBox);
            var items = Helper.FindVisualChildren<ListBoxItem>(panel);
            var selected = Convert.ToInt32(((Ayah)ayahListBox.SelectedItem).AyahNo);

            foreach (var item in items) {
                var presenter = Helper.FindVisualChild<ContentPresenter>(item);
                var ayah = (Ayah)presenter.Content;
                if (Convert.ToInt32(ayah.AyahNo) == selected) {
                    presenter.BringIntoView();
                    break;
                }
            }
            progress.IsIndeterminate = false;
        }, DispatcherPriority.Background);
    }

    void onTranslationChanged(object? sender, EventArgs e) {
        selectedTranslators = translators.Selected;
        updateTranslation(Convert.ToInt32(ayahs.First().SurahNo));

        if (ayahListBox.SelectedItems.Count == 0 || ayahListBox.SelectedItems.Count > 1) return;
        ayahListBox.ScrollIntoView(ayahListBox.SelectedItem);
    }

    //void onTicked(object? sender, EventArgs e) {
    //    var timer = (DispatcherTimer)sender;
    //    timer.Tick -= onTicked;
    //    timer.Stop();

    //    App.Current.Dispatcher.InvokeAsync(() => {
    //        ayahListBox.ScrollIntoView(ayahListBox.SelectedItem);

    //        var panel = Helper.FindVisualChild<VirtualizingStackPanel>(ayahListBox);
    //        var items = Helper.FindVisualChildren<ListBoxItem>(panel);
    //        var selected = Convert.ToInt32(((Ayah)ayahListBox.SelectedItem).AyahNo);

    //        foreach (var item in items) {
    //            var presenter = Helper.FindVisualChild<ContentPresenter>(item);
    //            var ayah = (Ayah)presenter.Content;
    //            if (Convert.ToInt32(ayah.AyahNo) == selected) {
    //                presenter.BringIntoView();
    //                break;
    //            }
    //        }
    //        progress.IsIndeterminate = false;
    //    }, DispatcherPriority.Background);
    //}

    List<Ayah> getAyahs(int surahNo) {
        var words = getWords(surahNo);
        int ayahCount = App.surahs[surahNo - 1].Verses;
        var list = new List<Ayah>(ayahCount);

        IEnumerator<string>[] iterators = null;
        int[] translatorIds = null;

        if (selectedTranslators.Length > 0) {
            iterators = new IEnumerator<string>[selectedTranslators.Length];
            translatorIds = new int[selectedTranslators.Length];
            var translatorNames = App.global.TranslationDictionary.Keys.ToList();

            int index = 0;
            for (int i = 0; i < selectedTranslators.Length; i++) {
                var file = App.global.TranslationDictionary[selectedTranslators[i]];
                var lines = System.IO.File.ReadLines("Resources/Tanzil/" + file);
                var iterator = lines.GetEnumerator();
                iterator.MoveNext();
                while (!iterator.Current.StartsWith(surahNo + "|")) iterator.MoveNext();
                iterators[index] = iterator;
                translatorIds[index] = translatorNames.IndexOf(selectedTranslators[i]);
                index++;
            }
        }

        var parts = new string[3];
        var wordIterator = words.GetEnumerator();
        wordIterator.MoveNext();

        if (selectedTranslators.Length > 0) {
            for (int i = 0; i < ayahCount; i++) {
                var translations = new Translation[iterators.Length];
                for (int j = 0; j < iterators.Length; j++) {
                    parts = iterators[j].Current.Split('|');

                    translations[j] = new Translation() {
                        TranslatorId = translatorIds[j],
                        Content = parts[2]
                    };
                    iterators[j].MoveNext();
                }

                var ayahNo = parts[1];
                var query = ":" + ayahNo + ":";

                list.Add(new Ayah() {
                    SurahNo = parts[0],
                    AyahNo = parts[1],
                    Translations = translations,
                    Words = new List<Word>()
                });

                while (wordIterator.Current.Reference.Contains(query)) {
                    list[i].Words.Add(wordIterator.Current);
                    wordIterator.MoveNext();
                    if (wordIterator.Current is null) break;
                }
            }
            for (int j = 0; j < iterators.Length; j++) iterators[j].Dispose();
        }
        else {
            var sNo = surahNo.ToString();
            for (int i = 0; i < ayahCount; i++) {
                var ayahNo = (i + 1).ToString();
                var query = ":" + ayahNo + ":";

                list.Add(new Ayah() {
                    SurahNo = sNo,
                    AyahNo = ayahNo,
                    Words = new List<Word>()
                });

                while (wordIterator.Current.Reference.Contains(query)) {
                    list[i].Words.Add(wordIterator.Current);
                    wordIterator.MoveNext();
                    if (wordIterator.Current is null) break;
                }
            }
        }
        wordIterator.Dispose();
        return list;
    }

    List<Word> getWords(int surahNo) {
        var words = new List<Word>();

        for (int i = 0; i < App.links.Count; i++) {
            if (terminator.IsCancellationRequested) break;

            var item = App.links[i];
            int no = Convert.ToInt32(item.Reference.Substring(0, item.Reference.IndexOf(':')));
            if (no > surahNo) break;
            if (no < surahNo) continue;

            words.Add(new Word() {
                Reference = item.Reference,
                Transliteration = App.transliterations[Convert.ToInt32(item.Transliteration)],
                Tags = item.Tags,
                Segments = Helper.getSegments(item),
                Lemmas = Helper.getLemmas(item),
                LemmaIndices = item.LemmaIndices,
                Spellings = Helper.getSpellings(item),
                Meaning = App.meanings[Convert.ToInt32(item.Meaning)],
                Explanation = item.Explanation,
                Root = item.Root,
                RootIndex = item.RootIndex,
                Details = item.Details
            });
        }
        return words;
    }

    void updateTranslation(int surahNo) {
        if (selectedTranslators.Length == 0) {
            for (int i = 0; i < ayahs.Count; i++) {
                ayahs[i].Translations = null;
                ayahs[i].OnPropertyChanged(nameof(Ayah.Translations));
            }
            return;
        }

        //it'll read all selected files always

        var iterators = new IEnumerator<string>[selectedTranslators.Length];
        var translatorIds = new int[selectedTranslators.Length];
        var liranslatorsName = App.global.TranslationDictionary.Keys.ToList();

        int index = 0;
        foreach (var item in selectedTranslators) {
            var file = App.global.TranslationDictionary[item];
            var lines = System.IO.File.ReadLines("Resources/Tanzil/" + file);
            var iterator = lines.GetEnumerator();
            iterator.MoveNext();
            while (!iterator.Current.StartsWith(surahNo + "|")) iterator.MoveNext();
            iterators[index] = iterator;
            translatorIds[index] = liranslatorsName.IndexOf(item);
            index++;
        }

        for (int i = 0; i < ayahs.Count; i++) {
            var translations = new Translation[iterators.Length];

            for (int j = 0; j < iterators.Length; j++) {
                var line = iterators[j].Current;
                var parts = line.Split('|');

                translations[j] = new Translation() {
                    TranslatorId = translatorIds[j],
                    Content = parts[2]
                };
                iterators[j].MoveNext();
            }
            ayahs[i].Translations = translations;
            ayahs[i].OnPropertyChanged(nameof(Ayah.Translations));
        }
        foreach (var iterator in iterators) iterator.Dispose();
    }

    void copyWord() {
        var ayah = (Ayah)ayahListBox.SelectedItem;
        var builder = new StringBuilder();
        for (int i = 0; i < ayah.Words.Count; i++) {
            if (!ayah.Words[i].IsHighlighted) continue;
            ayah.Words[i].Segments[App.global.Transcript].Split('|').toArabic(builder);
            builder.Append(" ");
        }
        builder.Remove(builder.Length - 1, 1);
        Clipboard.SetText(builder.ToString());
    }

    void copyArabic() {
        var selected = ayahListBox.SelectedItems.Cast<Ayah>();
        progress.IsIndeterminate = true;

        Task.Run(() => {
            var builder = new StringBuilder();
            foreach (Ayah ayah in selected) {
                if (terminator.IsCancellationRequested) break; // want to check in nested loops?

                builder
                .Append(ayah.SurahNo.toArabicNo())
                .Append(':')
                .Append(ayah.AyahNo.toArabicNo())
                .Append(" - ");

                foreach (var word in ayah.Words) {
                    word.Segments[App.global.Transcript].Split('|').toArabic(builder);
                    builder.Append(" ");
                }
                builder.AppendLine();

                if (!terminator.IsCancellationRequested) {
                    App.Current.Dispatcher.Invoke(() => {
                        Clipboard.SetText(builder.ToString());
                        progress.IsIndeterminate = false;
                    });
                }
            }
        }, terminator.Token);
    }

    void copyEnglish() {
        var selected = ayahListBox.SelectedItems.Cast<Ayah>();
        progress.IsIndeterminate = true;

        Task.Run(() => {
            var builder = new StringBuilder();
            foreach (Ayah ayah in selected) {
                if (terminator.IsCancellationRequested) break; // want to check in nested loops?
                builder
                .Append(ayah.SurahNo)
                .Append(':')
                .Append(ayah.AyahNo + " - ");

                if (ayah.Translations.Length == 1) {
                    builder.Append(ayah.Translations[0].Content)
                    .AppendLine();
                }
                else {
                    var translatorNames = App.global.TranslationDictionary.Keys.ToList();
                    for (int i = 0; i < ayah.Translations.Length; i++) {
                        builder.Append(translatorNames[i])
                        .Append(": ")
                        .Append(ayah.Translations[i].Content)
                        .AppendLine();
                    }
                }

                if (!terminator.IsCancellationRequested) {
                    App.Current.Dispatcher.Invoke(() => {
                        Clipboard.SetText(builder.ToString());
                        progress.IsIndeterminate = false;
                    });
                }
            }
        }, terminator.Token);
    }

    void copyBoth() {
        var selected = ayahListBox.SelectedItems.Cast<Ayah>();
        progress.IsIndeterminate = true;

        Task.Run(() => {
            var builder = new StringBuilder();
            foreach (Ayah ayah in selected) {
                if (terminator.IsCancellationRequested) break; // want to check in nested loops?

                builder
                .Append(ayah.SurahNo.toArabicNo())
                .Append(':')
                .Append(ayah.AyahNo.toArabicNo())
                .Append(" - ");

                foreach (var word in ayah.Words) {
                    word.Segments[App.global.Transcript].Split('|').toArabic(builder);
                    builder.Append(" ");
                }
                builder
                .AppendLine()
                .Append(ayah.SurahNo)
                .Append(':')
                .Append(ayah.AyahNo + " - ");


                if (ayah.Translations.Length == 1) {
                    builder.Append(ayah.Translations[0].Content)
                    .AppendLine();
                }
                else {
                    var translatorNames = App.global.TranslationDictionary.Keys.ToList();
                    for (int i = 0; i < ayah.Translations.Length; i++) {
                        builder.Append(translatorNames[i])
                        .Append(": ")
                        .Append(ayah.Translations[i].Content)
                        .AppendLine();
                    }
                }
                if (!terminator.IsCancellationRequested) {
                    App.Current.Dispatcher.Invoke(() => {
                        Clipboard.SetText(builder.ToString());
                        progress.IsIndeterminate = false;
                    });
                }
            }
        }, terminator.Token);
    }

    protected override void unload() {
        queryBox.KeyUp -= onQuery;
        gotoBox.KeyUp -= onGoto;
        searchState.MouseLeftButtonUp -= onLeftClick;
        ayahListBox.MouseRightButtonUp -= onRightMouseUp;
        translatorDescriptor.RemoveValueChanged(translators, onTranslationChanged);

        terminator.Cancel();
        terminator.Dispose();
        base.unload();
    }
}
