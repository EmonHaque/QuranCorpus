﻿class Character {
    public char English { get; set; }
    public string Arabic { get; set; }
    public string Description { get; set; }
    public string Transliteration { get; set; }
}
