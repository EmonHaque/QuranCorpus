﻿class ItemsControlPanelTemplate : ItemsPanelTemplate {
    public ItemsControlPanelTemplate() {
        var panel = new FrameworkElementFactory(typeof(VirtualizingStackPanel));
        VisualTree = panel;
    }
}
