﻿class TafsirViewer : ScrollViewer {
    // Wheel Scroll fails sometime with FormattedBlock
    FormattedBlock block;

    public TafsirViewer() {
        Template = new ScrollViewerTemplate();
        HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled;
        VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
        block = new FormattedBlock(this) { Margin = new Thickness(5) };
        Content = block;
    }

    public void Update(Tafsir source) {
        ScrollToTop();
        block.Update(source);
    }

    class FormattedBlock : FrameworkElement {
        /* following doesn't work if you want to give diacritical marks a separate color
           FormattedText.SetForegroundBrush(Brushes.Yellow, startIndex, count);
        
           it breaks the word just like the following:
        
           var disjointed = new TextBlock() {
               FontSize = 60,
               Inlines = {
                  new Run("\x0644"),
                  new Run("\x0650"),
                  new Run("\x0644"),
                  new Run("\x0651\x064E"),
                  new Run("\x0647\x0650")
               }
            };
        */

        Tafsir source;
        DrawingVisual visual;
        ScrollViewer viewer;
        Typeface arabic, english;

        public FormattedBlock(ScrollViewer viewer) {
            this.viewer = viewer;
            visual = new DrawingVisual();
            SetBinding(ArabicFontProperty, new Binding() {
                Path = new PropertyPath(nameof(Global.ArabicFontFamily)),
                Source = App.global
            });
            SetBinding(ArabicFontSizeProperty, new Binding() {
                Path = new PropertyPath(nameof(Global.ArabicFontSize)),
                Source = App.global
            });
            arabic = new Typeface(ArabicFont, FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
            english = new Typeface(new FontFamily("Segoe UI"), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
        }

        public void Update(Tafsir source) {
            this.source = source;
            draw();
        }

        void draw() {
            // create one FormattedText and format line by line with startIndex and count;
            double width = viewer.ActualWidth - Constants.ScrollBarThickness - Margin.Left - Margin.Right;
            double height = Margin.Top;

            visual.Children.Clear();
            var dc = visual.RenderOpen();

            for (int i = 0; i < source.Lines.Count; i++) {
                string content;

                var direction = FlowDirection.LeftToRight;
                double fontSize;
                Typeface face;
                var brush = Constants.Foreground;
                if (source.Lines[i].IsArabic) {
                    content = source.Lines[i].Content;
                    fontSize = ArabicFontSize;
                    direction = FlowDirection.RightToLeft;
                    face = arabic;
                }
                else {
                    content = source.Lines[i].Content + "\n\n";
                    fontSize = App.global.EnglishFontSize;
                   
                    if (source.Lines[i].IsBold) {
                        face = new Typeface(new FontFamily("Segoe UI"), FontStyles.Normal, FontWeights.Bold, FontStretches.Normal);
                        brush = Brushes.Gray;
                    }
                    else face = english;
                }

                var para = new FormattedText(
                    content,
                    CultureInfo.CurrentCulture,
                    direction,
                    face,
                    fontSize,
                    brush,
                    VisualTreeHelper.GetDpi(this).PixelsPerDip
                    );

                para.SetMaxTextWidths([width]);
                dc.DrawText(para, new Point(0, height));
                height += para.Height;
            }
            dc.Close();
            Height = height + Margin.Top + Margin.Bottom;
        }

        protected override int VisualChildrenCount => 1;
        protected override Visual GetVisualChild(int index) => visual;

        #region Dependencies
        public FontFamily ArabicFont {
            get { return (FontFamily)GetValue(ArabicFontProperty); }
            set { SetValue(ArabicFontProperty, value); }
        }

        public static readonly DependencyProperty ArabicFontProperty =
            DependencyProperty.Register("ArabicFont", typeof(FontFamily), typeof(FormattedBlock), new PropertyMetadata() {
                DefaultValue = App.global.ArabicFontFamily,
                PropertyChangedCallback = (o, e) => ((FormattedBlock)o).draw()
            });


        public double ArabicFontSize {
            get { return (double)GetValue(ArabicFontSizeProperty); }
            set { SetValue(ArabicFontSizeProperty, value); }
        }


        public static readonly DependencyProperty ArabicFontSizeProperty =
            DependencyProperty.Register("ArabicFontSize", typeof(double), typeof(FormattedBlock), new PropertyMetadata() {
                DefaultValue = App.global.ArabicFontSize,
                PropertyChangedCallback = (o, e) => ((FormattedBlock)o).draw()
            });
        #endregion
    }
}
