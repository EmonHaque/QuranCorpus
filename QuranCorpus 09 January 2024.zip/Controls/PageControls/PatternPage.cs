﻿class PatternPage : Page {
    Grid content;
    CancellationTokenSource terminator;
    ProgressBar progress;
    ScrollViewer columnViewer, rowViewer;
    Legend r4Legend;
    Pattern selected;

    static ScrollViewer contentViewer;
    static FormGrid current;

    List<string> possibleForms = new() {
        "I",
        "II",
        "III",
        "IV",
        "V",
        "VI",
        "VII",
        "VIII",
        "IX",
        "X",
        "XI",
        "XII"
    };

    public override PageType Type => PageType.Pattern;
    public override UIElement Content => content;

    public PatternPage() {
        terminator = new CancellationTokenSource();
        r4Legend = new Legend("r4", Foregrounds.R4);

        var palette = new StackPanel() {
            FlowDirection = FlowDirection.LeftToRight,
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Right,
            Children = {
                new Legend("r1", Foregrounds.R1),
                new Legend("r2", Foregrounds.R2),
                new Legend("r3", Foregrounds.R3),
                r4Legend,
                new Legend("additional", Foregrounds.NonRoot),
            }
        };
        progress = new ProgressBar() {
            Height = Constants.ProgressBarHeight,
            FlowDirection = FlowDirection.RightToLeft
        };
        columnViewer = new ScrollViewer() {
            VerticalScrollBarVisibility = ScrollBarVisibility.Disabled,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Hidden,
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0)
        };
        rowViewer = new ScrollViewer() {
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Hidden
        };
        contentViewer = new ScrollViewer() {
            Template = new ScrollViewerTemplate(),
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto
        };

        Grid.SetColumnSpan(progress, 2);

        Grid.SetColumn(palette, 1);
        Grid.SetColumn(columnViewer, 1);
        Grid.SetColumn(contentViewer, 1);

        Grid.SetRow(palette, 1);
        Grid.SetRow(columnViewer, 2);
        Grid.SetRow(contentViewer, 3);
        Grid.SetRow(rowViewer, 3);

        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(){Width = new GridLength(75)},
                new ColumnDefinition()
            },
            Children = { progress, palette, rowViewer, columnViewer, contentViewer }
        };
        content.SetValue(Grid.IsSharedSizeScopeProperty, true);

        contentViewer.ScrollChanged += onContentScroll;
        contentViewer.LayoutUpdated += onLayoutUpdated;
        rowViewer.ScrollChanged += onRowScroll;
        columnViewer.ScrollChanged += onColumnScroll;
    }

    public PatternPage(List<PatternSegment> consolidated) : this() {
        HeaderText = "Consolidated";
        progress.IsIndeterminate = true;
        Task.Run(() => {
            List<RootForm> source = new();
            var groups = consolidated.GroupBy(x => x.Pattern).ToList();
            var helper = new PatternHelper();

            for (int i = 0; i < groups.Count; i++) {
                var list = groups[i].ToList();
                List<RootForm> result = groups[i].Key switch {
                    "+~+" => helper.shaddaPlus(list),
                    "++~" => helper.plusShadda(list),
                    "w++" => helper.wawPlusPlus(list),
                    "+w+" => helper.plusWawPlus(list),
                    "++w" => helper.plusPlusWaw(list),
                    "y++" => helper.yaPlusPlus(list),
                    "+y+" => helper.plusYaPlus(list),
                    "++y" => helper.plusPlusYa(list),
                    "A++" => helper.hamzaPlusPlus(list),
                    "+A+" => helper.plusHamzaPlus(list),
                    "++A" => helper.plusPlusHamza(list),
                    "Aw+" => helper.hamzaWawPlus(list),
                    "Ay+" => helper.hamzaYaPlus(list),
                    "yA+" => helper.yaHamzaPlus(list),
                    "wA+" => helper.wawHamzaPlus(list),
                    "yw+" => helper.yaWawPlus(list),
                    "w+y" => helper.wawPlusYa(list),
                    "A+y" => helper.hamzaPlusYa(list),
                    "y+y" => helper.yaPlusYa(list),
                    "w+A" => helper.wawPlusHamza(list),
                    "+wy" => helper.plusWawYa(list),
                    "+wA" => helper.plusWawHamza(list),
                    "+yA" => helper.plusYaHamza(list),
                    "+Ay" => helper.plusHamzaYa(list),
                    "A+w" => helper.hamzaPlusWaw(list),
                    "A+~" => helper.hamzaPlusShadda(list),
                    "w+~" => helper.wawPlusShadda(list),
                    "y+~" => helper.yaPlusShadda(list),
                    "Ay~" => helper.hamzaYaShadda(list),
                    "+w~" => helper.plusWawShadda(list),
                    "+y~" => helper.plusYaShadda(list),
                    "Awy" => helper.alifWawYa(list),
                    "++++" => helper.quad(list),
                    "-+-+" => helper.quad(list),
                    _ => helper.normal(list)
                };
                source.AddRange(result);
            }
            source = source.OrderBy(x => x.Pattern).ToList();
            List<string> rows = new();
            List<string> columns = new();

            for (int i = 0; i < source.Count; i++) {
                var match = source[i];
                if (!rows.Contains(match.Form)) {
                    rows.Add(match.Form);
                }
                if (string.IsNullOrEmpty(match.SubTag)) {
                    if (!columns.Contains(match.Tag)) columns.Add(match.Tag);
                }
                else {
                    if (!columns.Contains(match.SubTag)) columns.Add(match.SubTag);
                }
            }

            rows = possibleForms.Intersect(rows).ToList();
            columns = helper.PossibleTags.Intersect(columns).ToList();

            App.Current.Dispatcher.Invoke(() => {
                makeConsolidatedMatrix(rows, columns, source);
                progress.IsIndeterminate = false;
            });
        }, terminator.Token);
    }

    public PatternPage(Pattern selected, List<PatternSegment> source) : this() => reset(selected, source);

    public void setContent(Pattern selected, List<PatternSegment> source) {
        if (this.selected is null) return;
        if (this.selected.Equals(selected)) return;
        reset(selected, source);
    }

    void reset(Pattern selected, List<PatternSegment> source) {
        this.selected = selected;
        //this.source = source;
        HeaderText = selected.Root;

        progress.IsIndeterminate = true;
        contentViewer.Content = null;
        columnViewer.Content = null;
        rowViewer.Content = null;
        r4Legend.Visibility = selected.Root.Length == 4 ?
           Visibility.Visible : Visibility.Collapsed;

        Task.Run(() => {
            var helper = new PatternHelper();
            List<RootForm> list = selected.Root switch {
                "+~+" => helper.shaddaPlus(source),
                "++~" => helper.plusShadda(source),
                "w++" => helper.wawPlusPlus(source),
                "+w+" => helper.plusWawPlus(source),
                "++w" => helper.plusPlusWaw(source),
                "y++" => helper.yaPlusPlus(source),
                "+y+" => helper.plusYaPlus(source),
                "++y" => helper.plusPlusYa(source),
                "A++" => helper.hamzaPlusPlus(source),
                "+A+" => helper.plusHamzaPlus(source),
                "++A" => helper.plusPlusHamza(source),
                "Aw+" => helper.hamzaWawPlus(source),
                "Ay+" => helper.hamzaYaPlus(source),
                "yA+" => helper.yaHamzaPlus(source),
                "wA+" => helper.wawHamzaPlus(source),
                "yw+" => helper.yaWawPlus(source),
                "w+y" => helper.wawPlusYa(source),
                "A+y" => helper.hamzaPlusYa(source),
                "y+y" => helper.yaPlusYa(source),
                "w+A" => helper.wawPlusHamza(source),
                "+wy" => helper.plusWawYa(source),
                "+wA" => helper.plusWawHamza(source),
                "+yA" => helper.plusYaHamza(source),
                "+Ay" => helper.plusHamzaYa(source),
                "A+w" => helper.hamzaPlusWaw(source),
                "A+~" => helper.hamzaPlusShadda(source),
                "w+~" => helper.wawPlusShadda(source),
                "y+~" => helper.yaPlusShadda(source),
                "Ay~" => helper.hamzaYaShadda(source),
                "+w~" => helper.plusWawShadda(source),
                "+y~" => helper.plusYaShadda(source),
                "Awy" => helper.alifWawYa(source),
                "++++" => helper.quad(source),
                "-+-+" => helper.quad(source),
                _ => helper.normal(source)
            };
            list = list.OrderBy(x => x.Pattern).ToList();
            List<string> rows = new();
            List<string> columns = new();

            for (int i = 0; i < list.Count; i++) {
                var match = list[i];
                if (!rows.Contains(match.Form)) {
                    rows.Add(match.Form);
                }
                if (string.IsNullOrEmpty(match.SubTag)) {
                    if (!columns.Contains(match.Tag)) columns.Add(match.Tag);
                }
                else {
                    if (!columns.Contains(match.SubTag)) columns.Add(match.SubTag);
                }
            }

            rows = possibleForms.Intersect(rows).ToList();
            columns = helper.PossibleTags.Intersect(columns).ToList();

            App.Current.Dispatcher.Invoke(() => {
                makeMatrix(rows, columns, list);
                progress.IsIndeterminate = false;
            });
        }, terminator.Token);
    }

    void onContentScroll(object sender, ScrollChangedEventArgs e) {
        columnViewer.ScrollToHorizontalOffset(e.HorizontalOffset);
        rowViewer.ScrollToVerticalOffset(e.VerticalOffset);
    }

    void onColumnScroll(object sender, ScrollChangedEventArgs e) {
        contentViewer.ScrollToHorizontalOffset(e.HorizontalOffset);
    }

    void onRowScroll(object sender, ScrollChangedEventArgs e) {
        contentViewer.ScrollToVerticalOffset(e.VerticalOffset);
    }

    void onLayoutUpdated(object? sender, EventArgs e) {
        rowViewer.Margin =
            contentViewer.ComputedHorizontalScrollBarVisibility == Visibility.Visible ?
            new Thickness(0, 0, 0, Constants.ScrollBarThickness) :
            rowViewer.Margin = new Thickness(0);
    }

    void makeMatrix(List<string> rows, List<string> columns, List<RootForm> source) {
        var columnGrid = new Grid() { ShowGridLines = true };
        var rowGrid = new Grid() { ShowGridLines = true };
        var grid = new Grid() { ShowGridLines = true };

        for (int i = 0; i < columns.Count; i++) {
            grid.ColumnDefinitions.Add(new ColumnDefinition() { Tag = columns[i], SharedSizeGroup = "col" + i });
            columnGrid.ColumnDefinitions.Add(new ColumnDefinition() { Tag = columns[i], SharedSizeGroup = "col" + i });
            var block = new TextBlockEnglish() {
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(10, 0, 10, 0),
                Text = columns[i],
                HorizontalAlignment = HorizontalAlignment.Center
            };
            Grid.SetColumn(block, i);
            columnGrid.Children.Add(block);
        }

        for (int i = 0; i < rows.Count; i++) {
            grid.RowDefinitions.Add(new RowDefinition() { Tag = rows[i], SharedSizeGroup = "row" + i });
            rowGrid.RowDefinitions.Add(new RowDefinition() { Tag = rows[i], SharedSizeGroup = "row" + i });
            var block = new TextBlockEnglish() {
                FontWeight = FontWeights.Bold,
                Text = "Form " + rows[i],
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetRow(block, i);
            rowGrid.Children.Add(block);
        }

        for (int i = 0; i < rowGrid.RowDefinitions.Count; i++) {
            for (int j = 0; j < columnGrid.ColumnDefinitions.Count; j++) {
                var block = new StackPanel() {
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(10, 0, 10, 0)
                };
                Grid.SetColumn(block, j);
                Grid.SetRow(block, i);
                grid.Children.Add(block);
            }
        }

        List<FormGrid> added = new();
        var groups = source.GroupBy(x => new { x.Pattern, x.Segmentation, x.SubTag, x.Form }).ToImmutableList();

        for (int i = 0; i < source.Count; i++) {
            int column = 0;
            for (int j = 0; j < columnGrid.ColumnDefinitions.Count; j++) {
                if (!columnGrid.ColumnDefinitions[j].Tag.Equals(source[i].SubTag)) continue;
                column = j;
                break;
            }
            int row = 0;
            for (int j = 0; j < rowGrid.RowDefinitions.Count; j++) {
                if (!rowGrid.RowDefinitions[j].Tag.Equals(source[i].Form)) continue;
                row = j;
                break;
            }

            var stack = grid
                .Children.OfType<StackPanel>()
                .First(e => Grid.GetRow(e) == row && Grid.GetColumn(e) == column);

            bool isFound = false;
            for (int j = 0; j < stack.Children.Count; j++) {
                var c = (FormGrid)stack.Children[j];
                if (!c.Segmentation.Equals(source[i].Segmentation)) continue;
                c.WordCount += source[i].Count;
                c.References.AddRange(source[i].References);
                isFound = true;
                break;
            }

            if (isFound) continue;

            var subList = groups.First(
                x => x.Key.Pattern.Equals(source[i].Pattern)
                && x.Key.Segmentation.Equals(source[i].Segmentation)
                && x.Key.SubTag.Equals(source[i].SubTag)
                && x.Key.Form.Equals(source[i].Form));

            var newSpelling = new FormGrid() {
                Tag = source[i].Form + " - " + source[i].SubTag,
                Segments = source[i].Segments,
                Segmentation = source[i].Segmentation,
                RootCount = subList.Select(x => x.Root).Distinct().Count(),
                WordCount = source[i].Count,
                ReferenceCount = subList.Sum(x => x.References.Sum(x => x.References.Count)),
                References = source[i].References
            };

            stack.Children.Add(newSpelling);
            added.Add(newSpelling);
        }

        var duplicateGroups =
            added.GroupBy(x => x.Segmentation)
            .Where(x => x.Count() > 1)
            .ToList();

        for (int i = 0; i < duplicateGroups.Count; i++) {
            var text = duplicateGroups[i].Select(x => x.Tag.ToString()).ToArray();
            for (int j = 0; j < duplicateGroups[i].Count(); j++) {
                duplicateGroups[i].ElementAt(j).DuplicateTags = text;
            }
        }

        columnViewer.Content = new Border() {
            Child = columnGrid,
            BorderThickness = new Thickness(0, 0, 0, 0.5),
            BorderBrush = Brushes.LightGray
        };
        rowViewer.Content = new Border() {
            Child = rowGrid,
            BorderThickness = new Thickness(0, 0, 0.5, 0),

            BorderBrush = Brushes.LightGray
        };
        contentViewer.Content = grid;
    }

    void makeConsolidatedMatrix(List<string> rows, List<string> columns, List<RootForm> source) {
        var columnGrid = new Grid() { ShowGridLines = true };
        var rowGrid = new Grid() { ShowGridLines = true };
        var grid = new Grid() { ShowGridLines = true };

        for (int i = 0; i < columns.Count; i++) {
            grid.ColumnDefinitions.Add(new ColumnDefinition() { Tag = columns[i], SharedSizeGroup = "col" + i });
            columnGrid.ColumnDefinitions.Add(new ColumnDefinition() { Tag = columns[i], SharedSizeGroup = "col" + i });
            var block = new TextBlockEnglish() {
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(10, 0, 10, 0),
                Text = columns[i],
                HorizontalAlignment = HorizontalAlignment.Center
            };
            Grid.SetColumn(block, i);
            columnGrid.Children.Add(block);
        }

        for (int i = 0; i < rows.Count; i++) {
            grid.RowDefinitions.Add(new RowDefinition() { Tag = rows[i], SharedSizeGroup = "row" + i });
            rowGrid.RowDefinitions.Add(new RowDefinition() { Tag = rows[i], SharedSizeGroup = "row" + i });
            var block = new TextBlockEnglish() {
                FontWeight = FontWeights.Bold,
                Text = "Form " + rows[i],
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetRow(block, i);
            rowGrid.Children.Add(block);
        }

        for (int i = 0; i < rowGrid.RowDefinitions.Count; i++) {
            for (int j = 0; j < columnGrid.ColumnDefinitions.Count; j++) {
                var block = new StackPanel() {
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(10, 0, 10, 0)
                };
                Grid.SetColumn(block, j);
                Grid.SetRow(block, i);
                grid.Children.Add(block);
            }
        }

        List<FormGrid> added = new();
        var groups = source.GroupBy(x => new { x.Pattern, x.Segmentation, x.SubTag, x.Form }).ToImmutableList();

        for (int i = 0; i < source.Count; i++) {
            int column = 0;
            for (int j = 0; j < columnGrid.ColumnDefinitions.Count; j++) {
                if (!columnGrid.ColumnDefinitions[j].Tag.Equals(source[i].SubTag)) continue;
                column = j;
                break;
            }
            int row = 0;
            for (int j = 0; j < rowGrid.RowDefinitions.Count; j++) {
                if (!rowGrid.RowDefinitions[j].Tag.Equals(source[i].Form)) continue;
                row = j;
                break;
            }

            var stack = grid
                .Children.OfType<StackPanel>()
                .First(e => Grid.GetRow(e) == row && Grid.GetColumn(e) == column);

            bool isFound = false;
            for (int j = 0; j < stack.Children.Count; j++) {
                var c = (FormGrid)stack.Children[j];
                if (!c.Segmentation.Equals(source[i].Segmentation)) continue;
                c.WordCount += source[i].Count;
                c.References.AddRange(source[i].References);
                isFound = true;
                break;
            }

            if (isFound) continue;

            var subList = groups.First(
                x => x.Key.Pattern.Equals(source[i].Pattern)
                && x.Key.Segmentation.Equals(source[i].Segmentation)
                && x.Key.SubTag.Equals(source[i].SubTag)
                && x.Key.Form.Equals(source[i].Form));

            var newSpelling = new FormGrid() {
                Tag = source[i].Form + " - " + source[i].SubTag,
                Segments = source[i].Segments,
                Segmentation = source[i].Segmentation,
                RootCount = subList.Select(x => x.Root).Distinct().Count(),
                WordCount = source[i].Count,
                ReferenceCount = subList.Sum(x => x.References.Sum(x => x.References.Count)),
                References = source[i].References
            };

            stack.Children.Add(newSpelling);
            added.Add(newSpelling);
        }

        var duplicateGroups =
            added.GroupBy(x => x.Segmentation)
            .Where(x => x.Count() > 1)
            .ToList();

        for (int i = 0; i < duplicateGroups.Count; i++) {
            var text = duplicateGroups[i].Select(x => x.Tag.ToString()).ToArray();
            for (int j = 0; j < duplicateGroups[i].Count(); j++) {
                duplicateGroups[i].ElementAt(j).DuplicateTags = text;
            }
        }

        columnViewer.Content = new Border() {
            Child = columnGrid,
            BorderThickness = new Thickness(0, 0, 0, 0.5),
            BorderBrush = Brushes.LightGray
        };
        rowViewer.Content = new Border() {
            Child = rowGrid,
            BorderThickness = new Thickness(0, 0, 0.5, 0),

            BorderBrush = Brushes.LightGray
        };
        contentViewer.Content = grid;
    }

    protected override void unload() {
        terminator.Cancel();
        terminator.Dispose();
        contentViewer.ScrollChanged -= onContentScroll;
        rowViewer.ScrollChanged -= onRowScroll;
        columnViewer.ScrollChanged -= onColumnScroll;
        contentViewer.LayoutUpdated -= onLayoutUpdated;
        base.unload();
    }

    class FormGrid : Border {
        bool isLoaded;
        Grid child;
        TextBlockArabic word;
        TextBlockEnglish counts;
        Border duplicateBorder;
        Popup pop;
        ListBox popList;

        public int RootCount { get; set; }
        public int ReferenceCount { get; set; }
        public int WordCount { get; set; }
        public string[] DuplicateTags { get; set; }
        public List<RootSegment> Segments { get; set; }
        public List<PatternReference> References { get; set; }
        public string Segmentation { get; set; }

        public FormGrid() {
            FlowDirection = FlowDirection.LeftToRight;
            Margin = new Thickness(1);
            Padding = new Thickness(0, 0, 2.5, 0);
            CornerRadius = new CornerRadius(10);
            BorderThickness = new Thickness(Constants.BottomLineThickness);
            BorderBrush = Brushes.Transparent;
            Background = Brushes.Transparent;

            word = new TextBlockArabic() {
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };
            counts = new TextBlockEnglish() {
                Margin = new Thickness(5, 0, 0, 0),
                TextAlignment = TextAlignment.Center
            };
            Grid.SetColumn(word, 1);

            child = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){ Width = new GridLength(50) },
                    new ColumnDefinition()
                },
                Children = { counts, word }
            };
            Child = child;

            Loaded += onLoaed;
            Unloaded += onUnloaded;
        }

        void onLoaed(object sender, RoutedEventArgs e) {
            if (!isLoaded) {
                addSegments();
                
                counts.Inlines.Add(new Run(RootCount.ToString()) {
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.Gray
                });
                counts.Inlines.Add(new Run("\n" + WordCount));
                counts.Inlines.Add(new Run("\n" + ReferenceCount.ToString("N0")) { Foreground = Brushes.SkyBlue });
                
                if (DuplicateTags is not null) {
                    child.ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(30) });
                    var block = new TextBlockEnglish() {
                        HorizontalAlignment = HorizontalAlignment.Center,
                        VerticalAlignment = VerticalAlignment.Center,
                        Text = DuplicateTags.Length.ToString(),
                    };
                    
                    duplicateBorder = new Border() {
                        Background = Brushes.Transparent,
                        Height = 24,
                        Width = 24,
                        BorderBrush = Brushes.Gray,
                        BorderThickness = new Thickness(Constants.BottomLineThickness),
                        CornerRadius = new CornerRadius(12),
                        Child = block
                    };
                    Grid.SetColumn(duplicateBorder, 2);
                    child.Children.Add(duplicateBorder);

                    popList = new ListBox() { ItemsSource = DuplicateTags };
                    pop = new Popup() {
                        AllowsTransparency = true,
                        PlacementTarget = duplicateBorder,
                        Placement = PlacementMode.Bottom,
                        StaysOpen = false,
                        Child = new Border() {
                            CornerRadius = new CornerRadius(10),
                            Padding = new Thickness(5),
                            BorderThickness = new Thickness(Constants.BottomLineThickness),
                            BorderBrush = Constants.Foreground,
                            Background = Constants.Background,
                            Child = popList
                        }
                    };
                }
                
                App.global.PropertyChanged += onTatweelLengthChanged;
                isLoaded = true;
            }

            if (duplicateBorder is null) return;
            duplicateBorder.MouseEnter += onDuplicateHoverEnter;
            popList.MouseLeftButtonUp += onPopListClick;
            pop.Closed += onPopClosed;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            if (duplicateBorder is null) return;
            duplicateBorder.MouseEnter -= onDuplicateHoverEnter;
            popList.MouseLeftButtonUp -= onPopListClick;
            pop.Closed -= onPopClosed;
        }

        void onTatweelLengthChanged(object? sender, PropertyChangedEventArgs e) {
            if (!e.PropertyName.Equals(nameof(App.global.TatweelLength))) return;
            word.Inlines.Clear();
            addSegments();
        }

        void onPopClosed(object? sender, EventArgs e) {
            if (!Equals(current)) {
                BorderBrush = Brushes.Transparent;
                Background = Brushes.Transparent;
            }
            else Background = Constants.BackgroundDark;
            pop.IsOpen = false;
        }

        void onDuplicateHoverEnter(object sender, MouseEventArgs e) {
            if (pop.IsOpen) return;
            pop.IsOpen = true;
        }

        void onPopListClick(object sender, MouseButtonEventArgs e) {
            pop.IsOpen = false;
            if (popList.SelectedItem is null) return;
            var selected = popList.SelectedItem.ToString();
            var item = Tag.ToString();
            if (item.Equals(selected)) return;
            var parts = selected.Split('-', StringSplitOptions.TrimEntries);

            int row = 0, column = 0;
            var grid = Helper.FindParentOfType<Grid>(this);
            for (int i = 0; i < grid.RowDefinitions.Count; i++) {
                if (!grid.RowDefinitions[i].Tag.Equals(parts[0])) continue;
                row = i;
                break;
            }
            for (int i = 0; i < grid.ColumnDefinitions.Count; i++) {
                if (!grid.ColumnDefinitions[i].Tag.Equals(parts[1])) continue;
                column = i;
                break;
            }
            var stack = grid
                .Children.OfType<StackPanel>()
                .First(e => Grid.GetRow(e) == row && Grid.GetColumn(e) == column);

            FormGrid formGrid = null;
            for (int i = 0; i < stack.Children.Count; i++) {
                var form = (FormGrid)stack.Children[i];
                if (!form.Segmentation.Equals(Segmentation)) continue;
                formGrid = form;
            }

            var position = formGrid.TransformToVisual(grid).Transform(new Point(0, 0));
            position.X -= formGrid.ActualWidth + Margin.Right + Padding.Right;
            position.Y -= formGrid.ActualHeight - Margin.Top - Padding.Top;

            contentViewer.ScrollToHorizontalOffset(position.X);
            contentViewer.ScrollToVerticalOffset(position.Y);

            formGrid.Background = Brushes.Black;
        }

        void addSegments() {
            for (int i = 0; i < Segments.Count; i++) {
                Brush b = Segments[i].SegmentNo switch {
                    0 => Foregrounds.NonRoot,
                    1 => Foregrounds.R1,
                    2 => Foregrounds.R2,
                    3 => Foregrounds.R3,
                    4 => Foregrounds.R4
                };
                word.Inlines.Add(new Run() {
                    Foreground = b,
                    Text = Segments[i].IsRoot ?
                    (
                        PatternHelper.leadingTatweel +
                        Segments[i].Token.Replace("+", "") +
                        PatternHelper.trailingTatweel
                    ).toArabic()
                    : Segments[i].Token.toArabic()
                });
            }
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            base.OnMouseEnter(e);
            if (!Equals(current)) BorderBrush = Brushes.LightGray;
        }

        protected override void OnMouseLeave(MouseEventArgs e) {
            base.OnMouseLeave(e);
            if (!Equals(current)) {
                BorderBrush = Brushes.Transparent;
                Background = Brushes.Transparent;
            }
            else Background = Constants.BackgroundDark;
        }

        protected override void OnPreviewMouseDown(MouseButtonEventArgs e) {
            base.OnPreviewMouseUp(e);
            if (e.ChangedButton != MouseButton.Left) return;
            if (e.ClickCount != 2) return;
            if (current is not null) {
                current.BorderBrush = Brushes.Transparent;
                current.Background = Brushes.Transparent;
            }
            current = this;
            current.BorderBrush = Brushes.LightGray;
            current.Background = Constants.BackgroundDark;
            ((App)Application.Current).FocusedControl
                .addPatternMatchPage(string.Join("", Segments.Select(x => x.Token)), References);
        }
    }

    class Legend : StackPanel {
        public Legend(string text, Brush brush) {
            Orientation = Orientation.Horizontal;
            var block = new TextBlockEnglish() { Text = text };
            var rect = new Ellipse() {
                Width = 10,
                Height = 10,
                Fill = brush,
                Margin = new Thickness(5, 0, 7.5, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            Children.Add(block);
            Children.Add(rect);
        }
    }
}