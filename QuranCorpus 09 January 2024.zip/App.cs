﻿class App : Application {
    public static string indexMa, indexIz, indexYwm, indexKll, indexHyn, indexNEm;
    public IDataObject clipData;
    public static Global global = new();
    public static List<Character> characters;
    public static List<Surah> surahs;
    public static List<string> transliterations;
    public static List<string> explanations;
    public static List<string> meanings;
    public static List<string> roots;
    public static List<string> segments;
    public static List<string> lemmas;
    public static List<string> spellings;
    public static List<Tag> tags;
    public static List<Detail> details;
    public static List<Link> links;
    public static List<HadithBook> hadithBooks;
    public static List<HadithChapter> hadithChapters;
    public static List<HadithSection> hadithSections;

    public static string[] tagArray = { "N", "PN", "ADJ", "LOC", "INTG", "T", "COND" };
   
    public PageControl FocusedControl => Pages.First(x => x.IsFocused);
    public List<PageControl> Pages { get; set; }

    List<Form> rootForms;
    public List<Form> RootForms {
        get {
            if (rootForms is null) rootForms = Helper.getRootForms();
            return rootForms; 
        }
    }

    [STAThread]
    static void Main(string[] args) => new App().Run();

    protected override void OnStartup(StartupEventArgs e) {
        Current.DispatcherUnhandledException += unhandledDispatchExceptons;
        TaskScheduler.UnobservedTaskException += taskExceptionHandler;
        //AppDomain.CurrentDomain.UnhandledException += unhandledNonUIException;
        getData();
        setStyle();
        Pages = new List<PageControl>() { new PageControl() { IsFocused = true } };
        MainWindow = new RootWindow() {
            Content = new RootPanel() {
                Children = {
                    new MainView(),
                    new AboutView(),
                    new UsageView()
                }
            }
        };
        MainWindow.Show();
    }

    protected override void OnExit(ExitEventArgs e) {
        var font = string.IsNullOrEmpty(global.ArabicFont) ? global.FontDictionary.Last().Key : global.ArabicFont;
        var translation = string.IsNullOrEmpty(global.Translation) ? global.TranslationDictionary.First().Key : global.Translation;
        var transcript = global.TranscriptDictionary[global.Transcript];
        int popup = global.PopupOnHover ? 1 : 0;
        int colorize = global.ColorizeSegments ? 1 : 0;
        int transliteration = global.Transliteration ? 1 : 0;
        int wordByWordTranslation = global.WordByWordTranslation ? 1 : 0;
        string settings =
            @"ArabicFontSize=" + global.ArabicFontSize + '\n' +
            "EnglishFontSize=" + global.EnglishFontSize + '\n' +
            "ArabicFont=" + font + '\n' +
            "Translation=" + translation + '\n' +
            "Transcript=" + transcript + '\n' +
            "Popup=" + popup + '\n' +
            "Colorize=" + colorize + '\n' +
            "Transliteration=" + transliteration + '\n' +
            "WordByWordTranslation=" + wordByWordTranslation + '\n' +
            "TatweelLength=" + global.TatweelLength;

        System.IO.File.WriteAllText("Resources/settings.txt", settings);

        try {
            if ((clipData is not null) && Clipboard.IsCurrent(clipData)) {
                Clipboard.Flush();
            }
        }
        catch (COMException ex) { }

        base.OnExit(e);
    }

    void getData() {
        var allLines = System.IO.File.ReadAllLines("Resources/settings.txt").ToList();
        for (int i = 0; i < allLines.Count; i++) {
            var parts = allLines[i].Split('=');
            switch (parts[0]) {
                case "ArabicFont":
                    global.ArabicFont = parts[1];
                    var directory = parts[1].StartsWith("KFGQPC") ? "Resources/KFGQPC/Fonts/#" : "Resources/Fonts/#";
                    global.ArabicFontFamily =
                        new FontFamily(System.IO.Path.GetFullPath(directory) + global.FontDictionary[parts[1]]);
                    break;
                case "ArabicFontSize":
                    global.ArabicFontSize = Convert.ToDouble(parts[1]);
                    break;
                case "EnglishFontSize":
                    global.EnglishFontSize = Convert.ToDouble(parts[1]);
                    break;
                case "Translation":
                    global.Translation = parts[1];
                    break;
                case "Transcript":
                    global.Transcript = global.TranscriptDictionary.First(x => x.Value.Equals(parts[1])).Key;
                    break;
                case "Popup":
                    global.PopupOnHover = parts[1].Equals("1");
                    break;
                case "Colorize":
                    global.ColorizeSegments = parts[1].Equals("1");
                    break;
                case "Transliteration":
                    global.Transliteration = parts[1].Equals("1");
                    break;
                case "WordByWordTranslation":
                    global.WordByWordTranslation = parts[1].Equals("1");
                    break;
                case "TatweelLength":
                    global.TatweelLength = Convert.ToInt32(parts[1]);
                    break;
            }
        }

        characters = new List<Character>();
        var lines = System.IO.File.ReadLines("Resources/Corpus/buckwalter.txt").ToList();
        for (int i = 0; i < lines.Count; i++) {
            if (lines[i].StartsWith('#')) continue;
            var parts = lines[i].Split('\t');
            characters.Add(new Character() {
                Arabic = parts[0],
                English = char.Parse(parts[1]),
                Description = parts[2],
                Transliteration = parts[3]
            });
        }

        surahs = new List<Surah>();
        lines = System.IO.File.ReadLines("Resources/surahName.txt").Skip(1).ToList();
        for (int i = 0; i < lines.Count; i++) {
            var parts = lines[i].Split('\t');
            surahs.Add(new Surah() {
                Id = Convert.ToInt32(parts[0]),
                Order = Convert.ToInt32(parts[1]),
                Full = parts[2],
                Simple = parts[3],
                Transliteration = parts[4],
                Meaning = parts[5],
                Verses = Convert.ToInt32(parts[6]),
                Place = parts[7]
            });
        }

        transliterations = System.IO.File.ReadAllLines("Resources/Corpus/transliterations.txt").ToList();
        explanations = System.IO.File.ReadAllLines("Resources/Corpus/explanations.txt").ToList();
        meanings = System.IO.File.ReadAllLines("Resources/Corpus/meanings.txt").ToList();
        roots = System.IO.File.ReadAllLines("Resources/Corpus/roots.txt").ToList();
        segments = System.IO.File.ReadAllLines("Resources/Corpus/segments.txt").ToList();
        lemmas = System.IO.File.ReadAllLines("Resources/Corpus/lemmas.txt").ToList();
        spellings = System.IO.File.ReadAllLines("Resources/Corpus/spellings.txt").ToList();

        tags =
            System.IO.File.ReadAllLines("Resources/Corpus/tags.txt")
            .Select(x => x.Split('\t'))
            .Select(x => new Tag() { Name = x[0], Value = x[1] })
            .ToList();

        details =
            System.IO.File.ReadAllLines("Resources/Corpus/details.txt")
            .Select(x => x.Split('\t'))
            .Select(x => new Detail() { Name = x[0], Value = x[1] })
            .ToList();

        links = new List<Link>();
        allLines = System.IO.File.ReadAllLines("Resources/Corpus/links.txt").Skip(1).ToList();
        for (int i = 0; i < allLines.Count; i++) {
            var parts = allLines[i].Split('\t');
            links.Add(new Link() {
                Reference = parts[0],
                SegmentsCorpus = parts[1],
                SegmentsSimple = parts[2],
                Tags = parts[3],
                Transliteration = parts[4],
                Meaning = parts[5],
                Explanation = parts[6],
                Root = parts[7],
                LemmaCorpus = parts[8],
                LemmaSimple = parts[9],
                LemmaIndices = parts[10],
                SpellingGroupCorpus = parts[11],
                SpellingGroupSimple = parts[12],
                RootIndex = parts[13],
                Details = parts[14]
            });
        }

        indexMa = "|" + lemmas.IndexOf("mA");
        indexIz = "|" + lemmas.IndexOf("<*");
        indexYwm = roots.IndexOf("ywm").ToString();
        indexHyn = roots.IndexOf("Hyn").ToString();
        indexKll = roots.IndexOf("kll").ToString();
        indexNEm = roots.IndexOf("nEm").ToString();

        hadithBooks =
           System.IO.File.ReadAllLines("Resources/Hadith/books.txt")
           .Skip(1)
           .Select(x => x.Split('\t'))
           .Select(x => new HadithBook() {
               Id = Convert.ToInt32(x[0]),
               TitleArabic = x[1],
               TitleEnglish = x[2],
               AuthorArabic = x[3],
               AuthorEnglish = x[4]
           })
           .ToList();
    }

    void setStyle() {
        /*
         * ScrollViewer.TemplateProperty doesn't apply
         * uncomment the following ScrollViewer.StyleProperty.OverrideMetadata ...
         * go to RootMatrixPage and remove 
         * Template = new ScrollViewerTemplate() from 
         * contentViewer = new ScrollViewer() in the constructor
         * see it doesn't take the template - ScrollViewerTemplate
         */

        //ScrollViewer.StyleProperty.OverrideMetadata(typeof(ScrollViewer), new FrameworkPropertyMetadata() {
        //    DefaultValue = new Style() {
        //        Setters = {
        //            new Setter(ScrollViewer.OverridesDefaultStyleProperty, true),
        //            new Setter(ScrollViewer.TemplateProperty, new ScrollViewerTemplate()),
        //        }
        //    }
        //});

        Current.Resources.Add(SystemParameters.VerticalScrollBarWidthKey, Constants.ScrollBarThickness);
        Current.Resources.Add(SystemParameters.HorizontalScrollBarHeightKey, Constants.ScrollBarThickness);

        TreeView.StyleProperty.OverrideMetadata(typeof(TreeView), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(TreeView.TemplateProperty, new TreeViewTemplate()),
                    new Setter(TreeView.BorderThicknessProperty, new Thickness(0)),
                    new Setter(VirtualizingPanel.IsVirtualizingProperty, true)
                }
            }
        });

        TreeViewItem.StyleProperty.OverrideMetadata(typeof(TreeViewItem), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(TreeViewItem.TemplateProperty, new TreeItemTemplate()),
                    new Setter(TreeViewItem.FocusVisualStyleProperty, null),
                    new Setter(TextElement.ForegroundProperty, Constants.Foreground)
                }
            }
        });

        ListBox.StyleProperty.OverrideMetadata(typeof(ListBox), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(ListBox.TemplateProperty, new ListBoxTemplate()),
                    new Setter(ListBox.BorderThicknessProperty, new Thickness(0)),
                    new Setter(ListBox.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch),
                    new Setter(ListBox.IsSynchronizedWithCurrentItemProperty, true),
                    new Setter(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel)
                }
            }
        });

        ListBoxItem.StyleProperty.OverrideMetadata(typeof(ListBoxItem), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(ListBoxItem.TemplateProperty, new ListBoxItemTemplate()),
                    new Setter(ListBoxItem.FocusVisualStyleProperty, null),
                    new Setter(TextElement.ForegroundProperty, Constants.Foreground),
                    new EventSetter(ListBoxItem.PreviewGotKeyboardFocusEvent, new KeyboardFocusChangedEventHandler((s, e) => ((ListBoxItem)s).IsSelected = true))
                }
            }
        });
        Separator.StyleProperty.OverrideMetadata(typeof(Separator), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(Separator.BorderThicknessProperty, new Thickness(0.1))
                }
            }
        });
        ToolTip.StyleProperty.OverrideMetadata(typeof(ToolTip), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    //new Setter(ToolTip.OverridesDefaultStyleProperty, true),
                    new Setter(ToolTip.TemplateProperty, new ToolTipTemplate()),
                    new Setter(ToolTip.HorizontalOffsetProperty, 15d)
                }
            }
        });
        Control.StyleProperty.OverrideMetadata(typeof(Control), new FrameworkPropertyMetadata() {
            DefaultValue = new Style() {
                Setters = {
                    new Setter(MenuItem.BorderThicknessProperty, new Thickness(0)),
                    new Setter(MenuItem.PaddingProperty, new Thickness(0)),
                    new Setter(TextBox.BackgroundProperty, null),
                    new Setter(Control.BackgroundProperty, null),
                    new Setter(Control.ForegroundProperty, Constants.Foreground)
                }
            }
        });
    }

    void unhandledDispatchExceptons(object sender, DispatcherUnhandledExceptionEventArgs e) {
        InfoDialog.Activate("UI Exception", e.Exception.Message + "\n" + e.Exception.StackTrace);
        e.Handled = true;
    }

    void taskExceptionHandler(object? sender, UnobservedTaskExceptionEventArgs e) {
        App.Current.Dispatcher.Invoke(() => {
            InfoDialog.Activate("Task Exception", e.Exception.Message + "\n" + e.Exception.InnerException);
        });
    }

    //void unhandledNonUIException(object sender, UnhandledExceptionEventArgs e) {
    //    App.Current.Dispatcher.Invoke(() => {
    //        InfoDialog.Activate("Domain Exception", "");
    //    });
    //}
}