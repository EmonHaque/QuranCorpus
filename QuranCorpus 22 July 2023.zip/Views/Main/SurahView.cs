﻿class SurahView : CardView {
    public override string Icon => Icons.Book;
    EditText query;
    ListBox surahNames;
    PageControl pages;
    SurahVM vm;
    

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new SurahVM();
        DataContext = vm;
        pages = ((App)Application.Current).Pages;
        initializeUI();
        bind();
    }

    void initializeUI() {
        query = new EditText() {
            Icon = Icons.Search,
            Hint = "Surah",
            IsTrimBottomRequested = true
        };
        surahNames = new ListBox() {
            FlowDirection = FlowDirection.RightToLeft,
            Margin = new Thickness(5, 0, 0, 0),
            ItemTemplate = new SurahNameTemplate()
        };
        Grid.SetRow(surahNames, 1);
        surahNames.PreviewMouseRightButtonDown += onRightButtonDown;
        surahNames.MouseRightButtonUp += onRightButtonUp;

        var content = new Grid() { 
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { query, surahNames }
        };
        setContent(content);
    }

    void bind() {
        surahNames.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Surahs)));
        surahNames.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.SelectedSurah)) { 
            Mode = BindingMode.OneWayToSource 
        });
        query.SetBinding(EditText.TextProperty, new Binding(nameof(vm.Query)) {
            Mode = BindingMode.OneWayToSource,
            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
        });
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) => pages.addSurahPage(vm.SelectedSurah.Id);

    void onRightButtonDown(object sender, MouseButtonEventArgs e) => vm.WasRightClicked = true;
}
