﻿class ReciterView : CardView {
    public override string Icon => Icons.BullHorn;
    public override bool OverridesToolTip => true;
    public override UIElement Tip => getTip();
    public static FontFamily reciterFont;

    TagPanel tags;
    WaterBox query;
    TextBlockEnglish counts;
    ListBox surahNames;
    ICollectionView items;
    bool isTagSelection, wasRightClicked;

    public override void OnFirstSight() {
        base.OnFirstSight();
        initializeUI();
        
        tags.Selected = "Warsh";
        onTagSelectionChanged(tags.Selected);
        tags.SelectionChanged += onTagSelectionChanged;
        surahNames.PreviewMouseRightButtonDown += onRightButtonDown;
        surahNames.MouseRightButtonUp += onRightButtonUp;
        surahNames.SelectionChanged += onSurahSelectionChanged;
        query.KeyUp += onQuery;
        isTagSelection = false;
    }

    void onTagSelectionChanged(string name) {
        isTagSelection = true;
        reciterFont = Helper.getReciterFont(name);

        List<Tuple<string, string, string, string>> source = new();
        int surah = 0, ayah = 0;
        var file = System.IO.File.ReadLines("Resources/KFGQPC/Surah/" + name + ".txt");
        var iterator = file.GetEnumerator();
        iterator.MoveNext();
        while (iterator.Current is not null) {
            var parts = iterator.Current.Split('\t');
            var english = App.surahs[surah].Transliteration;
            surah++;
            ayah += Convert.ToInt32(parts[2]);
            source.Add(new Tuple<string, string, string, string>(parts[0], parts[1], parts[2], english));
            iterator.MoveNext();
        }
        iterator.Dispose();
        counts.Text = ayah.ToString("N0") + " ayah in " + surah + " surah";

        items = CollectionViewSource.GetDefaultView(source);
        items.Filter = filter;
        surahNames.ItemsSource = items;
        surahNames.SelectedIndex = -1;
    }

    void onSurahSelectionChanged(object sender, SelectionChangedEventArgs e) {
        if (isTagSelection) {
            isTagSelection = false;
            return;
        }
        if (wasRightClicked) {
            wasRightClicked = false;
            return;
        }
        if (surahNames.SelectedItem is null) return;
        var item = (Tuple<string, string, string, string>)surahNames.SelectedItem;
        if (((App)Application.Current).FocusedControl.SelectedPage is ReciterPage page) {
            page.setContent(tags.Selected, item.Item1);
        }
    }

    void onQuery(object sender, KeyEventArgs e) => items.Refresh();

    bool filter(object o) {
        if (string.IsNullOrEmpty(query.Text)) return true;
        var item = (Tuple<string, string, string, string>)o;
        return item.Item4.Contains(query.Text, StringComparison.InvariantCultureIgnoreCase);
    }

    void onRightButtonDown(object sender, MouseButtonEventArgs e) => wasRightClicked = true;

    void onRightButtonUp(object sender, MouseButtonEventArgs e) {
        if (surahNames.SelectedItem is null) return;
        var item = (Tuple<string, string, string, string>)surahNames.SelectedItem;
        ((App)Application.Current).FocusedControl.addReciterPage(tags.Selected, item.Item1);
    }

    void initializeUI() {
        tags = new TagPanel() {
            Items = System.IO.Directory.EnumerateFiles("Resources//KFGQPC/Surah").Select(x => x.Substring(x.LastIndexOf("\\") + 1).Replace(".txt", "")).ToList()
        };
        query = new WaterBox() {
            Icon = Icons.Search,
            Hint = "Surah (english)"
        };
        counts = new TextBlockEnglish() { 
            HorizontalAlignment = HorizontalAlignment.Right
        };
        surahNames = new ListBox() {
            Margin = new Thickness(0, 2.5, 0, 0),
            FlowDirection = FlowDirection.RightToLeft,
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(SurahNameTemplate))
            }
        };

        Grid.SetRow(counts, 1);
        Grid.SetRow(query, 2);
        
        Grid.SetRow(surahNames, 3);
        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { tags, query, counts, surahNames }
        };
        setContent(grid);
    }

    Grid getTip() {
        var header = new TextBlockEnglish() {
            Text = "Reciters/Readings",
            FontWeight = FontWeights.Bold
        };
        var separator = new Rectangle() {
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var description = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Text = "See 8 out of 10 recitations provided by King Fahad Glorious Quran Printing Complex."
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(description, 2);
        return new Grid() {
            MaxWidth = 200,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(10) },
                new RowDefinition()
            },
            Children = { header, separator, description }
        };
    }

    class SurahNameTemplate : Grid {
        TextBlock name;
        TextBlockEnglish english, ayah;
        public SurahNameTemplate() {
           
            name = new TextBlock() { 
                FontFamily = reciterFont,
                Margin = new Thickness(5,0,5,0)
            };
            ayah = new TextBlockEnglish() { Foreground = Brushes.Gray };
            english = new TextBlockEnglish();

            name.SetBinding(TextBlock.FontSizeProperty, new Binding() {
                Path = new PropertyPath(nameof(Global.ArabicFontSize)),
                Source = App.global
            });

            var stack = new StackPanel() {
                FlowDirection = FlowDirection.LeftToRight,
                VerticalAlignment = VerticalAlignment.Center,
                Children = {ayah, english}
            };
            
            SetColumn(stack, 1);

            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition { Width = GridLength.Auto });

            Children.Add(name);
            Children.Add(stack);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Tuple<string, string, string, string>)DataContext;
           
            name.Text = c.Item1.toArabicNo() + " " + c.Item2;
            ayah.Text = c.Item3 + " ayah";
            english.Text = c.Item4;
        }

    }
}
