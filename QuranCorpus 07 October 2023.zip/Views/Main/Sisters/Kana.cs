﻿class Kana : CardView {
    public override string Header => "kāna and her sisters";

    ListBox list;
    TextBlockEnglish count;
    KanaVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new KanaVM();
        DataContext = vm;
        initializeUI();
        bind();

        list.MouseRightButtonUp += onRightButtonUp;
        IsVisibleChanged += onVisibilityChange;
    }

    void initializeUI() {
        count = new TextBlockEnglish();
        list = new ListBox() {
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(SisterTemplate))
            }
        };
        list.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
        addActions(new UIElement[] { count });
        setContent(list);
    }

    void onVisibilityChange(object sender, DependencyPropertyChangedEventArgs e) {
        if (!IsVisible) return;
        if (vm.currentTranscript == App.global.Transcript) return;
        vm.Regroup();
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) {
        e.Handled = true;
        if (vm.Selected is null) return;
        ((App)Application.Current).FocusedControl.addMatchPage(vm.Selected);
    }

    void bind() {
        count.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = list,
            Mode = BindingMode.OneWay
        });
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Items)));
        list.SetBinding(ListBox.SelectedItemProperty, new Binding() {
            Path = new PropertyPath(nameof(vm.Selected)),
            Mode = BindingMode.OneWayToSource
        });
    }
}
