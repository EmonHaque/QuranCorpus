﻿class RLFreeTemplate : Grid {
    TextBlockArabic arabic;
    TextBlockEnglish count;

    public RLFreeTemplate()
    {
        arabic = new TextBlockArabic();
        count = new TextBlockEnglish() { VerticalAlignment = VerticalAlignment.Center };

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

        SetColumn(count, 1);

        Children.Add(arabic);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var item = (Lemma)DataContext;
        arabic.Text = item.Transcripts[App.global.Transcript].toArabic();
        count.Text = item.References.Count.ToString("N0");
    }
}
