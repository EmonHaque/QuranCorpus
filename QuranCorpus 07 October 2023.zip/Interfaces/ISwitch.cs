﻿interface ISwitch {
    bool IsHoverPopupEnabled { get; set; }
    bool HasColor { get; set; }
    event Action IsColored;
}
