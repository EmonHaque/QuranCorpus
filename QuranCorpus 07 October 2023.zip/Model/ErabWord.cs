﻿class ErabWord {
    public string Root { get; set; }
    public string Tag { get; set; }
    public string Spelling { get; set; }
    public string Gender { get; set; }
    public string INominative { get; set; }
    public string IGenitive { get; set; }
    public string IAccusative { get; set; }
    public string DNominative { get; set; }
    public string DGenitive { get; set; }
    public string DAccusative { get; set; }
    public bool IsSorted { get; set; }
    public List<string> References { get; set; }
    public ErabWord()
    {
        Root = "";
        Spelling = "";
        Gender = "";
        INominative = "";
        IGenitive = "";
        IAccusative = "";
        DNominative = "";
        DGenitive = "";
        DAccusative = "";
        References = new List<string>();
    }
}
