﻿class Ayah : Notifiable {
    public string SurahNo { get; set; }
    public string AyahNo { get; set; }
    public List<Word> Words { get; set; }

	Translation[] translations;
	public Translation[] Translations {
		get { return translations; }
		set { translations = value; }
	}
}

class Translation {
    public int TranslatorId { get; set; }
    public string Content { get; set; }
}

