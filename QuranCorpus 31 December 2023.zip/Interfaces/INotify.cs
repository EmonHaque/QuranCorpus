﻿public interface INotify
{
    event Action<int> CountChanged;
}
