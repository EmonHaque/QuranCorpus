﻿class PageContent : ContentControl {

    UIElement current;
    Border border;
    Grid contentGrid;
    bool canBeDropped;
    public PageControl Parent { get; set; }

    public PageContent() {
        AllowDrop = true;
        border = new Border() {
            IsHitTestVisible = false,
            Background = Constants.BackgroundDark,
            Opacity = 0
        };
        Grid.SetZIndex(border, 1);

        contentGrid = new Grid() {
            Children = { border }
        };
        Content = contentGrid;
    }

    protected override void OnPreviewDragEnter(DragEventArgs e) {
        base.OnDragOver(e);

        var source = e.Data.GetData("source");
        if (source is not Header) return;

        var dataObj = e.Data as DataObject;
        if (dataObj is null) return;

        var page = dataObj.GetData(typeof(Page)) as Page;
        if (page is null) return;

        canBeDropped = false;

        if (((App)Application.Current).Pages.Count == 4
            && !page.Parent.Equals(Parent)) {
            canBeDropped = true;
        }
        else {
            if (page.Parent.Equals(Parent)) {
                if (page.Parent.pages.Count > 1) {
                    if (page.Parent.Position == SplitPosition.None ||
                        page.Parent.Position == SplitPosition.Left ||
                        page.Parent.Position == SplitPosition.Right) {
                        canBeDropped = true;
                    }
                }
            }
            else canBeDropped = true;
        }
        if (canBeDropped) {
            border.Opacity = 0.75;
            e.Effects = DragDropEffects.Scroll;
        }
        else {
            e.Effects = DragDropEffects.None;
            //e.Handled = true;
        }
    }

    protected override void OnPreviewDragLeave(DragEventArgs e) {
        base.OnDragLeave(e);
        border.Opacity = 0;
        e.Effects = DragDropEffects.None;
        //e.Handled = true;
    }

    protected override void OnPreviewDrop(DragEventArgs e) {
        base.OnDrop(e);
        border.Opacity = 0;
        if (!canBeDropped) return;

        var dataObj = e.Data as DataObject;
        if (dataObj is null) return;

        var page = dataObj.GetData(typeof(Page)) as Page;
        if (page is null) return;

        var oldControl = page.Parent;
        oldControl.removePage(page);
        oldControl.IsFocused = false;

        if (oldControl.Equals(Parent)) {
            var newControl = new PageControl(false);
            newControl.addPage(page);

            var pages = ((App)Application.Current).Pages;
            var count = pages.Count;
            pages.Add(newControl);

            if (count == 1) {
                oldControl.Position = SplitPosition.Right;
                newControl.Position = SplitPosition.Left;
                MainView.tab.AddVertical();
            }
            else {
                if (oldControl.Position == SplitPosition.Left) {
                    oldControl.Position = SplitPosition.TopLeft;
                    newControl.Position = SplitPosition.BottomLeft;
                }
                else {
                    oldControl.Position = SplitPosition.TopRight;
                    newControl.Position = SplitPosition.BottomRight;
                }
                MainView.tab.AddHorizontal();
            }
            newControl.IsFocused = true;
        }
        else {
            Parent.addPage(page);
            Parent.IsFocused = true;
        }
    }

    public void setContent(UIElement content) {
        if (current is not null) removeContent();

        current = content;
        Grid.SetZIndex(current, 0);
        contentGrid.Children.Add(current);
    }

    public void removeContent() {
        contentGrid.Children.Remove(current);
    }
}
