﻿abstract class Page {
    string headerText;
    protected string HeaderText {
        get { return headerText; }
        set { headerText = value; Tab.Text = value; }
    }
    public abstract PageType Type { get; }
    public abstract UIElement Content { get; }
    public Header Tab { get; set; }
    public PageControl Parent { get; set; }
    public event Action<Page> SelectionChanged, CloseRequested;

    public Page() {
        Tab = new Header(this);
        Tab.SelectionChanged += onSelectionChanged;
        Tab.CloseRequested += onCloseRequested;
    }

    void onCloseRequested(Header h) {
        CloseRequested?.Invoke(this);
        unload();
    }
    void onSelectionChanged(Header h) {
        h.IsSelected = true;
        SelectionChanged?.Invoke(this);
        handleSelectionChange();
    }
    protected virtual void unload() {
        Tab.SelectionChanged -= onSelectionChanged;
        Tab.CloseRequested -= onCloseRequested;
    }
    protected virtual void handleSelectionChange() { }
}

