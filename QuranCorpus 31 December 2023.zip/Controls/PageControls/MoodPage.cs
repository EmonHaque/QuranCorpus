﻿class MoodPage : Page {
    List<MoodWord> current;
    Grid content;
    StringBuilder builder = new();

    WaterBox indicative, subjunctive, jussive, root;
    
    Run morphCount, morphTotal;
    TextBlockEnglish meaningCount;
    List<Morph> morphs;
    ContentListBox erabs, listMorph;
    ListBox listMeaning;
    ICollectionView erabView;

    public override PageType Type => PageType.Mood;
    public override UIElement Content => content;

    public MoodPage() {
        root = new WaterBox() {
            Width = 100,
            Margin = new Thickness(0,0,5,0),
            Icon = Icons.Sprout,
            Hint = "root"
        };
        var buckwalter = new BuckwalterPopup();
        Grid.SetColumn(buckwalter, 1);
        var rootGrid = new Grid() {
            HorizontalAlignment = HorizontalAlignment.Right,
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { root, buckwalter }
        };
        var countBlock = new TextBlockEnglish();
        var header = getHeader();
        erabs = new ContentListBox() {
            Margin = new Thickness(0, 0, 0, 5),
            Template = new ListBoxLedgerTemplate(),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MoodTemplate))
            },
        };
        var separator = new Rectangle() {
            VerticalAlignment = VerticalAlignment.Bottom,
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var splitter = new GridSplitter() {
            ResizeDirection = GridResizeDirection.Rows,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Template = new SplitterTemplate()
        };

        morphCount = new Run();
        morphTotal = new Run();
        var morphCountBlock = new TextBlockEnglish() {
            IsHitTestVisible = false,
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center,
            Inlines = { morphTotal, new Run(" in "), morphCount }
        };
        meaningCount = new TextBlockEnglish() {
            IsHitTestVisible = false,
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Left
        };

        listMorph = new ContentListBox() {
            Margin = new Thickness(0, 5, 0, 0),
            FlowDirection = FlowDirection.RightToLeft,
            Template = new ListBoxLedgerTemplate(),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MorphListTemplate))
            }
        };
        listMorph.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMorph.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

        listMeaning = new ListBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 0, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MeaningListTemplate))
            }
        };
        listMeaning.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMeaning.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

        Grid.SetRow(header, 1);
        Grid.SetRow(erabs, 2);
        Grid.SetRow(separator, 2);
        Grid.SetRow(splitter, 3);
        Grid.SetRow(morphCountBlock, 3);
        Grid.SetRow(meaningCount, 3);
        Grid.SetRow(listMorph, 4);
        Grid.SetRow(listMeaning, 4);

        Grid.SetColumn(rootGrid, 1);
        Grid.SetColumn(listMorph, 1);
        Grid.SetColumn(morphCountBlock, 1);


        Grid.SetColumnSpan(header, 2);
        Grid.SetColumnSpan(erabs, 2);
        Grid.SetColumnSpan(separator, 2);
        Grid.SetColumnSpan(splitter, 2);
        content = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(1.5, GridUnitType.Star)}
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(1.5, GridUnitType.Star)},
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { rootGrid, countBlock, header, erabs, separator, splitter, morphCountBlock, listMorph, meaningCount, listMeaning }
        };

        morphCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMorph,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        meaningCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMeaning,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        countBlock.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = erabs,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });

        erabs.Fired += onErabFired;
        listMorph.Fired += onMorphFired;
        listMeaning.MouseDoubleClick += onMeaningDoubleClick;
        indicative.KeyUp += onErabKeyUp;
        subjunctive.KeyUp += onErabKeyUp;
        jussive.KeyUp += onErabKeyUp;
        root.KeyUp += onErabKeyUp;
    }

    public MoodPage(List<MoodWord> source) : this() {
        current = source;
        HeaderText = source.First().Gender + " (" + source.Count + ")";
        erabView = CollectionViewSource.GetDefaultView(source);
        erabView.Filter = filter;
        erabs.ItemsSource = erabView;
    }

    public void setContent(List<MoodWord> source) {
        if (current.Equals(source)) return;
        current = source;
        HeaderText = source.First().Gender + " (" + source.Count + ")";
        erabView = CollectionViewSource.GetDefaultView(source);
        erabView.Filter = filter;
        erabs.ItemsSource = erabView;
    }

    bool filter(object o) {
        bool result = true;
        var erab = (MoodWord)o;
        if (!string.IsNullOrEmpty(indicative.Text)) {
            result = result && indicative.Text.StartsWith('!') ?
                !erab.Indicative.EndsWith(indicative.Text.Substring(1)) :
                erab.Indicative.EndsWith(indicative.Text);
        }
        if (!string.IsNullOrEmpty(subjunctive.Text)) {
            result = result && subjunctive.Text.StartsWith('!') ?
                !erab.Subjunctive.EndsWith(subjunctive.Text.Substring(1)) :
                erab.Subjunctive.EndsWith(subjunctive.Text);
        }
        if (!string.IsNullOrEmpty(jussive.Text)) {
            result = result && jussive.Text.StartsWith('!') ?
                !erab.Jussive.EndsWith(jussive.Text.Substring(1)) :
                erab.Jussive.EndsWith(jussive.Text);
        }
        
        if (!string.IsNullOrEmpty(root.Text)) {
            result = result && erab.Root.Contains(root.Text);
        }
        return result;
    }

    void onErabFired(object item) {
        var selected = (MoodWord)item;
        morphs = new List<Morph>();
        int linkIndex = 0;
        if (!selected.IsSorted) {
            selected.References.Sort(new SurahAyahWordNoComparator());
            selected.IsSorted = true;
        }
        for (int i = 0; i < selected.References.Count; i++) {
            while (!App.links[linkIndex].Reference.Equals(selected.References[i])) linkIndex++;
            var parts = App.global.Transcript == 0 ?
                App.links[linkIndex].SpellingGroupCorpus.Split('|') :
                App.links[linkIndex].SpellingGroupSimple.Split('|');
            int index = 0;
            for (int j = 0; j < parts.Length; j++) {
                if (!App.spellings[Convert.ToInt32(parts[j])].Equals(selected.Spelling)) continue;
                index = j;
                break;
            }
            morphs.Add(App.links[linkIndex].toMorph(builder));
        }
        var listSource = morphs.GroupBy(x => new { Word = x.Segments[1], x.Explanation })
              .Select(x => new Morph() {
                  Segments = x.First().Segments,
                  Count = x.Count(),
                  Tags = x.First().Tags,
                  Explanation = x.Key.Explanation,
                  References = x.SelectMany(x => x.References).ToList()
              })
              .OrderByDescending(x => x.Count)
              .ToList();

        listMorph.ItemsSource = listSource;
        morphTotal.Text = listSource.Sum(x => x.Count).ToString();
    }

    void onMorphFired(object item) {
        listMeaning.ItemsSource = ((Morph)item).References;
    }

    void onMeaningDoubleClick(object sender, MouseButtonEventArgs e) {
        if (listMeaning.SelectedItem is null) return; // can be null?
        var item = (Tuple<string, string, string>)listMeaning.SelectedItem;
        ((App)Application.Current).FocusedControl.addSurahPage(item.Item1);
    }

    void onErabKeyUp(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        erabView.Refresh();
    }

    Grid getHeader() {
        indicative = new WaterBox() {
            Hint = "Indicative",
            Icon = Icons.ArrowLeft
        };
        subjunctive = new WaterBox() {
            Hint = "Subjunctive",
            Icon = Icons.ArrowTopLeft
        };
        jussive = new WaterBox() {
            Hint = "Jussive",
            Icon = Icons.CircleOutline
        };
        Grid.SetColumn(subjunctive, 1);
        Grid.SetColumn(indicative, 2);
        return new Grid() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(Constants.ScrollBarThickness, 5, 0, 5),
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(),
                    new ColumnDefinition()
                },
            Children = { indicative, subjunctive, jussive }
        };
    }

    protected override void unload() {
        erabs.Fired -= onErabFired;
        listMorph.Fired -= onMorphFired;
        listMeaning.MouseDoubleClick -= onMeaningDoubleClick;
        indicative.KeyUp -= onErabKeyUp;
        subjunctive.KeyUp -= onErabKeyUp;
        jussive.KeyUp -= onErabKeyUp;
        root.KeyUp -= onErabKeyUp;
        base.unload();
    }

    class MoodTemplate : Grid {
        TextBlockArabic indicative, subjunctive, jussive;

        public MoodTemplate() {
            indicative = new TextBlockArabic();
            subjunctive = new TextBlockArabic();
            jussive = new TextBlockArabic();

            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());

            SetColumn(subjunctive, 1);
            SetColumn(jussive, 2);

            Children.Add(indicative);
            Children.Add(subjunctive);
            Children.Add(jussive);

            Resources.Add(typeof(TextBlockArabic), new Style() {
                Setters = {
                    new Setter(TextBlockArabic.MarginProperty, new Thickness(20,0,0,0))
                }
            });
        }

        public override void EndInit() {
            base.EndInit();
            var c = (MoodWord)DataContext;
            indicative.Text = string.IsNullOrEmpty(c.Indicative) ? "" : c.Indicative.toArabic();
            subjunctive.Text = string.IsNullOrEmpty(c.Subjunctive) ? "" : c.Subjunctive.toArabic();
            jussive.Text = string.IsNullOrEmpty(c.Jussive) ? "" : c.Jussive.toArabic();
        }
    }
}
