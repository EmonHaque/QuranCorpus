﻿class MorphPage : Page {
    Grid content;
    StringBuilder builder = new();

    Run morphCount, morphTotal;
    TextBlockEnglish meaningCount;
    List<Morph> morphs;
    ContentListBox listMorph;
    ListBox listMeaning;
    TagCount tags;
    public override PageType Type => PageType.Morph;
    public override UIElement Content => content;

    public MorphPage() {
        tags = new TagCount() { FlowDirection = FlowDirection.LeftToRight };

        morphCount = new Run();
        morphTotal = new Run();
        var listCountBlock = new TextBlockEnglish() {
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center,
            Inlines = { morphTotal, new Run(" in "), morphCount }
        };
        meaningCount = new TextBlockEnglish() {
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Right
        };

        listMorph = new ContentListBox() {
            Margin = new Thickness(0, 5, 0, 0),
            FlowDirection = FlowDirection.RightToLeft,
            Template = new ListBoxLedgerTemplate(),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MorphListTemplate))
            }
        };
        listMorph.SetValue(Grid.IsSharedSizeScopeProperty, true);

        listMeaning = new ListBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 0, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MeaningListTemplate))
            }
        };
        listMeaning.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMeaning.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

        Grid.SetRow(tags, 1);
        Grid.SetRow(listCountBlock, 1);
        Grid.SetRow(meaningCount, 1);
        Grid.SetRow(listMorph, 2);
        Grid.SetRow(listMeaning, 2);
        Grid.SetColumn(listMeaning, 1);
        Grid.SetColumn(meaningCount, 1);

        content = new Grid() {
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = new GridLength(1.5, GridUnitType.Star)},
                new ColumnDefinition()
            },
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { tags, listMorph, listCountBlock, meaningCount, listMeaning }
        };

        morphCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMorph,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        meaningCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMeaning,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });

        tags.SelectionChanged += onTagSelectionChanged;
        listMorph.Fired += onMorphFired;
        listMeaning.MouseDoubleClick += onMeaningDoubleClick;
        App.global.PropertyChanged += onTranscriptChanged;
    }

    public MorphPage(string spelling) : this() {

        morphs = new List<Morph>();

        if(App.global.Transcript == 0) {
            for (int i = 0; i < App.links.Count; i++) {
                if (string.IsNullOrEmpty(App.links[i].Root)) continue;
                var link = App.links[i];

                var spellings = link.SpellingGroupCorpus.Split('|').Select(x => App.spellings[Convert.ToInt32(x)]).ToArray();
                if (!spellings.Contains(spelling)) continue;

                morphs.Add(link.toMorph(builder));
            }
        }
        else {
            for (int i = 0; i < App.links.Count; i++) {
                if (string.IsNullOrEmpty(App.links[i].Root)) continue;
                var link = App.links[i];

                var spellings = link.SpellingGroupSimple.Split('|').Select(x => App.spellings[Convert.ToInt32(x)]).ToArray();
                if (!spellings.Contains(spelling)) continue;

                morphs.Add(link.toMorph(builder));
            }
        }
       
        tags.Items = morphs.GroupBy(x => x.Gender).Select(x => new TagCount.TagItem() {
            Name = x.Key,
            Count = x.Count()
        }).ToList();

        HeaderText = "(" + tags.Items.Count + ") " + spelling.toArabic();

        tags.Selected = tags.Items.First();
        onTagSelectionChanged(tags.Selected);
    }

    void onTagSelectionChanged(TagCount.TagItem obj) {
        var listSource = morphs.Where(x => x.Gender.Equals(obj.Name))
            .GroupBy(x => new { Word = x.Segments[App.global.Transcript], x.Explanation })
              .Select(x => new Morph() {
                  Segments = x.First().Segments,
                  Count = x.Count(),
                  Tags = x.First().Tags,
                  Explanation = x.Key.Explanation,
                  References = x.SelectMany(x => x.References).ToList()
              })
              .OrderByDescending(x => x.Count)
              .ToList();
        morphTotal.Text = listSource.Sum(x => x.Count).ToString();
        listMorph.ItemsSource = listSource;
        listMorph.ScrollIntoView(listSource[0]);
    }

    void onMorphFired(object item) {
        var meaningSource = ((Morph)item).References;
        listMeaning.ItemsSource = meaningSource;
        listMeaning.ScrollIntoView(meaningSource[0]);
    }

    void onMeaningDoubleClick(object sender, MouseButtonEventArgs e) {
        if (listMeaning.SelectedItem is null) return; // can be null?
        var item = (Tuple<string, string, string>)listMeaning.SelectedItem;
        ((App)Application.Current).FocusedControl.addSurahPage(item.Item1);
    }

    void onTranscriptChanged(object? sender, PropertyChangedEventArgs e) => onTagSelectionChanged(tags.Selected);

    protected override void unload() {
        tags.SelectionChanged -= onTagSelectionChanged;
        listMorph.Fired -= onMorphFired;
        listMeaning.MouseDoubleClick -= onMeaningDoubleClick;
        App.global.PropertyChanged -= onTranscriptChanged;
        base.unload();
    }
}
