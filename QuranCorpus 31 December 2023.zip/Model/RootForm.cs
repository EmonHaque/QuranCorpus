﻿class RootForm {
    public string Root { get; set; }
    public string Pattern { get; set; }
    public string Segmentation { get; set; }
    List<RootSegment> segments;
    public List<RootSegment> Segments {
        get { return segments; }
        set { 
            segments = value; 
            Pattern = string.Join("", value.Select(x => x.Token));
            Segmentation = string.Join("", value.Select(x => x.IsRoot.ToString() + x.SegmentNo + x.Token));
        }
    }
    public int Count { get; set; }
    public string Tag { get; set; }
    public string SubTag { get; set; }
    public string Form { get; set; }
    public List<PatternReference> References { get; set; }
}
