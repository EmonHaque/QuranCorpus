﻿class Pattern {
    public string Root { get; set; }
    public List<Tuple<string, List<string>>> Roots { get; set; } = new();
}
