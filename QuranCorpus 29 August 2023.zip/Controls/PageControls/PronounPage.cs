﻿class PronounPage : Page {
    string indexMa;
    byte searchMode;
    Grid content;
    StringBuilder builder = new();

    Run morphCount, morphTotal;
    TextBlockEnglish meaningCount, wordCount, pronounCount;
    
    ListBox listMorph, listMeaning;
    ProgressBar progress;
    CancellationTokenSource terminator;

    List<Conjugated> source;
    TreeView tree;
    ListBox wordList;

    public override PageType Type => PageType.Pronoun;
    public override UIElement Content => content;

    public PronounPage() {
        indexMa = "|" + ((App)Application.Current).indexMa;
        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };
        terminator = new CancellationTokenSource();

        tree = new TreeView() {
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            // if you set HorizontalScrollBarVisibilityProperty here and disable the 
                            // tree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
                            // it will mess up when scrollbar appears and disappears
                            //new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()),
                        }
                    }
                }}
        };
        tree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        tree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true); // no default virtualization

        wordList = new ListBox() {
            Margin = new Thickness(0,5,0,0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(WordTemplate))
            },
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()),
                        }
                    }
                }}
        };
        wordList.SetValue(Grid.IsSharedSizeScopeProperty, true);
        wordList.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        wordList.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        wordCount = new TextBlockEnglish();
        pronounCount = new TextBlockEnglish();

        var morphGrid = getMorphGrid();

        var separator1 = new Rectangle() {
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };

        var separator2 = new Rectangle() {
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };

        Grid.SetColumn(separator1, 1);
        Grid.SetColumn(wordList, 2);
        Grid.SetColumn(separator2, 3);
        Grid.SetColumn(morphGrid, 4);
        Grid.SetColumn(wordCount, 2);

        Grid.SetRow(pronounCount, 1);
        Grid.SetRow(wordCount, 1);
        Grid.SetRow(tree, 2);
        Grid.SetRow(wordList, 2);

        Grid.SetRowSpan(separator1, 3);
        Grid.SetRowSpan(separator2, 3);
        Grid.SetRowSpan(morphGrid, 3);

        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(5) },
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(5) },
                new ColumnDefinition(){ Width = new GridLength(1.75, GridUnitType.Star)}
            },
            Children = { progress, pronounCount, wordCount, tree, separator1, wordList, separator2, morphGrid }
        };

        pronounCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = tree,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });

        wordCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = wordList,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });

        tree.SelectedItemChanged += onTreeSelectionChanged;
        wordList.SelectionChanged += onWordSelectionChanged;
        listMorph.SelectionChanged += onMorphSelectionChanged;
        listMeaning.MouseDoubleClick += onMeaningDoubleClick;
        App.global.PropertyChanged += onTranscriptChanged;
    }

    public PronounPage(List<Conjugated> source) : this() => group(source);

    public void setContent(List<Conjugated> source) => group(source);

    void getMorphs(Conjugated selected) {
        progress.IsIndeterminate = true;
        Task.Run(() => {
            var morphs = new List<Morph>();

            var iterator = App.links.GetEnumerator();
            iterator.MoveNext();

            if (!selected.IsSorted) {
                selected.References.Sort(new SurahAyahWordNoComparator());
                selected.IsSorted = true;
            }

            if (App.global.Transcript == 0) {
                for (int i = 0; i < selected.References.Count; i++) {
                    if (terminator.IsCancellationRequested) break;

                    while (!iterator.Current.Reference.Equals(selected.References[i])) iterator.MoveNext();

                    if (!string.IsNullOrEmpty(iterator.Current.Root)) {
                        searchMode = iterator.Current.Root.Contains('|') ? (byte)3 : (byte)1;
                    }
                    else if (!string.IsNullOrEmpty(iterator.Current.LemmaSimple)) {
                        searchMode = iterator.Current.LemmaSimple.Contains('|') ? (byte)3 : (byte)2;
                    }
                    else searchMode = 3;

                    morphs.Add(getMorph(iterator.Current));
                }
            }
            else {
                for (int i = 0; i < selected.References.Count; i++) {
                    if (terminator.IsCancellationRequested) break;

                    while (!iterator.Current.Reference.Equals(selected.References[i])) iterator.MoveNext();

                    if (!string.IsNullOrEmpty(iterator.Current.Root)) {
                        searchMode = iterator.Current.Root.Contains('|') ? (byte)3 : (byte)1;
                    }
                    else if (!string.IsNullOrEmpty(iterator.Current.LemmaSimple)) {
                        searchMode = iterator.Current.LemmaSimple.Contains('|') ? (byte)3 : (byte)2;
                    }
                    else searchMode = 3;

                    morphs.Add(getMorph(iterator.Current));
                }
            }

            iterator.Dispose();

            var listSource = morphs
              .GroupBy(x => new { Word = x.Segments[App.global.Transcript], x.Explanation })
              .Select(x => new Morph() {
                  Segments = x.First().Segments,
                  Count = x.Count(),
                  Tags = x.First().Tags,
                  Explanation = x.Key.Explanation,
                  References = x.SelectMany(x => x.References).ToList()
              })
              .OrderByDescending(x => x.Count)
              .ToList();

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    listMorph.ItemsSource = listSource;
                    morphTotal.Text = listSource.Sum(x => x.Count).ToString();
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);

    }

    Grid getMorphGrid() {
        morphCount = new Run();
        morphTotal = new Run();
        var listCountBlock = new TextBlockEnglish() {
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center,
            Inlines = { morphTotal, new Run(" in "), morphCount }
        };
        meaningCount = new TextBlockEnglish() {
            IsHitTestVisible = false,
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Right
        };

        listMorph = new ListBox() {
            Margin = new Thickness(0, 5, 0, 0),
            FlowDirection = FlowDirection.RightToLeft,
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MorphListTemplate))
            },
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()),
                        }
                    }
                }}
        };
        listMorph.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMorph.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        listMorph.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        listMeaning = new ListBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 0, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MeaningListTemplate))
            }
        };
        listMeaning.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMeaning.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        listMeaning.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        var splitter = new GridSplitter() {
            Margin = new Thickness(0, 5, 0, 0),
            ResizeDirection = GridResizeDirection.Rows,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Template = new SplitterTemplate()
        };

        Grid.SetRow(listMorph, 1);
        Grid.SetRow(meaningCount, 2);
        Grid.SetRow(splitter, 2);
        Grid.SetRow(listMeaning, 3);
       
        morphCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMorph,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        meaningCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMeaning,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });

        return new Grid() {
            Margin = new Thickness(5,0,0,0),
            FlowDirection = FlowDirection.LeftToRight,
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = new GridLength(2, GridUnitType.Star)},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { listMorph, listCountBlock, meaningCount, splitter, listMeaning }
        };
    }

    void group(List<Conjugated> source) {
        this.source = source;
        HeaderText = source.First().Person;
        regroup();
    }

    void regroup() {
        tree.Items.Clear();
        var groups =
            source.GroupBy(x => x.Pronoun[App.global.Transcript])
            .Select(x => new { x.Key, Value = x.GroupBy(x => x.To).ToList() })
            .ToList();

        foreach (var group in groups) {
            var branch = new TreeViewItem() {
                IsExpanded = true,
                Header = new TextBlockArabic() { Text = group.Key.toArabic() }
            };
            tree.Items.Add(branch);

            foreach (var v in group.Value) {

                var subGroups =
                    v.GroupBy(x => x.As)
                    .Select(x => new Tuple<string, int, int>(x.Key, x.Count(), x.Sum(x => x.References.Count)))
                    .ToList();

                if (subGroups.Count == 1) {
                    var leaf = new TreeViewItem() {
                        Tag = group.Key,
                        FlowDirection = FlowDirection.LeftToRight,
                        Header = new Tuple<string, string, int, int>(v.Key, subGroups[0].Item1, subGroups[0].Item2, subGroups[0].Item3),
                        HeaderTemplate = new DataTemplate() {
                            VisualTree = new FrameworkElementFactory(typeof(TreeHeaderTemplate))
                        }
                    };
                    branch.Items.Add(leaf);
                }
                else {
                    var subBranch = new TreeViewItem() {
                        FlowDirection = FlowDirection.LeftToRight,
                        IsExpanded = true,
                        Header = new TextBlockEnglish() { Text = v.Key }
                    };
                    branch.Items.Add(subBranch);
                    foreach (var to in subGroups) {
                        var leaf = new TreeViewItem() {
                            Tag = group.Key,
                            FlowDirection = FlowDirection.LeftToRight,
                            Header = new Tuple<string, string, int, int>(v.Key, to.Item1, to.Item2, to.Item3),
                            HeaderTemplate = new DataTemplate() {
                                VisualTree = new FrameworkElementFactory(typeof(TreeItemTemplate))
                            }
                        };
                        subBranch.Items.Add(leaf);
                    }
                }
            }

            branch.Items.SortDescriptions.Add(new SortDescription("Items.Count", ListSortDirection.Descending));
        }
    }

    void onTreeSelectionChanged(object sender, RoutedPropertyChangedEventArgs<object> e) {
        var item = ((TreeViewItem)e.NewValue);
        if(item is null) {
            wordList.ItemsSource = null;
            return;
        }
        var value = item.Header as Tuple<string, string, int, int>;
        if (value is null) return;

        wordList.ItemsSource = source.Where(
            x => x.Pronoun[App.global.Transcript].Equals(item.Tag) &&
            x.To.Equals(value.Item1) &&
            x.As.Equals(value.Item2))
            .ToList();
    }

    void onWordSelectionChanged(object sender, SelectionChangedEventArgs e) {
        if(wordList.SelectedItem is null) {
            listMorph.ItemsSource = null;
            morphTotal.Text = "0";
            return;
        }
        getMorphs((Conjugated)wordList.SelectedItem);
    }

    void onMorphSelectionChanged(object sender, SelectionChangedEventArgs e) {
        if (listMorph.SelectedItem is null) {
            listMeaning.ItemsSource = null;
            return;
        }
        listMeaning.ItemsSource = ((Morph)listMorph.SelectedItem).References;
    }

    void onMeaningDoubleClick(object sender, MouseButtonEventArgs e) {
        if (listMeaning.SelectedItem is null) return; // can be null?
        var item = (Tuple<string, string, string>)listMeaning.SelectedItem;
        ((App)Application.Current).Pages.addSurahPage(item.Item1);
    }

    void onTranscriptChanged(object? sender, PropertyChangedEventArgs e) => regroup();

    Morph getMorph(Link item) {
        string tag = "";
        string[] tags;
        string details = "";

        if (searchMode == 1) {
            details = item.Details.Split(',')[Convert.ToInt32(item.RootIndex)];
            details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
            int lIndex;
            if (item.LemmaSimple.EndsWith(indexMa)) {
                // in 8 cases it ends with maA
                lIndex = 0;
            }
            else lIndex = Convert.ToInt32(item.LemmaIndices);

            tags = item.Tags.Split('|');
            tag = App.tags[Convert.ToInt32(tags[lIndex])].Name;
        }
        else if (searchMode == 2) {
            var indices = item.LemmaIndices.Split('|');
            if (indices.Length == 1) {
                details = item.Details.Split(',')[Convert.ToInt32(item.LemmaIndices)];
                details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
                int lIndex;
                if (item.LemmaSimple.EndsWith(indexMa)) {
                    // in 8 cases it ends with maA
                    lIndex = 0;
                }
                else lIndex = Convert.ToInt32(item.LemmaIndices);

                tags = item.Tags.Split('|');
                tag = App.tags[Convert.ToInt32(tags[lIndex])].Name;
            }
            else {
                builder.Clear();
                item.explain(builder);
                var m = new Morph() {
                    Segments = Helper.getSegments(item),
                    Tags = item.Tags.Split('|'),
                    Spellings = new string[] {
                                string.Join("", item.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)])),
                                string.Join("", item.SegmentsSimple.Split('|').Select(x => App.segments[Convert.ToInt32(x)]))
                            },
                    Explanation = builder.ToString(),
                    Tag = ""
                };
                m.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));
                return m;
            }
        }
        else {
            if (!item.SpellingGroupSimple.Contains('|')) {
                details = item.Details;
                details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
                tag = App.tags[Convert.ToInt32(item.Tags)].Name;
                tags = item.Tags.Split('|');
            }
            else {
                builder.Clear();
                item.explain(builder);
                var m = new Morph() {
                    Segments = Helper.getSegments(item),
                    Tags = item.Tags.Split('|'),
                    Spellings = new string[] {
                                string.Join("", item.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)])),
                                string.Join("", item.SegmentsSimple.Split('|').Select(x => App.segments[Convert.ToInt32(x)]))
                            },
                    Explanation = builder.ToString(),
                    Tag = ""
                };
                m.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));
                return m;
            }
        }

        Morph t = new() {
            Tag = tag,
            Tags = tags,
            Segments = Helper.getSegments(item),
            Spellings = getSpellings(item)
        };
        builder.Clear();
        item.explain(builder);

        t.Explanation = builder.ToString();
        t.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));

        var array = details.Split('|');
        if (App.tagArray.Contains(tag)) {
            for (int i = 0; i < array.Length; i++) {
                if (string.IsNullOrEmpty(array[i])) continue;
                if (array[i].Equals("PCPL") ||
                    array[i].Equals("ACC") ||
                    array[i].Equals("NOM") ||
                    array[i].Equals("GEN") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("ACT")) t.SubTag = "Active Participle";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive Participle";
                else if (array[i].Equals("VN")) t.SubTag = "Verbal Noun";
                else if (array[i].Equals("IN")) t.SubTag = "Noun";
                else if (array[i].Equals("CN")) t.SubTag = "Noun";
                else if (array[i].Equals("IP")) t.SubTag = "Particle";
                else if (array[i].Equals("CP")) t.SubTag = "Particle";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("V")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUBJ") ||
                    array[i].Equals("JUS") ||
                    array[i].Equals("JUSS") ||
                    array[i].Equals("SP:kaAn") ||
                    array[i].Equals("SP:kaAd") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("IMPF")) t.SubTag = "Imperfect";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive";
                else if (array[i].Equals("IMPV")) t.SubTag = "Imperative";
                else if (array[i].Equals("PERF")) t.SubTag = "Perfect";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("PRON")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUB")) t.SubTag = "Subject";
                else if (array[i].Equals("OBJ")) t.SubTag = "Object";
                else if (array[i].Equals("PER")) t.SubTag = "Personal";
                else if (array[i].Equals("POS")) t.SubTag = "Possessive";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name;
                else t.Gender = Helper.getGender(array[i]).Name;
            }
        }
        return t;

        string[] getSpellings(Link item) {
            int lIndex;
            if (item.LemmaSimple.EndsWith(indexMa)) {
                // in 8 cases it ends with maA
                lIndex = 0;
            }
            else {
                if (string.IsNullOrEmpty(item.LemmaIndices)) {
                    return new string[] {
                    item.SpellingGroupCorpus,
                    item.SpellingGroupSimple
                };
                }

                lIndex = Convert.ToInt32(item.LemmaIndices);
            }
            return new string[] {
                item.SpellingGroupCorpus.Split('|')[lIndex],
                item.SpellingGroupSimple.Split('|')[lIndex]
            };
        }
    }

    protected override void unload() {
        tree.SelectedItemChanged -= onTreeSelectionChanged;
        wordList.SelectionChanged -= onWordSelectionChanged;
        listMorph.SelectionChanged -= onMorphSelectionChanged;
        listMeaning.MouseDoubleClick -= onMeaningDoubleClick;
        App.global.PropertyChanged -= onTranscriptChanged;
        terminator.Cancel();
        terminator.Dispose();
        base.unload();
    }

    class TreeHeaderTemplate : Grid {
        TextBlockEnglish to, @as, noOfWord, times;

        public TreeHeaderTemplate() {
            Margin = new Thickness(0, 2.5, 0, 2.5);
            to = new TextBlockEnglish() { Margin = new Thickness(0, 0, 5, 0), };
            @as = new TextBlockEnglish();
            noOfWord = new TextBlockEnglish() {
                Margin = new Thickness(5, 0, 5, 0),
                HorizontalAlignment = HorizontalAlignment.Right
            };
            times = new TextBlockEnglish() { HorizontalAlignment = HorizontalAlignment.Right };

            SetColumn(@as, 1);
            SetColumn(noOfWord, 2);
            SetColumn(times, 3);

            // 50 is hardcoded in TreeItemTemplate first column margin
            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(50) });
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(35) });
            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(35) });

            Children.Add(to);
            Children.Add(@as);
            Children.Add(noOfWord);
            Children.Add(times);
        }
        public override void EndInit() {
            base.EndInit();
            var c = (Tuple<string, string, int, int>)DataContext;
            to.Text = c.Item1;
            @as.Text = c.Item2;
            noOfWord.Text = c.Item3.ToString("N0");
            times.Text = c.Item4.ToString("N0");
        }
    }

    class TreeItemTemplate : Grid {
        TextBlockEnglish @as, noOfWord, times;

        public TreeItemTemplate() {
            // 50 is the first column width of TreeHeaderTemplate
            Margin = new Thickness(50 - Constants.TreeExpansionWidth, 2.5, 0, 2.5);
            @as = new TextBlockEnglish();
            noOfWord = new TextBlockEnglish() {
                Margin = new Thickness(5, 0, 5, 0),
                HorizontalAlignment = HorizontalAlignment.Right
            };
            times = new TextBlockEnglish() { HorizontalAlignment = HorizontalAlignment.Right };

            SetColumn(noOfWord, 1);
            SetColumn(times, 2);

            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(35) });
            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(35) });

            Children.Add(@as);
            Children.Add(noOfWord);
            Children.Add(times);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Tuple<string, string, int, int>)DataContext;
            @as.Text = c.Item2;
            noOfWord.Text = c.Item3.ToString("N0");
            times.Text = c.Item4.ToString("N0");
        }
    }

    class WordTemplate : Grid {
        TextBlockArabic word;
        TextBlockEnglish count;

        public WordTemplate() {
            word = new TextBlockArabic();
            count = new TextBlockEnglish() {
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Center
            };

            SetColumn(count, 1);

            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

            Children.Add(word);
            Children.Add(count);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Conjugated)DataContext;
            word.Text = c.Word[App.global.Transcript].toArabic();
            count.Text = c.References.Count.ToString("N0");
        }
    }
}
