﻿class SurahVM : Notifiable {
    Surah selectedSurah;
    public Surah SelectedSurah {
        get { return selectedSurah; }
        set {
            if (value is null) return;
            if (!value.Equals(selectedSurah)) {
                selectedSurah = value;
            }
            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).Pages.SelectedPage is SurahPage page) {
                page.setContent(value.Id);
            }
        }
    }

    string query;
    public string Query {
        get { return query; }
        set { query = value; Surahs.Refresh(); }
    }
    int selectedOrder;
    public int SelectedOrder {
        get { return selectedOrder; }
        set { selectedOrder = value; sort(); }
    }

    public bool WasRightClicked { get; set; }
    public ICollectionView Surahs { get; set; }

    public SurahVM() {
        Surahs = new CollectionViewSource() { Source = App.surahs }.View;
        Surahs.Filter = filter;
    }

    void sort() {
        var defer = Surahs.DeferRefresh();
        Surahs.SortDescriptions.Clear();
        switch (SelectedOrder) {
            case 0: Surahs.SortDescriptions.Add(new SortDescription(nameof(Surah.Id), ListSortDirection.Ascending)); break;
            case 1: Surahs.SortDescriptions.Add(new SortDescription(nameof(Surah.Order), ListSortDirection.Ascending)); break;
            case 2: Surahs.SortDescriptions.Add(new SortDescription(nameof(Surah.Verses), ListSortDirection.Descending)); break;
        }
        defer.Dispose();
    }

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((Surah)o).Transliteration.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }
}
