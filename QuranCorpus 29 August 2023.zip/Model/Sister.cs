﻿class Sister {
    public string[] Spellings { get; set; }
    public string[] Lemmas { get; set; }
    public List<string> References { get; set; }
    public Sister() {
        References = new();
    }
    public Sister(Sister rhs) {
        Spellings = new string[] { rhs.Spellings[0], rhs.Spellings[1] };
        Lemmas = new string[] { rhs.Lemmas[0], rhs.Lemmas[1] };
        References = new List<string>(rhs.References);
    }
}

