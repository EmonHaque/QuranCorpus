﻿class Segment {
    public string[] Tags { get; set; }
    public string[] Details { get; set; }
    public string[] Segments { get; set; }
    public string[] Spellings { get; set; }
    public List<Link>[] References { get; set; }
}

