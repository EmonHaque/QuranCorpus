﻿
class SettingsView : CardView {
    public override string Icon => Icons.Cog;
    public override bool OverridesToolTip => true;
    public override UIElement Tip => getTip();

    ListBox fonts, translations, transcripts;

    public override void OnFirstSight() {
        base.OnFirstSight();
        initializeUI();
        bind();
    }

    void initializeUI() {
        var arabicFontSizer = new FontSizer() {
            Header = "Arabic font size",
            Minimum = 14,
            Maximum = 30,
            Current = App.global.ArabicFontSize,
            IncreaseCommand = () => App.global.ArabicFontSize++,
            DecreaseCommand = () => App.global.ArabicFontSize--
        };
        var englishFontSizer = new FontSizer() {
            Header = "English font size",
            Minimum = 12,
            Maximum = 16,
            Current = App.global.EnglishFontSize,
            IncreaseCommand = () => App.global.EnglishFontSize++,
            DecreaseCommand = () => App.global.EnglishFontSize--
        };
        var fontBlock = new TextBlock() { Text = "Arabic Font", FontWeight = FontWeights.Bold };
        var translationBlock = new TextBlock() { 
            Text = "Translation", 
            Margin = new Thickness(0,5,0,0),
            FontWeight = FontWeights.Bold 
        };
        var transcriptBlock = new TextBlock() { 
            Text = "Transcript",
            Margin = new Thickness(0, 5, 0, 0),
            FontWeight = FontWeights.Bold 
        };
        fonts = new ListBox() {
            ItemsSource = App.global.FontDictionary.Keys
        };

        translations = new ListBox() {
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(TranslationTemplate))
            },
            ItemsSource = App.global.TranslationDictionary.Keys
        };
        translations.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        translations.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
        transcripts = new ListBox() {
            ItemsSource = App.global.TranscriptDictionary.Values
        };

        Grid.SetRow(englishFontSizer, 1);
        Grid.SetRow(fontBlock, 2);
        Grid.SetRow(fonts, 3);
        Grid.SetRow(translationBlock, 4);
        Grid.SetRow(translations, 5);
        Grid.SetRow(transcriptBlock, 6);
        Grid.SetRow(transcripts, 7);
        var content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto},
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(),
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto}
            },
            Children = { 
                arabicFontSizer, englishFontSizer, fontBlock, fonts, 
                translationBlock, translations, transcriptBlock, transcripts }
        };
        setContent(content);
    }

    void bind() {
        fonts.SetBinding(ListBox.SelectedItemProperty, new Binding() {
            Path = new PropertyPath(nameof(App.global.ArabicFont)),
            Source = App.global
        });
        translations.SetBinding(ListBox.SelectedItemProperty, new Binding() {
            Path = new PropertyPath(nameof(App.global.Translation)),
            Source = App.global
        });
        transcripts.SetBinding(ListBox.SelectedIndexProperty, new Binding() {
            Path = new PropertyPath(nameof(App.global.Transcript)),
            Source = App.global
        });
    }

    Grid getTip() {
        var header = new TextBlockEnglish() {
            Text = "Settings",
            FontWeight = FontWeights.Bold
        };
        var separator = new Rectangle() {
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var description = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Text = "Set font, font size, translation and transcript."
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(description, 2);
        return new Grid() {
            MaxWidth = 200,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(10) },
                new RowDefinition()
            },
            Children = { header, separator, description }
        };
    }

    class TranslationTemplate : TextBlock {
        public TranslationTemplate()
        {
            TextWrapping = TextWrapping.Wrap;
            SetBinding(TextProperty, new Binding());
        }
    }
}
