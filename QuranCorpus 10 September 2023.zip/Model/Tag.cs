﻿public class Tag {
    public string Name { get; set; }
    public string Value { get; set; }
}
