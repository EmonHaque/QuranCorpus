﻿class TextBoxArabic : TextBox {
    ContextPopup context;

    public TextBoxArabic() {
        ContextMenu = null;
        Background = Brushes.Transparent;
        BorderThickness = new Thickness(0);
        SelectionBrush = new SolidColorBrush(Color.FromArgb(150, 0, 0, 0));
        FlowDirection = FlowDirection.RightToLeft;
        IsReadOnly = true;

        SetBinding(FontSizeProperty, new Binding() {
            Path = new PropertyPath(nameof(Global.ArabicFontSize)),
            Source = App.global
        });
        SetBinding(FontFamilyProperty, new Binding() {
            Path = new PropertyPath(nameof(Global.ArabicFontFamily)),
            Source = App.global
        });
        context = new ContextPopup(new List<ContextItem>() {
            new ContextItem(){ Icon = Icons.Copy, Text = "copy", Command =  () => ApplicationCommands.Copy.Execute(null, null) }
        });
    }

    protected override void OnMouseRightButtonUp(MouseButtonEventArgs e) {
        base.OnMouseRightButtonUp(e);
        context.IsOpen = true;
    }
}
