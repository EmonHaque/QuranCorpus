﻿class RootMatrixPage : Page {
    string root;
    List<Form> forms;
    Grid content;
    ScrollViewer columnViewer, rowViewer, contentViewer;
    List<string> possibleTags = new() {
        "Perfect",
        "Perfect Passive",
        "Imperfect",
        "Imperfect Passive",
        "Imperative",
        "Active Participle",
        "Passive Participle",
        "ADJ",
        "Verbal Noun",
        "Noun",
        "N",
        "PN",
        "IMPN",
        "LOC",
        "T",
        "Particle",
        "P"
    };
    List<string> possibleForms = new() {
        "I",
        "II",
        "III",
        "IV",
        "V",
        "VI",
        "VII",
        "VIII",
        "IX",
        "X",
        "XI",
        "XII"
    };

    public override PageType Type => PageType.RootMatrix;
    public override UIElement Content => content;

    public RootMatrixPage() {
        columnViewer = new ScrollViewer() {
            VerticalScrollBarVisibility = ScrollBarVisibility.Disabled,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Hidden,
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0)
            //Margin = new Thickness(0, 0, SystemParameters.VerticalScrollBarWidth, 0)
        };
        rowViewer = new ScrollViewer() {
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Hidden
            //Margin = new Thickness(0, 0, 0, SystemParameters.HorizontalScrollBarHeight)
        };
        contentViewer = new ScrollViewer() {
            Template = new ScrollViewerTemplate(),
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto
        };

        Grid.SetColumn(columnViewer, 1);
        Grid.SetColumn(contentViewer, 1);
        Grid.SetRow(contentViewer, 1);
        Grid.SetRow(rowViewer, 1);

        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(){Width = new GridLength(75)},
                new ColumnDefinition()
            },
            Children = { rowViewer, columnViewer, contentViewer }
        };
        content.SetValue(Grid.IsSharedSizeScopeProperty, true);

        contentViewer.ScrollChanged += onContentScroll;
        rowViewer.ScrollChanged += onRowScroll;
        columnViewer.ScrollChanged += onColumnScroll;
        App.global.PropertyChanged += onTranscriptChanged;
    }

    public RootMatrixPage(string root, List<Form> forms) : this() {
        this.root = root;
        this.forms = forms;
        makeMatrix();
    }

    public void setContent(string root, List<Form> forms) {
        if (this.root.Equals(root)) return;
        this.root = root;
        this.forms = forms;
        makeMatrix();
    }

    void makeMatrix() {
        List<RootForm> list = new();
        List<string> rows = new();
        List<string> columns = new();

        for (int i = 0; i < forms.Count; i++) {
            if (!forms[i].Root.Equals(root)) continue;

            var pos = new RootForm() {
                Spelling = forms[i].Spellings[App.global.Transcript],
                Tag = forms[i].Tag
            };
            
            setDetail(forms[i].Detail, pos);

            RootForm match = null;
            int j = 0, k = list.Count - 1;
            while (j <= k) {
                if (list[j].Gender.Equals(pos.Gender) &&
                    list[j].Spelling.Equals(pos.Spelling) &&
                    list[j].SubTag.Equals(pos.SubTag) &&
                    list[j].Form.Equals(pos.Form) &&
                    list[j].Tag.Equals(pos.Tag)) {
                    match = list[j];
                }
                if (list[k].Gender.Equals(pos.Gender) &&
                    list[k].Spelling.Equals(pos.Spelling) &&
                    list[k].SubTag.Equals(pos.SubTag) &&
                    list[k].Form.Equals(pos.Form) &&
                    list[k].Tag.Equals(pos.Tag)) {
                    match = list[k];
                }
                j++;
                k--;
            }
            if (match is not null) continue;

            if (!rows.Contains(pos.Form)) {
                rows.Add(pos.Form);
            }
            if (string.IsNullOrEmpty(pos.SubTag)) {
                if (!columns.Contains(pos.Tag)) columns.Add(pos.Tag);
            }
            else {
                if (!columns.Contains(pos.SubTag)) columns.Add(pos.SubTag);
            }

            list.Add(pos);
        }

        rows = possibleForms.Intersect(rows).ToList();
        columns = possibleTags.Intersect(columns).ToList();

        var columnGrid = new Grid() { ShowGridLines = true };
        var rowGrid = new Grid() { ShowGridLines = true };
        var grid = new Grid() { ShowGridLines = true };

        for (int i = 0; i < columns.Count; i++) {
            grid.ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col" + i });
            columnGrid.ColumnDefinitions.Add(new ColumnDefinition() { Tag = columns[i], SharedSizeGroup = "col" + i });

            var block = new TextBlockEnglish() {
                FontWeight = FontWeights.Bold,
                Margin = new Thickness(10, 0, 10, 0),
                Text = columns[i],
                HorizontalAlignment = HorizontalAlignment.Center
            };
            Grid.SetColumn(block, i);
            columnGrid.Children.Add(block);
        }

        for (int i = 0; i < rows.Count; i++) {
            grid.RowDefinitions.Add(new RowDefinition() { SharedSizeGroup = "row" + i });
            rowGrid.RowDefinitions.Add(new RowDefinition() { Tag = rows[i], SharedSizeGroup = "row" + i });

            var block = new TextBlockEnglish() {
                FontWeight = FontWeights.Bold,
                Text = "Form " + rows[i],
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetRow(block, i);
            rowGrid.Children.Add(block);
        }

        for (int i = 0; i < rowGrid.RowDefinitions.Count; i++) {
            for (int j = 0; j < columnGrid.ColumnDefinitions.Count; j++) {
                var block = new StackPanel() {
                    VerticalAlignment = VerticalAlignment.Center,
                    Margin = new Thickness(10, 0, 10, 0)
                };
                Grid.SetColumn(block, j);
                Grid.SetRow(block, i);
                grid.Children.Add(block);
            }
        }

        List<FormGrid> added = new();

        int formCount = 0;
        for (int i = 0; i < list.Count; i++) {
            int column = 0;
            for (int j = 1; j < columnGrid.ColumnDefinitions.Count; j++) {
                if (!columnGrid.ColumnDefinitions[j].Tag.Equals(string.IsNullOrEmpty(list[i].SubTag) ? list[i].Tag : list[i].SubTag)) continue;
                column = j;
                break;
            }
            int row = 0;
            for (int j = 1; j < rowGrid.RowDefinitions.Count; j++) {
                if (!rowGrid.RowDefinitions[j].Tag.Equals(list[i].Form)) continue;
                row = j;
                break;
            }

            var stack = grid
                .Children.OfType<StackPanel>()
                .First(e => Grid.GetRow(e) == row && Grid.GetColumn(e) == column);

            bool isFound = false;
            for (int j = 0; j < stack.Children.Count; j++) {
                var c = (FormGrid)stack.Children[j];
                if (!c.Content.Equals(list[i].Spelling)) continue;
                c.Gender = list[i].Gender;
                isFound = true;
                break;
            }

            if (isFound) continue;

            var newSpelling = new FormGrid() {
                Content = list[i].Spelling,
                Gender = list[i].Gender
            };
            stack.Children.Add(newSpelling);
            added.Add(newSpelling);

            formCount++;
        }

        var duplicateGroups = 
            added.GroupBy(x => x.Content)
            .Where(x => x.Count() > 1)
            .ToList();

        for (int i = 0; i < duplicateGroups.Count; i++) {
            Random rand = new();
            var brush = new SolidColorBrush(Color.FromRgb((byte)rand.Next(127, 255), (byte)rand.Next(127, 255), (byte)rand.Next(127, 255)));
            for (int j = 0; j < duplicateGroups[i].Count(); j++) {
                duplicateGroups[i].ElementAt(j).DuplicateBrush = brush;
            }
        }

        columnViewer.Content = new Border() {
            Child = columnGrid,
            BorderThickness = new Thickness(0, 0, 0, 0.5),
            BorderBrush = Brushes.LightGray
        };
        rowViewer.Content = new Border() {
            Child = rowGrid,
            BorderThickness = new Thickness(0, 0, 0.5, 0),

            BorderBrush = Brushes.LightGray
        };
        contentViewer.Content = grid;

        HeaderText = "(" + formCount + ") " + root.toArabic();

        contentViewer.LayoutUpdated += onLayoutUpdated;
    }

    void setDetail(string detail, RootForm word) {
        if (string.IsNullOrEmpty(detail)) {
            word.Form = "I";
            word.Gender = "";
            word.SubTag = "";
            return;
        }
        var array = detail.Split('|').Select(x => App.details[Convert.ToInt32(x)].Name).ToArray();
        var tag = word.Tag;
        if (App.tagArray.Contains(tag)) {
            for (int i = 0; i < array.Length; i++) {
                if (string.IsNullOrEmpty(array[i])) continue;
                if (array[i].Equals("PCPL") ||
                    array[i].Equals("ACC") ||
                    array[i].Equals("NOM") ||
                    array[i].Equals("GEN") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("ACT")) word.SubTag = "Active Participle";
                else if (array[i].Equals("PASS")) word.SubTag = "Passive Participle";
                else if (array[i].Equals("VN")) word.SubTag = "Verbal Noun";
                else if (array[i].Equals("IN")) word.SubTag = "Noun";
                else if (array[i].Equals("CN")) word.SubTag = "Noun";
                else if (array[i].Equals("IP")) word.SubTag = "Particle";
                else if (array[i].Equals("CP")) word.SubTag = "Particle";
                else if (array[i].StartsWith('(')) word.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else word.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(word.Form)) word.Form = "I";
            if (string.IsNullOrEmpty(word.Gender)) word.Gender = "";
            if (string.IsNullOrEmpty(word.SubTag)) word.SubTag = "";
        }
        else if (tag.Equals("V")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUBJ") ||
                    array[i].Equals("JUS") ||
                    array[i].Equals("JUSS") ||
                    array[i].Equals("SP:kaAn") ||
                    array[i].Equals("SP:kaAd") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("IMPF")) word.SubTag = "Imperfect";
                else if (array[i].Equals("PASS")) word.SubTag += " Passive";
                else if (array[i].Equals("IMPV")) word.SubTag = "Imperative";
                else if (array[i].Equals("PERF")) word.SubTag = "Perfect";
                else if (array[i].StartsWith('(')) word.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else word.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(word.Form)) word.Form = "I";
            if (string.IsNullOrEmpty(word.Gender)) word.Gender = "";
            if (string.IsNullOrEmpty(word.SubTag)) word.SubTag = "";
        }

    }

    void onTranscriptChanged(object? sender, PropertyChangedEventArgs e) {
        makeMatrix();
    }

    void onLayoutUpdated(object? sender, EventArgs e) {
        contentViewer.LayoutUpdated -= onLayoutUpdated;
        //((Rectangle)contentViewer.Template.FindName("Corner", contentViewer)).Fill = Constants.Background;

        rowViewer.Margin = 
            contentViewer.ComputedHorizontalScrollBarVisibility == Visibility.Visible ?
            new Thickness(0, 0, 0, Constants.ScrollBarThickness) :
            rowViewer.Margin = new Thickness(0);
    }

    void onContentScroll(object sender, ScrollChangedEventArgs e) {
        columnViewer.ScrollToHorizontalOffset(e.HorizontalOffset);
        rowViewer.ScrollToVerticalOffset(e.VerticalOffset);
    }

    void onColumnScroll(object sender, ScrollChangedEventArgs e) {
        contentViewer.ScrollToHorizontalOffset(e.HorizontalOffset);
    }

    void onRowScroll(object sender, ScrollChangedEventArgs e) {
        contentViewer.ScrollToVerticalOffset(e.VerticalOffset);
    }

    protected override void unload() {
        contentViewer.ScrollChanged -= onContentScroll;
        rowViewer.ScrollChanged -= onRowScroll;
        columnViewer.ScrollChanged -= onColumnScroll;
        contentViewer.LayoutUpdated -= onLayoutUpdated;
        App.global.PropertyChanged -= onTranscriptChanged;
        base.unload();

    }

    class RootForm {
        public string Tag { get; set; }
        public string Spelling { get; set; }
        public string Form { get; set; }
        public string Gender { get; set; }
        public string SubTag { get; set; }
    }

    class FormGrid : Border {
        TextBlockArabic word;
        StackPanel genderpanel;
        List<string> genders;
        string gender;
        public string Gender {
            get { return gender; }
            set { 
                gender = value;
                if (!genders.Contains(gender)) {
                    addGender(value);
                    genders.Add(gender);
                }
                   
            }
        }
        string content;
        public string Content {
            get { return content; }
            set { content = value; word.Text = content.toArabic(); }
        }
        public Brush DuplicateBrush {
            set => word.Foreground = value;
        }

        public FormGrid() {
            FlowDirection = FlowDirection.LeftToRight;
            Margin = new Thickness(5);
            Padding = new Thickness(5);
            CornerRadius = new CornerRadius(10);
            BorderThickness = new Thickness(Constants.BottomLineThickness);
            BorderBrush = Brushes.Transparent;
            Background = Brushes.Transparent;

            word = new TextBlockArabic() {
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };
            genderpanel = new StackPanel() {
                Margin = new Thickness(0, 0, 10, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(word, 1);
            Child = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){ Width = new GridLength(60) },
                    new ColumnDefinition()
                },
                Children = { genderpanel, word}
            };
            genders = new List<string>();
        }

        void addGender(string gender) {
            var block = new TextBlockEnglish() {
                Text = gender,
                HorizontalAlignment = HorizontalAlignment.Center
            };
            var border = new Border() {
                Padding = new Thickness(5),
                Margin = new Thickness(0, 1, 0, 1),
                CornerRadius = new CornerRadius(5),
                BorderThickness = new Thickness(0.5),
                BorderBrush = Brushes.Gray,
                Child = block
            };

            if (gender.Contains("M")) {
                border.Background = Brushes.Black;
            }
            else if (gender.Contains("F")) {
                border.Background = Brushes.DarkGreen;
            }
            genderpanel.Children.Add(border);
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            base.OnMouseEnter(e);
            BorderBrush = Brushes.LightGray;
        }

        protected override void OnMouseLeave(MouseEventArgs e) {
            base.OnMouseLeave(e);
            BorderBrush = Brushes.Transparent;
        }

        protected override void OnPreviewMouseDown(MouseButtonEventArgs e) {
            base.OnPreviewMouseUp(e);
            if (e.ChangedButton != MouseButton.Left) return;
            if (e.ClickCount != 2) return;
            ((App)Application.Current).FocusedControl.addMorphPage(Content);
        }
    }
}
