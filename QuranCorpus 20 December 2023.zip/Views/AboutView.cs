﻿class AboutView : CardView {
    public override string Icon => Icons.InfoCircle;

    public override void OnFirstSight() {
        base.OnFirstSight();
        var corpusLink = new Hyperlink() {
            NavigateUri = new Uri("http://corpus.quran.com"),
            Inlines = {new Run("The Quranic Arabic Corpus")}
        };
        var tanzilLink = new Hyperlink() {
            NavigateUri = new Uri("https://tanzil.net"),
            Inlines = { new Run("Tanzil") }
        };

        var hablullahLink = new Hyperlink() {
            NavigateUri = new Uri("https://github.com/hablullah/data-quran"),
            Inlines = { new Run("GitHub") }
        };

        var quranComLink = new Hyperlink() {
            NavigateUri = new Uri("https://quran.com/1:1/tafsirs/en-tafisr-ibn-kathir"),
            Inlines = { new Run("Quran.com") }
        };

        var kfgqpcLink = new Hyperlink() {
            NavigateUri = new Uri("https://qurancomplex.gov.sa/en/"),
            Inlines = { new Run("KFGQPC") }
        };

        var hadithsLink = new Hyperlink() {
            NavigateUri = new Uri("https://github.com/ShathaTm/LK-Hadith-Corpus"),
            Inlines = { new Run("GitHub") }
        };

        var arabicFontLink = new Hyperlink() {
            NavigateUri = new Uri("https://arabicfonts.net/"),
            Inlines = { new Run("Arabic Fonts") }
        };

        var materialDesignLink = new Hyperlink() {
            NavigateUri = new Uri("https://materialdesignicons.com/"),
            Inlines = { new Run("Material Design") }
        };

        var appRepoLink = new Hyperlink() {
            NavigateUri = new Uri("https://github.com/EmonHaque/QuranCorpus"),
            Inlines = { new Run("GitHub") }
        };

        var box = new RichEnglishTextBox() { 
            IsDocumentEnabled = true,
            Resources = {
                {
                    typeof(Hyperlink), new Style() {
                        Setters = {
                            new Setter(Hyperlink.TextDecorationsProperty, null),
                            new Setter(Hyperlink.ForegroundProperty, Brushes.SkyBlue),
                            new Setter(Hyperlink.FontWeightProperty, FontWeights.Bold),
                            new EventSetter(Hyperlink.RequestNavigateEvent, new RequestNavigateEventHandler(onWebRequested))
                        }
                    }
                } }
        };

        var blocks = box.Document.Blocks;
        blocks.Add(new Paragraph() {
            Margin = new Thickness(0,0,0,5),
            Foreground = Brushes.Gray,
            FontWeight = FontWeights.Black,
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
            BorderBrush = Constants.Foreground,
            Inlines = { new Run("External resource") }
        });
        blocks.Add(new Paragraph() {
            Margin = new Thickness(0),
            Inlines = {
                new Run("Transcriptions, word segmentations, roots, lemmas and gramatical tags have been taken from the \"Quranic Arabic Corpus (Version 0.4)\". Visit "),
                corpusLink,
                new Run(" for more information. Transliterations, word by word translations, morphological explanations, buckwalter character maps have also been parsed from their site. All their data can be found in the Resources/Corpus folder in nine plain text files and an additional indexing \"link.txt\" file has been added there. Each of those nine files contains unique list and in the \"link.txt\" indices of those lists are stored. Some lemmas end with the character '2' in their Version 0.4 text file and that ending character '2' has been removed. The word nahnu in 2:102:31 has been classified as dual instead of plural and na in 18:38:2 has been removed so 18:38:1 has become lakinna instead of lakin plus na. ba'damA in 2:181, 8:6 and 13:37 has been split into two words. 15:7:1-2 (law + ma), 27:20:4-5 (ma + liya) and 36:22:1-2 (wama + liya) have been merged. Pronoun alif in 2:186:11 has been removed and merged into daEa and faillam in 11:14:1 has become fa + in + lam. In total 8,947 new segments have been added:")
            }
        });
        blocks.Add(new List() {
            MarkerStyle = TextMarkerStyle.Circle,
            ListItems = {
                new ListItem(new Paragraph(new Run("572 'ta', at the end of third person feminine singular perfect and perfect passive verbs, has been separated and classified as subject pronoun, go to Pronoun View and right click 3FS to see those."))),
                new ListItem(new Paragraph(new Run("7,964 more can be seen under SUFF tag in POS View. With simple script you'll see 25 suffix listed on the left and each of those, except the long _ta and _Y (alif maksura), has one explanation. _ta and _Y have two explanation. To see the explanation select a leaf word in the middle. These explanation could be wrong."))),
                new ListItem(new Paragraph(new Run("341 more can be seen under BRID tag in POS View, each of those 3 phonetic bridges has one explanation and these could be wrong. For example - the ya in kibriyah probably is not a phonetic bridge, it probably has been used to make it noun or adjective. ahlihim and ahliyhim sound same but one has ya and the other doesn't."))),
                new ListItem(new Paragraph(new Run("and the rest 70 can be seen under root 'ywm'. iz from yawmaiz and yawmiiz has been separated and yawm has been classified as noun, genitive when it's yawmi-iz and accusative when it's yawma-iz. You can see those under root 'ywm' in Words View.")))
            }
        });
        blocks.Add(new Paragraph(new Run("To see one of the words with longest segments in the popup, enter 5:44:14 in the go to box of Surah page and hover over the word. Corpus transcripts has been modified and the modified version is almost identical to KFGQPC Version 2.2 Uthmanic Hafs script. Unicode 0657 (inverted damma), 065E (fatha with two dots) and 0656 (subscript alif) of KFGQPC V 2.2 have been replaced with 064B (fathatan), 064C (dammatan) and 064D (kasratan).")));
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("There're 16 english translations available in "),
                tanzilLink,
                new Run(" as of 03 September 2023. All their plain text files are in Resources/Tanzil folder.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("Tafsir ibn kathir has been downloaded from "),
                hablullahLink,
                new Run(" and it, probably, downloads data from "),
                quranComLink,
                new Run(". Surah 105, Al-Feel, doesn't have separate tafsir, it displayed tafsir of Surah 104, Al-Humazah in Quran.com on 04 September 2023. Verses 7-8 of Surah 60, Al-Mumtahanah, and verses 17-28 of Surah 68, Al-Qalam, don't have english. The en-ibn-kathir-qurancom.md file has been renamed to .txt, fews lins at the beginning has been removed and modified file is in Resources/Tafsir folder.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("All eight recitations/readings have been downloaded from "),
                kfgqpcLink,
                new Run(" website. Under the Fonts menu there's a sub menu for \"The ten modes of Qur'anic reading\" and there's eight digitized version available as of 23 November 2023. Each reading comes in a MS Word Document along with a font and the word documents have been parsed with \"DocumentFormat.OpenXml 2.20\" nuget package. Bazzi, Hafs, Qunbul and Shuba includes bismillah as a separate verse of Surah Al Fatiha so it's there as a separate verse in .txt files in \"Resources/KFGQPC/Recitations\" folder. Bismillah has been removed from all other surah. Surah number, name and verse counts are in \"Resources/KFGQPC/Surah\" folder and all of their fonts are in \"Resources/KFGQPC/Fonts\" folder.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("All hadiths have been taken from "),
                hadithsLink,
                new Run(". There's an important note on these hadiths in their GitHub page, read that. According to their GitHub page, these csv files contains 39,038 hadith. I've used TextFieldParser of Microsoft.VisualBasic.FileIO to parse all those csv files and according to my count, there're 33,959 hadith with one hadith number, 123 hadith with 2 numbers, 5 hadith with 3 numbers and 1 hadith with 4 numbers so in total there're 34,224 hadith numbers in 34,088 hadith. Hadith with multiple hadith numbers have been found only in bukhari.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("Some or all Arabic fonts (1) Al Qalam Quran Majeed Web Regular, (2) Amiri Quran Regular, (3) Scheherazade Regular, (4) KFGQPC Uthman Taha Naskh Regular (5) KFGQPC Uthmanic Script HAFS Regular (6) me quran, (7) Lateef and (8) Droid Naskh have been taken from "),
                arabicFontLink,
                new Run(".")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("All svg icons have been taken from "),
                materialDesignLink,
                new Run(" and are embedded in the application.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("It's a .net 8 WPF application built with Visual Studio 2022 Community Edition on Windows 11. Visit "),
                appRepoLink,
                new Run(" to download the project.")
            }
        });
        setContent(new ScrollViewer() {
            Template = new ScrollViewerTemplate(),
            Content = box
        });
    }

    //void initializeUI() {
    //    var externalBorder = new Border() {
    //        BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
    //        BorderBrush = Brushes.LightGray,
    //        Child = new TextBlockEnglish() {
    //            Text = "External resources",
    //            FontWeight = FontWeights.Bold
    //        }
    //    };

    //    var corpusLink = new Hyperlink() {
    //        NavigateUri = new Uri("http://corpus.quran.com"),
    //        TextDecorations = null,
    //        Inlines = {
    //            new Run("The Quranic Arabic Corpus"){
    //                FontWeight = FontWeights.Bold,
    //                Foreground = Brushes.CornflowerBlue
    //            }
    //        }
    //    };
    //    //In total 
    //    var corpusBlock = new TextBlockEnglish() {
    //        TextWrapping = TextWrapping.Wrap,
    //        Inlines = {
    //           new Run("Transcriptions, word segmentations, roots, lemmas and gramatical tags have been taken from the \"Quranic Arabic Corpus (Version 0.4)\". Visit "),
    //           corpusLink,
    //           new Run(" for more information. Transliterations, word by word translations, morphological explanations, buckwalter character maps have also been parsed from their site. All their data can be found in the Resources/Corpus folder in nine plain text files and an additional indexing \"link.txt\" file has been added there. Each of those nine files contains unique list and in the \"link.txt\" indices of those lists are stored. Some lemmas end with the character '2' in their Version 0.4 text file and that ending character '2' has been removed. The word nahnu in 2:102:31 has been classified as dual instead of plural and na in 18:38:2 has been removed so 18:38:1 has become lakinna instead of lakin plus na. ba'damA in 2:181, 8:6 and 13:37 has been split into two words. 15:7:1-2 (law + ma), 27:20:4-5 (ma + liya) and 36:22:1-2 (wama + liya) have been merged. Pronoun alif in 2:186:11 has been removed and merged into daEa and faillam in 11:14:1 has become fa + in + lam. In total 8,907 new segments have been added:"),
    //           new LineBreak(),
    //           new LineBreak(),
    //           new Bullet(),
    //           new Run("572 'ta', at the end of third person feminine singular perfect and perfect passive verbs, has been separated and classified as subject pronoun, go to Pronoun View and right click 3FS to see those."),
    //           new LineBreak(),
    //           new LineBreak(),
    //           new Bullet(),
    //           new Run("7,925 more can be seen under SUFF tag in POS View. With simple script you'll see 25 suffix listed on the left and each of those, except the long _ta and _Y (alif maksura), has one explanation. _ta and _Y have two explanation. To see the explanation select a leaf word in the middle. These explanation could be wrong."),
    //           new LineBreak(),
    //           new LineBreak(),
    //           new Bullet(),
    //           new Run("340 more can be seen under BRID tag in POS View, each of those 3 phonetic bridges has one explanation and these could be wrong. For example - the ya in kibriyah probably is not a phonetic bridge, it probably has been used to make it noun or adjective. ahlihim and ahliyhim sound same but one has ya and the other doesn't."),
    //           new LineBreak(),
    //           new LineBreak(),
    //           new Bullet(),
    //           new Run("and the rest 70 can be seen under root 'ywm'. iz from yawmaiz and yawmiiz has been separated and yawm has been classified as noun, genitive when it's yawmi-iz and accusative when it's yawma-iz. You can see those under root 'ywm' in Words View."),
    //           new LineBreak(),
    //           new LineBreak(),
    //           new Run("To see one of the words with longest segments in the popup, enter 5:44:14 in the go to box of Surah page and hover over the word."),


    //        }
    //    };

    //    var tanzilLink = new Hyperlink() {
    //        NavigateUri = new Uri("https://tanzil.net"),
    //        TextDecorations = null,
    //        Inlines = {
    //            new Run("Tanzil"){
    //                FontWeight = FontWeights.Bold,
    //                Foreground = Brushes.CornflowerBlue
    //            }
    //        }
    //    };
    //    var tanzilBlock = new TextBlockEnglish() {
    //        Margin = new Thickness(0, 10, 0, 0),
    //        TextWrapping = TextWrapping.Wrap,
    //        Inlines = {
    //            new Run("There're 16 english translations available in "),
    //            tanzilLink,
    //            new Run(" as of 03 September 2023. All their plain text files are in Resources/Tanzil folder.")
    //        }
    //    };

    //    var hablullahLink = new Hyperlink() {
    //        NavigateUri = new Uri("https://github.com/hablullah/data-quran"),
    //        TextDecorations = null,
    //        Inlines = {
    //            new Run("GitHub"){
    //                FontWeight = FontWeights.Bold,
    //                Foreground = Brushes.CornflowerBlue
    //            }
    //        }
    //    };

    //    var quranComLink = new Hyperlink() {
    //        NavigateUri = new Uri("https://quran.com/1:1/tafsirs/en-tafisr-ibn-kathir"),
    //        TextDecorations = null,
    //        Inlines = {
    //            new Run("Quran.com"){
    //                FontWeight = FontWeights.Bold,
    //                Foreground = Brushes.CornflowerBlue
    //            }
    //        }
    //    };

    //    var hablullahBlock = new TextBlockEnglish() {
    //        Margin = new Thickness(0, 10, 0, 0),
    //        TextWrapping = TextWrapping.Wrap,
    //        Inlines = {
    //            new Run("Tafsir ibn kathir has been downloaded from "),
    //            hablullahLink,
    //            new Run(" and it, probably, downloads data from "),
    //            quranComLink,
    //            new Run(". Surah 105, Al-Feel, doesn't have separate tafsir, it displayed tafsir of Surah 104, Al-Humazah in Quran.com on 04 September 2023. Verses 7-8 of Surah 60, Al-Mumtahanah, and verses 17-28 of Surah 68, Al-Qalam, don't have english. The en-ibn-kathir-qurancom.md file has been renamed to .txt, fews lins at the beginning has been removed and modified file is in Resources/Tafsir folder.")
    //        }
    //    };

    //    var kfgqpcLink = new Hyperlink() {
    //        NavigateUri = new Uri("https://qurancomplex.gov.sa/en/"),
    //        TextDecorations = null,
    //        Inlines = {
    //            new Run("KFGQPC"){
    //                FontWeight = FontWeights.Bold,
    //                Foreground = Brushes.CornflowerBlue
    //            }
    //        }
    //    };

    //    var kfgqpcBlock = new TextBlockEnglish() {
    //        Margin = new Thickness(0, 10, 0, 0),
    //        TextWrapping = TextWrapping.Wrap,
    //        Inlines = {
    //            new Run("All eight recitations/readings have been downloaded from "),
    //            kfgqpcLink,
    //            new Run(" website. Under the Fonts menu there's a sub menu for \"The ten modes of Qur'anic reading\" and there's eight digitized version available as of 23 November 2023. Each reading comes in a MS Word Document along with a font and the word documents have been parsed with \"DocumentFormat.OpenXml 2.20\" nuget package. Bazzi, Hafs, Qunbul and Shuba includes bismillah as a separate verse of Surah Al Fatiha so it's there as a separate verse in .txt files in \"Resources/KFGQPC/Recitations\" folder. Bismillah has been removed from all other surah. Surah number, name and verse counts are in \"Resources/KFGQPC/Surah\" folder and all of their fonts are in \"Resources/KFGQPC/Fonts\" folder.")
    //        }
    //    };

    //    var hadithsLink = new Hyperlink() {
    //        NavigateUri = new Uri("https://github.com/ShathaTm/LK-Hadith-Corpus"),
    //        TextDecorations = null,
    //        Inlines = {
    //            new Run("GitHub"){
    //                FontWeight = FontWeights.Bold,
    //                Foreground = Brushes.CornflowerBlue
    //            }
    //        }
    //    };

    //    var hadithBlock = new TextBlockEnglish() {
    //        Margin = new Thickness(0, 10, 0, 0),
    //        TextWrapping = TextWrapping.Wrap,
    //        Inlines = {
    //            new Run("All hadiths have been taken from "),
    //            hadithsLink,
    //            new Run(". There's an important note on these hadiths in their GitHub page, read that. According to their GitHub page, these csv files contains 39,038 hadith. I've used TextFieldParser of Microsoft.VisualBasic.FileIO to parse all those csv files and according to my count, there're 33,959 hadith with one hadith number, 123 hadith with 2 numbers, 5 hadith with 3 numbers and 1 hadith with 4 numbers so in total there're 34,224 hadith numbers in 34,088 hadith. Hadith with multiple hadith numbers have been found only in bukhari.")
    //        }
    //    };

    //    var arabicFontLink = new Hyperlink() {
    //        NavigateUri = new Uri("https://arabicfonts.net/"),
    //        TextDecorations = null,
    //        Inlines = {
    //            new Run("Arabic Fonts"){
    //                FontWeight = FontWeights.Bold,
    //                Foreground = Brushes.CornflowerBlue
    //            }
    //        }
    //    };
    //    var arabicFontBlock = new TextBlockEnglish() {
    //        Margin = new Thickness(0, 10, 0, 0),
    //        TextWrapping = TextWrapping.Wrap,
    //        Inlines = {
    //            new Run("Some or all Arabic fonts (1) Al Qalam Quran Majeed Web Regular, (2) Amiri Quran Regular, (3) Scheherazade Regular, (4) KFGQPC Uthman Taha Naskh Regular (5) KFGQPC Uthmanic Script HAFS Regular (6) me quran, (7) Lateef and (8) Droid Naskh have been taken from "),
    //            arabicFontLink,
    //            new Run(".")
    //        }
    //    };

    //    var materialDesignLink = new Hyperlink() {
    //        NavigateUri = new Uri("https://materialdesignicons.com/"),
    //        TextDecorations = null,
    //        Inlines = {
    //            new Run("Material Design"){
    //                FontWeight = FontWeights.Bold,
    //                Foreground = Brushes.CornflowerBlue
    //            }
    //        }
    //    };
    //    var materialDesignBlock = new TextBlockEnglish() {
    //        Margin = new Thickness(0, 10, 0, 0),
    //        TextWrapping = TextWrapping.Wrap,
    //        Inlines = {
    //            new Run("All svg icons have been taken from "),
    //            materialDesignLink,
    //            new Run(" and are embedded in the application.")
    //        }
    //    };

    //    var appRepoLink = new Hyperlink() {
    //        NavigateUri = new Uri("https://github.com/EmonHaque/QuranCorpus"),
    //        TextDecorations = null,
    //        Inlines = {
    //            new Run("GitHub"){
    //                FontWeight = FontWeights.Bold,
    //                Foreground = Brushes.CornflowerBlue
    //            }
    //        }
    //    };

    //    var microsoftBlock = new TextBlockEnglish() {
    //        Margin = new Thickness(0, 10, 0, 0),
    //        Inlines = {
    //            new Run("It's a .net 8 WPF application built with Visual Studio 2022 Community Edition on Windows 11. Visit "),
    //            appRepoLink,
    //            new Run(" to download the project.")
    //        }
    //    };

    //    var usageBorder = new Border() {
    //        Margin = new Thickness(0, 10, 0, 0),
    //        BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
    //        BorderBrush = Brushes.LightGray,
    //        Child = new TextBlockEnglish() {
    //            Text = "Usage",
    //            FontWeight = FontWeights.Bold
    //        }
    //    };

    //    Grid.SetRow(corpusBlock, 1);
    //    Grid.SetRow(tanzilBlock, 2);
    //    Grid.SetRow(hablullahBlock, 3);
    //    Grid.SetRow(kfgqpcBlock, 4);
    //    Grid.SetRow(hadithBlock, 5);
    //    Grid.SetRow(arabicFontBlock, 6);
    //    Grid.SetRow(materialDesignBlock, 7);
    //    Grid.SetRow(microsoftBlock, 8);
    //    Grid.SetRow(usageBorder, 9);
  
    //    var scroll = new ScrollViewer() {
    //        Template = new ScrollViewerTemplate(),
    //        HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
    //        VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
    //        Content = new Grid() {
    //            RowDefinitions = {
    //                new RowDefinition(){ Height = GridLength.Auto },
    //                new RowDefinition(){ Height = GridLength.Auto },
    //                new RowDefinition(){ Height = GridLength.Auto },
    //                new RowDefinition(){ Height = GridLength.Auto },
    //                new RowDefinition(){ Height = GridLength.Auto },
    //                new RowDefinition(){ Height = GridLength.Auto },
    //                new RowDefinition(){ Height = GridLength.Auto },
    //                new RowDefinition(){ Height = GridLength.Auto },
    //                new RowDefinition(){ Height = GridLength.Auto },
    //                new RowDefinition(){ Height = GridLength.Auto }
    //            },
    //            Children = {
    //                externalBorder,
    //                corpusBlock,
    //                tanzilBlock,
    //                hablullahBlock,
    //                kfgqpcBlock,
    //                hadithBlock,
    //                arabicFontBlock,
    //                microsoftBlock,
    //                materialDesignBlock
    //            }
    //        }
    //    };
    //    setContent(scroll);

    //    corpusLink.RequestNavigate += onWebRequested;
    //    tanzilLink.RequestNavigate += onWebRequested;
    //    hablullahLink.RequestNavigate += onWebRequested;
    //    kfgqpcLink.RequestNavigate += onWebRequested;
    //    hadithsLink.RequestNavigate += onWebRequested;
    //    quranComLink.RequestNavigate += onWebRequested;
    //    arabicFontLink.RequestNavigate += onWebRequested;
    //    materialDesignLink.RequestNavigate += onWebRequested;
    //    appRepoLink.RequestNavigate += onWebRequested;
    //}

    void onWebRequested(object sender, RequestNavigateEventArgs e) {
        Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri) { UseShellExecute = true });
    }

    //class Bullet : BulletDecorator {
    //    public Bullet() {
    //        Bullet = new Ellipse() { Height = 10, Width = 10, Fill = Constants.Foreground };
    //        Margin = new Thickness(25, 0, 5, 0);
    //    }
    //}
}
