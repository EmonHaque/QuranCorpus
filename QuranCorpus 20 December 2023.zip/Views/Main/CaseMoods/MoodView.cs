﻿class MoodView : CardView {
    public override string Header => "Moods";

    TextBlockEnglish count;
    ProgressBar progress;
    PageListBox list;
    MoodVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new MoodVM();
        DataContext = vm;
        initializeUI();
        bind();
        IsVisibleChanged += onVisibilityChange;
    }

    void onVisibilityChange(object sender, DependencyPropertyChangedEventArgs e) {
        if (!IsVisible) return;
        if (vm.currentTranscript == App.global.Transcript) return;
        vm.Regroup();
    }

    void initializeUI() {
        progress = new ProgressBar() {
            Height = Constants.ProgressBarHeight,
            FlowDirection = FlowDirection.RightToLeft
        };
        list = new PageListBox() {
            Context = vm,
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(StringCountTemplate))
            }
        };
        Grid.SetRow(list, 1);

        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { progress, list }
        };
        setContent(grid);

        count = new TextBlockEnglish();
        addActions(new UIElement[] { count });
    }

    void bind() {
        progress.SetBinding(ProgressBar.IsIndeterminateProperty, new Binding(nameof(vm.IsInProgress)));
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Genders)));
        count.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = list,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
    }
}
