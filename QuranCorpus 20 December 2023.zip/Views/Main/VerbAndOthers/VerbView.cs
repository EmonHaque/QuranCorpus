﻿class VerbView : CardView {
    public override string Header => "Verbs";
    VerbVM vm;
    Run itemCount, total;
    ProgressBar progress;
    PageListBox list;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new VerbVM();
        DataContext = vm;
        initializeUI();
        bind();
        
        IsVisibleChanged += onVisibilityChange;
    }

    void initializeUI() {
        progress = new ProgressBar() {
            Height = Constants.ProgressBarHeight,
            FlowDirection = FlowDirection.RightToLeft
        };
        list = new PageListBox() {
            Context = vm,
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = {
                            new Setter(GroupItem.TemplateProperty, new VerbAndOthersGroupTemplate())
                        }
                    }
                }
            },
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(NumberTemplate))
            }
        };
        list.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        list.SetValue(ScrollViewer.CanContentScrollProperty, false);
        Grid.SetRow(list, 1);

        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { progress, list }
        };
        setContent(grid);

        itemCount = new Run() { Foreground = Brushes.Gray, FontStyle = FontStyles.Italic };
        total = new Run();
        var count = new TextBlockEnglish() { 
            Inlines = { itemCount, new Run(" | ") { Foreground = Brushes.Gray }, total }
        };
        addActions(new UIElement[] { count });
    }

    void bind() {
        progress.SetBinding(ProgressBar.IsIndeterminateProperty, new Binding(nameof(vm.IsInProgress)));
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Items)));
        itemCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = list,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        total.SetBinding(Run.TextProperty, new Binding(nameof(vm.Total)) { StringFormat = "N0"});
    }

    void onVisibilityChange(object sender, DependencyPropertyChangedEventArgs e) {
        if (!IsVisible) return;
        if (vm.currentTranscript == App.global.Transcript) return;
        vm.Regroup();
    }

    class NumberTemplate : Grid {
        TextBlockEnglish name, count;
        public NumberTemplate() {
            name = new TextBlockEnglish();
            count = new TextBlockEnglish();
            SetColumn(count, 1);
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

            Children.Add(name);
            Children.Add(count);

            name.SetBinding(TextBlockEnglish.TextProperty, new Binding(nameof(VerbGroup.Number)));
            count.SetBinding(TextBlockEnglish.TextProperty, new Binding(nameof(VerbGroup.Count)) { StringFormat = "N0" });
        }
    }
}
