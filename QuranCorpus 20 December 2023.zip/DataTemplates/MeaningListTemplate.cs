﻿class MeaningListTemplate : Grid {
    TextBlockEnglish reference, transliteration, meaning;
    public MeaningListTemplate() {
        reference = new TextBlockEnglish();
        transliteration = new TextBlockEnglish() {
            Margin = new Thickness(5, 0, 5, 0),
            Foreground = Brushes.Khaki
        };
        meaning = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap
        };

        SetColumn(transliteration, 1);
        SetColumn(meaning, 2);
        ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col1" });
        ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col2" });
        ColumnDefinitions.Add(new ColumnDefinition());

        Children.Add(reference);
        Children.Add(transliteration);
        Children.Add(meaning);
    }

    public override void EndInit() {
        base.EndInit();
        var c = (Tuple<string, string, string>)DataContext;
        reference.Text = c.Item1;
        transliteration.Text = App.transliterations[Convert.ToInt32(c.Item2)];
        meaning.Text = App.meanings[Convert.ToInt32(c.Item3)];
    }
}
