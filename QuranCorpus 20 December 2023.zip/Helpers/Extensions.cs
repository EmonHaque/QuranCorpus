﻿static class Extensions {
    public static string toArabic(this string transcription) {
        StringBuilder builder = new();
        foreach (var character in transcription) {
            if (character == ' ') {
                builder.Append(' '); // happens only once in case of prophet il yas, eg. 37:130
                continue;
            }
            else if (character == '|') {
                builder.Append(" | "); // FormPage needs it for yabnaumma
                continue;
            }
            char c = (char)uint.Parse(App.characters.First(x => x.English == character).Arabic, NumberStyles.HexNumber);
            builder.Append(c);
        }
        return builder.ToString();

    }

    public static void toArabic(this string transcription, string[] segments, StringBuilder sb) {
        var characters = App.segments[Convert.ToInt32(transcription)];
        foreach (var character in characters) {
            if (character == ' ') {
                sb.Append(' '); // happens only once in case of prophet il yas, eg. 37:130
                continue;
            }
            char c = (char)uint.Parse(App.characters.First(x => x.English == character).Arabic, NumberStyles.HexNumber);
            sb.Append(c);
        }
    }

    public static void toArabic(this string[] segments, StringBuilder sb) {
        foreach (var segment in segments) {
            var characters = App.segments[Convert.ToInt32(segment)];
            foreach (var character in characters) {
                if (character == ' ') {
                    sb.Append(' '); // happens only once in case of prophet il yas, eg. 37:130
                    continue;
                }
                char c = (char)uint.Parse(App.characters.First(x => x.English == character).Arabic, NumberStyles.HexNumber);
                sb.Append(c);
            }
        }
    }

    public static string toRoot(this string transcription) {
        StringBuilder builder = new();
        foreach (var character in transcription) {
            var y = character == 'A' ? '>' : character;
            char c = (char)uint.Parse(App.characters.First(x => x.English == y).Arabic, NumberStyles.HexNumber);
            builder.Append(c).Append(' ');
        }
        builder.Remove(builder.Length - 1, 1);
        return builder.ToString();
    }

    public static string toTransliteratedRoot(this string transcription) {
        StringBuilder builder = new();
        foreach (var character in transcription) {
            var c = character == 'A' ? '\'' : character;
            builder.Append(App.characters.First(x => x.English == c).Transliteration).Append(' ');
        }
        builder.Remove(builder.Length - 1, 1);
        return builder.ToString();
    }

    public static string toArabicNo(this string value) {
        return value.Replace('0', '\u0660')
              .Replace('1', '\u0661')
              .Replace('2', '\u0662')
              .Replace('3', '\u0663')
              .Replace('4', '\u0664')
              .Replace('5', '\u0665')
              .Replace('6', '\u0666')
              .Replace('7', '\u0667')
              .Replace('8', '\u0668')
              .Replace('9', '\u0669');
    }

    public static string[] toSegments(this Link link) => new string[] {
        link.SegmentsCorpus,
        link.SegmentsSimple
    };
    
    public static string[] toLemmas(this Link link) => new string[] {
        link.LemmaCorpus,
        link.LemmaSimple
    };
    
    public static string[] toSpellings(this Link link) => new string[] {
        link.SpellingGroupCorpus,
        link.SpellingGroupSimple
    };

    public static void explain(this Word word, StringBuilder builder, string[] tags, bool hasDeterminant) {
        var parts = word.Reference.Split(':');
        string wordNo = parts[2] switch {
            "1" => "st ",
            "2" => "nd ",
            "3" => "rd",
            _ => "th "
        };
        builder
            .Append("The ")
            .Append(parts[2])
            .Append(wordNo)
            .Append(" word")
            .Append(" of verse ")
            .Append(parts[1])
            .Append(" of chapter ")
        .Append(parts[0]);

        var explanations = word.Explanation.Split('|');
        var details = word.Details.Split(',');
        var roots = new List<string>(explanations.Length);
        var r = word.Root.Split('|');

        if (!string.IsNullOrEmpty(word.RootIndex)) {
            var index = Convert.ToInt32(word.RootIndex);
            for (int i = 0; i < explanations.Length; i++) {
                if (i == index) roots.Add(r[0]);
                else roots.Add("");
            }
            if (r.Length > 1) roots[++index] = r[1];
        }
        else for (int i = 0; i < explanations.Length; i++) roots.Add("");

        List<string> tagNames = new();
        for (int i = 0; i < tags.Length; i++) {
            var tag = App.tags[Convert.ToInt32(tags[i])];
            var tagName = Helper.getTagName(tag, details[i]);
            tagNames.Add(tagName);
        }

        if (tags.Length > 1) {
            builder
                .Append(" is divided into ")
                .Append(tags.Length)
                .Append(" morphological segments. ")
                .Append(
                (tagNames[0].StartsWith('a') || tagNames[0].StartsWith('e') || tagNames[0].StartsWith('i')) ?
                "An " : "A ");

            var groups = tagNames.GroupBy(x => x).ToList();
            for (int i = 0; i < groups.Count; i++) {
                if (i > 0) {
                    builder.Append(i < groups.Count - 1 ? ", " : " and ");
                }
                if (groups[i].Count() > 1) {
                    builder.Append(groups[i].Count()).Append(' ').Append(groups[i].Key).Append('s');
                }
                else builder.Append(groups[i].Key);
            }
            builder.Append(".");
        }
        builder.Append(' ');

        for (int i = 0; i < explanations.Length; i++) {
            Tuple<string, string> tup = null;

            if (!string.IsNullOrEmpty(explanations[i])) {
                var exp = App.explanations[Convert.ToInt32(explanations[i])];
                tup =
                    Helper.getExplanations(exp, "jār wa majrūr") ??
                    Helper.getExplanations(exp, "kāda and her sisters") ??
                    Helper.getExplanations(exp, "kāna and her sisters");

                builder
                    .Append(tup is null ? exp : tup.Item1)
                    .Append('.');
            }

            if (!string.IsNullOrEmpty(roots[i])) {
                var root = App.roots[Convert.ToInt32(roots[i])];
                builder
                    .Append(' ')
                    .Append("The ")
                    .Append(tagNames[i])
                    .Append('\'')
                    .Append('s')
                    .Append(root.Length == 3 ? " triliteral " : " quadriliteral ")
                    .Append("root is ")
                    .Append(root.toTransliteratedRoot())
                    .Append(" (")
                    .Append(root.toRoot())
                    .Append(").");
            }
            if (tup is not null && tup.Item2 is not null) {
                builder.Append(' ').Append(tup.Item2).Append('.');
            }
            builder.Append(' ');
        }
        builder.Remove(builder.Length - 1, 1);
    }

    public static void explain(this Link link, StringBuilder builder) {
        var tags = link.Tags.Split('|');
        var explanations = link.Explanation.Split('|');
        var details = link.Details.Split(',');

        List<string> tagNames = new();
        for (int i = 0; i < tags.Length; i++) {
            var tag = App.tags[Convert.ToInt32(tags[i])];
            var tagName = Helper.getTagName(tag, details[i]);
            tagNames.Add(tagName);
        }

        if (tags.Length > 1) {
            builder.Append(
                (tagNames[0].StartsWith('a') || tagNames[0].StartsWith('e') || tagNames[0].StartsWith('i')) ?
                "An " : "A ");

            var groups = tagNames.GroupBy(x => x).ToList();
            for (int i = 0; i < groups.Count; i++) {
                if (i > 0) {
                    builder.Append(i < groups.Count - 1 ? ", " : " and ");
                }
                if (groups[i].Count() > 1) {
                    builder.Append(groups[i].Count()).Append(' ').Append(groups[i].Key).Append('s');
                }
                else builder.Append(groups[i].Key);
            }
            builder.Append(". ");
        }

        for (int i = 0; i < explanations.Length; i++) {
            if (string.IsNullOrEmpty(explanations[i])) continue;
            var exp = App.explanations[Convert.ToInt32(explanations[i])];
            builder.Append(exp).Append(". ");
        }
        builder.Remove(builder.Length - 1, 1);
    }

    public static Morph toMorph(this Link item, StringBuilder builder) {
        string tag = "";
        string[] tags;
        string details = "";
        byte searchMode;
        if (string.IsNullOrEmpty(item.Root)) {
            if (string.IsNullOrEmpty(item.LemmaSimple)) searchMode = 3;
            else searchMode = 2;
        }
        else {
            if (item.Root.Contains('|')) {
                // in one case 20:94:2 - ya ibna umma - two roots bny and Amm
                searchMode = 3;
            }
            else searchMode = 1;
        }

        if (searchMode == 1) {
            details = item.Details.Split(',')[Convert.ToInt32(item.RootIndex)];
            details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
            int lIndex;
            if (item.LemmaSimple.EndsWith(App.indexMa)) {
                // in 8 cases it ends with maA
                lIndex = 0;
            }
            else if (item.Root.Equals(App.indexYwm) && item.LemmaSimple.EndsWith(App.indexIz)) {
                lIndex = Convert.ToInt32(item.RootIndex);
            }
            else lIndex = Convert.ToInt32(item.LemmaIndices);

            tags = item.Tags.Split('|');
            tag = App.tags[Convert.ToInt32(tags[lIndex])].Name;
        }
        else if (searchMode == 2) {
            var indices = item.LemmaIndices.Split('|');
            if (indices.Length == 1) {
                details = item.Details.Split(',')[Convert.ToInt32(item.LemmaIndices)];
                details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
                int lIndex;
                if (item.LemmaSimple.EndsWith(App.indexMa)) {
                    // in 8 cases it ends with maA
                    lIndex = 0;
                }
                else lIndex = Convert.ToInt32(item.LemmaIndices);

                tags = item.Tags.Split('|');
                tag = App.tags[Convert.ToInt32(tags[lIndex])].Name;
            }
            else {
                builder.Clear();
                item.explain(builder);
                var m = new Morph() {
                    Segments = item.toSegments(),
                    Tags = item.Tags.Split('|'),
                    Spellings = new string[] {
                                string.Join("", item.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)])),
                                string.Join("", item.SegmentsSimple.Split('|').Select(x => App.segments[Convert.ToInt32(x)]))
                            },
                    Explanation = builder.ToString(),
                    Tag = ""
                };
                m.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));
                return m;
            }
        }
        else {
            if (!item.SpellingGroupSimple.Contains('|')) {
                details = item.Details;
                details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
                tag = App.tags[Convert.ToInt32(item.Tags)].Name;
                tags = item.Tags.Split('|');
            }
            else {
                builder.Clear();
                item.explain(builder);
                var m = new Morph() {
                    Segments = item.toSegments(),
                    Tags = item.Tags.Split('|'),
                    Spellings = new string[] {
                                string.Join("", item.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)])),
                                string.Join("", item.SegmentsSimple.Split('|').Select(x => App.segments[Convert.ToInt32(x)]))
                            },
                    Explanation = builder.ToString(),
                    Tag = ""
                };
                m.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));
                return m;
            }
        }

        Morph t = new() {
            Tag = tag,
            Tags = tags,
            Segments = item.toSegments(),
            Spellings = getSpellings(item)
        };
        builder.Clear();
        item.explain(builder);

        t.Explanation = builder.ToString();
        t.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));

        var array = details.Split('|');
        if (App.tagArray.Contains(tag)) {
            for (int i = 0; i < array.Length; i++) {
                if (string.IsNullOrEmpty(array[i])) continue;
                if (array[i].Equals("PCPL") ||
                    array[i].Equals("ACC") ||
                    array[i].Equals("NOM") ||
                    array[i].Equals("GEN") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("ACT")) t.SubTag = "Active Participle";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive Participle";
                else if (array[i].Equals("VN")) t.SubTag = "Verbal Noun";
                else if (array[i].Equals("IN")) t.SubTag = "Noun";
                else if (array[i].Equals("CN")) t.SubTag = "Noun";
                else if (array[i].Equals("IP")) t.SubTag = "Particle";
                else if (array[i].Equals("CP")) t.SubTag = "Particle";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("V")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUBJ") ||
                    array[i].Equals("JUS") ||
                    array[i].Equals("JUSS") ||
                    array[i].Equals("SP:kaAn") ||
                    array[i].Equals("SP:kaAd") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("IMPF")) t.SubTag = "Imperfect";
                else if (array[i].Equals("PASS")) t.SubTag += "Passive";
                else if (array[i].Equals("IMPV")) t.SubTag = "Imperative";
                else if (array[i].Equals("PERF")) t.SubTag = "Perfect";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("PRON")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUB")) t.SubTag = "Subject";
                else if (array[i].Equals("OBJ")) t.SubTag = "Object";
                else if (array[i].Equals("PER")) t.SubTag = "Personal";
                else if (array[i].Equals("POS")) t.SubTag = "Possessive";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name;
                else t.Gender = Helper.getGender(array[i]).Name;
            }
        }
        return t;

        string[] getSpellings(Link item) {
            int lIndex;
            if (item.LemmaSimple.EndsWith(App.indexMa)) {
                // in 8 cases it ends with maA
                lIndex = 0;
            }
            else if (item.Root.Equals(App.indexYwm) && item.LemmaSimple.EndsWith(App.indexIz)) {
                lIndex = Convert.ToInt32(item.RootIndex);
            }
            else {
                if (string.IsNullOrEmpty(item.LemmaIndices)) {
                    return new string[] {
                    item.SpellingGroupCorpus,
                    item.SpellingGroupSimple
                };
                }

                lIndex = Convert.ToInt32(item.LemmaIndices);
            }
            return new string[] {
                item.SpellingGroupCorpus.Split('|')[lIndex],
                item.SpellingGroupSimple.Split('|')[lIndex]
            };
        }
    }
}
