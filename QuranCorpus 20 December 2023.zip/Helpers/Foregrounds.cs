﻿class Foregrounds {
    public static string[] Defined = new string[] { "", "DET", "V", "N", "PN", "ADJ", "REL", "DEM", "P", "PRON", "CONJ", "INTG", "NEG" };
    public static SolidColorBrush DET_Brush = Brushes.Gray;
    public static SolidColorBrush V_Brush = Brushes.Aqua;
    public static SolidColorBrush N_PN_ADJ_Brush = Brushes.LightGray;
    public static SolidColorBrush DEM_REL_Brush = Brushes.LightGoldenrodYellow;
    public static SolidColorBrush P_Brush = Brushes.PowderBlue;
    public static SolidColorBrush CONJ_Brush = Brushes.Chocolate;
    public static SolidColorBrush INTG_Brush = Brushes.CornflowerBlue;
    public static SolidColorBrush NEG_Brush = Brushes.Olive;
    public static SolidColorBrush PRON1_Brush = Brushes.LightGreen;
    public static SolidColorBrush PRON2_Brush = Brushes.Plum;
    public static SolidColorBrush PRON3_Brush = Brushes.Plum;
    public static SolidColorBrush OTHER1_Brush = Brushes.Coral;
    public static SolidColorBrush OTHER2_Brush = Brushes.NavajoWhite;
    public static SolidColorBrush OTHER3_Brush = Brushes.NavajoWhite;
}
