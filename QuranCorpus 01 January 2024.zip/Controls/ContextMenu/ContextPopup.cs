﻿class ContextPopup : Popup {
    //Border border;
    Border[] stacks;
    Grid grid;
    public List<ContextItem> items;

    public ContextPopup(List<ContextItem> items) { 
        this.items = items;
        stacks = new Border[items.Count()];
        grid = new Grid();
        int index = 0;
        foreach (var item in items) {
            var block = new TextBlockEnglish() { 
                Text = item.Text,
                Foreground = item.IsDisabled ? Brushes.Gray : Constants.Foreground,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(5, 0, 0, 0)
            };
            var border = new Border() {
                Tag = index,
                Padding = new Thickness(2.5),
                BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, Constants.BottomLineThickness),
                Child = new StackPanel() {
                    Orientation = Orientation.Horizontal,
                    Children = {
                        Helper.getIcon(item.Icon, Brushes.LightGray),
                        block
                    }
                }
            };
            stacks[index] = border;
            grid.RowDefinitions.Add(new RowDefinition());
            Grid.SetRow(border, index++);
            grid.Children.Add(border);
        }
        var outerBorder = new Border() {
            Background = Constants.Background,
            BorderBrush = Brushes.LightGray,
            BorderThickness = new Thickness(Constants.BottomLineThickness),
            Padding = new Thickness(5),
            CornerRadius = new CornerRadius(5),
            Child = grid
        };
        StaysOpen = false;
        AllowsTransparency = true;
        Placement = PlacementMode.MousePoint;
        VerticalOffset = 5;
        Child = outerBorder;
    }

    public void addAction(ContextItem item) {
        var index = items.Count;
        items.Add(item);
       
        var block = new TextBlockEnglish() {
            Text = item.Text,
            Foreground = Constants.Foreground,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(5, 0, 0, 0)
        };
        var border = new Border() {
            Tag = index,
            Padding = new Thickness(2.5),
            BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, Constants.BottomLineThickness),
            Child = new StackPanel() {
                Orientation = Orientation.Horizontal,
                Children = {
                        Helper.getIcon(item.Icon, Brushes.LightGray),
                        block
                    }
            }
        };
       
        Array.Resize(ref stacks, items.Count);
       
        stacks[index] = border;
        grid.RowDefinitions.Add(new RowDefinition());
        Grid.SetRow(border, index++);
        grid.Children.Add(border);
    }

    public void disableAction(ContextItem item) {
        var border = stacks[items.IndexOf(item)];
        var stack = (StackPanel)border.Child;
        var path = (Path)stack.Children[0];
        var block = (TextBlockEnglish)stack.Children[1];
        if (item.IsDisabled) {
            block.Foreground = Brushes.Gray;
            path.Fill = Brushes.Gray;
        }
        else {
            block.Foreground = Constants.Foreground;
            path.Fill = Brushes.LightGray;
        }
        
    }

    void onMouseEnter(object sender, MouseEventArgs e) {
        var stack = (Border)sender;
        stack.Background = Constants.BackgroundDark;
        stack.BorderBrush = Brushes.LightGray;
    }

    void onMouseLeave(object sender, MouseEventArgs e) {
        var stack = (Border)sender;
        stack.Background = null;
        stack.BorderBrush = null;
    }

    void onLeftClick(object sender, MouseButtonEventArgs e) {
        IsOpen = false;
        var stack = (Border)sender;
        var item = items.ElementAt(Convert.ToInt32(stack.Tag));
        if (item.IsDisabled) return;
        item.Command.Invoke();
    }
    
    protected override void OnOpened(EventArgs e) {
        base.OnOpened(e);
        foreach (var stack in stacks) {
            stack.MouseEnter += onMouseEnter;
            stack.MouseLeave += onMouseLeave;
            stack.MouseLeftButtonUp += onLeftClick;
        }
    }

    protected override void OnClosed(EventArgs e) {
        base.OnClosed(e);
        foreach (var stack in stacks) {
            stack.MouseEnter -= onMouseEnter;
            stack.MouseLeave -= onMouseLeave;
            stack.MouseLeftButtonUp -= onLeftClick;
        }
    }
}
