﻿class PatternGroupPage : Page {
    Grid content;
    TextBlockEnglish patternCount, morphCount, meaningCount;
    Toggle sortToggle, lengthToggle;
    WaterBox queryBox;
    List<RootMorph> morphs;
    ContentListBox list, morphList;
    ListBox listMeaning;
    ContentTreeView tagTree, rootTree;
    CheckGroup checkGroup;
    DependencyPropertyDescriptor groupStateDescriptor;

    ICollectionView patternView;
    List<PatternGroup> source;
    string query;
    int count;

    public override PageType Type => PageType.PatternGroup;
    public override UIElement Content => content;

    public PatternGroupPage(List<PatternSegment> consolidated) {
        HeaderText = "Unique";
        var helper = new PatternHelper();
        List<RootForm> forms = new();
        var grr = consolidated.GroupBy(x => x.Pattern).ToList();

        for (int i = 0; i < grr.Count; i++) {
            var source = grr[i].ToList();
            List<RootForm> l = grr[i].Key switch {
                "+~+" => helper.shaddaPlus(source),
                "++~" => helper.plusShadda(source),
                "w++" => helper.wawPlusPlus(source),
                "+w+" => helper.plusWawPlus(source),
                "++w" => helper.plusPlusWaw(source),
                "y++" => helper.yaPlusPlus(source),
                "+y+" => helper.plusYaPlus(source),
                "++y" => helper.plusPlusYa(source),
                "A++" => helper.hamzaPlusPlus(source),
                "+A+" => helper.plusHamzaPlus(source),
                "++A" => helper.plusPlusHamza(source),
                "Aw+" => helper.hamzaWawPlus(source),
                "Ay+" => helper.hamzaYaPlus(source),
                "yA+" => helper.yaHamzaPlus(source),
                "wA+" => helper.wawHamzaPlus(source),
                "yw+" => helper.yaWawPlus(source),
                "w+y" => helper.wawPlusYa(source),
                "A+y" => helper.hamzaPlusYa(source),
                "y+y" => helper.yaPlusYa(source),
                "w+A" => helper.wawPlusHamza(source),
                "+wy" => helper.plusWawYa(source),
                "+wA" => helper.plusWawHamza(source),
                "+yA" => helper.plusYaHamza(source),
                "+Ay" => helper.plusHamzaYa(source),
                "A+w" => helper.hamzaPlusWaw(source),
                "A+~" => helper.hamzaPlusShadda(source),
                "w+~" => helper.wawPlusShadda(source),
                "y+~" => helper.yaPlusShadda(source),
                "Ay~" => helper.hamzaYaShadda(source),
                "+w~" => helper.plusWawShadda(source),
                "+y~" => helper.plusYaShadda(source),
                "Awy" => helper.alifWawYa(source),
                "++++" => helper.quad(source),
                "-+-+" => helper.quad(source),
                _ => helper.normal(source)
            };

            forms.AddRange(l);
        }

        source = forms.GroupBy(x => new {
            x.Pattern,
            x.Segmentation
        })
            .Select(x => new PatternGroup() {
                Pattern = x.Key.Pattern,
                Segmentation = x.Key.Segmentation,
                References = x.ToList()
            })
            .ToList();

        var left = getLeftGrid();
        var right = getRightGrid();
        Grid.SetColumn(left, 1);
        content = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(2.5, GridUnitType.Star)}
            },
            Children = { left, right }
        };

        groupStateDescriptor = DependencyPropertyDescriptor.FromProperty(CheckGroup.SelectedProperty, typeof(CheckGroup));
        groupStateDescriptor.AddValueChanged(checkGroup, onCheckStateChanged);

        list.Fired += onListFired;
        morphList.Fired += onMorphFired;
        listMeaning.MouseDoubleClick += onMeaningDoubleClick;
        queryBox.KeyUp += onQuery;

        var listSource = source.Select(x => new UniquePattern() {
            Segments = x.References.First().Segments,
            Pattern = x.Pattern,
            Segmentation = x.Segmentation,
            RootCount = x.References.Select(x => x.Root).Distinct().Count(),
            ReferenceCount = x.References.Sum(x => x.References.Sum(x => x.References.Count))
        }).ToList();

        patternView = CollectionViewSource.GetDefaultView(listSource);
        patternView.Filter = filter;
        list.ItemsSource = patternView;
    }

    Grid getRightGrid() {
        sortToggle = new Toggle() {
            Margin = new Thickness(0, 0, 5, 5),
            OnIcon = Icons.Sprout,
            OffIcon = Icons.List,
            OnTip = "by root",
            OffTip = "by reference",
            Command = sort
        };
        queryBox = new WaterBox() {
            Margin = new Thickness(5,0,5,0),
            FlowDirection = FlowDirection.LeftToRight,
            Icon = Icons.Search,
            Hint = "Pattern (eg. +a+o+aAn)"
        };
        lengthToggle = new Toggle() {
            VerticalAlignment = VerticalAlignment.Center,
            OnIcon = Icons.Equal,
            OffIcon = Icons.Approximate,
            OnTip = "equal length",
            OffTip = "equal or greater length"
        };
        var buckwalterPop = new BuckwalterPopup() { Margin = new Thickness(5, 0, 5, 0) };
        patternCount = new TextBlockEnglish();

        list = new ContentListBox() {
            Margin = new Thickness(0, 5, 0, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(PatternTemplate))
            }
        };

        Grid.SetRow(list, 1);
        Grid.SetColumn(buckwalterPop, 1);
        Grid.SetColumn(lengthToggle, 2);
        Grid.SetColumn(queryBox, 3);
        Grid.SetColumn(sortToggle, 4);
        Grid.SetColumnSpan(list, 5);

        patternCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = list,
            StringFormat = "N0"
        });

        return new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto},
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition() { Width = GridLength.Auto },
                new ColumnDefinition() { Width = GridLength.Auto },
                new ColumnDefinition() { Width = GridLength.Auto },
                new ColumnDefinition(),
                new ColumnDefinition() { Width = GridLength.Auto }
            },
            Children = { sortToggle, queryBox, lengthToggle, buckwalterPop, patternCount, list }
        };
    }

    Grid getLeftGrid() {
        checkGroup = new CheckGroup() {
            FlowDirection = FlowDirection.LeftToRight,
            HorizontalAlignment = HorizontalAlignment.Left,
            Icons = new string[] { Icons.List, Icons.Tag, Icons.Sprout },
            Tips = new string[] { "flat", "tag", "root" }
        };

        morphCount = new TextBlockEnglish() {
            IsHitTestVisible = false,
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center
        };

        meaningCount = new TextBlockEnglish() {
            IsHitTestVisible = false,
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Right,
        };

        morphList = new ContentListBox() {
            Margin = new Thickness(0, 5, 0, 0),
            FlowDirection = FlowDirection.RightToLeft,
            Template = new ListBoxLedgerTemplate(),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(RootMorphListTemplate))
            }
        };
        var separatorHorizontal = new Rectangle() {
            VerticalAlignment = VerticalAlignment.Bottom,
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };

        var separatorVertical = new Rectangle() {
            Margin = new Thickness(5, 0, 5, 0),
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        var splitter = new GridSplitter() {
            ResizeDirection = GridResizeDirection.Rows,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Template = new SplitterTemplate()
        };

        morphList.SetValue(Grid.IsSharedSizeScopeProperty, true);
        morphList.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

        listMeaning = new ListBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 0, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MeaningListTemplate))
            }
        };
        listMeaning.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMeaning.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

        initializeTrees();

        Grid.SetRow(morphList, 1);
        Grid.SetRow(tagTree, 1);
        Grid.SetRow(rootTree, 1);

        Grid.SetRow(meaningCount, 2);
        Grid.SetRow(separatorHorizontal, 2);
        Grid.SetRow(splitter, 2);
        Grid.SetRow(listMeaning, 3);

        Grid.SetColumn(morphCount, 1);
        Grid.SetColumn(checkGroup, 1);

        Grid.SetColumn(morphList, 1);
        Grid.SetColumn(tagTree, 1);
        Grid.SetColumn(rootTree, 1);

        Grid.SetColumn(meaningCount, 1);
        Grid.SetColumn(separatorHorizontal, 1);
        Grid.SetColumn(splitter, 1);
        Grid.SetColumn(listMeaning, 1);

        Grid.SetRowSpan(separatorVertical, 4);

        meaningCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMeaning,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });

        return new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition()
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(2, GridUnitType.Star) },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { morphCount, checkGroup, morphList, tagTree, rootTree, separatorHorizontal, splitter, meaningCount, listMeaning, separatorVertical }
        };
    }

    void initializeTrees() {
        tagTree = new ContentTreeView() {
            Visibility = Visibility.Hidden,
            Template = new TreeViewLedgerTemplate()
        };
        rootTree = new ContentTreeView() {
            Visibility = Visibility.Hidden,
            Template = new TreeViewLedgerTemplate()
        };
        rootTree.SetValue(Grid.IsSharedSizeScopeProperty, true);
        tagTree.SetValue(Grid.IsSharedSizeScopeProperty, true);
    }

    void onListFired(object item) {
        var p = (UniquePattern)item;
        var selected = source.First(x => x.Pattern.Equals(p.Pattern) && x.Segmentation.Equals(p.Segmentation));
        // why so many select many?
        var references = selected.References.SelectMany(x => x.References.SelectMany(x => x.References)).ToList();
        references.Sort(new SurahAyahWordNoComparator());
        int linkIndex = 0, refIndex = 0;
        morphs = new List<RootMorph>();
        StringBuilder builder = new();
        do {
            while (!App.links[linkIndex].Reference.Equals(references[refIndex])) linkIndex++;
            morphs.Add(App.links[linkIndex].toRootMorph(builder));
            if (App.links[linkIndex].Root.Contains('|')) {
                // yabnaumma
                if (p.Pattern.Equals("+u+~")) {
                    morphs.Add(App.links[linkIndex].toRootMorph(builder, true));
                }
            }
            refIndex++;
        } while (refIndex < references.Count);

        var listSource = morphs
            .GroupBy(x => new {
                Word = x.Segments[App.global.Transcript],
                Root = x.Root,
                x.Explanation
            })
              .Select(x => new RootMorph() {
                  Segments = x.First().Segments,
                  Count = x.Count(),
                  Tags = x.First().Tags,
                  Root = x.Key.Root,
                  Tag = x.First().Tag,
                  Explanation = x.Key.Explanation,
                  References = x.SelectMany(x => x.References).ToList()
              })
              .OrderByDescending(x => x.Count)
              .ToList();

        morphList.ItemsSource = listSource;
        morphList.ScrollIntoView(listSource[0]);

        var rootSource = morphs.GroupBy(x => x.Root).ToList();
        var tagSource = morphs.GroupBy(x => x.Tag).ToList();

        rootTree.Items.Clear();
        tagTree.Items.Clear();

        foreach (var root in rootSource) {
            var items = root.GroupBy(x => new {
                Word = x.Segments[App.global.Transcript],
                x.Explanation
            })
              .Select(x => new RootMorph() {
                  Segments = x.First().Segments,
                  Count = x.Count(),
                  Tags = x.First().Tags,
                  Tag = x.First().Tag,
                  Explanation = x.Key.Explanation,
                  References = x.SelectMany(x => x.References).ToList()
              })
              .OrderByDescending(x => x.Count)
              .ToList();
            var refCount = items.Sum(x => x.References.Count);

            var leaf = new TreeViewItem() {
                Header = new Tuple<string, string>(root.Key, refCount + " in " + items.Count),
                HeaderTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(RootTreeHeaderTemplate))
                },
                ItemTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(RootTreeItemTemplate))
                },
                ItemsSource = items
            };
            rootTree.Items.Add(leaf);
        }

        foreach (var tag in tagSource) {
            var items = tag.GroupBy(x => new {
                Word = x.Segments[App.global.Transcript],
                Root = x.Root,
                x.Explanation
            })
              .Select(x => new RootMorph() {
                  Segments = x.First().Segments,
                  Count = x.Count(),
                  Tags = x.First().Tags,
                  Root = x.Key.Root,
                  Explanation = x.Key.Explanation,
                  References = x.SelectMany(x => x.References).ToList()
              })
              .OrderByDescending(x => x.Count)
              .ToList();
            var refCount = items.Sum(x => x.References.Count);

            var leaf = new TreeViewItem() {
                FlowDirection = FlowDirection.LeftToRight,
                Header = new Tuple<string, string>(tag.Key, refCount + " in " + items.Count),
                HeaderTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(TagTreeHeaderTemplate))
                },
                ItemTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(RootMorphListTemplate))
                },
                ItemsSource = items
            };
            tagTree.Items.Add(leaf);
        }

        count = listSource.Sum(x => x.Count);
        updateCount();
    }

    void onMorphFired(object item) => updateMeaning(item);

    void onRootFired(object item) => updateMeaning(item);

    void onTagFired(object item) => updateMeaning(item);

    void onCheckStateChanged(object? sender, EventArgs e) {
        if (checkGroup.Selected == 0) {
            tagTree.Fired -= onTagFired;
            rootTree.Fired -= onRootFired;
            morphList.Fired += onMorphFired;

            tagTree.Visibility = Visibility.Hidden;
            rootTree.Visibility = Visibility.Hidden;
            morphList.Visibility = Visibility.Visible;
        }
        else if (checkGroup.Selected == 1) {
            tagTree.Fired += onTagFired;
            rootTree.Fired -= onRootFired;
            morphList.Fired -= onMorphFired;

            rootTree.Visibility = Visibility.Hidden;
            morphList.Visibility = Visibility.Hidden;
            tagTree.Visibility = Visibility.Visible;
        }
        else {
            tagTree.Fired -= onTagFired;
            rootTree.Fired += onRootFired;
            morphList.Fired -= onMorphFired;

            morphList.Visibility = Visibility.Hidden;
            tagTree.Visibility = Visibility.Hidden;
            rootTree.Visibility = Visibility.Visible;
        }
        updateCount();
    }

    void onMeaningDoubleClick(object sender, MouseButtonEventArgs e) {
        if (listMeaning.SelectedItem is null) return; // can be null?
        var item = (Tuple<string, string, string>)listMeaning.SelectedItem;
        ((App)Application.Current).FocusedControl.addSurahPage(item.Item1);
    }

    void onQuery(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        query = queryBox.Text.Trim();
        patternView.Refresh();
    }

    void updateMeaning(object item) {
        if (item is not RootMorph morph) return;
        var meaningSource = morph.References;
        listMeaning.ItemsSource = meaningSource;
        listMeaning.ScrollIntoView(meaningSource[0]);
    }

    void updateCount() {
        var countStr = count.ToString("N0");
        morphCount.Text = checkGroup.Selected switch {
            0 => countStr + " in " + morphList.Items.Count.ToString("N0"),
            1 => countStr + " in " + tagTree.Items.Count.ToString("N0"),
            2 => countStr + " in " + rootTree.Items.Count.ToString("N0"),
        };
    }

    bool filter(object o) {
        if (string.IsNullOrEmpty(query)) return true;

        var pattern = ((UniquePattern)o).Pattern;
        return lengthToggle.IsOn ?
            pattern.Contains(query) :
            pattern.Equals(query);
    }

    void sort() {
        using (patternView.DeferRefresh()) {
            patternView.SortDescriptions.Clear();
            if (sortToggle.IsOn) {
                patternView.SortDescriptions.Add(new SortDescription(nameof(UniquePattern.RootCount), ListSortDirection.Descending));
            }
            else {
                patternView.SortDescriptions.Add(new SortDescription(nameof(UniquePattern.ReferenceCount), ListSortDirection.Descending));
            }
        }
    }

    protected override void unload() {
        tagTree.Fired -= onTagFired;
        rootTree.Fired -= onRootFired;
        list.Fired -= onListFired;
        morphList.Fired -= onMorphFired;
        listMeaning.MouseDoubleClick -= onMeaningDoubleClick;
        queryBox.KeyUp -= onQuery;
        groupStateDescriptor.RemoveValueChanged(checkGroup, onCheckStateChanged);
        base.unload();
    }

    class PatternGroup {
        public string Segmentation { get; set; }
        public string Pattern { get; set; }
        public List<RootForm> References { get; set; }
    }

    class UniquePattern {
        public string Pattern { get; set; }
        public string Segmentation { get; set; }
        public List<RootSegment> Segments { get; set; }
        public int RootCount { get; set; }
        public int ReferenceCount { get; set; }
    }

    class PatternTemplate : Grid {
        TextBlockArabic pattern;
        TextBlockEnglish rootCount, referenceCount;

        public PatternTemplate() {
            pattern = new TextBlockArabic();
            rootCount = new TextBlockEnglish() {
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            referenceCount = new TextBlockEnglish() {
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            SetColumn(rootCount, 1);
            SetColumn(referenceCount, 2);

            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(50) });
            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(50) });

            Children.Add(pattern);
            Children.Add(rootCount);
            Children.Add(referenceCount);

            Loaded += onLoaded;
            Unloaded += onUnloaded;
        }

        void onLoaded(object sender, RoutedEventArgs e) {
            App.global.PropertyChanged += onTatweelLengthChanged;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            App.global.PropertyChanged -= onTatweelLengthChanged;
        }

        void onTatweelLengthChanged(object? sender, PropertyChangedEventArgs e) {
            if (!e.PropertyName.Equals(nameof(App.global.TatweelLength))) return;
            pattern.Inlines.Clear();
            var c = (UniquePattern)DataContext;
            addSegments(c.Segments);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (UniquePattern)DataContext;
            addSegments(c.Segments);
            rootCount.Text = c.RootCount.ToString("N0");
            referenceCount.Text = c.ReferenceCount.ToString("N0");
        }

        void addSegments(List<RootSegment> Segments) {
            for (int i = 0; i < Segments.Count; i++) {
                Brush b = Segments[i].SegmentNo switch {
                    0 => Foregrounds.NonRoot,
                    1 => Foregrounds.R1,
                    2 => Foregrounds.R2,
                    3 => Foregrounds.R3,
                    4 => Foregrounds.R4
                };
                pattern.Inlines.Add(new Run() {
                    Foreground = b,
                    Text = Segments[i].IsRoot ?
                    (
                        PatternHelper.leadingTatweel +
                        Segments[i].Token.Replace("+", "") +
                        PatternHelper.trailingTatweel
                    ).toArabic()
                    : Segments[i].Token.toArabic()
                });
            }
        }
    }

    class RootMorphListTemplate : Grid {
        TextBlockArabic arabic, root;
        TextBlockEnglish explanation, count;

        public RootMorphListTemplate() {
            FlowDirection = FlowDirection.RightToLeft;
            arabic = new TextBlockArabic();
            root = new TextBlockArabic() {
                Foreground = Brushes.Gray,
                Margin = new Thickness(10, 0, 0, 0)
            };
            explanation = new TextBlockEnglish() {
                Margin = new Thickness(10, 0, 10, 0),
                FlowDirection = FlowDirection.LeftToRight,
                TextWrapping = TextWrapping.Wrap,
                VerticalAlignment = VerticalAlignment.Center
            };
            count = new TextBlockEnglish() {
                Foreground = Brushes.Gray,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right
            };

            SetColumn(root, 1);
            SetColumn(explanation, 2);
            SetColumn(count, 3);

            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col1" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col2" });
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col4" });

            Children.Add(arabic);
            Children.Add(root);
            Children.Add(explanation);
            Children.Add(count);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (RootMorph)DataContext;
            StringBuilder builder = new();
            explanation.Text = c.Explanation;
            count.Text = c.Count.ToString();
            root.Text = c.Root.toArabic();
            var segments = c.Segments[App.global.Transcript].Split('|');
            int index = 0;
            int pronCount, otherCount;
            pronCount = otherCount = 0;
            string lastPos = "";
            foreach (var segment in segments) {
                segment.toArabic(segments, builder);
                var run = new Run(builder.ToString());
                builder.Clear();

                var tag = App.tags[Convert.ToInt32(c.Tags[index])].Name;
                switch (tag) {
                    case "DET": run.Foreground = Foregrounds.DET_Brush; break;
                    case "V": run.Foreground = Foregrounds.V_Brush; break;
                    case "N":
                    case "PN":
                    case "ADJ": run.Foreground = Foregrounds.N_PN_ADJ_Brush; break;
                    case "REL":
                    case "DEM": run.Foreground = Foregrounds.DEM_REL_Brush; break;
                    case "P": run.Foreground = Foregrounds.P_Brush; break;
                    case "CONJ": run.Foreground = Foregrounds.CONJ_Brush; break;
                    case "INTG": run.Foreground = Foregrounds.INTG_Brush; break;
                    case "NEG": run.Foreground = Foregrounds.NEG_Brush; break;
                    case "PRON":
                        if (lastPos.Equals("PRON")) pronCount++;
                        if (pronCount == 1) run.Foreground = Foregrounds.PRON1_Brush;
                        else if (pronCount == 2) run.Foreground = Foregrounds.PRON2_Brush;
                        else run.Foreground = Foregrounds.PRON3_Brush;
                        break;
                    default:
                        if (!Foregrounds.Defined.Contains(lastPos)) otherCount++;
                        if (otherCount == 1) run.Foreground = Foregrounds.OTHER1_Brush;
                        else if (otherCount == 2) run.Foreground = Foregrounds.OTHER2_Brush;
                        else run.Foreground = Foregrounds.OTHER3_Brush;
                        break;
                }
                lastPos = tag;
                arabic.Inlines.Add(run);
                index++;
            }
        }
    }

    class RootTreeHeaderTemplate : Grid {
        TextBlockArabic root;
        TextBlockEnglish counts;

        public RootTreeHeaderTemplate() {
            root = new TextBlockArabic();
            counts = new TextBlockEnglish() {
                FlowDirection = FlowDirection.LeftToRight,
                VerticalAlignment = VerticalAlignment.Center
            };
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            SetColumn(counts, 1);
            Children.Add(root);
            Children.Add(counts);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Tuple<string, string>)DataContext;
            root.Text = c.Item1.toArabic();
            counts.Text = c.Item2;
        }
    }

    class RootTreeItemTemplate : Grid {
        TextBlockArabic arabic;
        TextBlockEnglish explanation, tag, count;

        public RootTreeItemTemplate() {
            arabic = new TextBlockArabic();
            tag = new TextBlockEnglish() {
                Margin = new Thickness(10, 10, 0, 0),
                FlowDirection = FlowDirection.LeftToRight,
            };
            explanation = new TextBlockEnglish() {
                Margin = new Thickness(10, 0, 10, 0),
                FlowDirection = FlowDirection.LeftToRight,
                TextWrapping = TextWrapping.Wrap,
                VerticalAlignment = VerticalAlignment.Center
            };
            count = new TextBlockEnglish() {
                Foreground = Brushes.Gray,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right
            };

            SetColumn(tag, 1);
            SetColumn(explanation, 2);
            SetColumn(count, 3);

            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col1" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col2" });
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col4" });

            Children.Add(arabic);
            Children.Add(tag);
            Children.Add(explanation);
            Children.Add(count);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (RootMorph)DataContext;
            StringBuilder builder = new();
            explanation.Text = c.Explanation;
            count.Text = c.Count.ToString();
            tag.Text = c.Tag;
            var segments = c.Segments[App.global.Transcript].Split('|');
            int index = 0;
            int pronCount, otherCount;
            pronCount = otherCount = 0;
            string lastPos = "";
            foreach (var segment in segments) {
                segment.toArabic(segments, builder);
                var run = new Run(builder.ToString());
                builder.Clear();

                var tag = App.tags[Convert.ToInt32(c.Tags[index])].Name;
                switch (tag) {
                    case "DET": run.Foreground = Foregrounds.DET_Brush; break;
                    case "V": run.Foreground = Foregrounds.V_Brush; break;
                    case "N":
                    case "PN":
                    case "ADJ": run.Foreground = Foregrounds.N_PN_ADJ_Brush; break;
                    case "REL":
                    case "DEM": run.Foreground = Foregrounds.DEM_REL_Brush; break;
                    case "P": run.Foreground = Foregrounds.P_Brush; break;
                    case "CONJ": run.Foreground = Foregrounds.CONJ_Brush; break;
                    case "INTG": run.Foreground = Foregrounds.INTG_Brush; break;
                    case "NEG": run.Foreground = Foregrounds.NEG_Brush; break;
                    case "PRON":
                        if (lastPos.Equals("PRON")) pronCount++;
                        if (pronCount == 1) run.Foreground = Foregrounds.PRON1_Brush;
                        else if (pronCount == 2) run.Foreground = Foregrounds.PRON2_Brush;
                        else run.Foreground = Foregrounds.PRON3_Brush;
                        break;
                    default:
                        if (!Foregrounds.Defined.Contains(lastPos)) otherCount++;
                        if (otherCount == 1) run.Foreground = Foregrounds.OTHER1_Brush;
                        else if (otherCount == 2) run.Foreground = Foregrounds.OTHER2_Brush;
                        else run.Foreground = Foregrounds.OTHER3_Brush;
                        break;
                }
                lastPos = tag;
                arabic.Inlines.Add(run);
                index++;
            }
        }
    }

    class TagTreeHeaderTemplate : Grid {
        TextBlockEnglish tag, counts;

        public TagTreeHeaderTemplate() {
            tag = new TextBlockEnglish();
            counts = new TextBlockEnglish();
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            SetColumn(counts, 1);
            Children.Add(tag);
            Children.Add(counts);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Tuple<string, string>)DataContext;
            tag.Text = c.Item1;
            counts.Text = c.Item2;
        }
    }
}
