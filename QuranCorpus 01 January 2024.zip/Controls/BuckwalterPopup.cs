﻿class BuckwalterPopup : ActionButton {
    PopupDraggable popup;

    public BuckwalterPopup() {
        Icon = Icons.Eye;
        ToolTip = "show transcript";
       
        var box = new ListBox() {
            Width = 300,
            Height = 300,
            Margin = new Thickness(0,5,0,0),
            ItemsSource = App.characters,
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(BoxTemplate))
            }
        };
        box.SetValue(Grid.IsSharedSizeScopeProperty, true);

        var close = new ActionButton() {
            HorizontalAlignment = HorizontalAlignment.Right,
            Icon = Icons.CloseCircle,
            Command = () => {
                Icon = Icons.Eye;
                ToolTip = "show transcript";
                popup.IsOpen = false;
            }
        };
        Grid.SetRow(box, 1);
        popup = new PopupDraggable() {
            Child = new Border() {
                Padding = new Thickness(5),
                CornerRadius = new CornerRadius(5),
                BorderThickness = new Thickness(Constants.BottomLineThickness),
                BorderBrush = Brushes.LightGray,
                Background = Constants.Background,
                Child = new Grid() {
                    RowDefinitions = {
                        new RowDefinition(){ Height = GridLength.Auto },
                        new RowDefinition()
                    },
                    Children = { close, box }
                }
            }
        };
    }

    protected override void OnPreviewMouseLeftButtonUp(MouseButtonEventArgs e) {
        base.OnPreviewMouseLeftButtonUp(e);
        if (popup.IsOpen) {
            Icon = Icons.Eye;
            ToolTip = "show transcript";
            popup.IsOpen = false;
        }
        else {
            Icon = Icons.EyeOff;
            ToolTip = "hide popup";
            popup.IsOpen = true;
        }
    }

    class BoxTemplate : Grid {
        TextBlockArabic arabic;
        TextBlockEnglish transcript, description;

        public BoxTemplate() {
            arabic = new TextBlockArabic() { HorizontalAlignment = HorizontalAlignment.Center };
            transcript = new TextBlockEnglish() {
                Margin = new Thickness(10, 0, 10, 0),
                HorizontalAlignment = HorizontalAlignment.Center,
                VerticalAlignment = VerticalAlignment.Center
            };
            description = new TextBlockEnglish() {
                HorizontalAlignment = HorizontalAlignment.Left,
                VerticalAlignment = VerticalAlignment.Center,
                Foreground = Brushes.Gray
            };

            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col1" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col1" });
            ColumnDefinitions.Add(new ColumnDefinition());

            SetColumn(transcript, 1);
            SetColumn(description, 2);

            Children.Add(arabic);
            Children.Add(transcript);
            Children.Add(description);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Character)DataContext;
            arabic.Text = c.English.ToString().toArabic();
            transcript.Text = c.English.ToString();
            description.Text = c.Description;
        }
    }
}
