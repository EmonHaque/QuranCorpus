﻿class RootWindow : Window
{
    double radius = 5;
    Border windowBorder;

    public RootWindow()
    {
        Height = 720;
        Width = 1280;
        WindowStartupLocation = WindowStartupLocation.CenterScreen;
        WindowStyle = WindowStyle.None;
        AllowsTransparency = true;

        WindowChrome.SetWindowChrome(this, new WindowChrome() {
            ResizeBorderThickness = new Thickness(5),
            CaptionHeight = 0
        });
        windowBorder = new Border() {
            Background = new SolidColorBrush(Color.FromRgb(70, 70, 70)),
            CornerRadius = new CornerRadius(radius),
            BorderThickness = new Thickness(0.75),
            BorderBrush = Brushes.LightGray,
        };
        AddVisualChild(windowBorder);
    }

    protected override void OnContentChanged(object oldContent, object newContent) {
        windowBorder.Child = (FrameworkElement)newContent;
    }
    protected override Visual GetVisualChild(int index) => windowBorder;
    protected override int VisualChildrenCount => 1;
}
