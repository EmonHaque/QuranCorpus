﻿class RootForm {
    public string Root { get; set; }
    public string Pattern { get; set; }
    public string Segmentation { get; set; }
    List<RootSegment> segments;
    public List<RootSegment> Segments {
        get { return segments; }
        set {
            segments = value;
            for (int i = 0; i < value.Count; i++) {
                Pattern += value[i].Token;
                Segmentation += value[i].IsRoot ?
                    value[i].SegmentNo + value[i].Token
                    : value[i].Token;
            }
        }
    }
    public int Count { get; set; }
    public string Tag { get; set; }
    public string SubTag { get; set; }
    public string Form { get; set; }
    public List<PatternReference> References { get; set; }
}
