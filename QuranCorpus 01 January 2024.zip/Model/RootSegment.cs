﻿class RootSegment {
    public string Token { get; set; }
    public int SegmentNo { get; set; }
    public bool IsRoot { get; set; }
}