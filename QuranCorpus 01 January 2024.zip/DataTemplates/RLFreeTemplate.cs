﻿class RLFreeTemplate : Grid {
    TextBlockArabic arabic;
    TextBlockEnglish count;

    public RLFreeTemplate()
    {
        arabic = new TextBlockArabic();
        count = new TextBlockEnglish() { VerticalAlignment = VerticalAlignment.Center };

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

        SetColumn(count, 1);

        Children.Add(arabic);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var item = (Lemma)DataContext;
        count.Text = item.References.Count.ToString("N0");
        /* 
         * this check is because RootLemmaLessVM groups items based on Transcript and one Transcripts
         * remains null, because some spelling completely vanish or reappear depending on the 
         * Transcript you choose, and it doesn't update underlying set until you go back to 
         * RootLemmaLessView after changing the Transcript. When you change Transcript and then 
         * change Arabic font, TextBlockArabic is triggered for font change and calls this function
         */
        int index = App.global.Transcript;
        if (item.Transcripts[App.global.Transcript] is null) {
            index = index == 1 ? 0 : 1;
        }
        arabic.Text = item.Transcripts[index].toArabic();
    }
}
