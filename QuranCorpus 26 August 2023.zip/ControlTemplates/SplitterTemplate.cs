﻿class SplitterTemplate : ControlTemplate {
    public SplitterTemplate() {
        TargetType = typeof(GridSplitter);
        var path = new FrameworkElementFactory(typeof(Path)) { Name = "path" };
        path.SetValue(Path.DataProperty, Geometry.Parse(Icons.SplitterHorizontal));
        path.SetValue(Path.FillProperty, Brushes.Gray);
        path.SetValue(Path.StretchProperty, Stretch.Uniform);
        path.SetValue(Path.HorizontalAlignmentProperty, HorizontalAlignment.Center);
        
        VisualTree = path;

        Triggers.Add(new Trigger() {
            Property = GridSplitter.IsMouseOverProperty,
            Value = true,
            Setters = {
                new Setter(Path.FillProperty, Brushes.CornflowerBlue, "path"),
            }
        });

        Triggers.Add(new Trigger() {
            Property = GridSplitter.ResizeDirectionProperty,
            Value = GridResizeDirection.Rows,
            Setters = {
                new Setter(GridSplitter.CursorProperty, Cursors.SizeNS)
            }
        });

        Triggers.Add(new Trigger() {
            Property = GridSplitter.ResizeDirectionProperty,
            Value = GridResizeDirection.Columns,
            Setters = {
                new Setter(Path.VerticalAlignmentProperty, VerticalAlignment.Center, "path"),
                new Setter(Path.DataProperty, Geometry.Parse(Icons.SplitterVertical), "path"),
                new Setter(GridSplitter.CursorProperty, Cursors.SizeWE)
            }
        });
    }
}
