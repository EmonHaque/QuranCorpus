﻿
class SurahAyahWordNoComparator : IComparer<string> {
    public int Compare(string? x, string? y) {
        int index1 = x.IndexOf(':');
        int index2 = y.IndexOf(':');
        var firstSurah = Convert.ToInt32(x.Substring(0, index1));
        var secondSurah = Convert.ToInt32(y.Substring(0, index2));

        if (firstSurah > secondSurah) return 1;
        else if (firstSurah < secondSurah) return -1;
        else {
            var rest1 = x.Substring(index1 + 1);
            var rest2 = y.Substring(index2 + 1);
            index1 = rest1.IndexOf(':');
            index2 = rest2.IndexOf(':');

            var firstAyah = Convert.ToInt32(rest1.Substring(0, index1));
            var secondAyah = Convert.ToInt32(rest2.Substring(0, index2));
            if (firstAyah > secondAyah) return 1;
            else if (firstAyah < secondAyah) return -1;
            else {
                var firstWord = Convert.ToInt32(rest1.Substring(index1 + 1));
                var secondWord = Convert.ToInt32(rest2.Substring(index2 + 1));

                if (firstWord > secondWord) return 1;
                else if (firstWord < secondWord) return -1;
                else return 0;
            }
        }
    }
}
