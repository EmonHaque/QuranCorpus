﻿class MultiTagView : CardView {
    public override string Icon => Icons.MultipleTags;
    public override string Header => "Multiple Tags";
    public override bool OverridesToolTip => true;
    public override UIElement Tip => getTip();

    CheckGroup checkGroup;
    TextBlockEnglish count;
    ListBox list;
    PageControl pages;
    MultiTagVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new MultiTagVM();
        DataContext = vm;
        pages = ((App)Application.Current).Pages;
        initilizeUI();
        bind();
        list.PreviewMouseRightButtonDown += onRightButtonDown;
        list.MouseRightButtonUp += onRightButtonUp;
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) {
        e.Handled = true;
        if (vm.Selected is null) return;
        if (!vm.Selected.IsSorted) {
            vm.Selected.References.Sort(new SurahAyahWordNoComparator());
            vm.Selected.IsSorted = true;
        }
        pages.addMatchPage(vm.Selected.Spelling, vm.Selected.References);
        if (vm.WasRightClicked) vm.WasRightClicked = false;
    }

    void onRightButtonDown(object sender, MouseButtonEventArgs e) => vm.WasRightClicked = true;

    void initilizeUI() {
        list = new ListBox() { 
            Margin = new Thickness(0,5,0,0),
            FlowDirection = FlowDirection.RightToLeft,
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(ListTemplate))
            }
        };
        list.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        list.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
        
        setContent(list);

        checkGroup = new CheckGroup() {
            Icons = new string[] { Icons.ABC, Icons.AB },
            Tips = new string[] { "Others", "N & ADJ" },
            Margin = new Thickness(0, 0, 5, 0)
        };
        count = new TextBlockEnglish();
        addActions(new UIElement[] { checkGroup, count });
    }

    void bind() {
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Items)));
        list.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.Selected)) { Mode = BindingMode.OneWayToSource });
        count.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = list,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        checkGroup.SetBinding(CheckGroup.SelectedProperty, new Binding(nameof(vm.SelectedCheck)) { Mode = BindingMode.OneWayToSource });
    }

    Grid getTip() {
        var header = new TextBlockEnglish() {
            Text = "Multiple Tags",
            FontWeight = FontWeights.Bold
        };
        var separator = new Rectangle() {
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var description = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Text = "See words which have multiple tags."
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(description, 2);
        return new Grid() {
            MaxWidth = 200,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(10) },
                new RowDefinition()
            },
            Children = { header, separator, description }
        };
    }

    class ListTemplate : Grid {
        TextBlockArabic word;
        TextBlockEnglish tags;

        public ListTemplate() {
            word = new TextBlockArabic();
            tags = new TextBlockEnglish() {
                Margin = new Thickness(10,0,0,0),
                FlowDirection = FlowDirection.LeftToRight,
                VerticalAlignment = VerticalAlignment.Center,
                TextWrapping = TextWrapping.Wrap
            };

            SetColumn(tags, 1);

            ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
            ColumnDefinitions.Add(new ColumnDefinition());

            Children.Add(word);
            Children.Add(tags);
        }
        public override void EndInit() {
            base.EndInit();
            var c = (MultiTag)DataContext;
            word.Text = c.Spelling.toArabic();
            tags.Text = c.Tags;
        }
    }
}
