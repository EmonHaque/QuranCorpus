﻿class WordView : View {
    public override string Icon => Icons.WorkPlace;
    public override bool OverridesToolTip => true;
    public override UIElement Tip => getTip();
    public override FrameworkElement container => grid;

    Grid grid;

    public WordView() {
        Margin = new Thickness(-7.5, 0, 0, 0);
        grid = new Grid();
        AddVisualChild(grid);
    }

    public override void OnFirstSight() {
        base.OnFirstSight();
        var root = new RootWordView();
        grid.Children.Add(new ViewContainer(NavPosition.BottomLeftVertical, NavOverlap.Left) {
            Children = {
                root,
                new LemmaView(),
                new RootLemmaLessView()
            }
        });
        root.OnFirstSight(); // is needed when the ViewContainer is not the initially selected view
    }

    Grid getTip() {
        var header = new TextBlockEnglish() { 
            Text = "Words", 
            FontWeight = FontWeights.Bold
        };
        var separator = new Rectangle() {
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var description = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Text = "See words with root, with lemma and without root and lemma."
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(description, 2);
        return new Grid() {
            MaxWidth = 200,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(10) },
                new RowDefinition()
            },
            Children = { header, separator, description }
        };
    }
}
