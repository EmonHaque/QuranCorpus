﻿class MoodVM : Notifiable {
    public int currentTranscript;
    List<ErabWordPrimary> words;
    List<MoodWord> source;
    public List<MoodWord> items;
    Tuple<string, int> selected;
    public Tuple<string, int> Selected {
        get { return selected; }
        set {
            if (value is null) {
                return;
            }
            if (value.Equals(selected)) return;

            selected = value;
            items = source.Where(x => x.Gender.Equals(value.Item1)).ToList();

            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }

            if (((App)Application.Current).Pages.SelectedPage is MoodPage page) {
                page.setContent(items);
            }
        }
    }
    public bool WasRightClicked { get; set; }
    public bool IsInProgress { get; set; }
    public List<Tuple<string, int>> Genders { get; set; }

    public MoodVM() {
        IsInProgress = true;
        Task.Run(() => {
            string impfIndex = App.details.IndexOf(App.details.First(x => x.Name.Equals("IMPF"))).ToString();
            words = new List<ErabWordPrimary>();
            for (int i = 0; i < App.links.Count; i++) {
                var t = App.links[i].Tags.Split('|').Select(x => App.tags[Convert.ToInt32(x)].Name).ToArray();
                bool hasIt = false;
                int index = 0;

                for (int j = 0; j < t.Length; j++) {
                    if (!t[j].Equals("V")) continue;
                    index = j;
                    var detail = App.links[i].Details.Split(',')[index].Split('|');
                    if (!detail.Contains(impfIndex)) continue;
                    hasIt = true;
                    break;
                }
                if (!hasIt) continue;

                var corpus = App.links[i].SegmentsCorpus.Split('|');
                var simple = App.links[i].SegmentsSimple.Split('|');

                if (App.links[i].Root.Contains('|')) {
                    var roots = App.links[i].Root.Split('|');
                    foreach (var root in roots) {
                        var w = new ErabWordPrimary() {
                            Spellings = new string[] {
                                App.spellings[Convert.ToInt32(App.links[i].SpellingGroupCorpus.Split('|')[index])],
                                App.spellings[Convert.ToInt32(App.links[i].SpellingGroupSimple.Split('|')[index])]
                            },
                            Segments = new string[] {
                                App.segments[Convert.ToInt32(corpus[index])],
                                App.segments[Convert.ToInt32(simple[index])]
                            },
                            Root = App.roots[Convert.ToInt32(root)],
                            Reference = App.links[i].Reference
                        };
                        setDetail(App.links[i].Details.Split(',')[index], w);
                        words.Add(w);
                        index++;
                    }
                }
                else {
                    var w = new ErabWordPrimary() {
                        Spellings = new string[] {
                                App.spellings[Convert.ToInt32(App.links[i].SpellingGroupCorpus.Split('|')[index])],
                                App.spellings[Convert.ToInt32(App.links[i].SpellingGroupSimple.Split('|')[index])]
                            },
                        Segments = new string[] {
                                App.segments[Convert.ToInt32(corpus[index])],
                                App.segments[Convert.ToInt32(simple[index])]
                            },
                        Root = string.IsNullOrEmpty(App.links[i].Root) ? "" : App.roots[Convert.ToInt32(App.links[i].Root)],
                        Reference = App.links[i].Reference
                    };
                    setDetail(App.links[i].Details.Split(',')[index], w);
                    words.Add(w);
                }
            }
            Regroup();
        });
    }

    public void Regroup() {
        if (!IsInProgress) {
            IsInProgress = true;
            Genders = null;
            OnPropertyChanged(nameof(Genders));
            OnPropertyChanged(nameof(IsInProgress));
        }
        Task.Run(() => {
            var x = words
                    .GroupBy(x => x.Root)
                    .Select(x => new { x.Key, Value = x.GroupBy(x => x.Spellings[App.global.Transcript]).ToList() })
                    .Select(x => new {
                        x.Key,
                        Value = x.Value.GroupBy(x => x.GroupBy(x => new { x.Gender, x.Erab }).ToList()).ToList()
                    })
                    .ToList();

            source = new List<MoodWord>();

            foreach (var root in x) {
                foreach (var spelling in root.Value) {
                    foreach (var item in spelling.Key) {
                        if (item.Key.Erab.Equals("Indicative")) {
                            foreach (var word in item) {
                                var match = source.Where(
                                    x => x.Gender.Equals(word.Gender) &&
                                    x.Root.Equals(word.Root) &&
                                    x.Spelling.Equals(word.Spellings[App.global.Transcript])).ToList();

                                if (match.Count == 0) {
                                    var w = new MoodWord() {
                                        Root = word.Root,
                                        Gender = word.Gender,
                                        Spelling = word.Spellings[App.global.Transcript],
                                        Indicative = word.Segments[App.global.Transcript]
                                    };
                                    w.References.Add(word.Reference);
                                    source.Add(w);
                                }
                                else {
                                    MoodWord w = null;
                                    bool hasIt = false;

                                    for (int i = 0; i < match.Count; i++) {
                                        if (string.IsNullOrEmpty(match[i].Indicative)) {
                                            hasIt = true;
                                            match[i].Indicative = word.Segments[App.global.Transcript];
                                            w = match[i];
                                            break;
                                        }
                                        if (!word.Segments[App.global.Transcript].Equals(match[i].Indicative)) continue;
                                        hasIt = true;
                                        w = match[i];
                                        break;
                                    }


                                    if (!hasIt) {
                                        w = new MoodWord() {
                                            Root = word.Root,
                                            Gender = word.Gender,
                                            Spelling = word.Spellings[App.global.Transcript],
                                            Indicative = word.Segments[App.global.Transcript]
                                        };
                                        w.References.Add(word.Reference);
                                        source.Add(w);
                                    }
                                    else w.References.Add(word.Reference);
                                }
                            }
                        }
                        else if (item.Key.Erab.Equals("Subjunctive")) {
                            foreach (var word in item) {
                                var match = source.Where(
                                    x => x.Gender.Equals(word.Gender) &&
                                    x.Root.Equals(word.Root) &&
                                    x.Spelling.Equals(word.Spellings[App.global.Transcript])).ToList();

                                if (match.Count == 0) {
                                    var w = new MoodWord() {
                                        Root = word.Root,
                                        Gender = word.Gender,
                                        Spelling = word.Spellings[App.global.Transcript],
                                        Subjunctive = word.Segments[App.global.Transcript]
                                    };
                                    w.References.Add(word.Reference);
                                    source.Add(w);
                                }
                                else {
                                    MoodWord w = null;
                                    bool hasIt = false;

                                    for (int i = 0; i < match.Count; i++) {
                                        if (string.IsNullOrEmpty(match[i].Subjunctive)) {
                                            hasIt = true;
                                            match[i].Subjunctive = word.Segments[App.global.Transcript];
                                            w = match[i];
                                            break;
                                        }
                                        if (!word.Segments[App.global.Transcript].Equals(match[i].Subjunctive)) continue;
                                        hasIt = true;
                                        w = match[i];
                                        break;
                                    }

                                    if (!hasIt) {
                                        w = new MoodWord() {
                                            Root = word.Root,
                                            Gender = word.Gender,
                                            Spelling = word.Spellings[App.global.Transcript],
                                            Subjunctive = word.Segments[App.global.Transcript]
                                        };
                                        w.References.Add(word.Reference);
                                        source.Add(w);
                                    }
                                    else w.References.Add(word.Reference);
                                }
                            }
                        }
                        else {
                            foreach (var word in item) {
                                var match = source.Where(
                                     x => x.Gender.Equals(word.Gender) &&
                                     x.Root.Equals(word.Root) &&
                                     x.Spelling.Equals(word.Spellings[App.global.Transcript])).ToList();

                                if (match.Count == 0) {
                                    var w = new MoodWord() {
                                        Root = word.Root,
                                        Gender = word.Gender,
                                        Spelling = word.Spellings[App.global.Transcript],
                                        Jussive = word.Segments[App.global.Transcript]
                                    };
                                    w.References.Add(word.Reference);
                                    source.Add(w);
                                }
                                else {
                                    MoodWord w = null;
                                    bool hasIt = false;
                                    for (int i = 0; i < match.Count; i++) {
                                        if (string.IsNullOrEmpty(match[i].Jussive)) {
                                            hasIt = true;
                                            match[i].Jussive = word.Segments[App.global.Transcript];
                                            w = match[i];
                                            break;
                                        }
                                        if (!word.Segments[App.global.Transcript].Equals(match[i].Jussive)) continue;
                                        hasIt = true;
                                        w = match[i];
                                        break;
                                    }

                                    if (!hasIt) {
                                        w = new MoodWord() {
                                            Root = word.Root,
                                            Gender = word.Gender,
                                            Spelling = word.Spellings[App.global.Transcript],
                                            Jussive = word.Segments[App.global.Transcript]
                                        };
                                        source.Add(w);
                                    }
                                    w.References.Add(word.Reference);
                                }
                            }
                        }
                    }
                }
            }

            currentTranscript = App.global.Transcript;
            IsInProgress = false;
            Genders =
               source.GroupBy(x => x.Gender)
               .Select(x => new Tuple<string, int>(x.Key, x.Count()))
               .ToList();

            App.Current.Dispatcher.Invoke(() => {
                OnPropertyChanged(nameof(Genders));
                OnPropertyChanged(nameof(IsInProgress));
            });
        });
    }

    void setDetail(string detail, ErabWordPrimary word) {
        if (string.IsNullOrEmpty(detail)) {
            word.Gender = "Undefined";
            word.Erab = "";
            return;
        }
        var array = detail.Split('|').Select(x => App.details[Convert.ToInt32(x)]).ToArray();

        for (int i = 0; i < array.Length; i++) {
            if (array[i].Name.Equals("IMPF") ||
                array[i].Name.Equals("PASS") ||
                array[i].Name.Equals("IMPV") ||
                array[i].Name.Equals("PERF") ||
                array[i].Name.StartsWith("(") ||
                array[i].Name.Equals("SP:kaAn") ||
                array[i].Name.Equals("SP:kaAd") ||
                array[i].Name.Equals("INDEF")) continue;

            if (array[i].Name.Equals("SUBJ")) word.Erab = "Subjunctive";
            else if (array[i].Name.Equals("JUS")) word.Erab = "Jussive";
            else if (array[i].Name.Equals("JUSS")) word.Erab = "Jussive";
            else word.Gender = Helper.getGender(array[i].Name).Name;
        }

        if (string.IsNullOrEmpty(word.Gender)) word.Gender = "Undefined";
        if (string.IsNullOrEmpty(word.Erab)) word.Erab = "Indicative";
    }
}
