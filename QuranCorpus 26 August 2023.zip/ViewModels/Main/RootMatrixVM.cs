﻿class RootMatrixVM : Notifiable {
    public List<Form> roots;
    List<string> strong = new(), waBegin = new(), waMiddle = new(),
        waEnd = new(), ya = new(), doubleWeak = new(), quad = new();

    string selected;
    public string Selected {
        get { return selected; }
        set {
            if (value is null) return;
            if (!value.Equals(selected)) {
                selected = value;
            }
            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).Pages.SelectedPage is RootMatrixPage page) {
                page.setContent(value, roots);
            }
        }
    }

    string query;
    public string Query {
        get { return query; }
        set { 
            query = value; 
            Items?.Refresh(); 
        }
    }

    public bool WasRightClicked { get; set; }
    public ICollectionView Items { get; set; }
    public List<TagCount.TagItem> tags1;
    public List<TagCount.TagItem> tags2;

    public RootMatrixVM() {
        roots = new List<Form>();
        for (int i = 0; i < App.links.Count; i++) {
            if (string.IsNullOrEmpty(App.links[i].Root)) continue;

            var index = Convert.ToInt32(App.links[i].RootIndex);
            var parts = App.links[i].Root.Split('|');
            var corpus = App.links[i].SpellingGroupCorpus.Split('|');
            var simple = App.links[i].SpellingGroupSimple.Split('|');
            var tags = App.links[i].Tags.Split('|');
            var details = App.links[i].Details.Split(',');

            if (App.links[i].Root.Contains('|')) {
                for (int j = 0; j < parts.Length; j++) {
                    var form = new Form() {
                        Root = App.roots[Convert.ToInt32(parts[j])],
                        Tag = App.tags[Convert.ToInt32(tags[index])].Name,
                        Spellings = new string[] {
                            App.spellings[Convert.ToInt32(corpus[index])],
                            App.spellings[Convert.ToInt32(simple[index])]
                        },
                        Detail = string.IsNullOrEmpty(details[index]) ? "" : details[index]
                    };
                    roots.Add(form);
                    index++;
                }
            }
            else {
                var form = new Form() {
                    Root = App.roots[Convert.ToInt32(App.links[i].Root)],
                    Tag = App.tags[Convert.ToInt32(tags[index])].Name,
                    Spellings = new string[] {
                        App.spellings[Convert.ToInt32(corpus[index])],
                        App.spellings[Convert.ToInt32(simple[index])]
                    },
                    Detail = string.IsNullOrEmpty(details[index]) ? "" : details[index]
                };
                roots.Add(form);
            }
        }

        int triCount = 0;
        int quadCount = 0;
        int waBeginCount = 0;
        int waEndCount = 0;
        int yaCount = 0;
        int waMiddleCount = 0;
        int doubleWeakCount = 0;
        int strongCount = 0;

        for (int i = 0; i < roots.Count; i++) {
            var item = roots[i];
            if (item.Root.Length > 3) {
                if (quad.Contains(item.Root)) continue;
                quad.Add(item.Root);
                quadCount++;
            }
            else {
                if (item.Root.Contains('w') && item.Root.Contains('y')) {
                    if (doubleWeak.Contains(item.Root)) continue;
                    doubleWeak.Add(item.Root);
                    doubleWeakCount++;
                    triCount++;
                }
                else {

                    if (item.Root.StartsWith('w')) {
                        if (waBegin.Contains(item.Root)) continue;
                        waBegin.Add(item.Root);
                        waBeginCount++;
                        triCount++;
                    }
                    else if (item.Root.EndsWith('w')) {
                        if (waEnd.Contains(item.Root)) continue;
                        waEnd.Add(item.Root);
                        waEndCount++;
                        triCount++;
                    }
                    else if (item.Root.Contains('w')) {
                        if (waMiddle.Contains(item.Root)) continue;
                        waMiddle.Add(item.Root);
                        waMiddleCount++;
                        triCount++;
                    }
                    else if (item.Root.Contains('y')) {
                        if (ya.Contains(item.Root)) continue;
                        ya.Add(item.Root);
                        yaCount++;
                        triCount++;
                    }
                    else {
                        if (strong.Contains(item.Root)) continue;
                        strong.Add(item.Root);
                        strongCount++;
                        triCount++;
                    }
                }
            }
        }

        tags1 = new List<TagCount.TagItem>() {
            new TagCount.TagItem(){ Name = "triliteral", Count = triCount },
            new TagCount.TagItem(){ Name = "quadriliteral", Count = quadCount }
        };

        tags2 = new List<TagCount.TagItem>() {
            new TagCount.TagItem(){ Name = "strong", Count = strongCount },
            new TagCount.TagItem(){ Name = "w+", Count = waBeginCount },
            new TagCount.TagItem(){ Name = "+w+", Count = waMiddleCount },
            new TagCount.TagItem(){ Name = "+w", Count = waEndCount },
            new TagCount.TagItem(){ Name = "ya", Count = yaCount },
            new TagCount.TagItem(){ Name = "wy", Count = doubleWeakCount }
        };

        Items = CollectionViewSource.GetDefaultView(strong);
        Items.Filter = filter;

        OnPropertyChanged(nameof(Items));

    }

    public void resetSource(TagCount.TagItem first, TagCount.TagItem second) {
        List<string> source = null;
        if (first is null) {
            source = second.Name switch {
                "strong" => strong,
                "w+" => waBegin,
                "+w+" => waMiddle,
                "+w" => waEnd,
                "ya" => ya,
                "wy" => doubleWeak
            };
        }
        else {
            if (first.Name.StartsWith('q')) source = quad;
            else {
                source = second.Name switch {
                    "strong" => strong,
                    "w+" => waBegin,
                    "+w+" => waMiddle,
                    "+w" => waEnd,
                    "ya" => ya,
                    "wy" => doubleWeak
                };
            }
        }
        Items = CollectionViewSource.GetDefaultView(source);
        Items.Filter = filter;
        OnPropertyChanged(nameof(Items));
    }

    bool filter(object o) {
        return string.IsNullOrEmpty(Query) ? true :
            o.ToString().Contains(query);
    }
}