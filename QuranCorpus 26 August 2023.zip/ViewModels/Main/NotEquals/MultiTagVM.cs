﻿class MultiTagVM : Notifiable {
    List<MultiTag> nounsAndAdjectives, others;
    public int SelectedCheck {
        set {
            if (others is null) return;
            Items = value == 0 ? others : nounsAndAdjectives;
            OnPropertyChanged(nameof(Items));
        }
    }

    public MultiTag Selected { get; set; }
    public bool WasRightClicked { get; set; }
    public List<MultiTag> Items { get; set; }

    public MultiTagVM() {
        Task.Run(() => {
            List<Tuple<string, string, string>> list = new();

            for (int i = 0; i < App.links.Count; i++) {
                var link = App.links[i];
                var ts = link.Tags.Split('|');
                var ss = link.SpellingGroupSimple.Split('|');
                for (int j = 0; j < ts.Length; j++) {
                    list.Add(new Tuple<string, string, string>(
                        App.tags[Convert.ToInt32(ts[j])].Name,
                        App.spellings[Convert.ToInt32(ss[j])],
                        link.Reference));
                }
            }

            var groups = list
                .GroupBy(x => x.Item2)
                .Select(x => new {
                    x.Key,
                    Value = x.GroupBy(x => x.Item1).Where(x => x.Count() > 1).ToList()
                })
                .Where(x => x.Value.Count > 1)
                .Select(x => new {
                    x.Key,
                    Value = x.Value.Select(x => new {
                        x.Key,
                        Value = x.Select(x => x.Item3).ToList()
                    }).ToList()
                }).ToList();

            var x = groups.Where(
                x => x.Value.Count == 2 &&
                (x.Value[0].Key.Equals("N") || x.Value[0].Key.Equals("ADJ")) &&
                x.Value[1].Key.Equals("N") || x.Value[1].Key.Equals("ADJ"))
                .ToList();

            var y = groups.Except(x).ToList();

            nounsAndAdjectives = x.Select(x => new MultiTag() {
                Spelling = x.Key,
                Tags = string.Join(", ", x.Value.Select(x => x.Key)),
                References = x.Value.SelectMany(x => x.Value).ToList()
            }).ToList();

            others = y.Select(x => new MultiTag() {
                Spelling = x.Key,
                Tags = string.Join(", ", x.Value.Select(x => x.Key)),
                References = x.Value.SelectMany(x => x.Value).ToList()
            }).ToList();

            App.Current.Dispatcher.Invoke(() => {
                Items = others;
                OnPropertyChanged(nameof(Items));
            });
        });
    }
}

class MultiTag {
    public string Spelling { get; set; }
    public string Tags { get; set; }
    public bool IsSorted { get; set; }
    public List<string> References { get; set; }
}
