﻿class SurahPage : Page {
    Grid content;
    WaterBox queryBox;
    TextBlock gotoBlock, count;
    TextBox gotoBox;
    Translators translators;
    DragListBox ayahListBox;
    ProgressBar progress;
    ContextPopup copyAyahContext, copyWordContext;
    MultiState searchState;
    CancellationTokenSource terminator;
    DependencyPropertyDescriptor translatorDescriptor;
    List<Ayah> ayahs;
    int currentSurah, matchCount;
    string[] selectedTranslators;

    public override PageType Type => PageType.Surah;
    public override UIElement Content => content;

    public SurahPage() {
        terminator = new CancellationTokenSource();
        queryBox = new WaterBox() {
            Hint = "Search (arabic)",
            Icon = Icons.Search,
            IsArabic = true,
            Visibility = Visibility.Collapsed
        };
        count = new TextBlock() {
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(7, 0, 7, 0)
        };
        gotoBlock = new TextBlock() {
            Text = "go to: ",
            VerticalAlignment = VerticalAlignment.Bottom
        };
        gotoBox = new TextBox() {
            TextAlignment = TextAlignment.Right,
            VerticalContentAlignment = VerticalAlignment.Bottom,
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness)
        };

        searchState = new MultiState() {
            Height = 12,
            Icons = new string[] { Icons.MagnifyPlus, Icons.MagnifyMinus },
            ToolTip = "Local search",
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(0, 0, 7, 0)
        };
        var globalSearch = new ActionButton() {
            Icon = Icons.SearchGlobal,
            ToolTip = "Global search",
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(0, 0, 7, 0),
            Command = () => ((App)Application.Current).Pages.addSearchPage()
        };

        translators = new Translators() {
            FlowDirection = FlowDirection.LeftToRight,
            HorizontalAlignment = HorizontalAlignment.Left,
            VerticalAlignment = VerticalAlignment.Bottom
        };
        Grid.SetColumn(count, 1);
        Grid.SetColumn(gotoBlock, 2);
        Grid.SetColumn(gotoBox, 3);

        Grid.SetColumn(searchState, 4);
        Grid.SetColumn(globalSearch, 5);
        Grid.SetColumn(translators, 6);
        var toolGrid = new Grid() {
            Margin = new Thickness(3, 0, 0, 10),
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width =  GridLength.Auto },
                new ColumnDefinition(){ Width = new GridLength(50) },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { queryBox, gotoBlock, gotoBox, searchState, globalSearch, count, translators }
        };
        ayahListBox = new DragListBox() {
            FlowDirection = FlowDirection.RightToLeft,
            ItemTemplate = new AyahTemplate()
        };
        ayahListBox.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        ayahListBox.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
        //ayahListBox.SetValue(ScrollViewer.IsDeferredScrollingEnabledProperty, true);

        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };
        Grid.SetRow(toolGrid, 1);
        Grid.SetRow(ayahListBox, 2);
        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, toolGrid, ayahListBox }
        };

        copyAyahContext = new ContextPopup(new List<ContextItem>() {
            new ContextItem(){ Icon = Icons.CopyArabic, Text = "copy arabic", Command = copyArabic },
            new ContextItem(){ Icon = Icons.CopyEnglish, Text = "copy english", Command = copyEnglish },
            new ContextItem(){ Icon = Icons.Copy, Text = "copy both", Command = copyBoth },
        });

        copyWordContext = new ContextPopup(new List<ContextItem>() {
            new ContextItem(){ Icon = Icons.CopyArabic, Text = "copy word(s)", Command = copyWord }
        });

        translatorDescriptor = DependencyPropertyDescriptor.FromProperty(Translators.SelectedProperty, typeof(Translators));
        translatorDescriptor.AddValueChanged(translators, onTranslationChanged);

        queryBox.KeyUp += onQuery;
        ayahListBox.MouseRightButtonUp += onRightMouseUp;
        searchState.MouseLeftButtonUp += onLeftClick;
        gotoBox.KeyUp += onGoto;
        selectedTranslators = translators.Selected;
    }

    public SurahPage(int surahNo) : this() {
        currentSurah = surahNo;
        HeaderText = surahNo + ") " + App.surahs.First(x => x.Id == surahNo).Transliteration;
        progress.IsIndeterminate = true;
        Task.Run(() => {
            ayahs = getAyahs(surahNo);
            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    ayahListBox.ItemsSource = ayahs;
                    count.Text = ayahs.Count + " ayah,";
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    public SurahPage(string reference) : this() => goToSurah(reference);

    public void setContent(int surahNo) {
        currentSurah = surahNo;
        HeaderText = surahNo + ") " + App.surahs.First(x => x.Id == surahNo).Transliteration;
        progress.IsIndeterminate = true;
        Task.Run(() => {
            ayahs = getAyahs(surahNo);
            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    gotoBox.Text = "";
                    ayahListBox.ItemsSource = ayahs;
                    count.Text = ayahs.Count + " ayah,";
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    void onQuery(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;

        if (string.IsNullOrWhiteSpace(queryBox.Text)) {
            if (ayahListBox.ItemsSource.Equals(ayahs)) return;

            for (int i = 0; i < ayahs.Count; i++) {
                for (int j = 0; j < ayahs[i].Words.Count; j++) {
                    ayahs[i].Words[j].IsHighlighted = false;
                }
            }

            count.Text = ayahs.Count.ToString();
            ayahListBox.ItemsSource = ayahs;
            count.Text = ayahs.Count + " ayah,";
            return;
        }

        var query = queryBox.Text.Trim();
        progress.IsIndeterminate = true;

        Task.Run(() => {
            List<Ayah> newList = new();
            StringBuilder builder = new();
            matchCount = 0;

            for (int i = 0; i < ayahs.Count; i++) {
                if (terminator.IsCancellationRequested) break;
                for (int j = 0; j < ayahs[i].Words.Count; j++) {

                    ayahs[i].Words[j].IsHighlighted = false;

                    var segments = ayahs[i].Words[j].Segments[App.global.Transcript].Split('|');
                    for (int k = 0; k < segments.Length; k++) {
                        segments[k].toArabic(segments, builder);
                    }
                    builder.Append(' ');
                }
                var ayah = builder.ToString();
                builder.Clear();

                if (ayah.Contains(query)) {
                    newList.Add(ayahs[i]);
                    var parts = query.Split(' ');
                    var words = ayah.Split(' ');
                    int count = 0;

                    if (parts.Length > 1) {
                        while (count < words.Length) {
                            while (!words[count].EndsWith(parts[0], StringComparison.Ordinal)) {
                                count++;
                                if (count == words.Length) break;
                            }
                            if (count == words.Length) break;

                            int index = count + 1;
                            int length = count + parts.Length - 1;
                            bool isMatch = true;
                            int partIndex = 1;
                            for (int j = index; j < length; j++) {
                                if (words[j].Equals(parts[partIndex++])) continue;
                                isMatch = false;
                                break;
                            }
                            if (isMatch) {
                                if (words[length].StartsWith(parts[parts.Length - 1], StringComparison.Ordinal)) {
                                    length++;
                                    for (int j = count; j < length; j++) {
                                        ayahs[i].Words[j].IsHighlighted = true;
                                    }
                                    matchCount++;
                                }
                            }
                            count += parts.Length;
                        }
                    }
                    else {
                        for (int j = 0; j < words.Length; j++) {
                            var word = words[j];
                            if (!words[j].Contains(query, StringComparison.Ordinal)) continue;
                            ayahs[i].Words[j].IsHighlighted = true;
                            matchCount++;
                        }
                    }
                }
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    ayahListBox.ItemsSource = newList;
                    count.Text = matchCount.ToString("N0") + " matches in " + newList.Count + " ayah";
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    void onGoto(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        var reference = gotoBox.Text.Trim();
        if (reference.Contains(':')) {
            var parts = reference.Split(':');
            if (parts.Length != 2) return;

            var isParsed = int.TryParse(parts[0], out int surah);
            if (!isParsed) return;
            if (surah < 1 || surah > 114) return;

            isParsed = int.TryParse(parts[1], out int ayah);
            if (!isParsed) return;
            if (ayah < 1 || ayah > App.surahs[surah - 1].Verses) return;

            if (currentSurah == surah) gotoAyah(ayah.ToString());
            else goToSurah(reference);
        }
        else {
            var isParsed = int.TryParse(reference, out int ayah);
            if (!isParsed) return;
            if (ayah < 1 || ayah > ayahs.Count) return;
            gotoAyah(ayah.ToString());
        }
    }

    void goToSurah(string reference) {
        var parts = reference.Split(':');
        int surah = Convert.ToInt32(parts[0]);
        int ayah = Convert.ToInt32(parts[1]);
        HeaderText = surah + ") " + App.surahs.First(x => x.Id == surah).Transliteration;
        progress.IsIndeterminate = true;

        Task.Run(() => {
            ayahs = getAyahs(surah);

            if (parts.Length == 3) {
                ayahs.First(x => x.SurahNo.Equals(parts[0]) && x.AyahNo.Equals(parts[1]))
                    .Words.First(x => x.Reference.Equals(reference))
                    .IsHighlighted = true;
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    count.Text = ayahs.Count + " ayah";
                    ayahListBox.ItemsSource = ayahs;
                    ayahListBox.SelectedItem = ayahs[ayah - 1];
                    // to get to the point in ayahListBox first you've to ScrollIntoView
                    // in DispatcherTimer or LayoutUpdated handler and then BringIntoView
                    // otherwise it doesn't work when ScrollUnit.Pixel is set
                    // and all these have to be in an InvokeAsync block
                    // otherwise it doesn't update the layout properly
                    // why is it so?
                    ayahListBox.LayoutUpdated += onLayoutUpdated;
                    //var timer = new DispatcherTimer();
                    //timer.Interval = new TimeSpan(0, 0, 0, 0, 250);
                    //timer.Tick += onTicked;
                    //timer.Start();
                });
            }
        }, terminator.Token);
    }

    void gotoAyah(string ayah) {
        foreach (var item in ayahListBox.Items) {
            if (!((Ayah)item).AyahNo.Equals(ayah)) continue;
            ayahListBox.SelectedItem = item;
            ayahListBox.ScrollIntoView(ayahListBox.SelectedItem);
            break;
        }
    }

    void onLeftClick(object sender, MouseButtonEventArgs e) {
        if (searchState.State == 1) {
            queryBox.Visibility = Visibility.Visible;
            searchState.ToolTip = "Hide search box";
        }
        else {
            queryBox.Visibility = Visibility.Collapsed;
            searchState.ToolTip = "Local search";
        }
    }

    void onRightMouseUp(object sender, MouseButtonEventArgs e) {
        if (ayahListBox.SelectedItems.Count == 0) return;
        bool wordsSelected = false;
        if (ayahListBox.SelectedItems.Count == 1) {
            var ayah = (Ayah)ayahListBox.SelectedItem;
            for (int i = 0; i < ayah.Words.Count; i++) {
                if (!ayah.Words[i].IsHighlighted) continue;
                wordsSelected = true;
                break;
            }
        }
        if (wordsSelected) copyWordContext.IsOpen = true;
        else copyAyahContext.IsOpen = true;
    }

    void onLayoutUpdated(object? sender, EventArgs e) {
        ayahListBox.LayoutUpdated -= onLayoutUpdated;
        App.Current.Dispatcher.InvokeAsync(() => {
            ayahListBox.ScrollIntoView(ayahListBox.SelectedItem);
            var panel = Helper.FindVisualChild<VirtualizingStackPanel>(ayahListBox);
            var items = Helper.FindVisualChildren<ListBoxItem>(panel);
            var selected = Convert.ToInt32(((Ayah)ayahListBox.SelectedItem).AyahNo);

            foreach (var item in items) {
                var presenter = Helper.FindVisualChild<ContentPresenter>(item);
                var ayah = (Ayah)presenter.Content;
                if (Convert.ToInt32(ayah.AyahNo) == selected) {
                    presenter.BringIntoView();
                    break;
                }
            }
            progress.IsIndeterminate = false;
        }, DispatcherPriority.Background);
    }

    void onTranslationChanged(object? sender, EventArgs e) {
        selectedTranslators = translators.Selected;
        updateTranslation(Convert.ToInt32(ayahs.First().SurahNo));

        if (ayahListBox.SelectedItems.Count == 0 || ayahListBox.SelectedItems.Count > 1) return;
        ayahListBox.ScrollIntoView(ayahListBox.SelectedItem);
    }

    //void onTicked(object? sender, EventArgs e) {
    //    var timer = (DispatcherTimer)sender;
    //    timer.Tick -= onTicked;
    //    timer.Stop();

    //    App.Current.Dispatcher.InvokeAsync(() => {
    //        ayahListBox.ScrollIntoView(ayahListBox.SelectedItem);

    //        var panel = Helper.FindVisualChild<VirtualizingStackPanel>(ayahListBox);
    //        var items = Helper.FindVisualChildren<ListBoxItem>(panel);
    //        var selected = Convert.ToInt32(((Ayah)ayahListBox.SelectedItem).AyahNo);

    //        foreach (var item in items) {
    //            var presenter = Helper.FindVisualChild<ContentPresenter>(item);
    //            var ayah = (Ayah)presenter.Content;
    //            if (Convert.ToInt32(ayah.AyahNo) == selected) {
    //                presenter.BringIntoView();
    //                break;
    //            }
    //        }
    //        progress.IsIndeterminate = false;
    //    }, DispatcherPriority.Background);
    //}

    List<Ayah> getAyahs(int surahNo) {
        var words = new List<Word>();
        string lastAyah = "";

        foreach (var item in App.links) {
            if (terminator.IsCancellationRequested) break;

            var refs = item.Reference.Split(':');

            int no = Convert.ToInt32(refs[0]);
            if (no > surahNo) break;
            if (no < surahNo) continue;

            lastAyah = refs[1];

            words.Add(new Word() {
                Reference = item.Reference,
                Transliteration = App.transliterations[Convert.ToInt32(item.Transliteration)],
                Tags = item.Tags,
                Segments = Helper.getSegments(item),
                Lemmas = Helper.getLemmas(item),
                LemmaIndices = item.LemmaIndices,
                Spellings = Helper.getSpellings(item),
                Meaning = App.meanings[Convert.ToInt32(item.Meaning)],
                Explanation = item.Explanation,
                Root = item.Root,
                RootIndex = item.RootIndex,
                Details = item.Details
            });
        }

        var list = new List<Ayah>();

        IEnumerator<string>[] iterators = null;
        int[] translatorIds = null;

        if (selectedTranslators.Length > 0) {
            iterators = new IEnumerator<string>[selectedTranslators.Length];
            translatorIds = new int[selectedTranslators.Length];
            var translatorNames = App.global.TranslationDictionary.Keys.ToList();

            int index = 0;
            foreach (var item in selectedTranslators) {
                var file = App.global.TranslationDictionary[item];
                var lines = System.IO.File.ReadLines("Resources/Tanzil/" + file);
                var iterator = lines.GetEnumerator();
                iterator.MoveNext();
                while (!iterator.Current.StartsWith(surahNo + "|")) iterator.MoveNext();
                iterators[index] = iterator;
                translatorIds[index] = translatorNames.IndexOf(item);
                index++;
            }
        }

        string line = "";
        var parts = new string[3];
        int ayahCount = Convert.ToInt32(lastAyah);

        if (selectedTranslators.Length > 0) {
            for (int i = 0; i < ayahCount; i++) {
                var translations = new Translations[iterators.Length];

                for (int j = 0; j < iterators.Length; j++) {
                    line = iterators[j].Current;
                    parts = line.Split('|');

                    translations[j] = new Translations() {
                        TranslatorId = translatorIds[j],
                        Content = parts[2]
                    };
                    iterators[j].MoveNext();
                }

                var ayahNo = parts[1];
                list.Add(new Ayah() {
                    SurahNo = parts[0],
                    AyahNo = parts[1],
                    Translations = translations,
                    Words = words.Where(x => x.Reference.Contains(":" + ayahNo + ":")).ToList()
                });
            }
            foreach (var iterator in iterators) iterator.Dispose();
        }
        else {
            for (int i = 0; i < ayahCount; i++) {
                var ayahNo = (i + 1).ToString();
                list.Add(new Ayah() {
                    SurahNo = surahNo.ToString(),
                    AyahNo = ayahNo,
                    Words = words.Where(x => x.Reference.Contains(":" + ayahNo + ":")).ToList()
                });
            }
        }

        return list;
    }

    void updateTranslation(int surahNo) {
        if (selectedTranslators.Length == 0) {
            for (int i = 0; i < ayahs.Count; i++) {
                ayahs[i].Translations = null;
                ayahs[i].OnPropertyChanged(nameof(Ayah.Translations));
            }
            return;
        }

        //it'll read all selected files always

        var iterators = new IEnumerator<string>[selectedTranslators.Length];
        var translatorIds = new int[selectedTranslators.Length];
        var liranslatorsName = App.global.TranslationDictionary.Keys.ToList();

        int index = 0;
        foreach (var item in selectedTranslators) {
            var file = App.global.TranslationDictionary[item];
            var lines = System.IO.File.ReadLines("Resources/Tanzil/" + file);
            var iterator = lines.GetEnumerator();
            iterator.MoveNext();
            while (!iterator.Current.StartsWith(surahNo + "|")) iterator.MoveNext();
            iterators[index] = iterator;
            translatorIds[index] = liranslatorsName.IndexOf(item);
            index++;
        }

        for (int i = 0; i < ayahs.Count; i++) {
            var translations = new Translations[iterators.Length];

            for (int j = 0; j < iterators.Length; j++) {
                var line = iterators[j].Current;
                var parts = line.Split('|');

                translations[j] = new Translations() {
                    TranslatorId = translatorIds[j],
                    Content = parts[2]
                };
                iterators[j].MoveNext();
            }
            ayahs[i].Translations = translations;
            ayahs[i].OnPropertyChanged(nameof(Ayah.Translations));
        }
        foreach (var iterator in iterators) iterator.Dispose();
    }

    void copyWord() {
        var ayah = (Ayah)ayahListBox.SelectedItem;
        var builder = new StringBuilder();
        for (int i = 0; i < ayah.Words.Count; i++) {
            if (!ayah.Words[i].IsHighlighted) continue;
            ayah.Words[i].Segments[App.global.Transcript].Split('|').toArabic(builder);
            builder.Append(" ");
        }
        builder.Remove(builder.Length - 1, 1);
        Clipboard.SetText(builder.ToString());
    }

    void copyArabic() {
        var selected = ayahListBox.SelectedItems.Cast<Ayah>();
        progress.IsIndeterminate = true;

        Task.Run(() => {
            var builder = new StringBuilder();
            foreach (Ayah ayah in selected) {
                if (terminator.IsCancellationRequested) break; // want to check in nested loops?

                builder
                .Append(ayah.SurahNo.toArabicNo())
                .Append(':')
                .Append(ayah.AyahNo.toArabicNo())
                .Append(" - ");

                foreach (var word in ayah.Words) {
                    word.Segments[App.global.Transcript].Split('|').toArabic(builder);
                    builder.Append(" ");
                }
                builder.AppendLine();

                if (!terminator.IsCancellationRequested) {
                    App.Current.Dispatcher.Invoke(() => {
                        Clipboard.SetText(builder.ToString());
                        progress.IsIndeterminate = false;
                    });
                }
            }
        }, terminator.Token);
    }

    void copyEnglish() {
        var selected = ayahListBox.SelectedItems.Cast<Ayah>();
        progress.IsIndeterminate = true;

        Task.Run(() => {
            var builder = new StringBuilder();
            foreach (Ayah ayah in selected) {
                if (terminator.IsCancellationRequested) break; // want to check in nested loops?
                builder
                .Append(ayah.SurahNo)
                .Append(':')
                .Append(ayah.AyahNo + " - ");

                if (ayah.Translations.Length == 1) {
                    builder.Append(ayah.Translations[0].Content)
                    .AppendLine();
                }
                else {
                    var translatorNames = App.global.TranslationDictionary.Keys.ToList();
                    for (int i = 0; i < ayah.Translations.Length; i++) {
                        builder.Append(translatorNames[i])
                        .Append(": ")
                        .Append(ayah.Translations[i].Content)
                        .AppendLine();
                    }
                }

                if (!terminator.IsCancellationRequested) {
                    App.Current.Dispatcher.Invoke(() => {
                        Clipboard.SetText(builder.ToString());
                        progress.IsIndeterminate = false;
                    });
                }
            }
        }, terminator.Token);
    }

    void copyBoth() {
        var selected = ayahListBox.SelectedItems.Cast<Ayah>();
        progress.IsIndeterminate = true;

        Task.Run(() => {
            var builder = new StringBuilder();
            foreach (Ayah ayah in selected) {
                if (terminator.IsCancellationRequested) break; // want to check in nested loops?

                builder
                .Append(ayah.SurahNo.toArabicNo())
                .Append(':')
                .Append(ayah.AyahNo.toArabicNo())
                .Append(" - ");

                foreach (var word in ayah.Words) {
                    word.Segments[App.global.Transcript].Split('|').toArabic(builder);
                    builder.Append(" ");
                }
                builder
                .AppendLine()
                .Append(ayah.SurahNo)
                .Append(':')
                .Append(ayah.AyahNo + " - ");


                if (ayah.Translations.Length == 1) {
                    builder.Append(ayah.Translations[0].Content)
                    .AppendLine();
                }
                else {
                    var translatorNames = App.global.TranslationDictionary.Keys.ToList();
                    for (int i = 0; i < ayah.Translations.Length; i++) {
                        builder.Append(translatorNames[i])
                        .Append(": ")
                        .Append(ayah.Translations[i].Content)
                        .AppendLine();
                    }
                }
                if (!terminator.IsCancellationRequested) {
                    App.Current.Dispatcher.Invoke(() => {
                        Clipboard.SetText(builder.ToString());
                        progress.IsIndeterminate = false;
                    });
                }
            }
        }, terminator.Token);
    }

    protected override void unload() {
        queryBox.KeyUp -= onQuery;
        gotoBox.KeyUp -= onGoto;
        searchState.MouseLeftButtonUp -= onLeftClick;
        ayahListBox.MouseRightButtonUp -= onRightMouseUp;
        translatorDescriptor.RemoveValueChanged(translators, onTranslationChanged);

        terminator.Cancel();
        terminator.Dispose();
        base.unload();
    }
}
