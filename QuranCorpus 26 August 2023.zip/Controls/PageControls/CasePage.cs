﻿class CasePage : Page {
    string indexMa;
    Grid content;
    StringBuilder builder = new();

    WaterBox DNom, DAcc, DGen, INom, IAcc, IGen, root;

    ListBox erabs;
    Run morphCount, morphTotal;
    TextBlockEnglish meaningCount;
    List<Morph> morphs;
    ListBox listMorph, listMeaning;
    ICollectionView erabView;

    public override PageType Type => PageType.Case;
    public override UIElement Content => content;

    public CasePage() {
        indexMa = "|" + ((App)Application.Current).indexMa;
        root = new WaterBox() {
            HorizontalAlignment = HorizontalAlignment.Right,
            FlowDirection = FlowDirection.LeftToRight,
            Width = 100,
            Icon = Icons.Sprout,
            Hint = "root"
        };
        var countBlock = new TextBlockEnglish();
        var header = getHeader();
        erabs = new ListBox() {
            Margin = new Thickness(0,0,0,5),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(ErabTemplate))
            },
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()),
                        }
                    }
                }}
        };
        erabs.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
        var separator = new Rectangle() {
            VerticalAlignment = VerticalAlignment.Bottom,
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var splitter = new GridSplitter() {
            ResizeDirection = GridResizeDirection.Rows,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Template = new SplitterTemplate()
        };

        morphCount = new Run();
        morphTotal = new Run();
        var morphCountBlock = new TextBlockEnglish() {
            IsHitTestVisible = false,
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center,
            Inlines = { morphTotal, new Run(" in "), morphCount }
        };
        meaningCount = new TextBlockEnglish() {
            IsHitTestVisible = false,
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Left
        };

        listMorph = new ListBox() {
            Margin = new Thickness(0, 5, 0, 0),
            FlowDirection = FlowDirection.RightToLeft,
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MorphListTemplate))
            },
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()),
                        }
                    }
                }}
        };
        listMorph.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMorph.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        listMorph.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        listMeaning = new ListBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 0, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MeaningListTemplate))
            }
        };
        listMeaning.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMeaning.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        listMeaning.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
        
        Grid.SetRow(header, 1);
        Grid.SetRow(erabs, 2);
        Grid.SetRow(separator, 2);
        Grid.SetRow(splitter, 3);
        Grid.SetRow(morphCountBlock, 3);
        Grid.SetRow(meaningCount, 3);
        Grid.SetRow(listMorph, 4);
        Grid.SetRow(listMeaning, 4);
        Grid.SetColumn(root, 1);
        Grid.SetColumn(listMorph, 1);
        Grid.SetColumn(morphCountBlock, 1);
        Grid.SetColumnSpan(header, 2);
        Grid.SetColumnSpan(erabs, 2);
        Grid.SetColumnSpan(separator, 2);
        Grid.SetColumnSpan(splitter, 2);
        content = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(1.5, GridUnitType.Star)}
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(1.5, GridUnitType.Star)},
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { root, countBlock, header, erabs, separator, splitter, morphCountBlock, listMorph, meaningCount, listMeaning }
        };

        morphCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMorph,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        meaningCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMeaning,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        countBlock.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = erabs,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        erabs.SelectionChanged += onErabSelectionChanged;
        listMorph.SelectionChanged += onMorphSelectionChanged;
        listMeaning.MouseDoubleClick += onMeaningDoubleClick;
        DNom.KeyUp += onErabKeyUp;
        DAcc.KeyUp += onErabKeyUp;
        DGen.KeyUp += onErabKeyUp;
        INom.KeyUp += onErabKeyUp;
        IAcc.KeyUp += onErabKeyUp;
        IGen.KeyUp += onErabKeyUp;
        root.KeyUp += onErabKeyUp;
    }

    public CasePage(List<ErabWord> source) : this() {
        HeaderText = source.First().Gender + " (" + source.Count + ")";
        erabView = CollectionViewSource.GetDefaultView(source);
        erabView.Filter = filter;
        erabs.ItemsSource = erabView;
    }

    public void setContent(List<ErabWord> source) {
        HeaderText = source.First().Gender + " (" + source.Count + ")";
        erabView = CollectionViewSource.GetDefaultView(source);
        erabView.Filter = filter;
        erabs.ItemsSource = erabView;
    }

    bool filter(object o) {
        bool result = true;
        var erab = (ErabWord)o;
        if (!string.IsNullOrEmpty(DNom.Text)) {
            result = result && DNom.Text.StartsWith('!') ?
                !erab.DNominative.EndsWith(DNom.Text.Substring(1)) :
                erab.DNominative.EndsWith(DNom.Text);
        }
        if (!string.IsNullOrEmpty(DAcc.Text)) {
            result = result && DAcc.Text.StartsWith('!') ?
                !erab.DAccusative.EndsWith(DAcc.Text.Substring(1)) :
                erab.DAccusative.EndsWith(DAcc.Text);
        }
        if (!string.IsNullOrEmpty(DGen.Text)) {
            result = result && DGen.Text.StartsWith('!') ?
                !erab.DGenitive.EndsWith(DGen.Text.Substring(1)) :
                erab.DGenitive.EndsWith(DGen.Text);
        }
        if (!string.IsNullOrEmpty(INom.Text)) {
            result = result && INom.Text.StartsWith('!') ?
                !erab.INominative.EndsWith(INom.Text.Substring(1)) :
                erab.INominative.EndsWith(INom.Text);
        }
        if (!string.IsNullOrEmpty(IAcc.Text)) {
            result = result && IAcc.Text.StartsWith('!') ?
                !erab.IAccusative.EndsWith(IAcc.Text.Substring(1)) :
                erab.IAccusative.EndsWith(IAcc.Text);
        }
        if (!string.IsNullOrEmpty(IGen.Text)) {
            result = result && IGen.Text.StartsWith('!') ?
                !erab.IGenitive.EndsWith(IGen.Text.Substring(1)) :
                erab.IGenitive.EndsWith(IGen.Text);
        }
        if (!string.IsNullOrEmpty(root.Text)) {
            result = result && erab.Root.Contains(root.Text);
        }
        return result;
    }

    void onErabSelectionChanged(object sender, SelectionChangedEventArgs e) {
        if(erabs.SelectedItem is null) {
            listMorph.ItemsSource = null;
            morphTotal.Text = "0";
            return;
        }
        var selected = (ErabWord)erabs.SelectedItem;
        morphs = new List<Morph>();
        var iterator = App.links.GetEnumerator();
        iterator.MoveNext();
        if (!selected.IsSorted) {
            selected.References.Sort(new SurahAyahWordNoComparator());
            selected.IsSorted = true;
        }
        for (int i = 0; i < selected.References.Count; i++) {
            while (!iterator.Current.Reference.Equals(selected.References[i])) iterator.MoveNext();
            var parts = App.global.Transcript == 0 ?
                iterator.Current.SpellingGroupCorpus.Split('|') :
                iterator.Current.SpellingGroupSimple.Split('|');

            int index = 0;
            for (int j = 0; j < parts.Length; j++) {
                if (!App.spellings[Convert.ToInt32(parts[j])].Equals(selected.Spelling)) continue;
                index = j;
                break;
            }
            morphs.Add(getMorph(iterator.Current, index));
            
        }
        var listSource = morphs.GroupBy(x => new { Word = x.Segments[1], x.Explanation })
              .Select(x => new Morph() {
                  Segments = x.First().Segments,
                  Count = x.Count(),
                  Tags = x.First().Tags,
                  Explanation = x.Key.Explanation,
                  References = x.SelectMany(x => x.References).ToList()
              })
              .OrderByDescending(x => x.Count)
              .ToList();

        listMorph.ItemsSource = listSource;
        morphTotal.Text = listSource.Sum(x => x.Count).ToString();
    }

    void onMorphSelectionChanged(object sender, SelectionChangedEventArgs e) {
        if (listMorph.SelectedItem is null) {
            listMeaning.ItemsSource = null;
            return;
        }
        listMeaning.ItemsSource = ((Morph)listMorph.SelectedItem).References;
    }

    void onMeaningDoubleClick(object sender, MouseButtonEventArgs e) {
        if (listMeaning.SelectedItem is null) return; // can be null?
        var item = (Tuple<string, string, string>)listMeaning.SelectedItem;
        ((App)Application.Current).Pages.addSurahPage(item.Item1);
    }

    Morph getMorph(Link item, int index) {
        string tag = "";
        string[] tags;
        string details = "";

        details = item.Details.Split(',')[Convert.ToInt32(index)];
        details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
        int lIndex;
        if (item.LemmaSimple.EndsWith(indexMa)) {
            // in 8 cases it ends with maA
            lIndex = 0;
        }
        else {
            lIndex = item.LemmaIndices.Contains('|') ?
                Convert.ToInt32(item.LemmaIndices.Split('|')[0]) :
                Convert.ToInt32(item.LemmaIndices);
        }

        tags = item.Tags.Split('|');
        tag = App.tags[Convert.ToInt32(tags[lIndex])].Name;


        Morph t = new() {
            Tag = tag,
            Tags = tags,
            Segments = Helper.getSegments(item),
            Spellings = getSpellings(item)
        };
        builder.Clear();
        item.explain(builder);

        t.Explanation = builder.ToString();
        t.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));

        var array = details.Split('|');
        if (App.tagArray.Contains(tag)) {
            for (int i = 0; i < array.Length; i++) {
                if (string.IsNullOrEmpty(array[i])) continue;
                if (array[i].Equals("PCPL") ||
                    array[i].Equals("ACC") ||
                    array[i].Equals("NOM") ||
                    array[i].Equals("GEN") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("ACT")) t.SubTag = "Active Participle";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive Participle";
                else if (array[i].Equals("VN")) t.SubTag = "Verbal Noun";
                else if (array[i].Equals("IN")) t.SubTag = "Noun";
                else if (array[i].Equals("CN")) t.SubTag = "Noun";
                else if (array[i].Equals("IP")) t.SubTag = "Particle";
                else if (array[i].Equals("CP")) t.SubTag = "Particle";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("V")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUBJ") ||
                    array[i].Equals("JUS") ||
                    array[i].Equals("JUSS") ||
                    array[i].Equals("SP:kaAn") ||
                    array[i].Equals("SP:kaAd") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("IMPF")) t.SubTag = "Imperfect";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive";
                else if (array[i].Equals("IMPV")) t.SubTag = "Imperative";
                else if (array[i].Equals("PERF")) t.SubTag = "Perfect";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("PRON")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUB")) t.SubTag = "Subject";
                else if (array[i].Equals("OBJ")) t.SubTag = "Object";
                else if (array[i].Equals("PER")) t.SubTag = "Personal";
                else if (array[i].Equals("POS")) t.SubTag = "Possessive";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name;
                else t.Gender = Helper.getGender(array[i]).Name;
            }
        }
        return t;

        string[] getSpellings(Link item) {
            int lIndex;
            if (item.LemmaSimple.EndsWith(indexMa)) {
                // in 8 cases it ends with maA
                lIndex = 0;
            }
            else {
                if (string.IsNullOrEmpty(item.LemmaIndices)) {
                    return new string[] {
                        item.SpellingGroupCorpus,
                        item.SpellingGroupSimple
                    };
                }

                lIndex = item.LemmaIndices.Contains('|') ?
                    Convert.ToInt32(item.LemmaIndices.Split('|')[0]) :
                    Convert.ToInt32(item.LemmaIndices);
            }
            return new string[] {
                item.SpellingGroupCorpus.Split('|')[lIndex],
                item.SpellingGroupSimple.Split('|')[lIndex]
            };
        }
    }

    Grid getHeader() {
        var deHeader = new TextBlockEnglish() { Text = "Definite", HorizontalAlignment = HorizontalAlignment.Center };
        DNom = new WaterBox() {
            Hint = "Nominative",
            Icon = Icons.ArrowLeft
        };
        DAcc = new WaterBox() {
            Hint = "Accusative",
            Icon = Icons.ArrowTopLeft
        };
        DGen = new WaterBox() {
            Hint = "Genitive",
            Icon = Icons.ArrowBottomLeft
        };
        Grid.SetRow(DNom, 1);
        Grid.SetRow(DAcc, 1);
        Grid.SetRow(DGen, 1);
        Grid.SetColumn(DAcc, 1);
        Grid.SetColumn(DNom, 2);
        Grid.SetColumnSpan(deHeader, 3);
        var definite = new Border() {
            Padding = new Thickness(5,0,5,0),
            BorderBrush = Brushes.Gray, 
            BorderThickness = new Thickness(1, 0, 0, 0),
            Child = new Grid() {
                RowDefinitions = {
                    new RowDefinition(),
                    new RowDefinition()
                },
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(),
                    new ColumnDefinition()
                },
                Children = { deHeader, DNom, DAcc, DGen }
            },
        };
        var inHeader = new TextBlockEnglish() { Text = "Indefinite", HorizontalAlignment = HorizontalAlignment.Center };
        INom = new WaterBox() {
            Hint = "Nominative",
            Icon = Icons.ArrowLeft
        };
        IAcc = new WaterBox() {
            Hint = "Accusative",
            Icon = Icons.ArrowTopLeft
        };
        IGen = new WaterBox() {
            Hint = "Genitive",
            Icon = Icons.ArrowBottomLeft
        };
        Grid.SetRow(INom, 1);
        Grid.SetRow(IAcc, 1);
        Grid.SetRow(IGen, 1);
        Grid.SetColumn(IAcc, 1);
        Grid.SetColumn(INom, 2);
        Grid.SetColumnSpan(inHeader, 3);
        var indefinite = new Border() {
            Padding = new Thickness(5, 0, 5, 0),
            BorderBrush = Brushes.LightGray,
            Child = new Grid() {
                RowDefinitions = {
                    new RowDefinition(),
                    new RowDefinition()
                },
                ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(),
                    new ColumnDefinition()
                },
                Children = { inHeader, INom, IAcc, IGen }
            },
        };
        Grid.SetColumn(definite, 1);

        return new Grid() {
            Margin = new Thickness(Constants.ScrollBarThickness, 0,0,5),
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition()
            },
            Children = { definite, indefinite }
        };
    }

    void onErabKeyUp(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        erabView.Refresh();
    }

    protected override void unload() {
        erabs.SelectionChanged -= onErabSelectionChanged;
        listMorph.SelectionChanged -= onMorphSelectionChanged;
        listMeaning.MouseDoubleClick -= onMeaningDoubleClick;
        DNom.KeyUp -= onErabKeyUp;
        DAcc.KeyUp -= onErabKeyUp;
        DGen.KeyUp -= onErabKeyUp;
        INom.KeyUp -= onErabKeyUp;
        IAcc.KeyUp -= onErabKeyUp;
        IGen.KeyUp -= onErabKeyUp;
        root.KeyUp -= onErabKeyUp;
        base.unload();
    }

    class ErabTemplate : Grid {
        TextBlockArabic dNom, dAcc, dGen, iNom, iAcc, iGen;

        public ErabTemplate() {
            dNom = new TextBlockArabic();
            dAcc = new TextBlockArabic();
            dGen = new TextBlockArabic();

            iNom = new TextBlockArabic();
            iAcc = new TextBlockArabic();
            iGen = new TextBlockArabic();

            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());

            SetColumn(dAcc, 1);
            SetColumn(dGen, 2);
            SetColumn(iNom, 3);
            SetColumn(iAcc, 4);
            SetColumn(iGen, 5);

            Children.Add(dNom);
            Children.Add(dAcc);
            Children.Add(dGen);
            Children.Add(iNom);
            Children.Add(iAcc);
            Children.Add(iGen);

            Resources.Add(typeof(TextBlockArabic), new Style() {
                Setters = {
                    new Setter(TextBlockArabic.MarginProperty, new Thickness(20,0,0,0))
                }
            });
        }

        public override void EndInit() {
            base.EndInit();
            var c = (ErabWord)DataContext;
            dNom.Text = string.IsNullOrEmpty(c.DNominative) ? "" : c.DNominative.toArabic();
            dAcc.Text = string.IsNullOrEmpty(c.DAccusative) ? "" : c.DAccusative.toArabic();
            dGen.Text = string.IsNullOrEmpty(c.DGenitive) ? "" : c.DGenitive.toArabic();

            iNom.Text = string.IsNullOrEmpty(c.INominative) ? "" : c.INominative.toArabic();
            iAcc.Text = string.IsNullOrEmpty(c.IAccusative) ? "" : c.IAccusative.toArabic();
            iGen.Text = string.IsNullOrEmpty(c.IGenitive) ? "" : c.IGenitive.toArabic();
        }
    }
}
