﻿static class Extensions {
    static StringBuilder builder = new();

    public static string toArabic(this string transcription) {
        builder.Clear();
        char last = '\0';
        foreach (var character in transcription) {
            
            if (character == 'o' || character == '@') continue; // Sukun or Small High Rounded Zero
            if (character == ' ') continue; // happens only once in case of prophet il yas, eg. 37:130
            if ((last == '>' && character == 'a') || // Alif + HamzaAbove followed by fatha
                (last == '<' && character == 'i') || // Alif + HamzaBelow followed by kesra
                (last == '`' && character == '^')) { // Alif Khanjareeya followed by Maddah
                continue;
            }
            if ((last != '\0') &&
                (character == '`' && last == 'a') || // fatha followed by AlifKhanjareeya
                (character == 'A' && last == 'a') || // fatha followed by Alif
                (character == 'w' && last == 'u') || // damma followed by Waw
                (character == 'y' && last == 'i')) { // kesra followed by Ya
                builder.Remove(builder.Length - 1, 1);
            }

            char c = (char)Int16.Parse(App.characters.First(x => x.English == character).Arabic, NumberStyles.HexNumber);
            builder.Append(c);
            last = character;
        }
        return builder.ToString();
    }

    public static void toArabic(this string transcription, string[] segments, StringBuilder sb) {
        int index = 0;
        char last = '\0';
        var characters = App.segments[Convert.ToInt32(transcription)];
        foreach (var character in characters) {
            if (character == 'o' || character == '@') continue; // Sukun or Small High Rounded Zero
            if (character == ' ') {
                // happens only once in case of prophet il yas, eg. 37:130
                sb.Append(' ');
                continue;
            }
            if ((last == '>' && character == 'a') || // Alif + HamzaAbove followed by fatha
                (last == '<' && character == 'i') || // Alif + HamzaBelow followed by kesra
                (last == '`' && character == '^')) { // Alif Khanjareeya followed by Maddah
                continue;
            }
            if ((last != '\0') &&
                (character == '`' && last == 'a') || // fatha followed by AlifKhanjareeya
                (character == 'A' && last == 'a') || // fatha followed by Alif
                (character == 'w' && last == 'u') || // damma followed by Waw
                (character == 'y' && last == 'i')) { // kesra followed by Ya
                sb.Remove(sb.Length - 1, 1);
            }

            char c = (char)Int16.Parse(App.characters.First(x => x.English == character).Arabic, NumberStyles.HexNumber);
            sb.Append(c);
            last = character;
        }
        if (index < segments.Length - 1) {
            var next = App.segments[Convert.ToInt32(segments[index + 1])][0];
            if ((next == 'A' && last == 'a') ||
                (next == 'w' && last == 'u') ||
                (next == 'y' && last == 'i')) {
                sb.Remove(sb.Length - 1, 1);
            }
        }
    }

    public static void toArabic(this string[] segments, StringBuilder sb) {
        int index = 0;
        char last = '\0';
        foreach (var segment in segments) {
            var characters = App.segments[Convert.ToInt32(segment)];
            foreach (var character in characters) {
                if (character == 'o' || character == '@') continue; // Sukun or Small High Rounded Zero
                if (character == ' ') {
                    // happens only once in case of prophet il yas, eg. 37:130
                    sb.Append(' ');
                    continue;
                }
                if ((last == '>' && character == 'a') || // Alif + HamzaAbove followed by fatha
                    (last == '<' && character == 'i') || // Alif + HamzaBelow followed by kesra
                    (last == '`' && character == '^')) { // Alif Khanjareeya followed by Maddah
                    continue;
                }
                if ((last != '\0') &&
                    (character == '`' && last == 'a') || // fatha followed by AlifKhanjareeya
                    (character == 'A' && last == 'a') || // fatha followed by Alif
                    (character == 'w' && last == 'u') || // damma followed by Waw
                    (character == 'y' && last == 'i')) { // kesra followed by Ya
                    sb.Remove(sb.Length - 1, 1);
                }
                char c = (char)Int16.Parse(App.characters.First(x => x.English == character).Arabic, NumberStyles.HexNumber);
                sb.Append(c);
                last = character;
            }
            if (index < segments.Length - 1) {
                var next = App.segments[Convert.ToInt32(segments[index + 1])][0];
                if ((next == 'A' && last == 'a') ||
                    (next == 'w' && last == 'u') ||
                    (next == 'y' && last == 'i')) {
                    sb.Remove(sb.Length - 1, 1);
                }
            }
            last = '\0';
        }
    }

    public static string toArabicNo(this string value) {
        return value.Replace('0', '\u0660')
              .Replace('1', '\u0661')
              .Replace('2', '\u0662')
              .Replace('3', '\u0663')
              .Replace('4', '\u0664')
              .Replace('5', '\u0665')
              .Replace('6', '\u0666')
              .Replace('7', '\u0667')
              .Replace('8', '\u0668')
              .Replace('9', '\u0669');
    }
}
