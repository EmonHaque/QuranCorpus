﻿class WordView : View {
    public override string Icon => Icons.WorkPlace;
    public override FrameworkElement container => grid;
    Grid grid;

    public WordView()  {
        Margin = new Thickness(-7.5, 0, 0, 0);
        grid = new Grid();
        AddVisualChild(grid);
    }

    public override void OnFirstSight() {
        base.OnFirstSight();
        var root = new RootWordView();
        grid.Children.Add(new ViewContainer(NavPosition.BottomLeftVertical, NavOverlap.Left) {
            Children = {
                root,
                new LemmaView(),
                new RootLemmaLessView()
            }
        });
        root.OnFirstSight();
    }
}
