﻿class TagGroupTemplate : Grid {
    TextBlockEnglish name, count;

    public TagGroupTemplate() {
        name = new TextBlockEnglish();
        count = new TextBlockEnglish() { Foreground = Brushes.Gray };

        SetColumn(count, 1);

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

        Children.Add(name);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var header = (Tuple<string, string>)DataContext;
        name.Text = header.Item1;
        count.Text = header.Item2;
    }
}
