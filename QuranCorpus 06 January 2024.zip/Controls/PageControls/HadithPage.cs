﻿class HadithPage : Page {
    List<HadithContent> source;
    int currentBook;

    Grid content;
    CheckGroup checkGroup;
    ProgressBar progress;
    ChapterView chapterView;
    GradeView gradeView;
    NarratorView narratorView;
    DependencyPropertyDescriptor groupStateDescriptor;
    CancellationTokenSource terminator;

    public override PageType Type => PageType.Hadith;
    public override UIElement Content => content;

    public HadithPage() {
        terminator = new CancellationTokenSource();
        source = new List<HadithContent>();

        progress = new ProgressBar() {
            Margin = new Thickness(0, 0, 0, 2.5),
            Height = Constants.ProgressBarHeight
        };
        checkGroup = new CheckGroup() {
            FlowDirection = FlowDirection.LeftToRight,
            HorizontalAlignment = HorizontalAlignment.Left,
            Icons = new string[] { Icons.AlphaCBox, Icons.AlphaGBox, Icons.AlphaNBox },
            Tips = new string[] { "chapters", "grades", "narrators" }
        };

        chapterView = new ChapterView();
        gradeView = new GradeView() { Visibility = Visibility.Hidden };
        narratorView = new NarratorView() { Visibility = Visibility.Hidden };

        Grid.SetRow(checkGroup, 1);
        Grid.SetRow(chapterView, 1);
        Grid.SetRow(gradeView, 1);
        Grid.SetRow(narratorView, 1);

        Grid.SetRowSpan(chapterView, 2);
        Grid.SetRowSpan(gradeView, 2);
        Grid.SetRowSpan(narratorView, 2);

        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, checkGroup, chapterView, gradeView, narratorView }
        };

        groupStateDescriptor = DependencyPropertyDescriptor.FromProperty(CheckGroup.SelectedProperty, typeof(CheckGroup));
        groupStateDescriptor.AddValueChanged(checkGroup, onGroupStateChanged);
    }

    public HadithPage(HadithBook book) : this() => updateUI(book);

    public void setContent(HadithBook book) => updateUI(book);

    void updateUI(HadithBook book) {
        if (currentBook == book.Id) return;

        currentBook = book.Id;
        HeaderText = book.TitleEnglish;
        progress.IsIndeterminate = true;

        Task.Run(() => {
            if (App.hadithChapters is null) initializeChaptersAndSections();

            var id = book.Id.ToString();
            source.Clear();

            var file = System.IO.File.ReadLines("Resources/Hadith/contents.txt");
            var iterator = file.GetEnumerator();
            iterator.MoveNext();

            while (!iterator.Current.StartsWith(id)) iterator.MoveNext();
            while (iterator.Current.StartsWith(id)) {
                if (terminator.IsCancellationRequested) break;

                var parts = iterator.Current.Split('\t');

                source.Add(new HadithContent() {
                    BookId = Convert.ToInt32(parts[0]),
                    Number = parts[1],
                    ChapterId = Convert.ToInt32(parts[2]),
                    SectionId = Convert.ToInt32(parts[3]),
                    ArabicIsnad = parts[4],
                    EnglishIsnad = parts[5].Equals("nan") ? "" : parts[5],
                    ArabicMatan = parts[6].Equals("nan") ? "" : parts[6],
                    EnglishMatan = parts[7],
                    ArabicGrade = parts[8],
                    EnglishGrade = parts[9].Equals("nan") ? "" : parts[9],
                    ArabicComment = parts[10].Equals("nan") ? "" : parts[10]
                });

                iterator.MoveNext();
                if (iterator.Current is null) break;
            }
            iterator.Dispose();


            if (!terminator.IsCancellationRequested) {
                chapterView.ResetSource(source);
                gradeView.ResetSource(source);
                narratorView.ResetSource(source);
                App.Current.Dispatcher.Invoke(() => {
                    chapterView.UpdateView();
                    gradeView.UpdateView();
                    narratorView.UpdateView();
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    void onGroupStateChanged(object? sender, EventArgs e) {
        if (checkGroup.Selected == 0) {
            gradeView.Visibility = Visibility.Hidden;
            narratorView.Visibility = Visibility.Hidden;
            chapterView.Visibility = Visibility.Visible;

        }
        else if (checkGroup.Selected == 1) {
            chapterView.Visibility = Visibility.Hidden;
            narratorView.Visibility = Visibility.Hidden;
            gradeView.Visibility = Visibility.Visible;
        }
        else {
            chapterView.Visibility = Visibility.Hidden;
            gradeView.Visibility = Visibility.Hidden;
            narratorView.Visibility = Visibility.Visible;
        }
    }

    void initializeChaptersAndSections() {
        App.hadithChapters =
             System.IO.File.ReadAllLines("Resources/Hadith/chapters.txt")
             .Skip(1)
             .Select(x => x.Split('\t'))
             .Select(x => new HadithChapter() {
                 Id = Convert.ToInt32(x[0]),
                 Chapter = Convert.ToInt32(x[1]),
                 Arabic = x[2],
                 English = x[3]
             }).ToList();

        App.hadithSections =
             System.IO.File.ReadAllLines("Resources/Hadith/sections.txt")
            .Skip(1)
            .Select(x => x.Split('\t'))
            .Select(x => new HadithSection() {
                Id = Convert.ToInt32(x[0]),
                Section = x[1],
                Arabic = x[2],
                English = x[3]
            }).ToList();
    }

    protected override void unload() {
        chapterView.Unload();
        gradeView.Unload();
        narratorView.Unload();
        groupStateDescriptor.RemoveValueChanged(checkGroup, onGroupStateChanged);
        terminator.Cancel();
        terminator.Dispose();
        base.unload();
    }

    class ChapterView : ViewGrid {
        WaterBox queryBox;
        ICollectionView groupView;
        string query;
        public string Query {
            get { return query; }
            set { query = value; groupView?.Refresh(); }
        }
        protected override Type viewTemplate => typeof(ChapterTemplate);

        public ChapterView() : base() {
            queryBox = new WaterBox() {
                Margin = new Thickness(Constants.ScrollBarThickness, 0, 0, 0),
                FlowDirection = FlowDirection.LeftToRight,
                Icon = Icons.Search,
                Hint = "Chapter (english)"
            };
            queryBox.SetBinding(WaterBox.TextProperty, new Binding(nameof(Query)) {
                Mode = BindingMode.OneWayToSource,
                Source = this
            });
            SetColumn(queryBox, 1);
            SetRow(queryBox, 1);
            leftGrid.Children.Add(queryBox);
        }

        public override void ResetSource(List<HadithContent> source) {
            this.source = source;
            groups = source
                .GroupBy(x => x.ChapterId)
                .Select(x => new {
                    Id = App.hadithChapters.First(y => y.Id == x.Key).Chapter,
                    Value = x,
                    x.Key
                })
                .OrderBy(x => x.Id)
                .Select(x => new Tuple<string, List<HadithContent>>(x.Key.ToString(), x.Value.Select(x => x).ToList()))
                .ToList();
        }

        protected override FrameworkElementFactory getHadithTemplate() {
            return new FrameworkElementFactory(typeof(HadithTemplate));
        }

        protected override void resetgroupBoxSource() {
            groupView = CollectionViewSource.GetDefaultView(groups);
            groupView.Filter = filter;
            groupBox.ItemsSource = groupView;
        }

        bool filter(object o) {
            if (string.IsNullOrEmpty(query)) return true;
            var c = (Tuple<string, List<HadithContent>>)o;
            return App.hadithChapters.First(x => x.Id.ToString().Equals(c.Item1)).English.ToLower().Contains(Query);
        }

        class ChapterTemplate : Grid {
            Tuple<string, List<HadithContent>> item;
            TextBlockArabic arabic;
            HiEnglishBlock english;
            TextBlockEnglish count;
            DependencyPropertyDescriptor fontDescriptor;

            public ChapterTemplate() {
                FlowDirection = FlowDirection.LeftToRight;
                arabic = new TextBlockArabic() { TextWrapping = TextWrapping.Wrap };
                english = new HiEnglishBlock() { TextWrapping = TextWrapping.Wrap };
                count = new TextBlockEnglish() {
                    Foreground = Brushes.Gray,
                    VerticalAlignment = VerticalAlignment.Bottom
                };
                SetColumnSpan(arabic, 2);
                SetRow(english, 1);
                SetRow(count, 1);
                SetColumn(count, 1);
                ColumnDefinitions.Add(new ColumnDefinition());
                ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
                RowDefinitions.Add(new RowDefinition());
                RowDefinitions.Add(new RowDefinition());
                Children.Add(arabic);
                Children.Add(english);
                Children.Add(count);

                english.SetBinding(HiEnglishBlock.QueryProperty, new Binding() {
                    Path = new PropertyPath("DataContext.Query"),
                    RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(ListBox), 1)
                });
                fontDescriptor = DependencyPropertyDescriptor.FromProperty(TextBlockArabic.FontFamilyProperty, typeof(TextBlockArabic));
                Loaded += onLoaded;
                Unloaded += onUnloaded;
            }

            public override void EndInit() {
                base.EndInit();
                item = (Tuple<string, List<HadithContent>>)DataContext;
                var chapter = App.hadithChapters.First(x => x.Id.ToString().Equals(item.Item1));
                string text = "";
                if (App.global.ArabicFont.Equals("KFGQPC Uthmanic HAFS") ||
                    App.global.ArabicFont.Equals("me quran")) {
                    arabic.Text = chapter.Chapter.ToString().toArabicNo() + " " + chapter.Arabic;
                }
                else arabic.Text = chapter.Chapter.ToString().toArabicNo() + ") " + chapter.Arabic;
                english.Text = chapter.Chapter + ") " + chapter.English;
                count.Text = item.Item2.Count.ToString("N0");
            }

            void onLoaded(object sender, RoutedEventArgs e) => fontDescriptor.AddValueChanged(arabic, onFontChanged);

            void onUnloaded(object sender, RoutedEventArgs e) => fontDescriptor.RemoveValueChanged(arabic, onFontChanged);

            void onFontChanged(object? sender, EventArgs e) {
                if (App.global.ArabicFont.Equals("KFGQPC Uthmanic HAFS") ||
                    App.global.ArabicFont.Equals("me quran")) {
                    if (arabic.Text.Contains(')')) {
                        var chapter = App.hadithChapters.First(x => x.Id.ToString().Equals(item.Item1));
                        arabic.Text = chapter.Chapter.ToString().toArabicNo() + " " + chapter.Arabic;
                    }
                }
                else {
                    if (!arabic.Text.Contains(')')) {
                        var chapter = App.hadithChapters.First(x => x.Id.ToString().Equals(item.Item1));
                        arabic.Text = chapter.Chapter.ToString().toArabicNo() + ") " + chapter.Arabic;
                    }
                }
            }
        }

        class HadithTemplate : HadithGrid {
            protected override string getGrade(HadithContent c) => c.EnglishGrade + "\nHadith no. " + c.Number;
        }
    }

    class GradeView : ViewGrid {
        protected override Type viewTemplate => typeof(ChapterTemplate);

        public override void ResetSource(List<HadithContent> source) {
            this.source = source;
            groups = source
                .GroupBy(x => x.ArabicGrade)
                .Select(x => new Tuple<string, List<HadithContent>>(x.Key, x.ToList()))
                .ToList();
        }

        protected override void resetgroupBoxSource() {
            groupBox.ItemsSource = groups;
            groupBox.ScrollIntoView(groups.First());
        }

        class ChapterTemplate : Grid {
            TextBlockArabic arabic;
            TextBlockEnglish count;

            public ChapterTemplate() {
                FlowDirection = FlowDirection.LeftToRight;
                arabic = new TextBlockArabic() { TextWrapping = TextWrapping.Wrap };
                count = new TextBlockEnglish() {
                    Foreground = Brushes.Gray,
                    VerticalAlignment = VerticalAlignment.Center
                };
                SetColumn(arabic, 1);
                ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
                ColumnDefinitions.Add(new ColumnDefinition());
                Children.Add(arabic);
                Children.Add(count);
            }

            public override void EndInit() {
                base.EndInit();
                var c = (Tuple<string, List<HadithContent>>)DataContext;
                arabic.Text = c.Item1;
                count.Text = c.Item2.Count.ToString("N0");
            }
        }
    }

    class NarratorView : ViewGrid {
        int count;
        WaterBox queryBox;
        Run filteredItemCount, filteredHadithCount;
        ICollectionView groupView;
        string query;
        public string Query {
            get { return query; }
            set {
                query = value;
                count = 0;
                groupView?.Refresh();
                filteredHadithCount.Text = count.ToString("N0");
            }
        }

        protected override Type viewTemplate => typeof(ChapterTemplate);

        public NarratorView() : base() {
            queryBox = new WaterBox() {
                Icon = Icons.Search,
                Hint = "Narrator (english)"
            };
            filteredItemCount = new Run();
            filteredHadithCount = new Run();
            var filterCount = new TextBlockEnglish() {
                Margin = new Thickness(5, 0, Constants.ScrollBarThickness, 0),
                Inlines = { filteredItemCount, new Run(" | "), filteredHadithCount }
            };

            Grid.SetColumn(filterCount, 1);
            var queryGrid = new Grid() {
                FlowDirection = FlowDirection.LeftToRight,
                ColumnDefinitions = {
                            new ColumnDefinition(),
                            new ColumnDefinition(){ Width = GridLength.Auto }
                        },
                Children = { queryBox, filterCount }
            };
            SetColumn(queryGrid, 1);
            SetRow(queryGrid, 1);
            leftGrid.Children.Add(queryGrid);
            groupBox.FlowDirection = FlowDirection.LeftToRight;

            filteredItemCount.SetBinding(Run.TextProperty, new Binding() {
                Path = new PropertyPath("Items.Count"),
                Source = groupBox,
                Mode = BindingMode.OneWay,
                StringFormat = "N0"
            });
            queryBox.SetBinding(WaterBox.TextProperty, new Binding(nameof(Query)) {
                Mode = BindingMode.OneWayToSource,
                Source = this
            });
        }

        public override void ResetSource(List<HadithContent> source) {
            this.source = source;
            groups = source
                .GroupBy(x => x.EnglishIsnad)
                .Select(x => new Tuple<string, List<HadithContent>>(x.Key, x.ToList()))
                .OrderBy(x => x.Item1)
                .ToList();
        }

        protected override void resetgroupBoxSource() {
            groupView = CollectionViewSource.GetDefaultView(groups);
            groupView.Filter = filter;
            groupBox.ItemsSource = groupView;
        }

        bool filter(object o) {
            if (string.IsNullOrEmpty(Query)) return true;
            var c = (Tuple<string, List<HadithContent>>)o;
            if (c.Item1.ToLower().Contains(Query)) {
                count += c.Item2.Count;
                return true;
            }
            return false;
        }

        class ChapterTemplate : Grid {
            HiEnglishBlock english;
            TextBlockEnglish count;

            public ChapterTemplate() {
                english = new HiEnglishBlock() { TextWrapping = TextWrapping.Wrap };
                count = new TextBlockEnglish() {
                    Foreground = Brushes.Gray,
                    VerticalAlignment = VerticalAlignment.Center
                };
                SetColumn(count, 1);
                ColumnDefinitions.Add(new ColumnDefinition());
                ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
                Children.Add(english);
                Children.Add(count);

                english.SetBinding(HiEnglishBlock.QueryProperty, new Binding() {
                    Path = new PropertyPath("DataContext.Query"),
                    RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(ListBox), 1)
                });
            }

            public override void EndInit() {
                base.EndInit();
                var c = (Tuple<string, List<HadithContent>>)DataContext;
                english.Text = c.Item1;
                count.Text = c.Item2.Count.ToString("N0");
            }
        }
    }

    abstract class ViewGrid : Grid {
        protected Grid leftGrid;
        protected ContentListBox groupBox;
        protected List<HadithContent> source;
        protected List<Tuple<string, List<HadithContent>>> groups;
        protected abstract Type viewTemplate { get; }

        Run listCount, hadithCount;
        WaterBox goToBox;
        ListBox hadithBox;
        
        public ViewGrid() {
            listCount = new Run();
            hadithCount = new Run();
            var counts = new TextBlockEnglish() {
                Margin = new Thickness(Constants.ScrollBarThickness, 0, 0, 0),
                FlowDirection = FlowDirection.LeftToRight,
                HorizontalAlignment = HorizontalAlignment.Left,
                Inlines = { hadithCount, listCount }
            };
            groupBox = new ContentListBox() {
                DataContext = this,
                Margin = new Thickness(0, 5, 0, 0),
                ItemTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(viewTemplate)
                }
            };
            groupBox.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

            var verticalSeparator = new Rectangle() {
                Margin = new Thickness(2.5, 0, 2.5, 0),
                HorizontalAlignment = HorizontalAlignment.Right,
                Width = Constants.BottomLineThickness,
                Fill = Brushes.Gray,
                VerticalAlignment = VerticalAlignment.Stretch
            };
            SetColumn(counts, 1);
            SetColumn(groupBox, 1);
            SetRow(groupBox, 2);
            SetRowSpan(verticalSeparator, 3);

            leftGrid = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){Width = GridLength.Auto },
                    new ColumnDefinition()
                },
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition()
                },
                Children = { counts, groupBox, verticalSeparator }
            };

            var toggle = new Toggle() {
                HorizontalAlignment = HorizontalAlignment.Right,
                OnIcon = Icons.DoorClose,
                OffIcon = Icons.DoorOpen,
                OnTip = "show left panel",
                OffTip = "hide left panel",
                Command = () => {
                    var col = ColumnDefinitions[1];
                    col.Width = col.Width.Value == 0 ? new GridLength(300) : new GridLength(0);
                }
            };

            var search = new ActionButton() {
                Margin = new Thickness(5, 0, 5, 0),
                Icon = Icons.SearchGlobal,
                ToolTip = "global search",
                Command = () => {
                    ((App)Application.Current).FocusedControl.addSearchHadithPage();
                }
            };
            goToBox = new WaterBox() {
                Width = 100,
                Icon = Icons.HandPointingRight,
                Hint = "Hadith no"
            };
            Grid.SetColumn(search, 1);
            Grid.SetColumn(goToBox, 2);
            var toolGrid = new Grid() {
                FlowDirection = FlowDirection.LeftToRight,
                ColumnDefinitions = {
                    new ColumnDefinition(){Width = GridLength.Auto},
                    new ColumnDefinition(){Width = GridLength.Auto},
                    new ColumnDefinition(){Width = GridLength.Auto}
                },
                Children = { toggle, search, goToBox }
            };

            hadithBox = new ListBox() {
                Margin = new Thickness(0, 5, 0, 0),
                ItemTemplate = new DataTemplate() {
                    VisualTree = getHadithTemplate()
                }
            };
            hadithBox.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

            SetRow(hadithBox, 1);
            var rightGrid = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){Height = GridLength.Auto},
                    new RowDefinition()
                },
                Children = { toolGrid, hadithBox }
            };

            SetColumn(leftGrid, 1);
            SetRow(leftGrid, 1);
            SetRow(rightGrid, 1);

            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(300) });

            Children.Add(leftGrid);
            Children.Add(rightGrid);

            groupBox.Fired += onSelectionChanged;
            goToBox.KeyUp += onGoToKeyUp;
            TabView.Split += onSplit;
        }

        public abstract void ResetSource(List<HadithContent> source);
        protected abstract void resetgroupBoxSource();

        protected virtual FrameworkElementFactory getHadithTemplate() {
            return new FrameworkElementFactory(typeof(HadithGrid));
        }

        public void UpdateView() {
            listCount.Text = groups.Count.ToString() + " chapters";
            hadithCount.Text = source.Count.ToString("N0") + " hadith in ";
            resetgroupBoxSource();
            groupBox.ScrollIntoView(groups.First());
        }

        void onSelectionChanged(object item) {
            var group = (Tuple<string, List<HadithContent>>)item;
            hadithBox.ItemsSource = group.Item2;

            Helper.FindVisualChild<ScrollViewer>(hadithBox).ScrollToTop();
        }

        void onGoToKeyUp(object sender, KeyEventArgs e) {
            if (e.Key != Key.Enter) return;
            bool isFound = false;
            HadithContent selected = null;
            for (int i = 0; i < groupBox.Items.Count; i++) {
                var item = (Tuple<string, List<HadithContent>>)groupBox.Items[i];
                for (int j = 0; j < item.Item2.Count; j++) {
                    if (item.Item2[j].Number.Contains(",")) {
                        var parts = item.Item2[j].Number.Split(",", StringSplitOptions.TrimEntries);
                        if (!parts.Contains(goToBox.Text)) continue;
                    }
                    else if (!item.Item2[j].Number.Equals(goToBox.Text)) continue;

                    isFound = true;
                    groupBox.SelectedItem = item;
                    selected = item.Item2[j];
                    groupBox.ScrollIntoView(groupBox.SelectedItem);
                    break;
                }
            }
            if (!isFound) return;

            hadithBox.SelectedItem = selected;
            hadithBox.LayoutUpdated += onLayoutUpdated;
        }

        void onLayoutUpdated(object? sender, EventArgs e) {
            hadithBox.LayoutUpdated -= onLayoutUpdated;
            App.Current.Dispatcher.InvokeAsync(() => {
                hadithBox.ScrollIntoView(hadithBox.SelectedItem);
                var panel = Helper.FindVisualChild<VirtualizingStackPanel>(hadithBox);
                var items = Helper.FindVisualChildren<ListBoxItem>(panel);
                var selected = ((HadithContent)hadithBox.SelectedItem).Number;

                foreach (var item in items) {
                    var presenter = Helper.FindVisualChild<ContentPresenter>(item);
                    var hadith = (HadithContent)presenter.Content;
                    if (hadith.Number.Equals(selected)) {
                        presenter.BringIntoView();
                        break;
                    }
                }
            }, DispatcherPriority.Background);
        }

        void onSplit() => hadithBox.Items.Refresh();

        public void Unload() {
            groupBox.Fired -= onSelectionChanged;
            goToBox.KeyUp -= onGoToKeyUp;
            TabView.Split -= onSplit;
        }
    }

    class HadithGrid : Grid {
        TextBoxArabic arIsnad, arMatan, arGrade, arSection, comment;
        TextBoxEnglish enIsnad, enMatan, enGrade, enSection;

        public HadithGrid() {
            arSection = new TextBoxArabic() { Foreground = Brushes.Wheat };
            arIsnad = new TextBoxArabic() { Foreground = Brushes.Gray };
            arMatan = new TextBoxArabic();
            arGrade = new TextBoxArabic() { Foreground = Brushes.LightSkyBlue };
            comment = new TextBoxArabic() { Foreground = Brushes.Gray };

            enSection = new TextBoxEnglish() { Foreground = Brushes.Wheat };
            enIsnad = new TextBoxEnglish() { Foreground = Brushes.Gray };
            enMatan = new TextBoxEnglish();
            enGrade = new TextBoxEnglish() { Foreground = Brushes.LightSkyBlue };

            SetColumn(enSection, 1);
            SetColumn(enIsnad, 1);
            SetColumn(enMatan, 1);
            SetColumn(enGrade, 1);

            SetRow(arIsnad, 1);
            SetRow(arMatan, 2);
            SetRow(arGrade, 3);
            SetRow(enIsnad, 1);
            SetRow(enMatan, 2);
            SetRow(enGrade, 3);
            SetRow(comment, 4);

            SetColumnSpan(comment, 2);

            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1.25, GridUnitType.Star) });
            ColumnDefinitions.Add(new ColumnDefinition());
            RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            RowDefinitions.Add(new RowDefinition());
            RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
            RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

            Children.Add(arSection);
            Children.Add(enSection);
            Children.Add(arIsnad);
            Children.Add(enIsnad);
            Children.Add(arMatan);
            Children.Add(enMatan);
            Children.Add(arGrade);
            Children.Add(enGrade);
            Children.Add(comment);

            Resources.Add(typeof(TextBoxEnglish), new Style() {
                Setters = {
                            new Setter(TextBoxEnglish.ForegroundProperty, Constants.Foreground),
                            new Setter(TextBoxEnglish.TextWrappingProperty, TextWrapping.Wrap),
                            new Setter(TextBoxEnglish.VerticalContentAlignmentProperty, VerticalAlignment.Center),
                            new Setter(TextBoxEnglish.FlowDirectionProperty, FlowDirection.LeftToRight)
                        }
            });
            Resources.Add(typeof(TextBoxArabic), new Style() {
                Setters = {
                            new Setter(TextBoxArabic.ForegroundProperty, Constants.Foreground),
                            new Setter(TextBoxArabic.TextWrappingProperty, TextWrapping.Wrap),
                            new Setter(TextBoxArabic.VerticalContentAlignmentProperty, VerticalAlignment.Center)
                        }
            });
        }

        public override void EndInit() {
            base.EndInit();
            var c = (HadithContent)DataContext;
            var s = App.hadithSections.First(x => x.Id == c.SectionId);

            comment.Visibility = string.IsNullOrEmpty(c.ArabicComment) ? Visibility.Collapsed : Visibility.Visible;
            enSection.Visibility = s.English.Equals("nan") ? Visibility.Collapsed : Visibility.Visible;
            arSection.Visibility = s.Arabic.Equals("nan") ? Visibility.Collapsed : Visibility.Visible;

            arIsnad.Text = c.ArabicIsnad;
            arMatan.Text = c.ArabicMatan;
            arGrade.Text = c.ArabicGrade;

            enIsnad.Text = c.EnglishIsnad;
            enMatan.Text = c.EnglishMatan;
            enGrade.Text = getGrade(c);
            comment.Text = c.ArabicComment;

            enSection.Text = s.English;
            arSection.Text = s.Arabic;
        }

        protected virtual string getGrade(HadithContent c) {
            return
                c.EnglishGrade + "\nHadith no. " +
                c.Number + "\nChapter: " +
                App.hadithChapters.First(x => x.Id == c.ChapterId).Chapter;
        }
    }
}
