﻿class LemmaVM : Notifiable, IAddPage {
    List<Lemma> filtered, source;
    bool isAscending;
    object selected;
    string query;
    public int currentTranscript;
    public string Covered { get; set; }
    public string Count { get; set; }
    public bool IsInProgress { get; set; }
    public List<Lemma> Lemmas { get; set; }

    public List<PageType> Types => new List<PageType>(1) { PageType.Lemma };

    public LemmaVM() {
        filtered = new List<Lemma>();

        Task.Run(() => {
            int count = 0;
            source = new List<Lemma>();
            for (int i = 0; i < App.links.Count; i++) {
                if (!string.IsNullOrEmpty(App.links[i].Root)) continue;
                if (string.IsNullOrEmpty(App.links[i].LemmaCorpus)) continue;

                count++;
                var link = App.links[i];
                var tags = link.Tags.Split('|');
                var indices = link.LemmaIndices.Split('|');
                var corpusLemmas = link.LemmaCorpus.Split('|');
                var simpleLemmas = link.LemmaSimple.Split('|');
                var corpusSegments = link.SegmentsCorpus.Split('|');
                var simpleSegments = link.SegmentsSimple.Split('|');

                for (int j = 0; j < indices.Length; j++) {
                    int index = Convert.ToInt32(indices[j]);
                    var pos = App.tags[Convert.ToInt32(tags[index])].Name;
                    var corpusLemma = App.lemmas[Convert.ToInt32(corpusLemmas[j])];
                    var simpleLemma = App.lemmas[Convert.ToInt32(simpleLemmas[j])];
                    var corpus = App.segments[Convert.ToInt32(corpusSegments[index])];
                    var simple = App.segments[Convert.ToInt32(simpleSegments[index])];
                    var references = new List<string>() { link.Reference };
                    source.Add(new Lemma() {
                        Transcripts = new string[] { corpus, simple },
                        Root = new string[] { corpusLemma, simpleLemma },
                        POS = pos,
                        References = references
                    });
                }
            }

            var groups = source.GroupBy(x => x.Root[App.global.Transcript]).ToList();

            for (int i = 0; i < groups.Count; i++) {
                if (groups[i].Count() == 1) {
                    filtered.Add(new Lemma(groups[i].ElementAt(0)));
                    continue;
                }
                var group = groups[i];
                var transcripts = new string[2];
                transcripts[App.global.Transcript] = group.Key;

                var le = new Lemma() { Transcripts = transcripts };
                le.Items = new List<Lemma>();

                for (int j = 0; j < group.Count(); j++) {
                    Lemma item = group.ElementAt(j), match = null;
                    int k = 0, l = le.Items.Count - 1;
                    while (k <= l) {
                        if (le.Items[k].Transcripts[App.global.Transcript].Equals(item.Transcripts[App.global.Transcript])
                            && le.Items[k].POS.Equals(item.POS)) {
                            match = le.Items[k];
                            break;
                        }
                        if (le.Items[l].Transcripts[App.global.Transcript].Equals(item.Transcripts[App.global.Transcript])
                            && le.Items[l].POS.Equals(item.POS)) {
                            match = le.Items[l];
                            break;
                        }
                        k++;
                        l--;
                    }
                    if (match is null) le.Items.Add(new Lemma(item));
                    else match.References.AddRange(item.References);
                }
                if (le.Items.Count == 1) {
                    filtered.Add(le.Items[0]);
                }
                else {
                    le.POS = string.Join("|", le.Items.Select(x => x.POS).Distinct());
                    filtered.Add(le);
                }
            }
            
            currentTranscript = App.global.Transcript;
            Filter("");
            App.Current.Dispatcher.Invoke(() => {
                Covered = count.ToString("N0") + " words covered";
                OnPropertyChanged(nameof(Covered));
            });
        });
    }

    public void Regroup() {
        filtered.Clear();
        int index = App.global.Transcript;
        var groups = source.GroupBy(x => x.Root[index]).ToList();

        foreach (var group in groups) {
            if (group.Count() == 1) {
                filtered.Add(new Lemma(group.ElementAt(0)));
                continue;
            }
            var transcripts = new string[2];
            transcripts[App.global.Transcript] = group.Key;

            var le = new Lemma() { Transcripts = transcripts };
            le.Items = new List<Lemma>();
            foreach (var item in group) {
                var match = le.Items.FirstOrDefault(x => x.Transcripts[App.global.Transcript].Equals(item.Transcripts[App.global.Transcript]) && x.POS.Equals(item.POS));
                if (match is null) {
                    le.Items.Add(new Lemma(item));
                }
                else {
                    match.References.AddRange(item.References);
                }
            }
            if (le.Items.Count == 1) {
                filtered.Add(le.Items[0]);
            }
            else {
                le.POS = string.Join("|", le.Items.Select(x => x.POS).Distinct());
                filtered.Add(le);
            }
        }
        Filter(query);
        currentTranscript = App.global.Transcript;
    }

    public void Sort() {
        isAscending = !isAscending;
        Filter(query);
    }

    public void Filter(string query) {
        IsInProgress = true;
        OnPropertyChanged(nameof(IsInProgress));
        this.query = query;

        Task.Run(() => {
            int rootCount = 0;
            int formCount = 0;
            Lemmas = new List<Lemma>();

            if (string.IsNullOrEmpty(query)) {
                for (int i = 0; i < filtered.Count; i++) {
                    rootCount++;
                    formCount += filtered[i].Items is null ? 1 : filtered[i].Items.Count;
                    Lemmas.Add(filtered[i]);
                }
            }
            else {
                for (int i = 0; i < filtered.Count; i++) {
                    if (!filtered[i].Transcripts[App.global.Transcript].Contains(query)) continue;

                    Lemmas.Add(filtered[i]);
                    rootCount++;
                    formCount += filtered[i].Items is null ? 1 : filtered[i].Items.Count;
                }
            }

            Lemmas.Sort(new Comparator(isAscending));

            App.Current.Dispatcher.Invoke(() => {
                Count = $"{formCount.ToString("N0")} spelling in {rootCount.ToString("N0")} lemma";
                IsInProgress = false;
                OnPropertyChanged(nameof(Count));
                OnPropertyChanged(nameof(IsInProgress));
                OnPropertyChanged(nameof(Lemmas));
            });
        });
    }

    public void UpdateSource(object item) => selected = item;

    public void AddPage() => ((App)Application.Current).FocusedControl.addLemmaPage(selected);

    public void ResetPage() => ((LemmaPage)((App)Application.Current).FocusedControl.SelectedPage).setContent(selected);

    class Comparator : IComparer<Lemma> {
        bool isAscending;
        public Comparator(bool isAscending) {
            this.isAscending = isAscending;
        }

        public int Compare(Lemma? x, Lemma? y) {
            int sumX = x.Items is null ? x.References.Count : x.Items.Sum(x => x.References.Count); 
            int sumY = y.Items is null ? y.References.Count : y.Items.Sum(x => x.References.Count);
            return isAscending ? sumX - sumY : sumY - sumX;
        }
    }
}