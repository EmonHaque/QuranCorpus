﻿class PatternVM : Notifiable, IAddPage {
    string query;
    Pattern selected;
    List<PatternSegment> source, filtered;
    public ICollectionView Patterns { get; set; }
    public bool IsInProgress { get; set; }
    public int RootCount { get; set; }
    public int ReferenceCount { get; set; }
    public List<PageType> Types => new List<PageType>(1) { PageType.Pattern };

    public PatternVM() {
        IsInProgress = true;
        Task.Run(() => {
            source = new List<PatternSegment>();
            var patterns =
                System.IO.File.ReadAllLines("Resources/rootPatterns.txt")
                .Select(x => new Pattern() { Root = x })
                .ToList();

            for (int i = 0; i < App.links.Count; i++) {
                if (string.IsNullOrEmpty(App.links[i].Root)) continue;
            
                var seg = App.links[i];
                string root;
                int index;
                if (App.links[i].Root.Contains('|')) {
                    var roots = App.links[i].Root.Split('|');
                    index = Convert.ToInt32(seg.RootIndex);
                    for (int j = 0; j < roots.Length; j++) {
                        root = App.roots[Convert.ToInt32(roots[j])];
                        addPattern(root, seg, index);
                        index++;
                    }
                }
                else {
                    root = App.roots[Convert.ToInt32(seg.Root)];
                    index = Convert.ToInt32(seg.RootIndex);
                    addPattern(root, seg, index);
                }
                
            }

            void addPattern(string root, Link seg, int index) {
                string pattern = "";
                if (root.Length == 3) {
                    pattern += getCharacter(root[0]);
                    if (root[0] == root[1]) {
                        pattern += '~';
                        pattern += getCharacter(root[2]);
                    }
                    else if (root[1] == root[2]) {
                        pattern += getCharacter(root[1]);
                        pattern += '~';
                    }
                    else {
                        pattern += getCharacter(root[1]);
                        pattern += getCharacter(root[2]);
                    }
                }
                else {
                    if (root[0] == root[2] && root[1] == root[3]) {
                        pattern = "-+-+";
                    }
                    else pattern = "++++";
                }

                var refs = seg.Reference.Substring(0, seg.Reference.LastIndexOf(':') + 1);
                var r = patterns.First(x => x.Root.Equals(pattern));
                var m = r.Roots.FirstOrDefault(x => x.Item1.Equals(root));
                if (m is null) {
                    r.Roots.Add(new Tuple<string, List<string>>(root, new List<string>() { refs }));
                }
                else m.Item2.Add(refs);

                var tags = seg.Tags.Split('|');
                var spellings = seg.SegmentsCorpus.Split('|');
                var details = seg.Details.Split(',');

                var tag = App.tags[Convert.ToInt32(tags[index])].Name;
                var spell = App.segments[Convert.ToInt32(spellings[index])];

                if (spell.Length > 1 && spell[1] == '~') {
                    spell = spell.Remove(1, 1);
                }
                var pos = new PatternSegment() {
                    Root = root,
                    Pattern = pattern,
                    Tag = tag,
                    Spelling = spell
                };
                setDetail(details[index], pos);

                var next = index + 1;
                bool hasSuffix = false;

                if (tags.Length - 1 > index) {
                    tag = App.tags[Convert.ToInt32(tags[index + 1])].Name;
                    if (tag.Equals("SUFF")) {
                        var group = App.spellings[Convert.ToInt32(seg.SpellingGroupSimple.Split('|')[index + 1])];
                        spell = App.segments[Convert.ToInt32(spellings[index + 1])];
                        if (!(group.Equals("_wna") ||
                              group.Equals("_yna") ||
                              group.Equals(".na") ||
                              group.Equals("_p") ||
                              group.Equals("_t") ||
                              group.Equals("_A") ||
                              group.Equals("_`t") ||
                              group.Equals("_At") ||
                              group.Equals("_`ni") ||
                              group.Equals("_Ani") ||
                              group.Equals("_ayni") ||
                              group.Equals("_ay") ||
                              group.Equals("_y~"))) {
                            pos.Spelling = pos.Spelling + spell;
                        }
                        else hasSuffix = true;
                    }
                    else if (tag.Equals("PRON") || tag.Equals("BRID")) hasSuffix = true;
                }

                if (!pos.Tag.Equals("V")) {
                    var expIndex = seg.Explanation.Split('|')[index];
                    if (!string.IsNullOrEmpty(expIndex)) {
                        var explanation = App.explanations[Convert.ToInt32(expIndex)];
                        if (explanation.Contains("plural")) {
                            if (string.IsNullOrEmpty(pos.SubTag)) {
                                pos.Number = "Plural";
                            }
                        }
                        else if (explanation.Contains("dual")) {
                            if (string.IsNullOrEmpty(pos.SubTag)) {
                                pos.Number = "Dual";
                            }
                        }
                    }
                }

                string spelling = pos.Spelling.Replace(":", "");
                if (spelling.Equals("mu") || spell.Equals("mi")) {
                    spelling = spelling + "t";
                }

                if (spelling.EndsWith("A@") || spelling.EndsWith("A\"")) {
                    spelling = spelling.Remove(spelling.Length - 2);
                }

                if (spelling.EndsWith('a') ||
                    spelling.EndsWith('u') ||
                    spelling.EndsWith('i') ||
                    spelling.EndsWith('N') ||
                    spelling.EndsWith('K') ||
                    spelling.EndsWith('o')) {
                   spelling = spelling.Remove(spelling.Length - 1);
                }
                else if (spelling.EndsWith("FA") ||
                         spelling.EndsWith("u[") ||
                         spelling.EndsWith("a[") ||
                         spelling.EndsWith("i]")) {
                    spelling = spelling.Remove(spelling.Length - 2);
                }
                else if (spelling.EndsWith("a[A")) {
                    spelling = spelling.Remove(spelling.Length - 3);
                }
                else if (spelling.EndsWith("F")) {
                    spelling = spelling.Remove(spelling.Length - 1);
                }

                if (spelling.Contains('[')) {
                    spelling = spelling.Replace("[", "");
                }

                if (spelling.StartsWith("_#")) {
                    spelling = "'" + spelling.Substring(2);
                }
                else if(spelling.StartsWith('}') ||
                        spelling.StartsWith('&')) {
                    spelling = "'" + spelling.Substring(1);
                }

                if ((spelling.EndsWith('}') ||
                    spelling.EndsWith('&') ||
                    spelling.EndsWith('>') ||
                    spelling.EndsWith('<'))) {
                    spelling = spelling.Remove(spelling.Length - 1) + "'";
                }
                else if (spelling.EndsWith("_#") ||
                         spelling.EndsWith(')')) {
                    spelling = spelling.Remove(spelling.Length - 2) + "'";
                }

                pos.Spelling = spelling;

                PatternSegment match = null;
                int j = 0, k = source.Count - 1;

                while (j <= k) {
                    if (source[j].Pattern.Equals(pos.Pattern) &&
                        source[j].Spelling.Equals(pos.Spelling) &&
                        source[j].Tag.Equals(pos.Tag) &&
                        source[j].SubTag.Equals(pos.SubTag) &&
                        source[j].Root.Equals(pos.Root) &&
                        source[j].Number.Equals(pos.Number) &&
                        source[j].Form.Equals(pos.Form)) {
                        match = source[j];
                        break;
                    }
                    if (source[k].Pattern.Equals(pos.Pattern) &&
                        source[k].Spelling.Equals(pos.Spelling) &&
                        source[k].Tag.Equals(pos.Tag) &&
                        source[k].SubTag.Equals(pos.SubTag) &&
                        source[k].Root.Equals(pos.Root) &&
                        source[k].Number.Equals(pos.Number) &&
                        source[k].Form.Equals(pos.Form)) {
                        match = source[k];
                        break;
                    }
                    j++;
                    k--;
                }

                if (match is null) {
                    pos.Reference = new List<string>() { seg.Reference };
                    source.Add(pos);
                }
                else match.Reference.Add(seg.Reference);
            }
            
            query = "";
            updateCounts();
            App.Current.Dispatcher.Invoke(() => {
                Patterns = CollectionViewSource.GetDefaultView(patterns);
                Patterns.Filter = filter;
                IsInProgress = false;
                OnPropertyChanged(nameof(RootCount));
                OnPropertyChanged(nameof(ReferenceCount));
                OnPropertyChanged(nameof(Patterns));
                OnPropertyChanged(nameof(IsInProgress));
            });
        });
    }

    char getCharacter(char c) => c switch {
        'A' => 'A',
        'w' => 'w',
        'y' => 'y',
        _ => '+'
    };

    void setDetail(string detail, PatternSegment word) {
        if (string.IsNullOrEmpty(detail)) {
            word.Form = "I";
            word.SubTag = "";
            return;
        }
        var array = detail.Split('|').Select(x => App.details[Convert.ToInt32(x)].Name).ToArray();
        var tag = word.Tag;
        if (App.tagArray.Contains(tag)) {
            for (int i = 0; i < array.Length; i++) {
                if (string.IsNullOrEmpty(array[i])) continue;
                if (array[i].Equals("PCPL") ||
                    array[i].Equals("ACC") ||
                    array[i].Equals("NOM") ||
                    array[i].Equals("GEN") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("ACT")) word.SubTag = "Active Participle";
                else if (array[i].Equals("PASS")) word.SubTag = "Passive Participle";
                else if (array[i].Equals("VN")) word.SubTag = "Verbal Noun";
                else if (array[i].Equals("IN")) word.SubTag = "Noun";
                else if (array[i].Equals("CN")) word.SubTag = "Noun";
                else if (array[i].Equals("IP")) word.SubTag = "Particle";
                else if (array[i].Equals("CP")) word.SubTag = "Particle";
                else if (array[i].StartsWith('(')) word.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
            }
            if (string.IsNullOrEmpty(word.Form)) word.Form = "I";
            if (string.IsNullOrEmpty(word.SubTag)) word.SubTag = "";
        }
        else if (tag.Equals("V")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUBJ") ||
                    array[i].Equals("JUS") ||
                    array[i].Equals("JUSS") ||
                    array[i].Equals("SP:kaAn") ||
                    array[i].Equals("SP:kaAd") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("IMPF")) word.SubTag = "Imperfect";
                else if (array[i].Equals("PASS")) word.SubTag += " Passive";
                else if (array[i].Equals("IMPV")) word.SubTag = "Imperative";
                else if (array[i].Equals("PERF")) word.SubTag = "Perfect";
                else if (array[i].StartsWith('(')) word.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
            }
            if (string.IsNullOrEmpty(word.Form)) word.Form = "I";
            if (string.IsNullOrEmpty(word.SubTag)) word.SubTag = "";
        }
    }

    bool filter(object o) {
        return string.IsNullOrEmpty(query) ?
            true : ((Pattern)o).Root.Contains(query);

    }

    void updateCounts() {
        var sub = source.Where(x => x.Pattern.Contains(query));
        RootCount = sub.Select(x => x.Root).Distinct().Count();
        ReferenceCount = sub.Sum(x => x.Reference.Count);
    }

    public void Filter(string query) {
        this.query = query;
        Patterns.Refresh();
        updateCounts();
        OnPropertyChanged(nameof(RootCount));
        OnPropertyChanged(nameof(ReferenceCount));
    }

    public void UpdateSource(object item) {
        selected = (Pattern)item;
        filtered = source.Where(x => x.Pattern.Equals(selected.Root)).ToList();
    }

    public void AddPage() => ((App)Application.Current).FocusedControl.addPatternPage(selected, filtered);

    public void ResetPage() => ((PatternPage)((App)Application.Current).FocusedControl.SelectedPage).setContent(selected, filtered);

    public void AddConsolidatedPage() => ((App)Application.Current).FocusedControl.addPatternPage(source);

    public void AddUniquePage() => ((App)Application.Current).FocusedControl.addPatternGroupPage(source);
}
