﻿class PronounVM : Notifiable, IAddPage {
    List<Conjugated> source;
    List<Conjugated> filtered;

    public List<string> Items { get; set; }
    public bool IsInProgress { get; set; }

    public List<PageType> Types => new List<PageType>(1) { PageType.Pronoun };

    public PronounVM() {
        IsInProgress = true;

        Task.Run(() => {
            source = new List<Conjugated>();
            var pronIndex = App.tags.IndexOf(App.tags.First(x => x.Name.Equals("PRON"))).ToString();

            for (int i = 0; i < App.links.Count; i++) {
                var tas = App.links[i].Tags.Split('|');
                if (tas.Length == 1) continue;

                for (int index = 0; index < tas.Length; index++) {
                    if (!tas[index].Equals(pronIndex)) continue;

                    var link = App.links[i];
                    string pronounForm = "";
                    string pronounDetail = "";
                    var detailArray = link.Details.Split(',')[index].Split('|');
                    if (detailArray.Length > 1) {
                        pronounDetail = App.details[Convert.ToInt32(detailArray[0])].Value;
                        pronounForm = App.details[Convert.ToInt32(detailArray[1])].Name;
                    }
                    else pronounForm = App.details[Convert.ToInt32(detailArray[0])].Name;

                    var corpus = link.SpellingGroupCorpus.Split('|');
                    var simple = link.SpellingGroupSimple.Split('|');

                    var word = new Conjugated() {
                        Person = pronounForm,
                        As = pronounDetail,
                        To = App.tags[Convert.ToInt32(tas[index - 1])].Name,
                        Word = new string[] {
                            App.spellings[Convert.ToInt32(corpus[index - 1])],
                            App.spellings[Convert.ToInt32(simple[index - 1])]
                        },
                        Pronoun = new string[] {
                            App.spellings[Convert.ToInt32(corpus[index])],
                            App.spellings[Convert.ToInt32(simple[index])]
                        }
                    };
                    Conjugated match = null;
                    int j = 0, k = source.Count - 1;
                    while (j <= k) {
                        if (source[j].Person.Equals(word.Person) &&
                            source[j].To.Equals(word.To) &&
                            source[j].Word[0].Equals(word.Word[0]) &&
                            source[j].Word[1].Equals(word.Word[1]) &&
                            source[j].Pronoun[0].Equals(word.Pronoun[0]) &&
                            source[j].Pronoun[1].Equals(word.Pronoun[1])) {
                            match = source[j];
                            break;
                        }
                        if (source[k].Person.Equals(word.Person) &&
                            source[k].To.Equals(word.To) &&
                            source[k].Word[0].Equals(word.Word[0]) &&
                            source[k].Word[1].Equals(word.Word[1]) &&
                            source[k].Pronoun[0].Equals(word.Pronoun[0]) &&
                            source[k].Pronoun[1].Equals(word.Pronoun[1])) {
                            match = source[k];
                            break;
                        }
                        j++;
                        k--;
                    }
                    if (match is null) {
                        source.Add(word);
                        word.References.Add(link.Reference);
                    }
                    else match.References.Add(link.Reference);
                }
            }

            Items = source.Select(x => x.Person).Distinct().ToList();
            IsInProgress = false;

            App.Current.Dispatcher.Invoke(() => {
                OnPropertyChanged(nameof(Items));
                OnPropertyChanged(nameof(IsInProgress));
            });
        });
    }

    public void UpdateSource(object item) => filtered = source.Where(x => x.Person.Equals(item.ToString())).ToList();
    
    public void AddPage() => ((App)Application.Current).FocusedControl.addPronounPage(filtered);

    public void ResetPage() => ((PronounPage)((App)Application.Current).FocusedControl.SelectedPage).setContent(filtered);
}
