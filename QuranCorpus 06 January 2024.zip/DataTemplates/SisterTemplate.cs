﻿class SisterTemplate : Grid {
    TextBlockArabic arabic;
    TextBlockEnglish count;

    public SisterTemplate() {
        arabic = new TextBlockArabic();
        count = new TextBlockEnglish() { VerticalAlignment = VerticalAlignment.Center };

        SetColumn(count, 1);
        Children.Add(arabic);
        Children.Add(count);
    }
    public override void EndInit() {
        base.EndInit();
        var c = (Sister)DataContext;
        var index = Convert.ToInt32(c.Spellings[App.global.Transcript]);
        arabic.Text = App.spellings[index].toArabic();
        count.Text = c.References.Count.ToString();
    }
}

