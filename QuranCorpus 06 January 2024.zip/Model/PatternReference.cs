﻿class PatternReference {
    public string Spelling { get; set; }
    public string Root { get; set; }
    public List<string> Tags { get; set; }
    public List<string> References { get; set; }
}
