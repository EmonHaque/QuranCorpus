﻿class DroppedData {
    public IList Items { get; set; }
    public object Element { get; set; }
}
