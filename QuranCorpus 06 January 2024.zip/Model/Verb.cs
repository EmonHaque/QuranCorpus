﻿class Verb {
    public string[] Simple { get; set; }
    public string[] Corpus { get; set; }
    public string SimpleFull { get; set; }
    public string CorpusFull { get; set; }
    public string[] Lemma { get; set; }
    public string Gender { get; set; }
    public string Person { get; set; }
    public string Number { get; set; }
    public string Form { get; set; }
    public string Mood { get; set; }
    public string Tense { get; set; }
    public string Voice { get; set; }
    public string Root { get; set; }
    public List<string> References { get; set; } = new();
    public bool IsSorted { get; set; }

    public Verb() { }

    public Verb(Verb rhs) {
        Simple = rhs.Simple;
        Corpus = rhs.Corpus;
        SimpleFull = rhs.SimpleFull;
        CorpusFull = rhs.CorpusFull;
        Lemma = rhs.Lemma;
        Gender = rhs.Gender;
        Person = rhs.Person;
        Number = rhs.Number;
        Form = rhs.Form;
        Mood = rhs.Mood;
        Tense = rhs.Tense;
        Voice = rhs.Voice;
        Root = rhs.Root;
        References = new List<string>(rhs.References);
    }
}
