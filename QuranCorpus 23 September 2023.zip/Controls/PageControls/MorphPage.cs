﻿class MorphPage : Page {
    string indexMa;
    Grid content;
    StringBuilder builder = new();

    Run morphCount, morphTotal;
    TextBlockEnglish meaningCount;
    List<Morph> morphs;
    ListBox listMorph, listMeaning;
    TagCount tags;
    public override PageType Type => PageType.Morph;
    public override UIElement Content => content;

    public MorphPage() {
        indexMa = "|" + ((App)Application.Current).indexMa;

        tags = new TagCount() { FlowDirection = FlowDirection.LeftToRight };

        morphCount = new Run();
        morphTotal = new Run();
        var listCountBlock = new TextBlockEnglish() {
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center,
            Inlines = { morphTotal, new Run(" in "), morphCount }
        };
        meaningCount = new TextBlockEnglish() {
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Right
        };

        listMorph = new ListBox() {
            Margin = new Thickness(0, 5, 0, 0),
            FlowDirection = FlowDirection.RightToLeft,
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MorphListTemplate))
            },
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()),
                        }
                    }
                }}
        };
        listMorph.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMorph.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        listMorph.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        listMeaning = new ListBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 0, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MeaningListTemplate))
            }
        };
        listMeaning.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMeaning.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        listMeaning.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        Grid.SetRow(tags, 1);
        Grid.SetRow(listCountBlock, 1);
        Grid.SetRow(meaningCount, 1);
        Grid.SetRow(listMorph, 2);
        Grid.SetRow(listMeaning, 2);
        Grid.SetColumn(listMeaning, 1);
        Grid.SetColumn(meaningCount, 1);

        content = new Grid() {
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = new GridLength(1.5, GridUnitType.Star)},
                new ColumnDefinition()
            },
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { tags, listMorph, listCountBlock, meaningCount, listMeaning }
        };

        morphCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMorph,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        meaningCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMeaning,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });

        tags.SelectionChanged += onTagSelectionChanged;
        listMorph.SelectionChanged += onMorphSelectionChanged;
        listMeaning.MouseDoubleClick += onMeaningDoubleClick;
    }

    public MorphPage(string spelling) : this() {

        morphs = new List<Morph>();

        for (int i = 0; i < App.links.Count; i++) {
            if (string.IsNullOrEmpty(App.links[i].Root)) continue;
            var link = App.links[i];

            var spellings = link.SpellingGroupSimple.Split('|').Select(x => App.spellings[Convert.ToInt32(x)]).ToArray();
            if (!spellings.Contains(spelling)) continue;

            morphs.Add(getMorph(link));
        }

        tags.Items = morphs.GroupBy(x => x.Gender).Select(x => new TagCount.TagItem() {
            Name = x.Key,
            Count = x.Count()
        }).ToList();

        HeaderText = "(" + tags.Items.Count + ") " + spelling.toArabic();

        tags.Selected = tags.Items.First();
        onTagSelectionChanged(tags.Selected);
    }

    void onTagSelectionChanged(TagCount.TagItem obj) {
        var listSource = morphs.Where(x => x.Gender.Equals(obj.Name))
            .GroupBy(x => new { Word = x.Segments[1], x.Explanation })
              .Select(x => new Morph() {
                  Segments = x.First().Segments,
                  Count = x.Count(),
                  Tags = x.First().Tags,
                  Explanation = x.Key.Explanation,
                  References = x.SelectMany(x => x.References).ToList()
              })
              .OrderByDescending(x => x.Count)
              .ToList();
        morphTotal.Text = listSource.Sum(x => x.Count).ToString();
        listMorph.ItemsSource = listSource;
    }

    void onMorphSelectionChanged(object sender, SelectionChangedEventArgs e) {
        if (listMorph.SelectedItem is null) {
            listMeaning.ItemsSource = null;
            return;
        }
        //var iterator = App.links.GetEnumerator();
        //iterator.MoveNext();

        listMeaning.ItemsSource = ((Morph)listMorph.SelectedItem).References;
    }

    void onMeaningDoubleClick(object sender, MouseButtonEventArgs e) {
        if (listMeaning.SelectedItem is null) return; // can be null?
        var item = (Tuple<string, string, string>)listMeaning.SelectedItem;
        ((App)Application.Current).FocusedControl.addSurahPage(item.Item1);
    }

    Morph getMorph(Link item) {
        string tag = "";
        string[] tags;
        string details = "";

        details = item.Details.Split(',')[Convert.ToInt32(item.RootIndex)];
        details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
        int lIndex;
        if (item.LemmaSimple.EndsWith(indexMa)) {
            // in 8 cases it ends with maA
            lIndex = 0;
        }
        else {
            lIndex = item.LemmaIndices.Contains('|') ?
                Convert.ToInt32(item.LemmaIndices.Split('|')[0]) :
                Convert.ToInt32(item.LemmaIndices);
        }

        tags = item.Tags.Split('|');
        tag = App.tags[Convert.ToInt32(tags[lIndex])].Name;


        Morph t = new() {
            Tag = tag,
            Tags = tags,
            Segments = Helper.getSegments(item),
            Spellings = getSpellings(item)
        };
        builder.Clear();
        item.explain(builder);

        t.Explanation = builder.ToString();
        t.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));

        var array = details.Split('|');
        if (App.tagArray.Contains(tag)) {
            for (int i = 0; i < array.Length; i++) {
                if (string.IsNullOrEmpty(array[i])) continue;
                if (array[i].Equals("PCPL") ||
                    array[i].Equals("ACC") ||
                    array[i].Equals("NOM") ||
                    array[i].Equals("GEN") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("ACT")) t.SubTag = "Active Participle";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive Participle";
                else if (array[i].Equals("VN")) t.SubTag = "Verbal Noun";
                else if (array[i].Equals("IN")) t.SubTag = "Noun";
                else if (array[i].Equals("CN")) t.SubTag = "Noun";
                else if (array[i].Equals("IP")) t.SubTag = "Particle";
                else if (array[i].Equals("CP")) t.SubTag = "Particle";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("V")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUBJ") ||
                    array[i].Equals("JUS") ||
                    array[i].Equals("JUSS") ||
                    array[i].Equals("SP:kaAn") ||
                    array[i].Equals("SP:kaAd") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("IMPF")) t.SubTag = "Imperfect";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive";
                else if (array[i].Equals("IMPV")) t.SubTag = "Imperative";
                else if (array[i].Equals("PERF")) t.SubTag = "Perfect";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("PRON")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUB")) t.SubTag = "Subject";
                else if (array[i].Equals("OBJ")) t.SubTag = "Object";
                else if (array[i].Equals("PER")) t.SubTag = "Personal";
                else if (array[i].Equals("POS")) t.SubTag = "Possessive";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name;
                else t.Gender = Helper.getGender(array[i]).Name;
            }
        }
        return t;

        string[] getSpellings(Link item) {
            int lIndex;
            if (item.LemmaSimple.EndsWith(indexMa)) {
                // in 8 cases it ends with maA
                lIndex = 0;
            }
            else {
                if (string.IsNullOrEmpty(item.LemmaIndices)) {
                    return new string[] {
                        item.SpellingGroupCorpus,
                        item.SpellingGroupSimple
                    };
                }

                lIndex = item.LemmaIndices.Contains('|') ?
                    Convert.ToInt32(item.LemmaIndices.Split('|')[0]) :
                    Convert.ToInt32(item.LemmaIndices);
            }
            return new string[] {
                item.SpellingGroupCorpus.Split('|')[lIndex],
                item.SpellingGroupSimple.Split('|')[lIndex]
            };
        }
    }

    protected override void unload() {
        tags.SelectionChanged -= onTagSelectionChanged;
        listMorph.SelectionChanged -= onMorphSelectionChanged;
        listMeaning.MouseDoubleClick -= onMeaningDoubleClick;
        base.unload();
    }
}
