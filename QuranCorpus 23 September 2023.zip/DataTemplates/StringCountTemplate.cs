﻿class StringCountTemplate : Grid {
    TextBlockEnglish gender, count;
    public StringCountTemplate() {
        gender = new TextBlockEnglish();
        count = new TextBlockEnglish() { HorizontalAlignment = HorizontalAlignment.Right };
        SetColumn(count, 1);
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition());
        Children.Add(gender);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var c = (Tuple<string, int>)DataContext;
        gender.Text = c.Item1;
        count.Text = c.Item2.ToString("N0");
    }
}
