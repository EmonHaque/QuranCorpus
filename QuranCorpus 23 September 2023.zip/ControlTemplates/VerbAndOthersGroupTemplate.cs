﻿class VerbAndOthersGroupTemplate : ControlTemplate {
    public VerbAndOthersGroupTemplate() {
        TargetType = typeof(GroupItem);
        var grid = new FrameworkElementFactory(typeof(Grid));
        var row1 = new FrameworkElementFactory(typeof(RowDefinition));
        var row2 = new FrameworkElementFactory(typeof(RowDefinition));
        var name = new FrameworkElementFactory(typeof(TextBlockEnglish)) { Name = "block" };
        var items = new FrameworkElementFactory(typeof(ItemsPresenter));

        row1.SetValue(RowDefinition.HeightProperty, GridLength.Auto);
        name.SetValue(TextBlockEnglish.FontWeightProperty, FontWeights.Bold);
        items.SetValue(Grid.RowProperty, 1);
        items.SetValue(ItemsPresenter.MarginProperty, new Thickness(7.5, 0, 0, 0));
        name.SetValue(TextBlockEnglish.ForegroundProperty, Brushes.Gray);
        name.SetBinding(TextBlockEnglish.TextProperty, new Binding(nameof(GroupItem.Name)));
       
        grid.AppendChild(row1);
        grid.AppendChild(row2);
        grid.AppendChild(name);
        grid.AppendChild(items);

        VisualTree = grid;

        Triggers.Add(new DataTrigger() {
            Binding = new Binding(nameof(CollectionViewGroup.IsBottomLevel)),
            Value = true,
            Setters = {
                new Setter(TextBlockEnglish.FontStyleProperty, FontStyles.Italic, "block")
            }
        });
    }
}
