﻿class TagPanel : WrapPanel {
    List<string> items;
    public List<string> Items {
        get { return items; }
        set {
            items = value;
            Children.Clear();
            for (int i = 0; i < items.Count; i++) {
                var tag = new Tag(items[i]);
                tag.Margin = new Thickness(0, 0, (i == items.Count - 1) ? 0 : 5, 5);
                Children.Add(tag);
            }
        }
    }

    string selected;
    public string Selected {
        get { return selected; }
        set {
            selected = value;
            for (int i = 0; i < Children.Count; i++) {
                var tag = (Tag)Children[i];
                if (!tag.Name.Equals(selected)) {
                    if (tag.IsSelected) tag.IsSelected = false;
                }
                else tag.IsSelected = true;
            }
        }
    }

    public event Action<string> SelectionChanged;

    protected override void OnPreviewMouseLeftButtonUp(MouseButtonEventArgs e) {
        base.OnPreviewMouseLeftButtonUp(e);
        Tag selected = null;
        for (int i = 0; i < Children.Count; i++) {
            var tag = (Tag)Children[i];
            if (Children[i].Equals(e.Source)) {
                tag.IsSelected = true;
                selected = tag;
            }
            else if (tag.IsSelected) tag.IsSelected = false;
        }
        this.selected = selected.Name;
        SelectionChanged?.Invoke(selected.Name);
    }

    public class Tag : Border {
        Brush background;
        TextBlock text;
        bool isSelected;
        public bool IsSelected {
            get { return isSelected; }
            set {
                isSelected = value;
                if (!IsSelected) normalize();
                else highlight();
            }
        }

        public string Name { get; set; }

        public Tag(string name) {
            Name = name;
            text = new TextBlock() { Text = name, IsHitTestVisible = false };
            BorderBrush = Brushes.Gray;
            BorderThickness = new Thickness(Constants.BottomLineThickness);
            CornerRadius = new CornerRadius(10);
            Padding = new Thickness(5, 2.5, 5, 2.5);
            Background = Brushes.Transparent;
            background = new SolidColorBrush(Color.FromArgb(50, 0, 0, 0));
            Child = text;
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            base.OnMouseEnter(e);
            if (IsSelected) return;
            highlight();
        }

        protected override void OnMouseLeave(MouseEventArgs e) {
            base.OnMouseLeave(e);
            if (IsSelected) return;
            normalize();
        }

        void highlight() {
            BorderBrush = Brushes.LightGray;
            Background = background;
        }

        void normalize() {
            BorderBrush = Brushes.Gray;
            Background = Brushes.Transparent;
        }
    }
}
