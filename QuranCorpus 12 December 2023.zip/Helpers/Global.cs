﻿class Global : Notifiable {
    double arabicFontSize;
    public double ArabicFontSize {
        get { return arabicFontSize; }
        set { arabicFontSize = value; OnPropertyChanged(nameof(ArabicFontSize)); }
    }

    double englishFontSize;
    public double EnglishFontSize {
        get { return englishFontSize; }
        set { englishFontSize = value; OnPropertyChanged(nameof(EnglishFontSize)); }
    }
    string arabicFont;
    public string ArabicFont {
        get { return arabicFont; }
        set {
            if (value is null) return;
            arabicFont = value;
            var directory = value.StartsWith("KFGQPC") ? "Resources/KFGQPC/Fonts/#" : "Resources/Fonts/#";
            ArabicFontFamily = new FontFamily(System.IO.Path.GetFullPath(directory) + FontDictionary[ArabicFont]);
            OnPropertyChanged(nameof(ArabicFontFamily));
        }
    }
    int transcript;
    public int Transcript {
        get { return transcript; }
        set { 
            transcript = value == -1 ? 0 : value; 
            OnPropertyChanged(nameof(Transcript)); }
    }

    public bool PopupOnHover { get; set; }
    public bool ColorizeSegments { get; set; }
    public bool Transliteration { get; set; }
    public bool WordByWordTranslation { get; set; }
    public string Translation { get; set; }
    public FontFamily ArabicFontFamily { get; set; }
    public Dictionary<string, string> FontDictionary { get; set; }
    public Dictionary<string, string> TranslationDictionary { get; set; }
    public Dictionary<int, string> TranscriptDictionary { get; set; }
    
    public Global() {
        FontDictionary = new Dictionary<string, string>() {
            { "Al Qalam Quran Majeed", "Al Qalam Quran Majeed Web Regular" },
            { "Amiri Quran", "Amiri Quran"},
            //{ "KFGQPC Uthmanic HAFS", "KFGQPC Uthmanic Script HAFS" },
            //{ "KFGQPC Uthmanic Taha Naskh", "KFGQPC Uthman Taha Naskh Regular" },
            { "KFGQPC Uthmanic HAFS", "KFGQPC HAFS Uthmanic Script" },
            { "KFGQPC Uthmanic Taha Naskh", "KFGQPC Uthman Taha Naskh" },
            { "Scheherazade", "Scheherazade" },
            { "me quran", "me_quran" },
            { "Lateef", "Lateef" },
            { "Droid Naskh", "Droid Arabic Naskh" }
        };
        TranslationDictionary = new Dictionary<string, string>() {
            { "Ahmed Ali", "en.ahmedali.txt" },
            { "Ahmed Raza Khan", "en.ahmedraza.txt" },
            { "A. J. Arberry", "en.arberry.txt" },
            { "Abdul Majid Daryabadi", "en.daryabadi.txt" },
            { "Muhammad Taqi-ud-Din al-Hilali and Muhammad Muhsin Khan ", "en.hilali.txt" },
            { "Talal Itani", "en.itani.txt" },
            { "Abul Ala Maududi", "en.maududi.txt" },
            { "Safi-ur-Rahman al-Mubarakpuri", "en.mubarakpuri.txt" },
            { "Mohammed Marmaduke William Pickthall", "en.pickthall.txt" },
            { "Ali Quli Qarai", "en.qarai.txt" },
            { "Hasan al-Fatih Qaribullah and Ahmad Darwish", "en.qaribullah.txt" },
            { "Saheeh International", "en.sahih.txt" },
            { "Muhammad Sarwar", "en.sarwar.txt" },
            { "Mohammad Habib Shakir", "en.shakir.txt" },
            { "Wahiduddin Khan", "en.wahiduddin.txt" },
            { "Abdullah Yusuf Ali", "en.yusufali.txt" }
        };
        TranscriptDictionary = new Dictionary<int, string>() {
            { 0, "Corpus" },
            { 1, "Simple" },
        };
    }
}
