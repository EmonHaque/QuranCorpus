﻿class VerbVM : Notifiable {
    List<Verb> source;
    List<VerbGroup> items;
    List<Tuple<int, int>> counts;
    public List<Verb> filtered;
    public int currentTranscript;
    VerbGroup selected;
    public VerbGroup Selected {
        get { return selected; }
        set {
            if (value is null) return;
            if (!value.Equals(selected)) {
                selected = value;
                filtered = source.Where(
                    x => x.Gender.Equals(value.Gender) &&
                    x.Person.Equals(value.Person) &&
                    x.Number.Equals(value.Number))
                .ToList();
            }
            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).FocusedControl.SelectedPage is VerbPage verbPage) {
                verbPage.setContent(filtered);
            }
        }
    }
    public int Total { get; set; }
    public bool WasRightClicked { get; set; }
    public bool IsInProgress { get; set; }
    public ICollectionView Items { get; set; }

    public VerbVM() {
        IsInProgress = true;
        Task.Run(() => {
            source = new List<Verb>();
            var verbTag = App.tags.IndexOf(App.tags.First(x => x.Name.Equals("V"))).ToString();
            var pronTag = App.tags.IndexOf(App.tags.First(x => x.Name.Equals("PRON"))).ToString();

            for (int i = 0; i < App.links.Count; i++) {
                var ts = App.links[i].Tags.Split('|');
                bool isMatch = false;
                int index = 0;
                for (int j = 0; j < ts.Length; j++) {
                    if (!ts[j].Equals(verbTag)) continue;
                    index = j;
                    isMatch = true;
                    break;
                }
                if (!isMatch) continue;

                var link = App.links[i];
                var det = link.Details.Split(',');
                var simple = link.SegmentsSimple.Split('|');
                var corpus = link.SegmentsCorpus.Split('|');

                string[] simpleSegments = new string[1];
                string[] corpusSegments = new string[1];

                if (ts.Length > index + 1) {
                    var tag = ts[index + 1];
                    if (tag.Equals(pronTag)) {
                        var array = det[index + 1].Split('|').Select(x => App.details[Convert.ToInt32(x)]).ToArray();
                        for (int k = 0; k < array.Length; k++) {
                            if (!array[k].Name.Equals("SUB")) continue;
                            simpleSegments = new string[2];
                            corpusSegments = new string[2];
                            simpleSegments[1] = App.segments[Convert.ToInt32(simple[index + 1])];
                            corpusSegments[1] = App.segments[Convert.ToInt32(corpus[index + 1])];
                            break;
                        }
                    }
                }
                var gender = "";
                var exp = link.Explanation.Split('|')[index];
                var explanation = App.explanations[Convert.ToInt32(exp)];
                if (explanation.Contains("masculine")) gender = "Masculine";
                else if (explanation.Contains("feminine")) gender = "Feminine";
                else gender = "Undefined";

                string s = App.segments[Convert.ToInt32(simple[index])];
                string c = App.segments[Convert.ToInt32(corpus[index])];

                string corp = "";
                if (c.StartsWith("_#")) corp = c.Replace("_#", "'");
                else if (c.StartsWith('}')) corp = c.Replace('}', '\'');
                corpusSegments[0] = corp;
                simpleSegments[0] = s.StartsWith('}') ? s.Replace('}', '\'') : s;

                var word = new Verb() {
                    Simple = simpleSegments,
                    Corpus = corpusSegments,
                    SimpleFull = string.Join("", simpleSegments),
                    CorpusFull = string.Join("", corpusSegments),
                    Root = App.roots[Convert.ToInt32(link.Root)],
                    Gender = gender,
                    Voice = "",
                    Mood = ""
                };

                var li = link.LemmaIndices.Split('|');
                var leSimple = link.LemmaSimple.Split('|');
                var leCorpus = link.LemmaSimple.Split('|');

                for (int k = 0; k < li.Length; k++) {
                    var idx = Convert.ToInt32(li[k]);
                    if (idx != index) continue;
                    word.Lemma = new string[] {
                        App.lemmas[Convert.ToInt32(leCorpus[k])],
                        App.lemmas[Convert.ToInt32(leSimple[k])]
                    };
                    break;
                }

                setDetail(det[index], word);

                Verb match = null;
                int m = 0, n = source.Count - 1;
                while (m <= n) {
                    if (source[m].SimpleFull.Equals(word.SimpleFull) &&
                        source[m].CorpusFull.Equals(word.CorpusFull) &&
                        source[m].Lemma[0].Equals(word.Lemma[0]) &&
                        source[m].Lemma[1].Equals(word.Lemma[1]) &&
                        source[m].Root.Equals(word.Root) &&
                        source[m].Form.Equals(word.Form) &&
                        source[m].Gender.Equals(word.Gender) &&
                        source[m].Person.Equals(word.Person) &&
                        source[m].Number.Equals(word.Number)) {
                        match = source[m];
                        break;
                    }
                    if (source[n].SimpleFull.Equals(word.SimpleFull) &&
                        source[n].CorpusFull.Equals(word.CorpusFull) &&
                        source[n].Lemma[0].Equals(word.Lemma[0]) &&
                        source[n].Lemma[1].Equals(word.Lemma[1]) &&
                        source[n].Root.Equals(word.Root) &&
                        source[n].Form.Equals(word.Form) &&
                        source[n].Gender.Equals(word.Gender) &&
                        source[n].Person.Equals(word.Person) &&
                        source[n].Number.Equals(word.Number)) {
                        match = source[n];
                        break;
                    }
                    m++;
                    n--;
                }

                if (match is null) {
                    word.References.Add(link.Reference);
                    source.Add(word);
                }
                else match.References.Add(link.Reference);
            }

            var group = source
                .GroupBy(x => x.Gender)
                .Select(x => new {
                    x.Key,
                    Value = x.GroupBy(x => x.Person)
                        .Select(x => new {
                            x.Key,
                            Value = x.GroupBy(x => x.Number).ToList()
                        }).ToList()
                }).ToList();

            counts = new List<Tuple<int, int>>();
            items = new List<VerbGroup>();

            foreach (var gender in group) {
                foreach (var person in gender.Value) {
                    foreach (var number in person.Value) {
                        var count = new Tuple<int, int>(number.Count(), number.GroupBy(x => new { s = x.SimpleFull, x.Voice, x.Mood }).Count());
                        counts.Add(count);
                        items.Add(new VerbGroup() {
                            Gender = gender.Key,
                            Person = person.Key,
                            Number = number.Key
                        });
                    }
                }
            }

            App.Current.Dispatcher.Invoke(() => {
                Regroup();
                Items = CollectionViewSource.GetDefaultView(items);
                Items.GroupDescriptions.Add(new PropertyGroupDescription(nameof(VerbGroup.Gender)));
                Items.GroupDescriptions.Add(new PropertyGroupDescription(nameof(VerbGroup.Person)));
                IsInProgress = false;
                OnPropertyChanged(nameof(Items));
                OnPropertyChanged(nameof(IsInProgress));
            });
        });
    }

    void setDetail(string detail, Verb word) {
        var array = detail.Split('|').Select(x => App.details[Convert.ToInt32(x)]).ToArray();
        for (int i = 0; i < array.Length; i++) {
            if (array[i].Name.Equals("SP:kaAn") ||
                array[i].Name.Equals("SP:kaAd")) continue;

            if (array[i].Name.Equals("IMPF")) word.Tense = "Imperfect";
            else if (array[i].Name.Equals("PERF")) word.Tense = "Perfect";
            else if (array[i].Name.Equals("IMPV")) word.Tense = "Imperative";
            else if (array[i].Name.Equals("PASS")) word.Voice = "Passive";
            else if (array[i].Name.Equals("SUBJ")) word.Mood = "Subjunctive";
            else if (array[i].Name.Equals("JUS")) word.Mood = "Jussive";
            else if (array[i].Name.Equals("JUSS")) word.Mood = "Jussive";
            else if (array[i].Name.StartsWith("(")) {
                switch (array[i].Name) {
                    case "(II)": word.Form = "II"; break;
                    case "(III)": word.Form = "III"; break;
                    case "(IV)": word.Form = "IV"; break;
                    case "(V)": word.Form = "V"; break;
                    case "(VI)": word.Form = "VI"; break;
                    case "(VII)": word.Form = "VII"; break;
                    case "(VIII)": word.Form = "VIII"; break;
                    case "(IX)": word.Form = "IX"; break;
                    case "(X)": word.Form = "X"; break;
                    case "(XI)": word.Form = "XI"; break;
                    case "(XII)": word.Form = "XII"; break;
                    default: word.Form = "I"; break;
                }
            }
            else {
                string value = "";
                switch (array[i].Name) {
                    case "P":
                    case "2D":
                    case "3D":
                    case "M":
                    case "MS":
                    case "MD":
                    case "2MD":
                    case "3MD":
                    case "MP":
                    case "2MS":
                    case "2MP":
                    case "3MS":
                    case "3MP":
                    case "1S":
                    case "1P":
                    case "F":
                    case "FS":
                    case "FP":
                    case "2FS":
                    case "FD":
                    case "2FD":
                    case "3FD":
                    case "3FS":
                    case "2FP":
                    case "3FP":
                        var d = App.details.First(x => x.Name.Equals(array[i].Name));
                        value = d.Value;
                        break;
                }

                if (value.Contains("first")) word.Person = "First";
                else if (value.Contains("second")) word.Person = "Second";
                else if (value.Contains("third")) word.Person = "Third";

                if (value.Contains("singular")) word.Number = "Singular";
                else if (value.Contains("dual")) word.Number = "Dual";
                if (value.Contains("plural")) word.Number = "Plural";
            }
        }
        if (word.Tense.Equals("Imperfect") && string.IsNullOrEmpty(word.Mood)) {
            word.Mood = "Indicative";
        }
        if (string.IsNullOrEmpty(word.Form)) {
            word.Form = "I";
        }
    }

    public void Regroup() {
        Total = 0;
        if (App.global.Transcript == 0) {
            for (int i = 0; i < items.Count; i++) {
                Total += counts[i].Item1;
                items[i].Count = counts[i].Item1;
                items[i].OnPropertyChanged(nameof(NotVerbGroup.Count));
            }
        }
        else {
            for (int i = 0; i < items.Count; i++) {
                Total += counts[i].Item2;
                items[i].Count = counts[i].Item2;
                items[i].OnPropertyChanged(nameof(NotVerbGroup.Count));
            }
        }
        currentTranscript = App.global.Transcript;
        OnPropertyChanged(nameof(Total));
    }
}

class VerbGroup : Notifiable {
    public string Gender { get; set; }
    public string Person { get; set; }
    public string Number { get; set; }
    public int Count { get; set; }
}
