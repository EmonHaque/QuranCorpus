﻿interface ISwitchPopupOnHover {
    bool IsHoverPopupDisabled { get; set; }
}
