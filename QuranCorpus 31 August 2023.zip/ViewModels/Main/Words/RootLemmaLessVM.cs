﻿class RootLemmaLessVM : Notifiable {
    List<RLFRee> sources;
    public int currentTranscript;
    Lemma selected;
    public Lemma Selected {
        get { return selected; }
        set {
            if (value is null) return;
            if (!value.Equals(selected)) {
                selected = value;
            }
            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).FocusedControl.SelectedPage is LemmaPage page) {
                page.setContent(value);
            }
        }
    }
    string query;
    public string Query {
        get { return query; }
        set {
            query = value;
            Items.Refresh();
        }
    }
    public string Covered { get; set; }
    public bool WasRightClicked { get; set; }
    public ICollectionView Items { get; set; }

    public RootLemmaLessVM() {
        Task.Run(() => {
            sources = new List<RLFRee>();
            int count = 0;
            foreach (var item in App.links) {
                if (!string.IsNullOrEmpty(item.LemmaCorpus)) continue;
                count++;
                var corpus = string.Join("", item.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)]));
                var simple = string.Join("", item.SegmentsSimple.Split('|').Select(x => App.segments[Convert.ToInt32(x)]));
                sources.Add(new RLFRee() {
                    Spellings = new string[]{ corpus, simple },
                    Reference = item.Reference
                });
            }

            currentTranscript = App.global.Transcript;
            var groups = sources
               .GroupBy(x => x.Spellings[App.global.Transcript])
               .ToList();

            var items = new List<Lemma>();
            foreach (var item in groups) {
                var transcripts = new string[2];
                transcripts[App.global.Transcript] = item.Key;
                items.Add(new Lemma() {
                    Transcripts = transcripts,
                    References = item.Select(x => x.Reference).ToList(),
                });
            }
            App.Current.Dispatcher.Invoke(() => {
                Items = CollectionViewSource.GetDefaultView(items);
                Items.Filter = filter;
                Covered = count.ToString("N0") + " words covered";
                OnPropertyChanged(nameof(Covered));
                OnPropertyChanged(nameof(Items));
            });
        });
    }

    public void Regroup() {
        var groups = sources
               .GroupBy(x => x.Spellings[App.global.Transcript])
               .ToList();

        var items = new List<Lemma>();
        foreach (var item in groups) {
            var transcripts = new string[2];
            transcripts[App.global.Transcript] = item.Key;
            items.Add(new Lemma() {
                Transcripts = transcripts,
                References = item.Select(x => x.Reference).ToList(),
            });
        }
        Items = CollectionViewSource.GetDefaultView(items);
        Items.Filter = filter;
        OnPropertyChanged(nameof(Items));
        currentTranscript = App.global.Transcript;
    }

    bool filter(object o) {
        if (string.IsNullOrEmpty(Query)) return true;
        var lemma = (Lemma)o;
        return lemma.Transcripts[App.global.Transcript].Contains(Query);
    }

    class RLFRee {
        public string[] Spellings { get; set; }
        public string Reference { get; set; }
    }
}
