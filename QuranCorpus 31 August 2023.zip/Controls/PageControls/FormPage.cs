﻿class FormPage : Page {
    string indexMa;
    byte searchMode;
    StringBuilder builder = new();
    POSFormKey current;
    List<POSForm> original, treeSource;

    Grid content;
    ProgressBar progress;
    TreeView tree;
    TagCount tags;
    WaterBox query;
    MorphView morphView;
    CancellationTokenSource terminator;

    public override PageType Type => PageType.Form;
    public override UIElement Content => content;

    public FormPage() {
        indexMa = "|" + ((App)Application.Current).indexMa;
        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };
        tags = new TagCount() {
            Margin = new Thickness(0, 0, 0, 5),
            FlowDirection = FlowDirection.LeftToRight
        };

        query = new WaterBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Icon = Icons.Search,
            Hint = "Root (buckwalter)"
        };

        var countBlock = new TextBlockEnglish() {
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(Constants.ScrollBarThickness + Constants.ScrollPresenterMargin, 0, 10, 0)
        };

        tree = new TreeView() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 0, 0),
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            // if you set HorizontalScrollBarVisibilityProperty here and disable the 
                            // tree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
                            // it will mess up when scrollbar appears and disappears
                            //new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()),
                        }
                    }
                }
            }
        };
        tree.SetValue(Grid.IsSharedSizeScopeProperty, true);
        tree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        tree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true); // no default virtualization

        Grid.SetRow(query, 1);
        Grid.SetRow(countBlock, 1);
        Grid.SetRow(tree, 2);
        Grid.SetColumn(query, 1);
        Grid.SetColumnSpan(tree, 2);
        Grid.SetColumnSpan(tags, 2);

        var leftGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition()
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { tags, query, countBlock, tree }
        };
        countBlock.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = tree,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });

        var separator = new Rectangle() {
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };

        morphView = new MorphView();

        Grid.SetRow(separator, 1);
        Grid.SetRow(leftGrid, 1);
        Grid.SetRow(morphView, 1);
        Grid.SetColumn(separator, 1);
        Grid.SetColumn(leftGrid, 2);
        Grid.SetColumnSpan(progress, 3);
        content = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = new GridLength(2.5, GridUnitType.Star) },
                new ColumnDefinition() { Width = new GridLength(10) },
                new ColumnDefinition()
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, leftGrid, separator, morphView }
        };

        terminator = new CancellationTokenSource();

        tags.SelectionChanged += onTagSelectionChanged;
        tree.SelectedItemChanged += onTreeSelectionChanged;
        query.KeyUp += onQueryEnter;
        App.global.PropertyChanged += onTranscriptChanged;
        morphView.unhookTranscriptListener();
    }

    public FormPage(POSFormKey key) : this() {
        setTags(key);
        
    }

    public void setContent(POSFormKey key) {
        current.PropertyChanged -= onCountChanged;
        setTags(key);
    }

    private void onCountChanged(object? sender, PropertyChangedEventArgs e) {
        if (!e.PropertyName.Equals(nameof(POSFormKey.NoOfWord))) return;
        tags.ResetNumbers(current.NoOfWord.Select(x => x.Item2).ToList());
    }

    void setTags(POSFormKey key) {
        current = key;
        HeaderText = "Form " + key.Form;
        tags.Items = key.NoOfWord
            .Select(x => new TagCount.TagItem() { Name = x.Item1, Count = x.Item2 })
            .ToList();
        tags.Selected = tags.Items.First();
        onTagSelectionChanged(tags.Selected);
        current.PropertyChanged += onCountChanged;
    }

    void onQueryEnter(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        var q = query.Text.Trim();
        if (string.IsNullOrEmpty(q)) createTree(treeSource);
        else {
            var source = treeSource.Where(x => x.Root.Contains(query.Text.Trim())).ToList();
            createTree(source);
        }
    }

    void onTagSelectionChanged(TagCount.TagItem item) {
        original = current.Items.First(x => x.Key.Equals(item.Name)).Value;
        filterSource();
        createTree(treeSource);
    }

    void filterSource() {
        var newSource = new List<POSForm>(original);
        var duplicates = newSource
            .GroupBy(x => new { Key = x.Spellings[App.global.Transcript], x.Tag, x.Root, x.Gender, x.Form })
                  .Where(x => x.Count() > 1)
                  .ToList();

        for (int i = 0; i < duplicates.Count; i++) {
            var list = duplicates[i].ToList();
            var item = new POSForm() {
                Form = list[0].Form,
                Gender = list[0].Gender,
                Root = list[0].Root,
                Spellings = list[0].Spellings,
                SubTag = list[0].SubTag,
                Tag = list[0].Tag
            };
            for (int j = 0; j < list.Count; j++) {
                newSource.Remove(list[j]);
                item.References.AddRange(list[j].References);
            }
            newSource.Add(item);
        }
        treeSource = newSource;
    }

    void onTreeSelectionChanged(object sender, RoutedPropertyChangedEventArgs<object> e) {
        if (tree.SelectedItem is null) return;
        var item = tree.SelectedItem as POSForm;
        if (item is null) {
            if (tree.SelectedItem is TreeViewItem ti) {
                item = ti.Header as POSForm;
            }
            if (item is null) return;
        }
        listMorph(item);
    }

    void onTranscriptChanged(object? sender, PropertyChangedEventArgs e) {
        if (!e.PropertyName.Equals(nameof(App.global.Transcript))) return;

        filterSource();
        createTree(treeSource);
    }

    void createTree(List<POSForm> source) {
        tree.Items.Clear();
        var groups =
            source.GroupBy(x => x.Gender)
            .Select(x => new {
                x.Key,
                Value = x.GroupBy(x => x.SubTag)
                    .OrderBy(x => x.Count())
                    .ToList()
            })
            .ToList();


        for (int i = 0; i < groups.Count; i++) {
            var key = string.IsNullOrEmpty(groups[i].Key) ? "Unidentified" : groups[i].Key;
            var branch = new TreeViewItem();
            int grandTotal = 0;

            for (int j = 0; j < groups[i].Value.Count; j++) {
                var val = groups[i].Value[j];
                var items = val.ToList();
                grandTotal += items.Count;

                if (!string.IsNullOrEmpty(val.Key)) {
                    var count = items.Sum(x => x.References.Count);
                    branch.Items.Add(new TreeViewItem() {
                        Header = new Tuple<string, string>(val.Key, items.Count + " | " + count),
                        HeaderTemplate = new DataTemplate() {
                            VisualTree = new FrameworkElementFactory(typeof(WordFormHeaderTemplate))
                        },
                        ItemsSource = items,
                        ItemTemplate = new DataTemplate() {
                            VisualTree = new FrameworkElementFactory(typeof(WordFormTemplate))
                        }
                    });
                }
                else {
                    for (int k = 0; k < items.Count; k++) {
                        branch.Items.Add(new TreeViewItem() {
                            Header = items[k],
                            HeaderTemplate = new DataTemplate() {
                                VisualTree = new FrameworkElementFactory(typeof(WordFormTemplate))
                            }
                        });
                    }
                }
            }
            branch.Header = new Tuple<string, string>(key, grandTotal.ToString("N0"));
            branch.HeaderTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(WordFormHeaderTemplate))
            };
            tree.Items.Add(branch);
        }
    }

    void listMorph(POSForm selected) {
        progress.IsIndeterminate = true;
        Task.Run(() => {
            var spelling = selected.Spellings[App.global.Transcript];
            var morphs = new List<Morph>();

            var iterator = App.links.GetEnumerator();
            iterator.MoveNext();

            if (!selected.IsSorted) {
                selected.References.Sort(new SurahAyahWordNoComparator());
                selected.IsSorted = true;
            }

            if (App.global.Transcript == 0) {
                for (int i = 0; i < selected.References.Count; i++) {
                    if (terminator.IsCancellationRequested) break;

                    while (!iterator.Current.Reference.Equals(selected.References[i])) iterator.MoveNext();

                    if (!string.IsNullOrEmpty(iterator.Current.Root)) {
                        searchMode = iterator.Current.Root.Contains('|') ? (byte)3 : (byte)1;
                    }
                    else searchMode = 3;

                    morphs.Add(getMorph(iterator.Current));
                }
            }
            else {
                for (int i = 0; i < selected.References.Count; i++) {
                    if (terminator.IsCancellationRequested) break;

                    while (!iterator.Current.Reference.Equals(selected.References[i])) iterator.MoveNext();

                    if (!string.IsNullOrEmpty(iterator.Current.Root)) {
                        searchMode = iterator.Current.Root.Contains('|') ? (byte)3 : (byte)1;
                    }
                    else searchMode = 3;

                    morphs.Add(getMorph(iterator.Current));
                }
            }

            iterator.Dispose();

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    morphView.Update(morphs);
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);

    }

    Morph getMorph(Link item) {
        string tag = "";
        string[] tags;
        string details = "";

        if (searchMode == 1) {
            details = item.Details.Split(',')[Convert.ToInt32(item.RootIndex)];
            details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
            int lIndex;
            if (item.LemmaSimple.EndsWith(indexMa)) {
                // in 8 cases it ends with maA
                lIndex = 0;
            }
            else lIndex = Convert.ToInt32(item.LemmaIndices);

            tags = item.Tags.Split('|');
            tag = App.tags[Convert.ToInt32(tags[lIndex])].Name;
        }
        else {
            if (!item.SpellingGroupSimple.Contains('|')) {
                details = item.Details;
                details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
                tag = App.tags[Convert.ToInt32(item.Tags)].Name;
                tags = item.Tags.Split('|');
            }
            else {
                builder.Clear();
                item.explain(builder);
                var m = new Morph() {
                    Segments = Helper.getSegments(item),
                    Tags = item.Tags.Split('|'),
                    Spellings = new string[] {
                                string.Join("", item.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)])),
                                string.Join("", item.SegmentsSimple.Split('|').Select(x => App.segments[Convert.ToInt32(x)]))
                            },
                    Explanation = builder.ToString(),
                    Tag = ""
                };
                m.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));
                return m;
            }
        }

        Morph t = new() {
            Tag = tag,
            Tags = tags,
            Segments = Helper.getSegments(item),
            Spellings = getSpellings(item)
        };
        builder.Clear();
        item.explain(builder);

        t.Explanation = builder.ToString();
        t.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));

        var array = details.Split('|');
        if (App.tagArray.Contains(tag)) {
            for (int i = 0; i < array.Length; i++) {
                if (string.IsNullOrEmpty(array[i])) continue;
                if (array[i].Equals("PCPL") ||
                    array[i].Equals("ACC") ||
                    array[i].Equals("NOM") ||
                    array[i].Equals("GEN") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("ACT")) t.SubTag = "Active Participle";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive Participle";
                else if (array[i].Equals("VN")) t.SubTag = "Verbal Noun";
                else if (array[i].Equals("IN")) t.SubTag = "Noun";
                else if (array[i].Equals("CN")) t.SubTag = "Noun";
                else if (array[i].Equals("IP")) t.SubTag = "Particle";
                else if (array[i].Equals("CP")) t.SubTag = "Particle";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("V")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUBJ") ||
                    array[i].Equals("JUS") ||
                    array[i].Equals("JUSS") ||
                    array[i].Equals("SP:kaAn") ||
                    array[i].Equals("SP:kaAd") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("IMPF")) t.SubTag = "Imperfect";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive";
                else if (array[i].Equals("IMPV")) t.SubTag = "Imperative";
                else if (array[i].Equals("PERF")) t.SubTag = "Perfect";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("PRON")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUB")) t.SubTag = "Subject";
                else if (array[i].Equals("OBJ")) t.SubTag = "Object";
                else if (array[i].Equals("PER")) t.SubTag = "Personal";
                else if (array[i].Equals("POS")) t.SubTag = "Possessive";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name;
                else t.Gender = Helper.getGender(array[i]).Name;
            }
        }
        return t;

        string[] getSpellings(Link item) {
            int lIndex;
            if (item.LemmaSimple.EndsWith(indexMa)) {
                // in 8 cases it ends with maA
                lIndex = 0;
            }
            else {
                if (string.IsNullOrEmpty(item.LemmaIndices)) {
                    return new string[] {
                    item.SpellingGroupCorpus,
                    item.SpellingGroupSimple
                };
                }

                lIndex = Convert.ToInt32(item.LemmaIndices);
            }
            return new string[] {
                item.SpellingGroupCorpus.Split('|')[lIndex],
                item.SpellingGroupSimple.Split('|')[lIndex]
            };
        }
    }

    protected override void unload() {
        tags.SelectionChanged -= onTagSelectionChanged;
        tree.SelectedItemChanged -= onTreeSelectionChanged;
        query.KeyUp -= onQueryEnter;
        App.global.PropertyChanged -= onTranscriptChanged;
        terminator.Cancel();
        terminator.Dispose();
        base.unload();
    }
}

class WordFormHeaderTemplate : Grid {
    TextBlockEnglish name, count;
    public WordFormHeaderTemplate() {
        FlowDirection = FlowDirection.LeftToRight;
        name = new TextBlockEnglish();
        count = new TextBlockEnglish();

        SetColumn(count, 1);

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

        Children.Add(name);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var c = (Tuple<string, string>)DataContext;
        name.Text = c.Item1;
        count.Text = c.Item2;
    }
}

class WordFormTemplate : Grid {
    TextBlockArabic word, root;
    TextBlockEnglish count;

    public WordFormTemplate() {
        word = new TextBlockArabic();
        root = new TextBlockArabic() {
            Foreground = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Left
        };
        count = new TextBlockEnglish() {
            Margin = new Thickness(0, 0, 5, 0),
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Left
        };

        SetColumn(root, 1);
        SetColumn(word, 2);

        ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col1" });
        ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col2" });
        ColumnDefinitions.Add(new ColumnDefinition());

        Children.Add(word);
        Children.Add(root);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var c = (POSForm)DataContext;

        word.Text = App.spellings[Convert.ToInt32(c.Spellings[App.global.Transcript])].toArabic();
        root.Text = c.Root.toArabic();
        count.Text = c.References.Count.ToString("N0");
    }
}
