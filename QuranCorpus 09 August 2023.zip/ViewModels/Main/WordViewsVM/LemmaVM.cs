﻿class LemmaVM : Notifiable {
    CancellationTokenSource terminator;
    Task task;
    List<Lemma> source;
    int scriptState;
    public int ScriptState {
        get { return scriptState; }
        set { scriptState = value; regroup(); }
    }

    object selected;
    public object Selected {
        get { return selected; }
        set {
            if (value is null) selected = null;
            if (value is not Lemma lemma) return;
            if (lemma.Items is not null) return;
            if (value.Equals(selected)) return;

            selected = value;

            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).Pages.SelectedPage is LemmaPage page) {
                page.setContent(lemma);
            }
        }
    }
    string query;
    public string Query {
        get { return query; }
        set {
            query = value;
            if (task != null && !task.IsCompleted) {
                // will it ever come here?
                // if it does what'll be the state of terminator in the next task?
                // will IsCancellationRequested be true
                terminator.Cancel();
            }
            filter(query);
        }
    }
    public bool WasRightClicked { get; set; }
    public string Count { get; set; }
    public bool IsInProgress { get; set; }
    public List<Lemma> Lemmas { get; set; }

    public LemmaVM() {
        terminator = new CancellationTokenSource();
        source = new List<Lemma>();

        Task.Run(() => {
            var list = new List<Lemma>();
            foreach (var link in App.links) {
                if (!string.IsNullOrEmpty(link.Root)) continue;
                if (string.IsNullOrEmpty(link.LemmaCorpus)) continue;
                
                var tags = link.Tags.Split('|');
                var indices = link.LemmaIndices.Split('|');
                var lemmas = link.LemmaCorpus.Split('|');
                var segments = link.SegmentsCorpus.Split('|');
                

                for (int i = 0; i < indices.Length; i++) {
                    int index = Convert.ToInt32(indices[i]);
                    var pos = App.tags[Convert.ToInt32(tags[index])].Name;
                    var lemma = App.lemmas[Convert.ToInt32(lemmas[i])];
                    var transcript = App.segments[Convert.ToInt32(segments[index])];

                    var references = new List<string>() { link.Reference };
                    list.Add(new Lemma() {
                        Transcription = transcript,
                        Root = lemma,
                        POS = pos,
                        References = references
                    });
                }
            }
            var groups = list.GroupBy(x => x.Root);
           
            foreach (var group in groups) {
                if (group.Count() == 1) {
                    source.Add(group.ElementAt(0));
                    continue;
                }

                var le = new Lemma() { Transcription = group.Key };
                le.Items = new List<Lemma>();
                foreach (var item in group) {
                    var match = le.Items.FirstOrDefault(x => x.Transcription.Equals(item.Transcription));
                    if (match is null) {
                        le.Items.Add(item);
                    }
                    else {
                        match.References.AddRange(item.References);
                    }
                }
                if(le.Items.Count == 1) {
                    var first = group.ElementAt(0);
                    first.References = le.Items[0].References;
                    source.Add(first);
                }
                else {
                    le.POS = string.Join("|", le.Items.Select(x => x.POS).Distinct());
                    source.Add(le);
                }
            }
            
            filter("");
        });
    }
   
    void filter(string query) {
        IsInProgress = true;
        OnPropertyChanged(nameof(IsInProgress));

        task = Task.Run(() => {
            int rootCount = 0;
            int formCount = 0;
            List<Lemma> list = new();

            if (string.IsNullOrEmpty(query)) {
                for (int i = 0; i < source.Count; i++) {
                    rootCount++;
                    formCount += source[i].Items is null ? 1 : source[i].Items.Count;
                    list.Add(source[i]);
                }
            }
            else {
                list = new List<Lemma>();
                var lower = query.ToLower();
                for (int i = 0; i < source.Count; i++) {
                    if (terminator.IsCancellationRequested) break;
                    if (!source[i].POS.ToLower().Contains(lower)) continue;
                    list.Add(source[i]);
                    rootCount++;
                    formCount += source[i].Items is null ? 1 : source[i].Items.Count;
                }
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    Count = $"{formCount.ToString("N0")} spelling in {rootCount.ToString("N0")} lemma";
                    IsInProgress = false;
                    Lemmas = list;
                    OnPropertyChanged(nameof(Count));
                    OnPropertyChanged(nameof(IsInProgress));
                    OnPropertyChanged(nameof(Lemmas));
                });
            }
            else {
                App.Current.Dispatcher.Invoke(() => {
                    IsInProgress = false;
                    OnPropertyChanged(nameof(IsInProgress));
                });
            }
        }, terminator.Token);
    }

    void regroup() {
        var list = new List<Lemma>();
        if(ScriptState == 0) {
            foreach (var link in App.links) {
                if (!string.IsNullOrEmpty(link.Root)) continue;
                if (string.IsNullOrEmpty(link.LemmaCorpus)) continue;

                var tags = link.Tags.Split('|');
                var indices = link.LemmaIndices.Split('|');
                var lemmas = link.LemmaCorpus.Split('|');
                var segments = link.SegmentsCorpus.Split('|');


                for (int i = 0; i < indices.Length; i++) {
                    int index = Convert.ToInt32(indices[i]);
                    var pos = App.tags[Convert.ToInt32(tags[index])].Name;
                    var lemma = App.lemmas[Convert.ToInt32(lemmas[i])];
                    var transcript = App.segments[Convert.ToInt32(segments[index])];

                    var references = new List<string>();
                    references.Add(link.Reference);
                    list.Add(new Lemma() {
                        Transcription = transcript,
                        Root = lemma,
                        POS = pos,
                        References = references
                    });
                }
            }          
        }
        else {
            foreach (var link in App.links) {
                if (!string.IsNullOrEmpty(link.Root)) continue;
                if (string.IsNullOrEmpty(link.LemmaSimple)) continue;

                var tags = link.Tags.Split('|');
                var indices = link.LemmaIndices.Split('|');
                var lemmas = link.LemmaSimple.Split('|');
                var segments = link.SegmentsSimple.Split('|');


                for (int i = 0; i < indices.Length; i++) {
                    int index = Convert.ToInt32(indices[i]);
                    var pos = App.tags[Convert.ToInt32(tags[index])].Name;
                    var lemma = App.lemmas[Convert.ToInt32(lemmas[i])];
                    var transcript = App.segments[Convert.ToInt32(segments[index])];

                    var references = new List<string>();
                    references.Add(link.Reference);
                    list.Add(new Lemma() {
                        Transcription = transcript,
                        Root = lemma,
                        POS = pos,
                        References = references
                    });
                }
            }
        }

        var groups = list.GroupBy(x => x.Root);
        source.Clear();
        foreach (var group in groups) {
            if (group.Count() == 1) {
                source.Add(group.ElementAt(0));
                continue;
            }

            var le = new Lemma() { Transcription = group.Key };
            le.Items = new List<Lemma>();
            foreach (var item in group) {
                var match = le.Items.FirstOrDefault(x => x.Transcription.Equals(item.Transcription));
                if (match is null) {
                    le.Items.Add(item);
                }
                else {
                    match.References.AddRange(item.References);
                }
            }
            if (le.Items.Count == 1) {
                var first = group.ElementAt(0);
                first.References = le.Items[0].References;
                source.Add(first);
            }
            else {
                le.POS = string.Join("|", le.Items.Select(x => x.POS).Distinct());
                source.Add(le);
            }
        }

        filter("");
    }
}