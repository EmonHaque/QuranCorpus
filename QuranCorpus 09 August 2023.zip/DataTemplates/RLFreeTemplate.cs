﻿class RLFreeTemplate : Grid {
    TextBlockArabic arabic;
    TextBlockEnglish count;

    public RLFreeTemplate()
    {
        arabic = new TextBlockArabic();
        count = new TextBlockEnglish();

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

        SetColumn(count, 1);

        Children.Add(arabic);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var item = (RootLemmaFree)DataContext;
        arabic.Text = item.Content;
        count.Text = item.Count.ToString("N0");
    }
}
