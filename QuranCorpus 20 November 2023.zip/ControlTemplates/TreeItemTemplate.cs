﻿class TreeItemTemplate : ControlTemplate {
    public TreeItemTemplate() {
        TargetType = typeof(TreeViewItem);

        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var row1 = new FrameworkElementFactory(typeof(RowDefinition));
        var row2 = new FrameworkElementFactory(typeof(RowDefinition));
        var headerBorder = new FrameworkElementFactory(typeof(Border)) { Name = "headerBorder" };
        var itemsBorder = new FrameworkElementFactory(typeof(Border)) { Name = "itemsBorder" };
        var header = new FrameworkElementFactory(typeof(ContentPresenter)) { Name = "PART_Header" }; // without naming the named part, it'll jump to top when you toggle
        var items = new FrameworkElementFactory(typeof(ItemsPresenter)) { Name = "items" };
        var state = new FrameworkElementFactory(typeof(ExpanderState)) { Name = "button" };

        row1.SetValue(RowDefinition.HeightProperty, GridLength.Auto);
        col1.SetValue(ColumnDefinition.WidthProperty, new GridLength(Constants.TreeExpansionWidth));
        state.SetValue(ExpanderState.VerticalAlignmentProperty, VerticalAlignment.Center);

        headerBorder.SetValue(Grid.ColumnProperty, 1);
        headerBorder.SetValue(Border.BorderThicknessProperty, new Thickness(0, Constants.BottomLineThickness, 0, Constants.BottomLineThickness));
        headerBorder.SetValue(Border.BorderBrushProperty, Constants.Background);
        headerBorder.SetValue(Border.PaddingProperty, new Thickness(0, 1.5, 1.5, 1.5));
        header.SetValue(ContentPresenter.ContentSourceProperty, nameof(TreeViewItem.Header));

        itemsBorder.SetValue(Grid.ColumnProperty, 1);
        itemsBorder.SetValue(Grid.RowProperty, 1);

        state.SetBinding(ExpanderState.IsTrueProperty, new Binding(nameof(TreeViewItem.IsExpanded)) {
            Mode = BindingMode.TwoWay,
            RelativeSource = RelativeSource.TemplatedParent
        });
        headerBorder.AppendChild(header);
        itemsBorder.AppendChild(items);
        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(row1);
        grid.AppendChild(row2);
        grid.AppendChild(state);
        grid.AppendChild(headerBorder);
        grid.AppendChild(itemsBorder);

        VisualTree = grid;

        Triggers.Add(new Trigger() {
            Property = TreeViewItem.IsExpandedProperty,
            Value = false,
            Setters = {
                new Setter(){
                    TargetName = "items",
                    Property = ItemsPresenter.VisibilityProperty,
                    Value = Visibility.Collapsed
                }
            }
        });
        Triggers.Add(new Trigger() {
            Property = TreeViewItem.HasItemsProperty,
            Value = false,
            Setters = {
                new Setter(){
                    TargetName = "button",
                    Property = ExpanderState.VisibilityProperty,
                    Value = Visibility.Hidden
                }
            }
        });
        Triggers.Add(new Trigger() {
            Property = TreeViewItem.IsMouseOverProperty,
            Value = true,
            Setters = {
                new Setter(Border.BackgroundProperty, Constants.BackgroundDark, "headerBorder"),
                new Setter(Border.BorderBrushProperty, Constants.BackgroundDark, "headerBorder")
            }
        }); ;
        Triggers.Add(new Trigger() {
            Property = TreeViewItem.IsSelectedProperty,
            Value = true,
            Setters = {
                new Setter(Border.BackgroundProperty, Constants.BackgroundDark, "headerBorder"),
                new Setter(Border.BorderBrushProperty, Brushes.Gray, "headerBorder")
            }
        });
        Triggers.Add(new MultiTrigger() {
            Conditions = {
                new Condition(TreeViewItem.IsExpandedProperty, true),
                new Condition(TreeViewItem.HasItemsProperty, true)
            },
            Setters = {
                new Setter(Border.BorderThicknessProperty, new Thickness(0, Constants.BottomLineThickness, 0, Constants.BottomLineThickness), "itemsBorder"),
                new Setter(Border.BorderBrushProperty, Brushes.Gray, "itemsBorder")
            }
        });
    }
}
