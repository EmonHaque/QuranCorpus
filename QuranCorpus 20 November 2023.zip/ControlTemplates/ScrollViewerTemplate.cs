﻿class ScrollViewerTemplate : ControlTemplate {
    public ScrollViewerTemplate() {
        TargetType = typeof(ScrollViewer);
        
        var grid = new FrameworkElementFactory(typeof(Grid));
        var col1 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var col2 = new FrameworkElementFactory(typeof(ColumnDefinition));
        var row1 = new FrameworkElementFactory(typeof(RowDefinition));
        var row2 = new FrameworkElementFactory(typeof(RowDefinition));

        var vScroll = new FrameworkElementFactory(typeof(ScrollBar)) { Name = "PART_VerticalScrollBar" };
        var hScroll = new FrameworkElementFactory(typeof(ScrollBar)) { Name = "PART_HorizontalScrollBar" };
        var presenter = new FrameworkElementFactory(typeof(ScrollContentPresenter)) { Name = "PART_ScrollContentPresenter" };

        col2.SetValue(ColumnDefinition.WidthProperty, GridLength.Auto);
        row2.SetValue(RowDefinition.HeightProperty, GridLength.Auto);

        vScroll.SetValue(ScrollBar.TemplateProperty, new VScrollTemplate());
        vScroll.SetValue(ScrollBar.ValueProperty, new TemplateBindingExtension(ScrollViewer.VerticalOffsetProperty));
        vScroll.SetValue(ScrollBar.MaximumProperty, new TemplateBindingExtension(ScrollViewer.ScrollableHeightProperty));
        vScroll.SetValue(ScrollBar.ViewportSizeProperty, new TemplateBindingExtension(ScrollViewer.ViewportHeightProperty));
        vScroll.SetValue(ScrollBar.VisibilityProperty, new TemplateBindingExtension(ScrollViewer.ComputedVerticalScrollBarVisibilityProperty));
        vScroll.SetValue(ScrollBar.ContextMenuProperty, null);

        hScroll.SetValue(ScrollBar.TemplateProperty, new HScrollTemplate());
        hScroll.SetValue(ScrollBar.OrientationProperty, Orientation.Horizontal);
        hScroll.SetValue(ScrollBar.ValueProperty, new TemplateBindingExtension(ScrollViewer.HorizontalOffsetProperty));
        hScroll.SetValue(ScrollBar.MaximumProperty, new TemplateBindingExtension(ScrollViewer.ScrollableWidthProperty));
        hScroll.SetValue(ScrollBar.ViewportSizeProperty, new TemplateBindingExtension(ScrollViewer.ViewportWidthProperty));
        hScroll.SetValue(ScrollBar.VisibilityProperty, new TemplateBindingExtension(ScrollViewer.ComputedHorizontalScrollBarVisibilityProperty));
        hScroll.SetValue(ScrollBar.ContextMenuProperty, null);

        presenter.SetValue(ScrollContentPresenter.CanContentScrollProperty, new TemplateBindingExtension(ScrollViewer.CanContentScrollProperty));

        vScroll.SetValue(Grid.ColumnProperty, 1);
        hScroll.SetValue(Grid.RowProperty, 1);

        grid.AppendChild(col1);
        grid.AppendChild(col2);
        grid.AppendChild(row1);
        grid.AppendChild(row2);
        grid.AppendChild(hScroll);
        grid.AppendChild(vScroll);
        grid.AppendChild(presenter);

        VisualTree = grid;
    }
}
