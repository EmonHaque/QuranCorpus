﻿public class ListBoxItemTemplate : ControlTemplate
{
    public ListBoxItemTemplate() {
        TargetType = typeof(ListBoxItem);
        var border = new FrameworkElementFactory(typeof(Border)) { Name = "border" };
        var content = new FrameworkElementFactory(typeof(ContentPresenter));

        border.SetValue(Border.BorderThicknessProperty, new Thickness(0, 0.5, 0, 0.5));
        border.SetValue(Border.BorderBrushProperty, Constants.Background);
        border.SetValue(Border.PaddingProperty, new Thickness(0, 1.5, 1.5, 1.5));

        border.AppendChild(content);
        VisualTree = border;

        Triggers.Add(new Trigger() {
            Property = ListBoxItem.IsMouseOverProperty,
            Value = true,
            Setters = {
                new Setter(Border.BackgroundProperty, Constants.BackgroundDark, "border"),
                new Setter(Border.BorderBrushProperty, Constants.BackgroundDark, "border")
            }
        }); ;
        Triggers.Add(new Trigger() {
            Property = ListBoxItem.IsSelectedProperty,
            Value = true,
            Setters = {
                new Setter(Border.BackgroundProperty, Constants.BackgroundDark, "border"),
                new Setter(Border.BorderBrushProperty, Brushes.Gray, "border")
            }
        });
    }
}
