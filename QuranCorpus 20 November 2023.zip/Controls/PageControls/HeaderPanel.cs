﻿class HeaderPanel : WrapPanel {
    bool isMouseDown, isDragging;
    double startX, startY, dragX, dragY;
    Header dragSource;
    Popup draggerPopup;
    Border draggerBorder;
    Size reqSize;

    public HeaderPanel() {
        AllowDrop = true;
        Orientation = Orientation.Horizontal;
        draggerBorder = new Border();
        draggerPopup = new Popup() {
            FlowDirection = FlowDirection.RightToLeft,
            AllowsTransparency = true,
            Child = draggerBorder
        };
    }
    
    protected override void OnPreviewMouseLeftButtonDown(MouseButtonEventArgs e) {
        if (e.Source == this) return;
        if (e.Source is Path || e.Source is ActionButton) return;

        isMouseDown = true;
        var point = e.GetPosition(this);
        startX = point.X;
        startY = point.Y;
    }
    protected override void OnPreviewMouseLeftButtonUp(MouseButtonEventArgs e) {
        if (!isMouseDown) return;
        isMouseDown = false;
        isDragging = false;
        if (dragSource is null) return;
        //dragSource.ReleaseMouseCapture();
        dragSource.IsBeingDragged = false;
        DragDrop.RemoveQueryContinueDragHandler(dragSource, DragContrinueHandler);
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        isMouseDown = false;
        isDragging = false;
    }
    protected override void OnPreviewMouseMove(MouseEventArgs e) {
        if (!isMouseDown) return;
        var point = e.GetPosition(this);
        dragX = Math.Abs(point.X - startX);
        dragY = Math.Abs(point.Y - startY);
       
        if ((isDragging == false) &&
            (dragX > SystemParameters.MinimumHorizontalDragDistance ||
            dragY > SystemParameters.MinimumVerticalDragDistance)) {

            isDragging = true;
            dragSource = (Header)e.Source;
            //dragSource.CaptureMouse();
            
            dragSource.IsBeingDragged = true;

            draggerBorder.Width = dragSource.ActualWidth;
            draggerBorder.Height = dragSource.ActualHeight;
            draggerBorder.Background = new VisualBrush(dragSource);
            draggerPopup.IsOpen = true;
            
            var dragData = new DataObject(typeof(Page), dragSource.Page);
            dragData.SetData("source", dragSource);

            DragDrop.AddQueryContinueDragHandler(dragSource, DragContrinueHandler);
            DragDrop.DoDragDrop(dragSource, dragData, DragDropEffects.All);
        }
    }
    protected override void OnDragOver(DragEventArgs e) {
        var point = e.GetPosition(this);
        dragX = point.X;
        dragY = point.Y;
    }
    protected override void OnDrop(DragEventArgs e) {
        if (!e.Data.GetDataPresent(typeof(Page))) return;

        e.Handled = true;
        var droptarget = (UIElement)e.Source;
        int droptargetIndex = -1, i = 0;
        foreach (UIElement element in Children) {
            if (element.Equals(droptarget)) {
                droptargetIndex = i;
                break;
            }
            i++;
        }
        if (droptargetIndex != -1) {
            Children.Remove(dragSource);
            Children.Insert(droptargetIndex, dragSource);
        }

        isMouseDown = false;
        isDragging = false;
        dragSource.IsBeingDragged = false;
        //dragSource.ReleaseMouseCapture();
        DragDrop.RemoveQueryContinueDragHandler(dragSource, DragContrinueHandler);
    }

    protected override Size MeasureOverride(Size constraint) {
        reqSize = new Size();
        foreach (FrameworkElement child in Children) {
            child.Measure(constraint);
            reqSize.Width += child.DesiredSize.Width;
            reqSize.Height = child.DesiredSize.Height;
        }
        return base.MeasureOverride(constraint);
    }
    protected override Size ArrangeOverride(Size arrangeSize) {
        if (reqSize.Width <= MaxWidth) return base.ArrangeOverride(arrangeSize);
        double x = 0;
        double width = 0;
        foreach (FrameworkElement child in Children) {
            width = MaxWidth / reqSize.Width * child.DesiredSize.Width;
            child.Arrange(new Rect(x, 0, width, arrangeSize.Height));
            x += width;
        }
        return new Size(MaxWidth, arrangeSize.Height);
    }

    void DragContrinueHandler(object sender, QueryContinueDragEventArgs e) {
        var point = Helper.GetMousePosition();
        draggerPopup.PlacementRectangle = new Rect(point, point);
        if (e.Action == DragAction.Continue && e.KeyStates != DragDropKeyStates.LeftMouseButton) {
            draggerPopup.IsOpen = false;
        }
    }

    public new double MaxWidthProperty {
        get { return (double)GetValue(MaxWidthPropertyProperty); }
        set { SetValue(MaxWidthPropertyProperty, value); }
    }

    public static readonly DependencyProperty MaxWidthPropertyProperty =
        DependencyProperty.Register("MaxWidthProperty", typeof(double), typeof(HeaderPanel), new FrameworkPropertyMetadata() {
            DefaultValue = 0d,
            AffectsArrange = true
        });
}

