﻿class MorphView : Grid {
    int currentTranscript;
    TextBlockEnglish treeCount, meaningCount;
    Run morphCount, morphTotal;
    TreeView tree;
    ListBox listMorph, listMeaning;
    List<Morph> source;

    public MorphView() {
        treeCount = new TextBlockEnglish();
        morphCount = new Run();
        morphTotal = new Run();
        var listCountBlock = new TextBlockEnglish() {
            HorizontalAlignment = HorizontalAlignment.Left,
            FlowDirection = FlowDirection.LeftToRight,
            Inlines = { morphTotal, new Run(" in "), morphCount }
        };
        tree = new TreeView() {
            Template = new TreeViewLedgerTemplate()
        };
        tree.SetValue(Grid.IsSharedSizeScopeProperty, true);

        var separator = new Rectangle() {
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        listMorph = new ListBox() {
            Template = new ListBoxLedgerTemplate(),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MorphListTemplate))
            }
        };
        listMorph.SetValue(Grid.IsSharedSizeScopeProperty, true);

        var splitter = new GridSplitter() {
            Margin = new Thickness(0, 5, 0, 0),
            ResizeDirection = GridResizeDirection.Rows,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Template = new SplitterTemplate()
        };

        meaningCount = new TextBlockEnglish() { HorizontalAlignment = HorizontalAlignment.Left };
        listMeaning = new ListBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 5, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MeaningListTemplate))
            }
        };
        listMeaning.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMeaning.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

        SetColumn(treeCount, 2);
        SetColumn(separator, 1);
        SetColumn(tree, 2);

        SetRow(tree, 1);
        SetRow(listMorph, 1);
        SetRow(splitter, 2);
        SetRow(meaningCount, 2);
        SetRow(listMeaning, 3);

        SetRowSpan(tree, 4);
        SetRowSpan(separator, 4);

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(10) });
        ColumnDefinitions.Add(new ColumnDefinition());

        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = new GridLength(2.5, GridUnitType.Star) });
        RowDefinitions.Add(new RowDefinition() { Height = new GridLength(15) });
        RowDefinitions.Add(new RowDefinition());

        Children.Add(treeCount);
        Children.Add(listCountBlock);
        Children.Add(separator);
        Children.Add(tree);
        Children.Add(listMorph);
        Children.Add(splitter);
        Children.Add(meaningCount);
        Children.Add(listMeaning);

        treeCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = tree,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        morphCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMorph,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        meaningCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMeaning,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });

        tree.SelectedItemChanged += onTreeSelectionChanged;
        listMorph.SelectionChanged += onMorphSelectionChanged;
        listMeaning.MouseDoubleClick += onMeaningDoubleClick;
        IsVisibleChanged += onVisibilityChanged;
        App.global.PropertyChanged += onTranscriptChanged;
        TabView.Split += onSplit;
    }

    public void Update(List<Morph> source) {
        this.source = source;
        tree.Items.Clear();
        createTree();
    }

    public void Unload() {
        tree.SelectedItemChanged -= onTreeSelectionChanged;
        listMorph.SelectionChanged -= onMorphSelectionChanged;
        listMeaning.MouseDoubleClick -= onMeaningDoubleClick;
        IsVisibleChanged -= onVisibilityChanged;
        App.global.PropertyChanged -= onTranscriptChanged;
        TabView.Split -= onSplit;
    }

    public void unhookTranscriptListener() {
        App.global.PropertyChanged -= onTranscriptChanged;
    }

    void createTree() {
        if (source is null) return;
        tree.Items.Clear();
        tree.Items.SortDescriptions.Clear();

        // global exception handlers don't catch null exception on source
        var groups = source.GroupBy(x => x.Spellings[App.global.Transcript]);

        foreach (var group in groups) {
            List<string> tags = new();
            var root = new TreeViewItem();
            int rootChildCount = 0;
            int total = 0;
            foreach (var item in group) {
                bool hasIt = false;
                for (int i = 0; i < root.Items.Count; i++) {
                    var added = (Morph)root.Items[i];
                    if (added.Tag.Equals(item.Tag) &&
                        added.SubTag.Equals(item.SubTag) &&
                        added.Gender.Equals(item.Gender) &&
                        added.Form.Equals(item.Form)) {
                        hasIt = true;
                        added.Count++;
                        total++;
                        break;

                    }
                }
                if (!hasIt) {
                    item.Count = 1;
                    root.Items.Add(item);
                    if (!tags.Contains(item.Tag)) {
                        tags.Add(item.Tag);
                    }
                    rootChildCount++;
                    total++;
                }
            }

            if (rootChildCount > 1) {
                root.HeaderTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(TreeHeaderTemplateMultiple))
                };
                root.ItemTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(TreeItemTemplate))
                };
                root.Header = new Tuple<string, string, string>(
                group.Key,
                string.Join(" | ", tags),
                total.ToString("N0") + " | " + rootChildCount.ToString());
            }
            else {
                root.Header = (Morph)root.Items[0];
                root.Items.Clear();
                root.HeaderTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(TreeHeaderTemplateSingle))
                };
            }

            tree.Items.Add(root);
        }
        
        tree.Items.SortDescriptions.Add(new SortDescription("Items.Count", ListSortDirection.Descending));

        listMorph.ItemsSource = null;
        currentTranscript = App.global.Transcript;
        if (tree.Items.Count > 0) ((TreeViewItem)tree.Items.GetItemAt(0)).IsSelected = true;
    }

    void onTreeSelectionChanged(object sender, RoutedPropertyChangedEventArgs<object> e) {
        if (e.NewValue is null) {
            morphTotal.Text = "0";
            return;
        }

        var value = e.NewValue as Morph;
        if (value is null) {
            value = ((TreeViewItem)e.NewValue).Header as Morph;
            if (value is null) return;
        }

        var listSource = source
              .Where(
                  x => x.Spellings[App.global.Transcript].Equals(value.Spellings[App.global.Transcript]) &&
                  x.Tag.Equals(value.Tag) &&
                  x.SubTag.Equals(value.SubTag) &&
                  x.Form.Equals(value.Form) &&
                  x.Gender.Equals(value.Gender))
              .GroupBy(x => new { Word = x.Segments[App.global.Transcript], x.Explanation })
              .Select(x => new Morph() {
                  Segments = x.First().Segments,
                  Count = x.Count(),
                  Tags = x.First().Tags,
                  Explanation = x.Key.Explanation,
                  References = x.SelectMany(x => x.References).ToList()
              })
              .OrderByDescending(x => x.Count)
              .ToList();

        listMorph.ItemsSource = listSource;
        morphTotal.Text = listSource.Sum(x => x.Count).ToString();
    }

    void onMorphSelectionChanged(object sender, SelectionChangedEventArgs e) {
        if (listMorph.SelectedItem is null) {
            listMeaning.ItemsSource = null;
            return;
        }
        listMeaning.ItemsSource = ((Morph)listMorph.SelectedItem).References;
    }

    void onMeaningDoubleClick(object sender, MouseButtonEventArgs e) {
        if (listMeaning.SelectedItem is null) return; // can be null?
        var item = (Tuple<string, string, string>)listMeaning.SelectedItem;
        ((App)Application.Current).FocusedControl.addSurahPage(item.Item1);
    }

    void onTranscriptChanged(object? sender, PropertyChangedEventArgs e) {
        if (!e.PropertyName.Equals(nameof(App.global.Transcript))) return;
        //if (!IsVisible) return;
        createTree();
    }

    void onVisibilityChanged(object sender, DependencyPropertyChangedEventArgs e) {
        if(!IsLoaded) return;
        if (!IsVisible) return;
        if (currentTranscript == App.global.Transcript) return;
        createTree();
    }

    void onSplit() {
        listMorph.Items.Refresh();
    }

    class TreeHeaderTemplateMultiple : Grid {
        TextBlockArabic arabic;
        TextBlockEnglish tags, count;

        public TreeHeaderTemplateMultiple() {
            arabic = new TextBlockArabic();
            tags = new TextBlockEnglish() {
                FlowDirection = FlowDirection.LeftToRight,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right,
                TextWrapping = TextWrapping.Wrap
            };
            count = new TextBlockEnglish() {
                Margin = new Thickness(5, 0, 0, 0),
                FlowDirection = FlowDirection.LeftToRight,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            SetColumn(tags, 1);
            SetColumn(count, 2);
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "mCol2" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "mCol3" });
            Children.Add(arabic);
            Children.Add(tags);
            Children.Add(count);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Tuple<string, string, string>)DataContext;
            arabic.Text = App.spellings[Convert.ToInt32(c.Item1)].toArabic();
            tags.Text = c.Item2;
            count.Text = c.Item3;
        }
    }

    class TreeHeaderTemplateSingle : Grid {
        TextBlockArabic arabic;
        TextBlockEnglish tags, count;
        public TreeHeaderTemplateSingle() {
            arabic = new TextBlockArabic();
            tags = new TextBlockEnglish() { TextWrapping = TextWrapping.Wrap };
            count = new TextBlockEnglish() {
                Margin = new Thickness(5, 0, 0, 0),
                HorizontalAlignment = HorizontalAlignment.Right
            };
            SetColumn(tags, 1);
            SetColumn(count, 2);
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "sCol2" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "sCol3" });
            Children.Add(arabic);
            Children.Add(tags);
            Children.Add(count);

            Resources.Add(typeof(TextBlockEnglish), new Style() {
                Setters = {
                        new Setter(VerticalAlignmentProperty, VerticalAlignment.Center),
                        new Setter(FlowDirectionProperty, FlowDirection.LeftToRight)
                    }
            });
        }
        public override void EndInit() {
            base.EndInit();
            var c = (Morph)DataContext;

            arabic.Text =
                int.TryParse(c.Spellings[App.global.Transcript], out int index) ?
                App.spellings[index].toArabic() :
                c.Spellings[App.global.Transcript].toArabic();

            StringBuilder builder = new();
            if (!string.IsNullOrEmpty(c.Tag)) builder.Append(c.Tag).Append(" - ");
            if (!string.IsNullOrEmpty(c.SubTag)) builder.Append(c.SubTag).Append(" | ");
            if (!string.IsNullOrEmpty(c.Gender)) builder.Append(c.Gender).Append(" | ");
            if (!string.IsNullOrEmpty(c.Form)) builder.Append(c.Form).Append(" | ");
            if (builder.Length > 0 && builder[builder.Length - 1].Equals(' ')) builder.Remove(builder.Length - 2, 2);

            tags.Text = builder.ToString();
            count.Text = c.Count.ToString();
        }
    }

    class TreeItemTemplate : Grid {
        TextBlockEnglish tag, count;

        public TreeItemTemplate() {
            Margin = new Thickness(0, 3.5, 0, 3.5);
            tag = new TextBlockEnglish() {
                HorizontalAlignment = HorizontalAlignment.Left,
                FlowDirection = FlowDirection.LeftToRight,
                TextWrapping = TextWrapping.Wrap,
            };
            count = new TextBlockEnglish() { HorizontalAlignment = HorizontalAlignment.Right };
            SetColumn(count, 1);
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col1" });
            Children.Add(tag);
            Children.Add(count);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Morph)DataContext;

            StringBuilder builder = new();
            if (!string.IsNullOrEmpty(c.Tag)) builder.Append(c.Tag).Append(" - ");
            if (!string.IsNullOrEmpty(c.SubTag)) builder.Append(c.SubTag).Append(" | ");
            if (!string.IsNullOrEmpty(c.Gender)) builder.Append(c.Gender).Append(" | ");
            if (!string.IsNullOrEmpty(c.Form)) builder.Append(c.Form).Append(" | ");
            if (builder.Length > 0 && builder[builder.Length - 1].Equals(' ')) builder.Remove(builder.Length - 2, 2);

            tag.Text = builder.ToString();
            count.Text = c.Count.ToString();
        }
    }
}
