﻿
class PatternPage : Page {
    bool isLoaded;
    byte searchMode;
    string query, indexMa;
    StringBuilder builder = new();

    ProgressBar progress;
    WaterBox queryBox;
    Toggle lengthToggle;
    TextBlockEnglish spellingCount, meaningCount;
    Run morphCount, morphTotal;
    ListBox spellings, listMorph, listMeaning;
    List<Pattern> corpus, simple;
    List<Morph> source;
    Grid content, queryGrid;
    CancellationTokenSource terminator;
    ICollectionView spellingsView;

    public override PageType Type => PageType.Pattern;
    public override UIElement Content => content;

    public PatternPage() {
        HeaderText = "Spellings";
        indexMa = "|" + ((App)Application.Current).indexMa;
        terminator = new CancellationTokenSource();
        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };
        queryBox = new WaterBox() {
            Icon = Icons.Search,
            Hint = "Spelling (pattern eg. +a+a+)"
        };
        lengthToggle = new Toggle() {
            Margin = new Thickness(5, 0, 0, 0),
            VerticalAlignment = VerticalAlignment.Center,
            OnIcon = Icons.Equal,
            OffIcon = Icons.Approximate,
            OnTip = "equal length",
            OffTip = "equal or greater length"
        };
        var buckwalterPop = new BuckwalterPopup() {
            Margin = new Thickness(5, 0, 5, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        spellingCount = new TextBlockEnglish() {
            Margin = new Thickness(0, 0, 0, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        Grid.SetColumn(lengthToggle, 1);
        Grid.SetColumn(buckwalterPop, 2);
        Grid.SetColumn(spellingCount, 3);
        queryGrid = new Grid() {
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { queryBox, lengthToggle, buckwalterPop, spellingCount }
        };

        morphCount = new Run();
        morphTotal = new Run();
        var listCountBlock = new TextBlockEnglish() {
            HorizontalAlignment = HorizontalAlignment.Left,
            FlowDirection = FlowDirection.LeftToRight,
            Inlines = { morphTotal, new Run(" in "), morphCount }
        };
        spellings = new ListBox() {
            Margin = new Thickness(5, 5, 0, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(SpellingTemplate))
            }
        };
        spellings.SetValue(Grid.IsSharedSizeScopeProperty, true);
        spellings.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

        var separator = new Rectangle() {
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        listMorph = new ListBox() {
            Template = new ListBoxLedgerTemplate(),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MorphListTemplate))
            }
        };
        listMorph.SetValue(Grid.IsSharedSizeScopeProperty, true);

        var splitter = new GridSplitter() {
            Margin = new Thickness(0, 5, 0, 0),
            ResizeDirection = GridResizeDirection.Rows,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Template = new SplitterTemplate()
        };

        meaningCount = new TextBlockEnglish() { HorizontalAlignment = HorizontalAlignment.Left };
        listMeaning = new ListBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 5, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MeaningListTemplate))
            }
        };
        listMeaning.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMeaning.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

        Grid.SetColumn(queryGrid, 2);
        Grid.SetColumn(separator, 1);
        Grid.SetColumn(spellings, 2);

        Grid.SetRow(queryGrid, 1);
        Grid.SetRow(listCountBlock, 1);
        Grid.SetRow(separator, 1);

        Grid.SetRow(spellings, 2);
        Grid.SetRow(listMorph, 2);
        Grid.SetRow(splitter, 3);
        Grid.SetRow(meaningCount, 3);
        Grid.SetRow(listMeaning, 4);

        Grid.SetRowSpan(spellings, 5);
        Grid.SetRowSpan(separator, 5);
        Grid.SetColumnSpan(progress, 3);

        content = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = new GridLength(10) },
                new ColumnDefinition()
            },
            RowDefinitions = {
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition() { Height = new GridLength(2.5, GridUnitType.Star) },
                new RowDefinition() { Height = new GridLength(15) },
                new RowDefinition()
            },
            Children = { progress, queryGrid, listCountBlock, separator, spellings, listMorph, splitter, meaningCount, listMeaning }
        };

        spellingCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = spellings,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        morphCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMorph,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        meaningCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMeaning,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });

        spellings.SelectionChanged += onSpellingSelectionChanged;
        spellings.MouseRightButtonUp += onRightButtonUp;
        listMorph.SelectionChanged += onMorphSelectionChanged;
        listMeaning.MouseDoubleClick += onMeaningDoubleClick;
        queryBox.KeyUp += onQuery;
        DataObject.AddPastingHandler(queryBox, onPste);
        App.global.PropertyChanged += onTranscriptChanged;
        content.Loaded += onLoaded;
        TabView.Split += onSplit;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        if (isLoaded) return;
        isLoaded = true;
        updateTranscript();
    }

    void onSpellingSelectionChanged(object sender, SelectionChangedEventArgs e) {
        if (spellings.SelectedItem is null) {
            listMorph.ItemsSource = null;
            return;
        }

        var pattern = (Pattern)spellings.SelectedItem;
        progress.IsIndeterminate = true;

        Task.Run(() => {
            var iterator = App.links.GetEnumerator();
            iterator.MoveNext();

            source = new List<Morph>();
            for (int i = 0; i < pattern.Reference.Count; i++) {
                if (terminator.IsCancellationRequested) break;
                while (!iterator.Current.Reference.Equals(pattern.Reference[i])) iterator.MoveNext();
   
                if (iterator.Current.SegmentsCorpus.Contains('|')) {
                    var parts = App.global.Transcript == 1 ?
                        iterator.Current.SpellingGroupSimple.Split('|') :
                        iterator.Current.SpellingGroupCorpus.Split('|');

                    int index = 0;
                    for (int j = 0; j < parts.Length; j++) {
                        var content = App.spellings[Convert.ToInt32(parts[j])];
                        if (!content.Equals(pattern.Spelling)) continue;
                        index = j;
                        break;
                    }

                    if (string.IsNullOrEmpty(iterator.Current.Root)) {
                        if (string.IsNullOrEmpty(iterator.Current.LemmaSimple)) searchMode = 3;
                        else {
                            parts = iterator.Current.LemmaIndices.Split('|');
                            searchMode = parts.Contains(index.ToString()) ? (byte)2 : (byte)3;
                        }
                    }
                    else {
                        parts = iterator.Current.LemmaIndices.Split('|');
                        searchMode = parts.Contains(index.ToString()) ? (byte)1 : (byte)3;
                    }
                }
                else {
                    if (string.IsNullOrEmpty(iterator.Current.Root)) {
                        searchMode = string.IsNullOrEmpty(iterator.Current.LemmaSimple) ? (byte)3 : (byte)2;
                    }
                    else {
                        // in one case 20:94:2 - ya ibna umma - two roots bny and Amm
                        searchMode = iterator.Current.Root.Contains('|') ? (byte)1 : (byte)3;
                    }
                }

                source.Add(getMorph(iterator.Current));
            }
            if (!terminator.IsCancellationRequested) {
                var listSource = source
                  .GroupBy(x => new { Word = x.Segments[App.global.Transcript], x.Explanation })
                  .Select(x => new Morph() {
                      Segments = x.First().Segments,
                      Count = x.Count(),
                      Tags = x.First().Tags,
                      Explanation = x.Key.Explanation,
                      References = x.SelectMany(x => x.References).ToList()
                  })
                  .OrderByDescending(x => x.Count)
                  .ToList();

                App.Current.Dispatcher.Invoke(() => {
                    listMorph.ItemsSource = listSource;
                    morphTotal.Text = listSource.Sum(x => x.Count).ToString("N0");
                    progress.IsIndeterminate = false;
                });
            }

        }, terminator.Token);
    }

    void onMorphSelectionChanged(object sender, SelectionChangedEventArgs e) {
        if (listMorph.SelectedItem is null) {
            listMeaning.ItemsSource = null;
            return;
        }
        listMeaning.ItemsSource = ((Morph)listMorph.SelectedItem).References;
    }

    void onMeaningDoubleClick(object sender, MouseButtonEventArgs e) {
        if (listMeaning.SelectedItem is null) return; // can be null?
        var item = (Tuple<string, string, string>)listMeaning.SelectedItem;
        ((App)Application.Current).FocusedControl.addSurahPage(item.Item1);
    }

    void onPste(object sender, DataObjectPastingEventArgs e) {
        var clip = e.DataObject.GetData(typeof(string)) as string;
        if (clip is null) return;
        var transcript = "";
        for (int i = 0; i < clip.Length; i++) {
            var hex = ((uint)clip[i]).ToString("X4");
            try {
                transcript += App.characters.First(x => x.Arabic.Equals(hex)).English;
            }
            catch {
                transcript += clip[i];
            }
        }
        queryBox.setText(transcript);
        e.CancelCommand();
    }

    void onQuery(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        query = queryBox.Text.Trim();
        spellingsView.Refresh();
    }

    void onTranscriptChanged(object? sender, PropertyChangedEventArgs e) {
        if (!e.PropertyName.Equals(nameof(App.global.Transcript))) return;

        spellingsView = CollectionViewSource.GetDefaultView(App.global.Transcript == 1 ? simple : corpus);
        spellingsView.Filter = filter;
        spellings.ItemsSource = spellingsView;
    }

    void onSplit() {
        spellings.Items.Refresh();
        listMorph.Items.Refresh();
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) {
        if (spellings.SelectedItem is null) return;

        var item = (Pattern)spellings.SelectedItem;
        var iterator = App.links.GetEnumerator();
        iterator.MoveNext();

        var transcripts = new string[2];
        Lemma lemma;

        if (string.IsNullOrEmpty(item.RootOrLemma)) {
            transcripts[App.global.Transcript] = item.Spelling;
            lemma = new Lemma() {
                Transcripts = transcripts,
                References = item.Reference
            };
        }
        else {
            transcripts[App.global.Transcript] = item.RootOrLemma;
            List<Pattern> list = App.global.Transcript == 1 ? simple : corpus;

            if (item.HasRoot) {
                var references = list.Where(x => x.HasRoot && x.RootOrLemma.Equals(item.RootOrLemma)).SelectMany(x => x.Reference).ToList();
                references.Sort(new SurahAyahWordNoComparator());
                lemma = new Lemma() {
                    Transcripts = transcripts,
                    Root = new string[] { item.RootOrLemma, "" },
                    References = references
                };
            }
            else {
                var references = list.Where(x => !x.HasRoot && x.RootOrLemma.Equals(item.RootOrLemma)).SelectMany(x => x.Reference).ToList();
                references.Sort(new SurahAyahWordNoComparator());
                lemma = new Lemma() {
                    Transcripts = transcripts,
                    References = references
                };
            }
        }
        ((App)Application.Current).FocusedControl.addLemmaPage(lemma);
    }

    void updateTranscript() {
        spellings.ItemsSource = null;
        queryGrid.IsEnabled = false;
        progress.IsIndeterminate = true;

        Task.Run(() => {
            corpus = new List<Pattern>();
            simple = new List<Pattern>();
            var iterator = App.links.GetEnumerator();
            iterator.MoveNext();

            while (iterator.Current is not null) {
                if (terminator.IsCancellationRequested) break;
                if (iterator.Current.SpellingGroupSimple.Contains('|')) {
                    var sParts = iterator.Current.SpellingGroupSimple.Split('|');
                    var cParts = iterator.Current.SpellingGroupCorpus.Split('|');
                    var tParts = iterator.Current.Tags.Split('|');
                    var parts = iterator.Current.LemmaIndices.Split('|');

                    for (int i = 0; i < sParts.Length; i++) {
                        bool hasRoot = !string.IsNullOrEmpty(iterator.Current.Root);
                        string sRootLemma = "";
                        string cRootLemma = "";

                        if (hasRoot) {
                            if (iterator.Current.RootIndex.Equals(i.ToString())) {
                                if (iterator.Current.Root.Contains('|')) {
                                    cRootLemma = string.Join("|", iterator.Current.Root.Split('|').Select(x => App.roots[Convert.ToInt32(x)]));
                                    sRootLemma = string.Join("|", iterator.Current.Root.Split('|').Select(x => App.roots[Convert.ToInt32(x)]));
                                }
                                else {
                                    cRootLemma = App.roots[Convert.ToInt32(iterator.Current.Root)];
                                    sRootLemma = App.roots[Convert.ToInt32(iterator.Current.Root)];
                                }
                            }
                        }
                        else {
                            if (!string.IsNullOrEmpty(iterator.Current.LemmaSimple)) {
                                int index = -1;
                                for (int j = 0; j < parts.Length; j++) {
                                    if (parts[j].Equals(i.ToString())) {
                                        index = j;
                                        break;
                                    }
                                }
                                if (index != -1) {
                                    var lemmas = iterator.Current.LemmaSimple.Split('|');
                                    sRootLemma = App.lemmas[Convert.ToInt32(lemmas[index])];

                                    lemmas = iterator.Current.LemmaCorpus.Split('|');
                                    cRootLemma = App.lemmas[Convert.ToInt32(lemmas[index])];
                                }
                            }
                        }

                        var sSpell = App.spellings[Convert.ToInt32(sParts[i])];
                        var cSpell = App.spellings[Convert.ToInt32(cParts[i])];
               
                        var sMatch = getMatch(sSpell, sRootLemma, simple);
                        var cMatch = getMatch(cSpell, cRootLemma, corpus);

                        if (sMatch is null) {
                            simple.Add(new Pattern() {
                                Spelling = sSpell,
                                HasRoot = hasRoot,
                                RootOrLemma = sRootLemma,
                                Tags = new List<string>() { tParts[i] },
                                Reference = new List<string>() { iterator.Current.Reference }
                            });
                        }
                        else {
                            if (!sMatch.Tags.Contains(tParts[i])) {
                                sMatch.Tags.Add(tParts[i]);
                            }
                            sMatch.Reference.Add(iterator.Current.Reference);
                        }
                        if (cMatch is null) {
                            corpus.Add(new Pattern() {
                                Spelling = cSpell,
                                HasRoot = hasRoot,
                                RootOrLemma = cRootLemma,
                                Tags = new List<string>() { tParts[i] },
                                Reference = new List<string>() { iterator.Current.Reference }
                            });
                        }
                        else {
                            if (!cMatch.Tags.Contains(tParts[i])) {
                                cMatch.Tags.Add(tParts[i]);
                            }
                            cMatch.Reference.Add(iterator.Current.Reference);
                        }
                    }
                }
                else {
                    bool hasRoot = !string.IsNullOrEmpty(iterator.Current.Root);
                    string sRootLemma = "";
                    string cRootLemma = "";
                    if (hasRoot) {
                        sRootLemma = cRootLemma = App.roots[Convert.ToInt32(iterator.Current.Root)];
                    }
                    else {
                        if (!string.IsNullOrEmpty(iterator.Current.LemmaSimple)) {
                            sRootLemma = App.lemmas[Convert.ToInt32(iterator.Current.LemmaSimple)];
                            cRootLemma = App.lemmas[Convert.ToInt32(iterator.Current.LemmaCorpus)];
                        }
                    }
                    var sSpell = App.spellings[Convert.ToInt32(iterator.Current.SpellingGroupSimple)];
                    var cSpell = App.spellings[Convert.ToInt32(iterator.Current.SpellingGroupCorpus)];
                    var sMatch = getMatch(sSpell, sRootLemma, simple);
                    var cMatch = getMatch(cSpell, cRootLemma, corpus);

                    if (sMatch is null) {
                        simple.Add(new Pattern() {
                            Spelling = sSpell,
                            HasRoot = hasRoot,
                            RootOrLemma = sRootLemma,
                            Tags = new List<string>() { iterator.Current.Tags },
                            Reference = new List<string>() { iterator.Current.Reference }
                        });
                    }
                    else {
                        if (!sMatch.Tags.Contains(iterator.Current.Tags)) {
                            sMatch.Tags.Add(iterator.Current.Tags);
                        }
                        sMatch.Reference.Add(iterator.Current.Reference);
                    }
                    if (cMatch is null) {
                        corpus.Add(new Pattern() {
                            Spelling = cSpell,
                            HasRoot = hasRoot,
                            RootOrLemma = cRootLemma,
                            Tags = new List<string>() { iterator.Current.Tags },
                            Reference = new List<string>() { iterator.Current.Reference }
                        });
                    }
                    else {
                        if (!cMatch.Tags.Contains(iterator.Current.Tags)) {
                            cMatch.Tags.Add(iterator.Current.Tags);
                        }
                        cMatch.Reference.Add(iterator.Current.Reference);
                    }
                }
                iterator.MoveNext();
            }
            iterator.Dispose();
            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    spellingsView = CollectionViewSource.GetDefaultView(App.global.Transcript == 1 ? simple : corpus);
                    spellingsView.Filter = filter;
                    spellings.ItemsSource = spellingsView;
                    queryGrid.IsEnabled = true;
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    Pattern getMatch(string spelling, string rootLemma, List<Pattern> list) {
        if (list.Count == 0) return null;
        Pattern match = null;
        int half = list.Count / 2;
        for (int j = 0, k = list.Count - 1; j < half + 1 || k > half; j++, k--) {
            if (list[j].Spelling.Equals(spelling) && list[j].RootOrLemma.Equals(rootLemma)) return list[j];
            if (list[k].Spelling.Equals(spelling) && list[k].RootOrLemma.Equals(rootLemma)) return list[k];
        }
        return match;
    }

    bool filter(object o) {
        if (string.IsNullOrEmpty(query)) return true;

        var text = ((Pattern)o).Spelling;
        bool match =
            lengthToggle.IsOn ?
            query.Length <= text.Length :
            query.Length == text.Length;

        if (match) {
            for (int i = 0; i < query.Length; i++) {
                if (query[i] == '+') continue;
                if (query[i] != text[i]) {
                    match = false;
                    break;
                }
            }
        }
        return match;
    }

    Morph getMorph(Link item) {
        string tag = "";
        string[] tags;
        string details = "";

        if (searchMode == 1) {
            details = item.Details.Split(',')[Convert.ToInt32(item.RootIndex)];
            details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
            int lIndex;
            if (item.LemmaSimple.EndsWith(indexMa)) {
                // in 8 cases it ends with maA
                lIndex = 0;
            }
            else lIndex = item.LemmaIndices.Contains('|') ?
                    Convert.ToInt32(item.LemmaIndices.Split('|')[0]) :
                    Convert.ToInt32(item.LemmaIndices);

            tags = item.Tags.Split('|');
            tag = App.tags[Convert.ToInt32(tags[lIndex])].Name;
        }
        else if (searchMode == 2) {
            var indices = item.LemmaIndices.Split('|');
            if (indices.Length == 1) {
                details = item.Details.Split(',')[Convert.ToInt32(item.LemmaIndices)];
                details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
                int lIndex;
                if (item.LemmaSimple.EndsWith(indexMa)) {
                    // in 8 cases it ends with maA
                    lIndex = 0;
                }
                else lIndex = Convert.ToInt32(item.LemmaIndices);

                tags = item.Tags.Split('|');
                tag = App.tags[Convert.ToInt32(tags[lIndex])].Name;
            }
            else {
                builder.Clear();
                item.explain(builder);
                var m = new Morph() {
                    Segments = Helper.getSegments(item),
                    Tags = item.Tags.Split('|'),
                    Spellings = new string[] {
                                string.Join("", item.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)])),
                                string.Join("", item.SegmentsSimple.Split('|').Select(x => App.segments[Convert.ToInt32(x)]))
                            },
                    Explanation = builder.ToString(),
                    Tag = ""
                };
                m.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));
                return m;
            }
        }
        else {
            if (!item.SpellingGroupSimple.Contains('|')) {
                details = item.Details;
                details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
                tag = App.tags[Convert.ToInt32(item.Tags)].Name;
                tags = item.Tags.Split('|');
            }
            else {
                builder.Clear();
                item.explain(builder);
                var m = new Morph() {
                    Segments = Helper.getSegments(item),
                    Tags = item.Tags.Split('|'),
                    Spellings = new string[] {
                                string.Join("", item.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)])),
                                string.Join("", item.SegmentsSimple.Split('|').Select(x => App.segments[Convert.ToInt32(x)]))
                            },
                    Explanation = builder.ToString(),
                    Tag = ""
                };
                m.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));
                return m;
            }
        }

        Morph t = new() {
            Tag = tag,
            Tags = tags,
            Segments = Helper.getSegments(item),
            Spellings = getSpellings(item)
        };
        builder.Clear();
        item.explain(builder);

        t.Explanation = builder.ToString();
        t.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));

        var array = details.Split('|');
        if (App.tagArray.Contains(tag)) {
            for (int i = 0; i < array.Length; i++) {
                if (string.IsNullOrEmpty(array[i])) continue;
                if (array[i].Equals("PCPL") ||
                    array[i].Equals("ACC") ||
                    array[i].Equals("NOM") ||
                    array[i].Equals("GEN") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("ACT")) t.SubTag = "Active Participle";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive Participle";
                else if (array[i].Equals("VN")) t.SubTag = "Verbal Noun";
                else if (array[i].Equals("IN")) t.SubTag = "Noun";
                else if (array[i].Equals("CN")) t.SubTag = "Noun";
                else if (array[i].Equals("IP")) t.SubTag = "Particle";
                else if (array[i].Equals("CP")) t.SubTag = "Particle";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("V")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUBJ") ||
                    array[i].Equals("JUS") ||
                    array[i].Equals("JUSS") ||
                    array[i].Equals("SP:kaAn") ||
                    array[i].Equals("SP:kaAd") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("IMPF")) t.SubTag = "Imperfect";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive";
                else if (array[i].Equals("IMPV")) t.SubTag = "Imperative";
                else if (array[i].Equals("PERF")) t.SubTag = "Perfect";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("PRON")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUB")) t.SubTag = "Subject";
                else if (array[i].Equals("OBJ")) t.SubTag = "Object";
                else if (array[i].Equals("PER")) t.SubTag = "Personal";
                else if (array[i].Equals("POS")) t.SubTag = "Possessive";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name;
                else t.Gender = Helper.getGender(array[i]).Name;
            }
        }
        return t;

        string[] getSpellings(Link item) {
            int lIndex;
            if (item.LemmaSimple.EndsWith(indexMa)) {
                // in 8 cases it ends with maA
                lIndex = 0;
            }
            else {
                if (string.IsNullOrEmpty(item.LemmaIndices)) {
                    return new string[] {
                        item.SpellingGroupCorpus,
                        item.SpellingGroupSimple
                    };
                }
                lIndex = item.LemmaIndices.Contains('|') ?
                    Convert.ToInt32(item.LemmaIndices.Split('|')[0]) :
                    Convert.ToInt32(item.LemmaIndices);
            }
            return new string[] {
                item.SpellingGroupCorpus.Split('|')[lIndex],
                item.SpellingGroupSimple.Split('|')[lIndex]
            };
        }
    }

    protected override void unload() {
        terminator.Cancel();
        terminator.Dispose();
        queryBox.KeyUp -= onQuery;
        content.Loaded -= onLoaded;
        spellings.MouseRightButtonUp -= onRightButtonUp;
        spellings.SelectionChanged -= onSpellingSelectionChanged;
        listMorph.SelectionChanged -= onMorphSelectionChanged;
        listMeaning.MouseDoubleClick -= onMeaningDoubleClick;
        DataObject.RemovePastingHandler(queryBox, onPste);
        App.global.PropertyChanged -= onTranscriptChanged;
        TabView.Split -= onSplit;
        base.unload();
    }

    class SpellingTemplate : Grid {
        TextBlockArabic spelling, rootLemma;
        TextBlockEnglish tags, count;

        public SpellingTemplate() {
            spelling = new TextBlockArabic();
            rootLemma = new TextBlockArabic() {
                Margin = new Thickness(5, 0, 5, 0)
            };
            tags = new TextBlockEnglish() {
                Margin = new Thickness(0, 0, 10, 0),
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Center,
                TextWrapping = TextWrapping.Wrap
            };
            count = new TextBlockEnglish() {
                VerticalAlignment = VerticalAlignment.Center,
                Foreground = Brushes.Gray
            };
            SetColumn(rootLemma, 1);
            SetColumn(tags, 2);
            SetColumn(count, 3);

            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col1" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col2" });
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col4" });

            Children.Add(spelling);
            Children.Add(rootLemma);
            Children.Add(tags);
            Children.Add(count);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Pattern)DataContext;
            spelling.Text = c.Spelling.toArabic();
            if (!string.IsNullOrEmpty(c.RootOrLemma)) {
                if (c.HasRoot) {
                    if (c.RootOrLemma.Contains('|')) {
                        rootLemma.Text = string.Join(" | ", c.RootOrLemma.Split('|').Select(x => x.toArabic()));
                    }
                    else rootLemma.Text = c.RootOrLemma.toArabic();
                    rootLemma.Foreground = Brushes.Gray;
                }
                else {
                    rootLemma.Text = c.RootOrLemma.toArabic();
                    rootLemma.Foreground = Brushes.SkyBlue;
                }
            }
            tags.Text = string.Join(", ", c.Tags.Select(x => App.tags[Convert.ToInt32(x)].Name));
            count.Text = c.Reference.Count.ToString("N0");
        }
    }
}
