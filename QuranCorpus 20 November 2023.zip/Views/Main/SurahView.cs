﻿class SurahView : CardView {
    public override string Icon => Icons.Book;
    public override bool OverridesToolTip => true;
    public override UIElement Tip => getTip();
    
    WaterBox query;
    CheckGroup checkGroup;
    ListBox surahNames;
    SurahVM vm;
    
    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new SurahVM();
        DataContext = vm;
        initializeUI();
        bind();
        surahNames.PreviewMouseRightButtonDown += onRightButtonDown;
        surahNames.MouseRightButtonUp += onRightButtonUp;
    }

    void initializeUI() {
        query = new WaterBox() {
            Icon = Icons.Search,
            Hint = "Surah (english)"
        };
        checkGroup = new CheckGroup() {
            Icons = new string[] { Icons.NumberAscending, Icons.ClockAscending, Icons.NumberDescending },
            Tips = new string[] { "by chapter number", "by revealation order", "by number of ayah" },
            Margin = new Thickness(5, 0, 0, 0)
        };
        Grid.SetColumn(checkGroup, 1);
        var topGrid = new Grid() {
            Margin = new Thickness(0,5,0,5),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { query, checkGroup }
        };

        surahNames = new ListBox() {
            FlowDirection = FlowDirection.RightToLeft,
            Margin = new Thickness(5, 0, 0, 0),
            ItemTemplate = new SurahNameTemplate()
        };

        Grid.SetRow(surahNames, 1);
        
        var content = new Grid() { 
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { topGrid, surahNames }
        };
        setContent(content);
    }

    void bind() {
        surahNames.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Surahs)));
        surahNames.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.SelectedSurah)) { 
            Mode = BindingMode.OneWayToSource 
        });
        query.SetBinding(WaterBox.TextProperty, new Binding(nameof(vm.Query)) {
            Mode = BindingMode.OneWayToSource
        });
        checkGroup.SetBinding(CheckGroup.SelectedProperty, new Binding(nameof(vm.SelectedOrder)) { Mode = BindingMode.OneWayToSource });
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) {
        if (vm.SelectedSurah is null) return;
        ((App)Application.Current).FocusedControl.addSurahPage(vm.SelectedSurah.Id);
    }

    void onRightButtonDown(object sender, MouseButtonEventArgs e) => vm.WasRightClicked = true;

    Grid getTip() {
        var header = new TextBlockEnglish() {
            Text = "Surah",
            FontWeight = FontWeights.Bold
        };
        var separator = new Rectangle() {
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var description = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Text = "See all surah."
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(description, 2);
        return new Grid() {
            MaxWidth = 200,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(10) },
                new RowDefinition()
            },
            Children = { header, separator, description }
        };
    }
}
