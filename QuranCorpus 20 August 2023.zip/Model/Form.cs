﻿class Form {
    public string Root { get; set; }
    public string Detail { get; set; }
    public string Spelling { get; set; }
    public string Tag { get; set; }
}
