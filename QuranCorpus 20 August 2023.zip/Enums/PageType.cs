﻿enum PageType {
    Surah,
    Match,
    Lemma,
    LemmaLess,
    Segment,
    Tag,
    POS,
    Form,
    Matrix,
    Morph,
    CaseEnding,
    Search
}

