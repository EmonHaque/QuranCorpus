﻿
class WaterBox : Grid {
    Path path;
    TextBox inputBox;
    TextBlock hintBlock;

    public string Icon { set => path.Data = Geometry.Parse(value); }
    public string Hint { set => hintBlock.Text = value; }

    public WaterBox() {
        path = new Path() {
            Width = 12,
            Height = 12,
            IsHitTestVisible = false,
            Stretch = Stretch.Uniform,
            Fill = Brushes.LightGray,
            Margin = new Thickness(0, 0, 5, 0)
        };
        hintBlock = new TextBlock() {
            Margin = new Thickness(5, 0, 0, 0),
            IsHitTestVisible = false,
            Foreground = Brushes.Gray
        };
        inputBox = new TextBox() {
            BorderThickness = new Thickness(0, 0, 0, 0.5),
            BorderBrush = Brushes.LightGray
        };

        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        ColumnDefinitions.Add(new ColumnDefinition());

        SetColumn(hintBlock, 1);
        SetColumn(inputBox, 1);

        Children.Add(path);
        Children.Add(inputBox);
        Children.Add(hintBlock);

        hintBlock.SetBinding(TextBlock.VisibilityProperty, new Binding() {
            Path = new PropertyPath(nameof(Text)),
            Source = inputBox,
            Converter = new VisibilityConverter()
        });
    }

    protected override void OnMouseEnter(MouseEventArgs e) {
        Mouse.SetCursor(Cursors.IBeam);
    }
    protected override void OnMouseLeave(MouseEventArgs e) {
        Mouse.SetCursor(Cursors.Arrow);
    }

    protected override void OnGotKeyboardFocus(KeyboardFocusChangedEventArgs e) {
        path.Fill = Brushes.CornflowerBlue;
    }
    protected override void OnPreviewLostKeyboardFocus(KeyboardFocusChangedEventArgs e) {
        path.Fill = Brushes.White;
    }

    public string Text {
        get { return inputBox.Text; }
        set { inputBox.Text = value; }
    }

    public static readonly DependencyProperty TextProperty = TextBox.TextProperty.AddOwner(typeof(WaterBox));
}

class VisibilityConverter : IValueConverter {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        if (value is null) {
            return Visibility.Visible;
        }
        else {
            return string.IsNullOrEmpty(value.ToString()) ?
                Visibility.Visible :
                Visibility.Hidden;
        }
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}