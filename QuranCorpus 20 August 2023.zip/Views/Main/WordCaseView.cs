﻿class WordCaseView : CardView {
    public override string Icon => Icons.TrendingUp;
    public override string Header => "Case Endings";

    TextBlockEnglish count;
    ProgressBar progress;
    ListBox list;
    PageControl pages;
    WordCaseVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new WordCaseVM();
        DataContext = vm;
        pages = ((App)Application.Current).Pages;
        initializeUI();
        bind();
        list.PreviewMouseRightButtonDown += onRightButtonDown;
        list.MouseRightButtonUp += onRightButtonUp;
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) {
        e.Handled = true;
        if (vm.Selected is null) return;
        pages.addCaseEndingPage(vm.items);
        if (vm.WasRightClicked) vm.WasRightClicked = false;
    }

    void onRightButtonDown(object sender, MouseButtonEventArgs e) => vm.WasRightClicked = true;

    void initializeUI() {
        progress = new ProgressBar() {
            Height = 1.5,
            FlowDirection = FlowDirection.RightToLeft
        };
        list = new ListBox();
        Grid.SetRow(list, 1);

        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { progress, list }
        };
        setContent(grid);

        count = new TextBlockEnglish();
        addActions(new UIElement[] { count });
    }

    void bind() {
        progress.SetBinding(ProgressBar.IsIndeterminateProperty, new Binding(nameof(vm.IsInProgress)));
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Genders)));
        list.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.Selected)){ Mode = BindingMode.OneWayToSource });
        count.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = list,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
    }
}
