﻿class WordCaseVM : Notifiable {
    List<ErabWord> source;
    string[] tagArray = { "N", "PN", "ADJ" };

    public List<ErabWord> items;
    string selected;
    public string Selected {
        get { return selected; }
        set {
            if (value is null) {
                return;
            }
            if (value.Equals(selected)) return;

            selected = value;
            items = source.Where(x => x.Gender.Equals(value)).ToList();

            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }

            if (((App)Application.Current).Pages.SelectedPage is CaseEndingPage page) {
                page.setContent(items);
            }
        }
    }
    public bool WasRightClicked { get; set; }
    public bool IsInProgress { get; set; }
    public List<string> Genders { get; set; }

    public WordCaseVM() {
        IsInProgress = true;
        Task.Run(() => {
            List<ErabWord1> words = new();
            for (int i = 0; i < App.links.Count; i++) {
                var t = App.links[i].Tags.Split('|').Select(x => App.tags[Convert.ToInt32(x)].Name).ToArray();
                bool hasIt = false;
                bool hasDet = false;
                int index = 0;
                for (int j = 0; j < t.Length; j++) {
                    if (t[j].Equals("DET")) hasDet = true;

                    if (!tagArray.Contains(t[j])) continue;
                    hasIt = true;
                    index = j;
                    break;
                }
                if (!hasIt) continue;

                var segs = App.links[i].SegmentsSimple.Split('|');
                if (App.links[i].Root.Contains('|')) {
                    var roots = App.links[i].Root.Split('|');
                    foreach (var root in roots) {
                        var w = new ErabWord1() {
                            Spelling = App.spellings[Convert.ToInt32(App.links[i].SpellingGroupSimple.Split('|')[index])],
                            Tag = t[index],
                            Detail = App.links[i].Details.Split(',')[index],
                            Reference = App.links[i].Reference,
                            Word = string.Join("", segs.Select(x => App.segments[Convert.ToInt32(x)])),
                            Root = App.roots[Convert.ToInt32(root)],
                            Simple = App.segments[Convert.ToInt32(segs[index])],
                            Explanation = App.explanations[Convert.ToInt32(App.links[i].Explanation.Split('|')[index])],
                            HasDet = hasDet
                        };
                        index++;
                        setDetail(w);
                        words.Add(w);
                    }
                }
                else {
                    var w = new ErabWord1() {
                        Spelling = App.spellings[Convert.ToInt32(App.links[i].SpellingGroupSimple.Split('|')[index])],
                        Tag = t[index],
                        Detail = App.links[i].Details.Split(',')[index],
                        Reference = App.links[i].Reference,
                        Word = string.Join("", segs.Select(x => App.segments[Convert.ToInt32(x)])),
                        Root = string.IsNullOrEmpty(App.links[i].Root) ? "" : App.roots[Convert.ToInt32(App.links[i].Root)],
                        Simple = App.segments[Convert.ToInt32(segs[index])],
                        Explanation = App.explanations[Convert.ToInt32(App.links[i].Explanation.Split('|')[index])],
                        HasDet = hasDet
                    };
                    setDetail(w);
                    words.Add(w);
                }
            }

            var x = words
                .GroupBy(x => x.Root)
                .Select(x => new { x.Key, Value = x.GroupBy(x => x.Spelling).ToList() })
                .Select(x => new {
                    x.Key,
                    Value = x.Value.GroupBy(x => x.GroupBy(x => new { x.Gender, x.Erab }).ToList()).ToList()
                })
                .ToList();


            source = new List<ErabWord>();
            foreach (var root in x) {
                foreach (var spelling in root.Value) {
                    foreach (var item in spelling.Key) {
                        if (item.Key.Erab.Equals("Genitive")) {
                            foreach (var word in item) {
                                var match = source.Where(
                                    x => x.Gender.Equals(word.Gender) &&
                                    x.Root.Equals(word.Root) &&
                                    x.Spelling.Equals(word.Spelling)).ToList();

                                if (match.Count == 0) {
                                    var w = new ErabWord() {
                                        Root = word.Root,
                                        Tag = word.Tag,
                                        Gender = word.Gender,
                                        Spelling = word.Spelling
                                    };
                                    w.References.Add(word.Reference);
                                    source.Add(w);
                                    if (word.HasDet) w.DGenutive = word.Simple;
                                    else w.IGenitive = word.Simple;
                                }
                                else {
                                    ErabWord w = null;
                                    bool hasIt = false;
                                    if (word.HasDet) {
                                        for (int i = 0; i < match.Count; i++) {
                                            if (string.IsNullOrEmpty(match[i].DGenutive)) {
                                                hasIt = true;
                                                match[i].DGenutive = word.Simple;
                                                w = match[i];
                                                break;
                                            }
                                            if (!word.Simple.Equals(match[i].DGenutive)) continue;
                                            hasIt = true;
                                            w = match[i];
                                            break;
                                        }
                                    }
                                    else {
                                        for (int i = 0; i < match.Count; i++) {
                                            if (string.IsNullOrEmpty(match[i].IGenitive)) {
                                                hasIt = true;
                                                match[i].IGenitive = word.Simple;
                                                w = match[i];
                                                break;
                                            }
                                            if (!word.Simple.Equals(match[i].IGenitive)) continue;
                                            hasIt = true;
                                            w = match[i];
                                            break;
                                        }
                                    }
                                    if (!hasIt) {
                                        w = new ErabWord() {
                                            Root = word.Root,
                                            Tag = word.Tag,
                                            Gender = word.Gender,
                                            Spelling = word.Spelling
                                        };
                                        if (word.HasDet) w.DGenutive = word.Simple;
                                        else w.IGenitive = word.Simple;
                                        w.References.Add(word.Reference);
                                        source.Add(w);
                                    }
                                    else w.References.Add(word.Reference);
                                }
                            }
                        }
                        else if (item.Key.Erab.Equals("Nominative")) {
                            foreach (var word in item) {
                                var match = source.Where(
                                    x => x.Gender.Equals(word.Gender) &&
                                    x.Root.Equals(word.Root) &&
                                    x.Spelling.Equals(word.Spelling)).ToList();

                                if (match.Count == 0) {
                                    var w = new ErabWord() {
                                        Root = word.Root,
                                        Tag = word.Tag,
                                        Gender = word.Gender,
                                        Spelling = word.Spelling
                                    };
                                    w.References.Add(word.Reference);
                                    source.Add(w);
                                    if (word.HasDet) w.DNominative = word.Simple;
                                    else w.INominative = word.Simple;
                                }
                                else {
                                    ErabWord w = null;
                                    bool hasIt = false;
                                    if (word.HasDet) {
                                        for (int i = 0; i < match.Count; i++) {
                                            if (string.IsNullOrEmpty(match[i].DNominative)) {
                                                hasIt = true;
                                                match[i].DNominative = word.Simple;
                                                w = match[i];
                                                break;
                                            }
                                            if (!word.Simple.Equals(match[i].DNominative)) continue;
                                            hasIt = true;
                                            w = match[i];
                                            break;
                                        }
                                    }
                                    else {
                                        for (int i = 0; i < match.Count; i++) {
                                            if (string.IsNullOrEmpty(match[i].INominative)) {
                                                hasIt = true;
                                                match[i].INominative = word.Simple;
                                                w = match[i];
                                                break;
                                            }
                                            if (!word.Simple.Equals(match[i].INominative)) continue;
                                            hasIt = true;
                                            w = match[i];
                                            break;
                                        }

                                    }
                                    if (!hasIt) {
                                        w = new ErabWord() {
                                            Root = word.Root,
                                            Tag = word.Tag,
                                            Gender = word.Gender,
                                            Spelling = word.Spelling
                                        };
                                        if (word.HasDet) w.DNominative = word.Simple;
                                        else w.INominative = word.Simple;
                                        w.References.Add(word.Reference);
                                        source.Add(w);
                                    }
                                    else w.References.Add(word.Reference);
                                }
                            }
                        }
                        else {
                            foreach (var word in item) {
                                var match = source.Where(
                                     x => x.Gender.Equals(word.Gender) &&
                                     x.Root.Equals(word.Root) &&
                                     x.Spelling.Equals(word.Spelling)).ToList();

                                if (match.Count == 0) {
                                    var w = new ErabWord() {
                                        Root = word.Root,
                                        Tag = word.Tag,
                                        Gender = word.Gender,
                                        Spelling = word.Spelling
                                    };
                                    w.References.Add(word.Reference);
                                    source.Add(w);
                                    if (word.HasDet) w.DAccusative = word.Simple;
                                    else w.IAccusative = word.Simple;
                                }
                                else {
                                    ErabWord w = null;
                                    bool hasIt = false;
                                    if (word.HasDet) {
                                        for (int i = 0; i < match.Count; i++) {
                                            if (string.IsNullOrEmpty(match[i].DAccusative)) {
                                                hasIt = true;
                                                match[i].DAccusative = word.Simple;
                                                w = match[i];
                                                break;
                                            }
                                            if (!word.Simple.Equals(match[i].DAccusative)) continue;
                                            hasIt = true;
                                            w = match[i];
                                            break;
                                        }
                                    }
                                    else {
                                        for (int i = 0; i < match.Count; i++) {
                                            if (string.IsNullOrEmpty(match[i].IAccusative)) {
                                                hasIt = true;
                                                match[i].IAccusative = word.Simple;
                                                w = match[i];
                                                break;
                                            }
                                            if (!word.Simple.Equals(match[i].IAccusative)) continue;
                                            hasIt = true;
                                            w = match[i];
                                            break;
                                        }
                                    }
                                    if (!hasIt) {
                                        w = new ErabWord() {
                                            Root = word.Root,
                                            Tag = word.Tag,
                                            Gender = word.Gender,
                                            Spelling = word.Spelling
                                        };
                                        if (word.HasDet) w.DAccusative = word.Simple;
                                        else w.IAccusative = word.Simple;
                                        source.Add(w);
                                    }
                                    w.References.Add(word.Reference);
                                }
                            }
                        }
                    }
                }
            }

            IsInProgress = false;
            Genders = source.Select(x => x.Gender).Distinct().ToList();
            App.Current.Dispatcher.Invoke(() => {
                OnPropertyChanged(nameof(Genders));
                OnPropertyChanged(nameof(IsInProgress));
            });
        });
    }

    void setDetail(ErabWord1 word) {
        if (string.IsNullOrEmpty(word.Detail)) {
            word.Form = "I";
            word.Gender = "Undefined";
            word.SubTag = "";
            word.Erab = "";
            return;
        }
        var array = word.Detail.Split('|').Select(x => App.details[Convert.ToInt32(x)]).ToArray();
        var tag = word.Tag;

        for (int i = 0; i < array.Length; i++) {
            if (string.IsNullOrEmpty(array[i].Name)) continue;
            if (array[i].Name.Equals("PCPL") ||
                array[i].Name.Equals("INDEF")) continue;

            if (array[i].Name.Equals("ACT")) word.SubTag = "Active Participle";
            else if (array[i].Name.Equals("PASS")) word.SubTag = "Passive Participle";
            else if (array[i].Name.Equals("VN")) word.SubTag = "Verbal Noun";
            else if (array[i].Name.Equals("IN")) word.SubTag = "Noun";
            else if (array[i].Name.Equals("CN")) word.SubTag = "Noun";
            else if (array[i].Name.Equals("IP")) word.SubTag = "Particle";
            else if (array[i].Name.Equals("CP")) word.SubTag = "Particle";
            else if (array[i].Name.Equals("ACC")) word.Erab = "Accusative";
            else if (array[i].Name.Equals("GEN")) word.Erab = "Genitive";
            else if (array[i].Name.Equals("NOM")) word.Erab = "Nominative";
            else if (array[i].Name.StartsWith('(')) word.Form = Helper.getForm(array[i].Name).Name.Replace("(", "").Replace(")", "");
            else word.Gender = Helper.getGender(array[i].Name).Name;
        }

        if (string.IsNullOrEmpty(word.Gender)) word.Gender = "Undefined";
    }

    class ErabWord1 {
        public string Reference { get; set; }
        public string Word { get; set; }
        public string Spelling { get; set; }
        public string Simple { get; set; }
        public string Tag { get; set; }
        public string Gender { get; set; }
        public string Erab { get; set; }
        public string Detail { get; set; }
        public string Root { get; set; }
        public string SubTag { get; set; }
        public string Form { get; set; }
        public bool HasDet { get; set; }
        public string Explanation { get; set; }
    }
}
