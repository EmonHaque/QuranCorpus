﻿class ReciterPage : Page {
    string currentSurah, currentReciter;
    int ayahCount;
    Grid content;
    CancellationTokenSource terminator;
    ProgressBar progress;
    TextBlock count, gotoBlock;
    TextBox gotoBox;
    ListBox ayahListBox;
    
    public FontFamily Font { get; set; }

    public override PageType Type => PageType.Reciter;
    public override UIElement Content => content;

    public ReciterPage() {
        terminator = new CancellationTokenSource();

        count = new TextBlock() {
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(7, 0, 7, 0)
        };
        gotoBlock = new TextBlock() {
            Text = "go to: ",
            VerticalAlignment = VerticalAlignment.Bottom
        };
        gotoBox = new TextBox() {
            TextAlignment = TextAlignment.Right,
            VerticalContentAlignment = VerticalAlignment.Bottom,
            CaretBrush = Brushes.LightGray,
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness)
        };
        Grid.SetColumn(gotoBlock, 1);
        Grid.SetColumn(gotoBox, 2);
        var toolGrid = new Grid() {
            Margin = new Thickness(5, 0, 0, 5),
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width =  GridLength.Auto },
                new ColumnDefinition(){ Width = new GridLength(50) }
            },
            Children = { count, gotoBlock, gotoBox }
        };

        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };

        ayahListBox = new ListBox() {
            DataContext = this,
            FlowDirection = FlowDirection.RightToLeft,
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(AyahTemplate))
            },
            ItemContainerStyle = new Style(typeof(ListBoxItem), new Style() {
                Setters = {
                    new Setter(ListBoxItem.TemplateProperty, new ListBoxItemTemplate()),
                    new EventSetter(ListBoxItem.PreviewGotKeyboardFocusEvent, new KeyboardFocusChangedEventHandler(selectCurrentItem))
                }
            })
        };
        ayahListBox.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        ayahListBox.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        Grid.SetRow(toolGrid, 1);
        Grid.SetRow(ayahListBox, 2);

        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, toolGrid, ayahListBox }
        };
        gotoBox.KeyUp += onGoto;
    }

    public ReciterPage(string reciter, string surah) : this() => reset(reciter, surah);

    public void setContent(string reciter, string surah) => reset(reciter, surah);

    void reset(string reciter, string surah) {
        HeaderText = surah + ") " + App.surahs[Convert.ToInt32(surah) - 1].Transliteration + " | " + reciter;
        
        currentReciter = reciter;
        currentSurah = surah;
        progress.IsIndeterminate = true;

        Task.Run(() => {
            var file = System.IO.File.ReadLines("Resources/KFGQPC/Recitations/" + reciter + ".txt");
            var iterator = file.GetEnumerator();
            iterator.MoveNext();
            var no = surah + "|";
            while (!iterator.Current.StartsWith(currentSurah)) iterator.MoveNext();

            ayahCount = 0;
            List<Tuple<string, string>> list = new();
            while (iterator.Current.StartsWith(currentSurah)) {
                if (terminator.IsCancellationRequested) break;

                var parts = iterator.Current.Split('|');
                list.Add(new Tuple<string, string>(parts[1], parts[2]));
                ayahCount++;

                iterator.MoveNext();
                if (iterator.Current is null) break;
            }

            Font = Helper.getReciterFont(reciter);

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    count.Text = ayahCount + " ayah in " + currentReciter + ",";
                    ayahListBox.ItemsSource = list;
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    void selectCurrentItem(object sender, KeyboardFocusChangedEventArgs e) {
        var item = (ListBoxItem)sender;
        item.IsSelected = true;
    }

    void onGoto(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        var reference = gotoBox.Text.Trim();
        if (reference.Contains(':')) {
            var parts = reference.Split(':');
            if (parts.Length != 2) return;

            var isParsed = int.TryParse(parts[0], out int surah);
            if (!isParsed) return;
            if (surah < 1 || surah > 114) return;

            isParsed = int.TryParse(parts[1], out int ayah);
            if (!isParsed) return;

            int surahNo = Convert.ToInt32(currentSurah);

            int noOfAyah = surahNo == surah ? ayahCount : getAyahCount(surah);
            if (ayah < 1 || ayah > noOfAyah) return;

            if (surahNo == surah) gotoAyah(ayah.ToString());
            else {
                ayahCount = noOfAyah;
                goToSurah(reference);
            }
        }
        else {
            var isParsed = int.TryParse(reference, out int ayah);
            if (!isParsed) return;
            if (ayah < 1 || ayah > ayahCount) return;
            gotoAyah(ayah.ToString());
        }
    }

    void gotoAyah(string ayah) {
        foreach (var item in ayahListBox.Items) {
            if (!((Tuple<string, string>)item).Item1.Equals(ayah)) continue;
            ayahListBox.SelectedItem = item;
            ayahListBox.ScrollIntoView(ayahListBox.SelectedItem);
            break;
        }
    }

    void goToSurah(string reference) {
        var parts = reference.Split(":");
        currentSurah = parts[0];
        HeaderText = currentSurah + ") " + App.surahs[Convert.ToInt32(currentSurah) - 1].Transliteration + " | " + currentReciter;
        progress.IsIndeterminate = true;

        Task.Run(() => {
            var file = System.IO.File.ReadLines("Resources/KFGQPC/Recitations/" + currentReciter + ".txt");
            var iterator = file.GetEnumerator();
            iterator.MoveNext();
            var no = currentSurah + "|";
            while (!iterator.Current.StartsWith(currentSurah)) iterator.MoveNext();

            ayahCount = 0;
            List<Tuple<string, string>> list = new();
            while (iterator.Current.StartsWith(currentSurah)) {
                if (terminator.IsCancellationRequested) break;

                var parts = iterator.Current.Split('|');
                list.Add(new Tuple<string, string>(parts[1], parts[2]));
                ayahCount++;

                iterator.MoveNext();
                if (iterator.Current is null) break;
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    count.Text = ayahCount + " ayah in " + currentReciter + ",";
                    ayahListBox.ItemsSource = list;
                    ayahListBox.SelectedItem = list[Convert.ToInt32(parts[1]) - 1];
                    ayahListBox.LayoutUpdated += onLayoutUpdated;
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    void onLayoutUpdated(object? sender, EventArgs e) {
        ayahListBox.LayoutUpdated -= onLayoutUpdated;
        App.Current.Dispatcher.InvokeAsync(() => {
            ayahListBox.ScrollIntoView(ayahListBox.SelectedItem);
            var panel = Helper.FindVisualChild<VirtualizingStackPanel>(ayahListBox);
            var items = Helper.FindVisualChildren<ListBoxItem>(panel);
            var selected = Convert.ToInt32(((Tuple<string, string>)ayahListBox.SelectedItem).Item1);

            foreach (var item in items) {
                var presenter = Helper.FindVisualChild<ContentPresenter>(item);
                var ayah = (Tuple<string, string>)presenter.Content;
                if (Convert.ToInt32(ayah.Item1) == selected) {
                    presenter.BringIntoView();
                    break;
                }
            }
            progress.IsIndeterminate = false;
        }, DispatcherPriority.Background);
    }

    int getAyahCount(int surah) {
        var file = System.IO.File.ReadLines("Resources/KFGQPC/Surah/" + currentReciter + ".txt");
        var iterator = file.GetEnumerator();
        iterator.MoveNext();
        var no = surah.ToString();
        while (!iterator.Current.StartsWith(no)) iterator.MoveNext();
        int count = Convert.ToInt32(iterator.Current.Split("\t")[2]);
        iterator.Dispose();
        return count;
    }

    protected override void unload() {
        gotoBox.KeyUp -= onGoto;
        terminator.Cancel();
        terminator.Dispose();
        base.unload();
    }

    class AyahTemplate : TextBox {
        ContextPopup context;
        public AyahTemplate() {
            ContextMenu = null;
            Background = null;
            SelectionBrush = new SolidColorBrush(Color.FromArgb(150, 0, 0, 0));
            TextWrapping = TextWrapping.Wrap;
            BorderThickness = new Thickness(0);
            IsReadOnly = true;
            SetBinding(TextBox.FontSizeProperty, new Binding() {
                Path = new PropertyPath(nameof(Global.ArabicFontSize)),
                Source = App.global
            });
            SetBinding(TextBox.FontFamilyProperty, new Binding() {
                Path = new PropertyPath("DataContext.Font"),
                Mode = BindingMode.OneTime,
                RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(ListBox), 1)
            });
            context = new ContextPopup(new List<ContextItem>() {
                new ContextItem(){ Icon = Icons.Copy, Text = "copy", Command =  () => ApplicationCommands.Copy.Execute(null, null) }
            });
        }

        public override void EndInit() {
            base.EndInit();
            var ayah = (Tuple<string, string>)DataContext;
            Text = ayah.Item1.toArabicNo() + " " + ayah.Item2;
        }

        protected override void OnMouseRightButtonUp(MouseButtonEventArgs e) {
            base.OnMouseRightButtonUp(e);
            context.IsOpen = true;
        }

        protected override void OnPreviewDragOver(DragEventArgs e) {
            e.Handled = true;
        }
    }
}
