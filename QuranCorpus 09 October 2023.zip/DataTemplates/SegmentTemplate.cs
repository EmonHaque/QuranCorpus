﻿class SegmentTemplate : Grid {
    TextBlockArabic word1, word2;
    Run count1, count2;
    public SegmentTemplate()
    {
        word1 = new TextBlockArabic();
        word2 = new TextBlockArabic();
        count1 = new Run();
        count2 = new Run();
        var countBlock = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center,
            Inlines = { count1, new Run(" | "), count2}
        };
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto});
        
        SetColumn(word1, 1);
        SetColumn(countBlock, 2);
        
        Children.Add(word1);
        Children.Add(word2);
        Children.Add(countBlock);
    }

    public override void EndInit() {
        base.EndInit();
        var context = (Segment)DataContext;
        // in all cases there're two variation in segmentation
        count1.Text = context.References[0].Count.ToString("N0");
        count2.Text = context.References[1].Count.ToString("N0");

        int pronCount, otherCount, index;
        pronCount = otherCount = index = 0;
        string lastPos = "";
        StringBuilder builder = new();

        var segments = context.Segments[0].Split('|');
        var tags = context.Tags[0].Split('|');
        foreach (var segment in segments) {
            segment.toArabic(segments, builder);
            var run = new Run(builder.ToString());
            builder.Clear();

            var tag = App.tags[Convert.ToInt32(tags[index])].Name;
            switch (tag) {
                case "DET": run.Foreground = Foregrounds.DET_Brush; break;
                case "V": run.Foreground = Foregrounds.V_Brush; break;
                case "N":
                case "PN":
                case "ADJ": run.Foreground = Foregrounds.N_PN_ADJ_Brush; break;
                case "REL":
                case "DEM": run.Foreground = Foregrounds.DEM_REL_Brush; break;
                case "P": run.Foreground = Foregrounds.P_Brush; break;
                case "CONJ": run.Foreground = Foregrounds.CONJ_Brush; break;
                case "INTG": run.Foreground = Foregrounds.INTG_Brush; break;
                case "NEG": run.Foreground = Foregrounds.NEG_Brush; break;
                case "PRON":
                    if (lastPos.Equals("PRON")) pronCount++;
                    if (pronCount == 1) run.Foreground = Foregrounds.PRON1_Brush;
                    else if (pronCount == 2) run.Foreground = Foregrounds.PRON2_Brush;
                    else run.Foreground = Foregrounds.PRON3_Brush;
                    break;
                default:
                    if (!Foregrounds.Defined.Contains(lastPos)) otherCount++;
                    if (otherCount == 1) run.Foreground = Foregrounds.OTHER1_Brush;
                    else if (otherCount == 2) run.Foreground = Foregrounds.OTHER2_Brush;
                    else run.Foreground = Foregrounds.OTHER3_Brush;
                    break;
            }
            lastPos = tag;
            word1.Inlines.Add(run);
            index++;
        }

        pronCount = otherCount = index = 0;
        lastPos = "";
        builder.Clear();

        segments = context.Segments[1].Split('|');
        tags = context.Tags[1].Split('|');
        foreach (var segment in segments) {
            segment.toArabic(segments, builder);
            var run = new Run(builder.ToString());
            builder.Clear();

            var tag = App.tags[Convert.ToInt32(tags[index])].Name;
            switch (tag) {
                case "DET": run.Foreground = Foregrounds.DET_Brush; break;
                case "V": run.Foreground = Foregrounds.V_Brush; break;
                case "N":
                case "PN":
                case "ADJ": run.Foreground = Foregrounds.N_PN_ADJ_Brush; break;
                case "REL":
                case "DEM": run.Foreground = Foregrounds.DEM_REL_Brush; break;
                case "P": run.Foreground = Foregrounds.P_Brush; break;
                case "CONJ": run.Foreground = Foregrounds.CONJ_Brush; break;
                case "INTG": run.Foreground = Foregrounds.INTG_Brush; break;
                case "NEG": run.Foreground = Foregrounds.NEG_Brush; break;
                case "PRON":
                    if (lastPos.Equals("PRON")) pronCount++;
                    if (pronCount == 1) run.Foreground = Foregrounds.PRON1_Brush;
                    else if (pronCount == 2) run.Foreground = Foregrounds.PRON2_Brush;
                    else run.Foreground = Foregrounds.PRON3_Brush;
                    break;
                default:
                    if (!Foregrounds.Defined.Contains(lastPos)) otherCount++;
                    if (otherCount == 1) run.Foreground = Foregrounds.OTHER1_Brush;
                    else if (otherCount == 2) run.Foreground = Foregrounds.OTHER2_Brush;
                    else run.Foreground = Foregrounds.OTHER3_Brush;
                    break;
            }
            lastPos = tag;
            word2.Inlines.Add(run);
            index++;
        }
    }
}
