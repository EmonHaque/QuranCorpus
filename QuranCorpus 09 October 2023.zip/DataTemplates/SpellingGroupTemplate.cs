﻿class SpellingGroupTemplate : Grid {
    TextBlockArabic arabic;
    TextBlockEnglish count;

    public SpellingGroupTemplate() {
        arabic = new TextBlockArabic();
        count = new TextBlockEnglish() { VerticalAlignment = VerticalAlignment.Center };
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

        SetColumn(count, 1);
        Children.Add(arabic);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var header = (Tuple<string, string>)DataContext;
        arabic.Text = header.Item1;
        count.Text = header.Item2;
    }
}
