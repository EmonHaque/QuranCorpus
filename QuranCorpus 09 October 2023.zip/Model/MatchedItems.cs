﻿class MatchedItems {
    public string Header { get; set; }
    public List<Match> Items { get; set; }
}

class HiMatchedItems {
    public string Header { get; set; }
    public List<MatchedItems> Items { get; set; }
}

class LemmaGroup {
    public string Lemma { get; set; }
    public List<IGrouping<string, Match>> Spelling { get; set; }
}
