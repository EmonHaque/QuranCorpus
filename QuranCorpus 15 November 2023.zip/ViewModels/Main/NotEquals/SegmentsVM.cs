﻿class SegmentsVM : Notifiable {
    Segment selected;
    public Segment Selected {
        get { return selected; }
        set {
            if (value is null) return;
            if (!value.Equals(selected)) {
                selected = value;
            }
            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).FocusedControl.SelectedPage is SegmentPage page) {
                page.setContent(value);
            }
        }
    }
    public List<Segment> Segments { get; set; }
    public bool WasRightClicked { get; set; }
    public bool IsInProgress { get; set; }

    public SegmentsVM() {
        IsInProgress = true;
        Task.Run(() => {
            var groups = App.links
            .GroupBy(x => new {
                x.SegmentsCorpus,
                Literal = string.Join("", x.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)])),
                Value = x.Tags.Split('|').Length
            })
            .GroupBy(x => x.Key.Literal)
            .Where(x => x.Count() > 1)
            .ToList();

            Segments = new List<Segment>(groups.Count);

            foreach (var word in groups) {
                var items = word.ToList();
                var segment = new Segment() {
                    Segments = new string[items.Count],
                    Spellings = new string[items.Count],
                    Tags = new string[items.Count],
                    Details = new string[items.Count],
                    References = new List<Link>[items.Count]
                };

                for (int i = 0; i < items.Count; i++) {
                    var first = items[i].First();
                    segment.Segments[i] = first.SegmentsCorpus;
                    segment.Spellings[i] = first.SpellingGroupCorpus;
                    segment.Details[i] = first.Details;
                    segment.Tags[i] = first.Tags;
                    segment.References[i] = new List<Link>(items[i]);
                }
                Segments.Add(segment);
            }
            IsInProgress = false;
            App.Current.Dispatcher.Invoke(() => {
                OnPropertyChanged(nameof(IsInProgress));
                OnPropertyChanged(nameof(Segments));
                
            });
        });

    }
}
