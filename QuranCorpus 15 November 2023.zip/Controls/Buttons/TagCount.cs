﻿class TagCount : WrapPanel {
    List<TagItem> items;
    public List<TagItem> Items {
        get { return items; }
        set { 
            items = value;
            Children.Clear();
            for (int i = 0; i < items.Count; i++) {
                var tag = new Tag(items[i]);
                tag.Margin = new Thickness(0, 0, (i == items.Count - 1) ? 0 : 5, 5);
                Children.Add(tag);
            }
        }
    }
    
    TagItem selected;
    public TagItem Selected {
        get { return selected; }
        set { 
            selected = value;
            for (int i = 0; i < Children.Count; i++) {
                var tag = (Tag)Children[i];
                if (!tag.Item.Equals(selected)) {
                    if (tag.IsSelected) tag.IsSelected = false;
                }
                else tag.IsSelected = true;
            }
        }
    }

    public event Action<TagItem> SelectionChanged;

    public void ResetNumbers(List<int> numbers) {
        for (int i = 0; i < Items.Count; i++) {
            var tag = (Tag)Children[i];
            tag.setNumber(numbers[i]);
        }
    }

    protected override void OnPreviewMouseLeftButtonUp(MouseButtonEventArgs e) {
        base.OnPreviewMouseLeftButtonUp(e);
        Tag selected = null;
        for (int i = 0; i < Children.Count; i++) {
            var tag = (Tag)Children[i];
            if (Children[i].Equals(e.Source)) {
                tag.IsSelected = true;
                selected = tag;
            }
            else if (tag.IsSelected) tag.IsSelected = false;
        }
        this.selected = selected.Item;
        SelectionChanged?.Invoke(selected.Item);
    }

    class Tag : Border {
        Brush background;
        TextBlock text, count;
        bool isSelected;
        public bool IsSelected {
            get { return isSelected; }
            set { 
                isSelected = value;
                if (!IsSelected) normalize();
                else highlight();
            }
        }

        public TagItem Item { get; set; }

        public Tag(TagItem item) {
            Item = item;
            BorderBrush = Brushes.Gray;
            BorderThickness = new Thickness(Constants.BottomLineThickness);
            CornerRadius = new CornerRadius(10);
            Padding = new Thickness(5, 2.5, 5, 2.5);
            Background = Brushes.Transparent;
            background = new SolidColorBrush(Color.FromArgb(50, 0, 0, 0));

            text = new TextBlock() { 
                Text = item.Name, 
                Margin = new Thickness(0, 0, 5, 0)
            };
            count = new TextBlock() { 
                Text = item.Count.ToString("N0"),
                Foreground = Brushes.Gray
            };

            Child = new StackPanel() {
                IsHitTestVisible = false,
                Orientation = Orientation.Horizontal,
                Children = { text, count } 
            };
        }

        public void setNumber(int no) {
            count.Text = no.ToString("N0");
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            base.OnMouseEnter(e);
            if (IsSelected) return;
            highlight();
        }

        protected override void OnMouseLeave(MouseEventArgs e) {
            base.OnMouseLeave(e);
            if (IsSelected) return;
            normalize();
        }

        void highlight() {
            BorderBrush = Brushes.LightGray;
            Background = background;
            count.Foreground = Constants.Foreground;
        }

        void normalize() {
            BorderBrush = Brushes.Gray;
            Background = Brushes.Transparent;
            count.Foreground = Brushes.Gray;
        }
    }
    
    public class TagItem {
        public string Name { get; set; }
        public int Count { get; set; }
    }
}
