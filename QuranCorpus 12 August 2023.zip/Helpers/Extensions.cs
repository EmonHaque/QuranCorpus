﻿static class Extensions {
    static StringBuilder builder = new();

    public static string toArabic(this string transcription) {
        builder.Clear();
        foreach (var character in transcription) {
            if (character == ' ') {
                builder.Append(' '); // happens only once in case of prophet il yas, eg. 37:130
                continue;
            } 
            char c = (char)uint.Parse(App.characters.First(x => x.English == character).Arabic, NumberStyles.HexNumber);
            builder.Append(c);
        }
        return builder.ToString();
    }

    public static void toArabic(this string transcription, string[] segments, StringBuilder sb) {
        var characters = App.segments[Convert.ToInt32(transcription)];
        foreach (var character in characters) {
            if (character == ' ') {
                sb.Append(' '); // happens only once in case of prophet il yas, eg. 37:130
                continue;
            }
            char c = (char)uint.Parse(App.characters.First(x => x.English == character).Arabic, NumberStyles.HexNumber);
            sb.Append(c);
        }
    }

    public static void toArabic(this string[] segments, StringBuilder sb) {
        foreach (var segment in segments) {
            var characters = App.segments[Convert.ToInt32(segment)];
            foreach (var character in characters) {
                if (character == ' ') {
                    sb.Append(' '); // happens only once in case of prophet il yas, eg. 37:130
                    continue;
                }
                char c = (char)uint.Parse(App.characters.First(x => x.English == character).Arabic, NumberStyles.HexNumber);
                sb.Append(c);
            }
        }
    }

    public static string toRoot(this string transcription) {
        builder.Clear();
        foreach (var character in transcription) {
            var y = character == 'A' ? '>' : character;
            char c = (char)uint.Parse(App.characters.First(x => x.English == y).Arabic, NumberStyles.HexNumber);
            builder.Append(c).Append(' ');
        }
        builder.Remove(builder.Length - 1, 1);
        return builder.ToString();
    }
    
    public static string toTransliteratedRoot(this string transcription) {
        builder.Clear();
        foreach (var character in transcription) {
            var c = character == 'A' ? '\'' : character;
            builder.Append(App.characters.First(x => x.English == c).Transliteration).Append(' ');
        }
        builder.Remove(builder.Length - 1, 1);
        return builder.ToString();
    }

    public static string toArabicNo(this string value) {
        return value.Replace('0', '\u0660')
              .Replace('1', '\u0661')
              .Replace('2', '\u0662')
              .Replace('3', '\u0663')
              .Replace('4', '\u0664')
              .Replace('5', '\u0665')
              .Replace('6', '\u0666')
              .Replace('7', '\u0667')
              .Replace('8', '\u0668')
              .Replace('9', '\u0669');
    }

    public static void explain(this Word word, StringBuilder builder, string[] tags, bool hasDeterminant) {
        var parts = word.Reference.Split(':');
        string wordNo = parts[2] switch {
            "1" => "st ",
            "2" => "nd ",
            "3" => "rd",
            _ => "th "
        };
        builder
            .Append("The ")
            .Append(parts[2])
            .Append(wordNo)
            .Append(" word")
            .Append(" of verse ")
            .Append(parts[1])
            .Append(" of chapter ")
        .Append(parts[0]);

        var divisionCount = hasDeterminant ? tags.Length - 1 : tags.Length;
        var explanations = word.Explanation.Split('|');
        var details = word.Details.Split(',');
        var roots = new List<string>(explanations.Length);
        var r = word.Root.Split('|');

        if (!string.IsNullOrEmpty(word.RootIndex)) {
            var index = Convert.ToInt32(word.RootIndex);
            for (int i = 0; i < explanations.Length; i++) {
                if (i == index) roots.Add(r[0]);
                else roots.Add("");
            }
            if (r.Length > 1) roots[++index] = r[1];
        }
        else for (int i = 0; i < explanations.Length; i++) roots.Add("");

        List<string> tagNames = new();
        for (int i = 0; i < tags.Length; i++) {
            var tag = App.tags[Convert.ToInt32(tags[i])];
            var tagName = Helper.getTagName(tag, details[i]);
            tagNames.Add(tagName);
        }

        if (divisionCount > 1) {
            builder
                .Append(" is divided into ")
                .Append(divisionCount)
                .Append(" morphological segments. ")
                .Append(
                (tagNames[0].StartsWith('a') || tagNames[0].StartsWith('e') || tagNames[0].StartsWith('i')) ?
                "An " : "A ");

            var groups = tagNames.GroupBy(x => x).ToList();
            for (int i = 0; i < groups.Count; i++) {
                if (i > 0) {
                    builder.Append(i < groups.Count - 1 ? ", " : " and ");
                }
                if (groups[i].Count() > 1) {
                    builder.Append("two ").Append(groups[i].Key).Append('s');
                }
                else builder.Append(groups[i].Key);
            }
            builder.Append(".");
        }
        builder.Append(' ');

        for (int i = 0; i < explanations.Length; i++) {
            if (string.IsNullOrEmpty(explanations[i])) continue;
            Tuple<string, string> tup = null;

            var exp = App.explanations[Convert.ToInt32(explanations[i])];
            tup =
                Helper.getExplanations(exp, "jār wa majrūr") ??
                Helper.getExplanations(exp, "kāda and her sisters") ??
                Helper.getExplanations(exp, "kāna and her sisters");

            builder
                .Append(tup is null ? exp : tup.Item1)
                .Append('.');

            if (!string.IsNullOrEmpty(roots[i])) {
                var root = App.roots[Convert.ToInt32(roots[i])];
                builder
                    .Append(' ')
                    .Append("The ")
                    .Append(tagNames[i])
                    .Append('\'')
                    .Append('s')
                    .Append(root.Length == 3 ? " triliteral " : " quadriliteral ")
                    .Append("root is ")
                    .Append(root.toTransliteratedRoot())
                    .Append(" (")
                    .Append(root.toRoot())
                    .Append(").");
            }
            if (tup is not null && tup.Item2 is not null) {
                builder.Append(' ').Append(tup.Item2).Append('.');
            }
            builder.Append(' ');
        }
        builder.Remove(builder.Length - 1, 1);
    }

    public static void explain(this Link link, StringBuilder builder) {
        var tags = link.Tags.Split('|');
        bool hasDeterminant = false;
        for (int i = 0; i < tags.Length; i++) {
            if (!App.tags[Convert.ToInt32(tags[i])].Name.Equals("DET")) continue;
            hasDeterminant = true;
            break;
        }
        var divisionCount = hasDeterminant ? tags.Length - 1 : tags.Length;
        var explanations = link.Explanation.Split('|');
        var details = link.Details.Split(',');

        List<string> tagNames = new();
        for (int i = 0; i < tags.Length; i++) {
            var tag = App.tags[Convert.ToInt32(tags[i])];
            var tagName = Helper.getTagName(tag, details[i]);
            tagNames.Add(tagName);
        }

        if (divisionCount > 1) {
            builder.Append(
                (tagNames[0].StartsWith('a') || tagNames[0].StartsWith('e') || tagNames[0].StartsWith('i')) ?
                "An " : "A ");

            var groups = tagNames.GroupBy(x => x).ToList();
            for (int i = 0; i < groups.Count; i++) {
                if (i > 0) {
                    builder.Append(i < groups.Count - 1 ? ", " : " and ");
                }
                if (groups[i].Count() > 1) {
                    builder.Append("two ").Append(groups[i].Key).Append('s');
                }
                else builder.Append(groups[i].Key);
            }
            builder.Append(". ");
        }

        for (int i = 0; i < explanations.Length; i++) {
            if (string.IsNullOrEmpty(explanations[i])) continue;
            var exp = App.explanations[Convert.ToInt32(explanations[i])];
            builder.Append(exp).Append(". ");
        }
        builder.Remove(builder.Length - 1, 1);
    }
}
