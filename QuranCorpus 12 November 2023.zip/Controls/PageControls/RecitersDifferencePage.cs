﻿class RecitersDifferencePage : Page {
    Grid content;
    TreeView tree;

    public override PageType Type => PageType.RecitersDifference;
    public override UIElement Content => content;

    public RecitersDifferencePage() {
        HeaderText = "Difference";
        tree = new TreeView() { 
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 0, 0),
            ItemContainerStyle = new Style(typeof(TreeViewItem)) {
                Setters = {
                    new Setter(TreeViewItem.TemplateProperty, new TreeItemTemplate()),
                    new Setter(TextElement.ForegroundProperty, Brushes.LightGray),
                    new EventSetter(TreeViewItem.RequestBringIntoViewEvent, new RequestBringIntoViewEventHandler((s,e) => e.Handled = true))
                }
            }
        };
        tree.SetValue(Grid.IsSharedSizeScopeProperty, true);
        tree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true); // no default virtualization

        var groups = getDifferences().GroupBy(x => x.Type).ToList();
        foreach (var group in groups) {
            var item = new TreeViewItem() {
                Header = new Tuple<string, int>(group.Key, group.Count()),
                HeaderTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(HeaderTemplate))
                },
                ItemsSource = group.ToList(),
                ItemTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(DifferenceTemplate))
                }
            };
            tree.Items.Add(item);
        }
        var info = new TextBoxEnglish() {
            Margin = new Thickness(0,5,0,0),
            Visibility = Visibility.Collapsed,
            FlowDirection = FlowDirection.LeftToRight,
            TextWrapping = TextWrapping.Wrap,
            Text = System.IO.File.ReadAllText("Resources/KFGQPC/differntiationProcess.txt")
        };
        info.SetValue(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Auto);
        

        var infoButton = new ActionButton() {
            ToolTip = "toggle info",
            HorizontalAlignment = HorizontalAlignment.Left,
            Icon = Icons.Info,
            Command = () => {
                if(info.Visibility == Visibility.Visible) {
                    info.Visibility = Visibility.Collapsed;
                    content.RowDefinitions[1].Height  = new GridLength(0);
                }
                else {
                    info.Visibility = Visibility.Visible;
                    content.RowDefinitions[1].Height = new GridLength(1, GridUnitType.Star);
                }
            }
        };

        Grid.SetRow(info, 1);
        Grid.SetRow(tree, 2);
        

        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){ Height = new GridLength(0)},
                 new RowDefinition(),
            },
            Children = { infoButton, info, tree }
        };
    }

    List<Difference> getDifferences() {
        var list = new List<Difference>();
        var lines = System.IO.File.ReadAllLines("Resources/KFGQPC/differences.txt").Skip(1);
        foreach (var line in lines) {
            var parts = line.Split("\t");
            list.Add(new Difference() {
                Hafs = parts[0],
                Bazzi = parts[1],
                Douri = parts[2],
                Qaloun = parts[3],
                Qunbul = parts[4],
                Shuba = parts[5],
                Sousi = parts[6],
                Warsh = parts[7],
                CountBazzi = parts[8],
                CountDouri = parts[9],
                CountQaloun = parts[10],
                CountQunbul = parts[11],
                CountShuba = parts[12],
                CountSousi = parts[13],
                CountWarsh = parts[14],
                RefBazzi = parts[15],
                RefDouri = parts[16],
                RefQaloun = parts[17],
                RefQunbul = parts[18],
                RefShuba = parts[19],
                RefSousi = parts[20],
                RefWarsh = parts[21],
                Type = parts[22]
            });
        }

        list.Sort(new DifferenceComparer());

        return list;
    }

    class HeaderTemplate : Grid {
        TextBlockEnglish type, count;
        public HeaderTemplate() {
            type = new TextBlockEnglish();
            count = new TextBlockEnglish() { HorizontalAlignment = HorizontalAlignment.Right };

            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());

            SetColumn(count, 1);

            Children.Add(type);
            Children.Add(count);
        }

        public override void EndInit() {
            base.EndInit();
            var d = (Tuple<string, int>)DataContext;

            type.Text = d.Item1;
            count.Text = d.Item2.ToString();
        }
    }

    class DifferenceTemplate : Grid {
        TextBlock hafs;
        DifferenceStak bazzi, douri, qaloun, qunbul, shuba, sousi, warsh;

        public DifferenceTemplate() {
            bazzi = new DifferenceStak();
            douri = new DifferenceStak();
            qaloun = new DifferenceStak();
            qunbul = new DifferenceStak();
            shuba = new DifferenceStak();
            sousi = new DifferenceStak();
            warsh = new DifferenceStak();
            hafs = new TextBlock() {
                Foreground = Brushes.SkyBlue,
                HorizontalAlignment = HorizontalAlignment.Center,
                FontFamily = Helper.getReciterFont("Hafs")
            };
            hafs.SetBinding(TextBlock.FontSizeProperty, new Binding() {
                Path = new PropertyPath(nameof(Global.ArabicFontSize)),
                Source = App.global
            });
            SetColumn(bazzi, 1);
            SetColumn(douri, 2);
            SetColumn(qaloun, 3);
            SetColumn(qunbul, 4);
            SetColumn(shuba, 5);
            SetColumn(sousi, 6);
            SetColumn(warsh, 7);


            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col1" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col2" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col3" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col4" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col5" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col6" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col7" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col8" });

            Children.Add(hafs);
            Children.Add(bazzi);
            Children.Add(douri);
            Children.Add(qaloun);
            Children.Add(qunbul);
            Children.Add(shuba);
            Children.Add(sousi);
            Children.Add(warsh);
        }

        public override void EndInit() {
            base.EndInit();
            var d = (Difference)DataContext;
            hafs.Text = d.Hafs;
            bazzi.setContent(new Tuple<string, string, string, string>("Bazzi", d.Bazzi, d.CountBazzi, d.RefBazzi));
            douri.setContent(new Tuple<string, string, string, string>("Douri", d.Douri, d.CountDouri, d.RefDouri));
            qaloun.setContent(new Tuple<string, string, string, string>("Qaloun", d.Qaloun, d.CountQaloun, d.RefQaloun));
            qunbul.setContent(new Tuple<string, string, string, string>("Qunbul", d.Qunbul, d.CountQunbul, d.RefQunbul));
            shuba.setContent(new Tuple<string, string, string, string>("Shuba", d.Shuba, d.CountShuba, d.RefShuba));
            sousi.setContent(new Tuple<string, string, string, string>("Sousi", d.Sousi, d.CountSousi, d.RefSousi));
            warsh.setContent(new Tuple<string, string, string, string>("Warsh", d.Warsh, d.CountWarsh, d.RefWarsh));
        }
    }

    class DifferenceStak : StackPanel {
        Tuple<string, string, string, string> item;
        TextBlock text;
        TextBlockEnglish count;
        PopupDraggable pop;

        public DifferenceStak() {
            Margin = new Thickness(2.5, 0, 2.5, 0);
            Background = Brushes.Transparent;
            HorizontalAlignment = HorizontalAlignment.Center;
            Orientation = Orientation.Horizontal;
            text = new TextBlock() { IsHitTestVisible = false };
            count = new TextBlockEnglish() {
                VerticalAlignment = VerticalAlignment.Center,
                Foreground = Brushes.Gray,
                Margin = new Thickness(2.5, 0, 0, 0),
                IsHitTestVisible = false
            };

            text.SetBinding(TextBlock.FontSizeProperty, new Binding() {
                Path = new PropertyPath(nameof(Global.ArabicFontSize)),
                Source = App.global
            });
            Children.Add(text);
            Children.Add(count);

            pop = new PopupDraggable() {
                Width = 200,
                MaxHeight = 300
            };
        }

        public void setContent(Tuple<string, string, string, string> d) {
            item = d;
            if (!string.IsNullOrEmpty(item.Item2)) {
                text.FontFamily = Helper.getReciterFont(item.Item1);
                text.Text = item.Item2;
                count.Text = item.Item3;
            }
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            base.OnMouseEnter(e);
            count.Foreground = Brushes.LightCoral;
        }

        protected override void OnMouseLeave(MouseEventArgs e) {
            base.OnMouseLeave(e);
            if (pop.IsOpen) return;
            count.Foreground = Brushes.Gray;
        }

        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
            base.OnMouseLeftButtonUp(e);
            if (!pop.IsOpen) {
                var close = new ActionButton() {
                    HorizontalAlignment = HorizontalAlignment.Right,
                    Icon = Icons.CloseCircle,
                    Command = () => {
                        pop.IsOpen = false;
                        count.Foreground = Brushes.Gray;
                    }
                };

                var hafs = new TextBlockEnglish() { Text = "Hafs" };
                var other = new TextBlockEnglish() { Text = item.Item1 };
                var contentGrid = new Grid() {
                    ColumnDefinitions = {
                        new ColumnDefinition(),
                        new ColumnDefinition(),
                    },
                };
                var scroll = new ScrollViewer() {
                    Content = contentGrid,
                    Template = new ScrollViewerTemplate(),
                    HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                    VerticalScrollBarVisibility = ScrollBarVisibility.Auto
                };

                Grid.SetRow(hafs, 1);
                Grid.SetRow(other, 1);
                Grid.SetRow(scroll, 2);
                Grid.SetColumn(other, 1);
                Grid.SetColumn(close, 1);
                Grid.SetColumnSpan(scroll, 2);

                var grid = new Grid() {
                    RowDefinitions = {
                        new RowDefinition(){ Height = GridLength.Auto },
                        new RowDefinition(){ Height = GridLength.Auto },
                        new RowDefinition()
                    },
                    ColumnDefinitions = {
                        new ColumnDefinition(),
                        new ColumnDefinition(),
                    },
                    Children = { close, hafs, other, scroll },
                    Resources = {
                        {typeof(TextBlockEnglish), new Style() {
                            Setters = {
                                new Setter(TextBlockEnglish.ForegroundProperty, Brushes.LightGray)
                            }
                        } }
                    }
                };
                
                var refs = item.Item4.Split(",", StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < refs.Length; i++) {
                    var parts = refs[i].Trim().Split('|');
                    contentGrid.RowDefinitions.Add(new RowDefinition());
                    var h = new TextBoxEnglish() { Text = parts[0] };
                    var o = new TextBoxEnglish() { Text = parts[1] };
                    Grid.SetColumn(o, 1);
                    Grid.SetRow(h, i);
                    Grid.SetRow(o, i);
                    contentGrid.Children.Add(h);
                    contentGrid.Children.Add(o);
                }

                pop.Child = new Border() {
                    Padding = new Thickness(10),
                    CornerRadius = new CornerRadius(5),
                    BorderBrush = Brushes.LightGray,
                    BorderThickness = new Thickness(Constants.BottomLineThickness),
                    Background = Constants.Background,
                    Child = grid
                };
                pop.IsOpen = true;
            }
            else pop.IsOpen = false;
        }
    }

    class Difference {
        public string Hafs { get; set; }
        public string Bazzi { get; set; }
        public string Douri { get; set; }
        public string Qaloun { get; set; }
        public string Qunbul { get; set; }
        public string Shuba { get; set; }
        public string Sousi { get; set; }
        public string Warsh { get; set; }

        public string CountBazzi { get; set; }
        public string CountDouri { get; set; }
        public string CountQaloun { get; set; }
        public string CountQunbul { get; set; }
        public string CountShuba { get; set; }
        public string CountSousi { get; set; }
        public string CountWarsh { get; set; }

        public string RefBazzi { get; set; }
        public string RefDouri { get; set; }
        public string RefQaloun { get; set; }
        public string RefQunbul { get; set; }
        public string RefShuba { get; set; }
        public string RefSousi { get; set; }
        public string RefWarsh { get; set; }
        public string Type { get; set; }
    }

    class DifferenceComparer : IComparer<Difference> {
        public int Compare(Difference? x, Difference? y) {
            int xCount = 0, yCount = 0;
            if (!string.IsNullOrEmpty(x.Bazzi)) xCount++;
            if (!string.IsNullOrEmpty(x.Douri)) xCount++;
            if (!string.IsNullOrEmpty(x.Qaloun)) xCount++;
            if (!string.IsNullOrEmpty(x.Qunbul)) xCount++;
            if (!string.IsNullOrEmpty(x.Shuba)) xCount++;
            if (!string.IsNullOrEmpty(x.Sousi)) xCount++;
            if (!string.IsNullOrEmpty(x.Warsh)) xCount++;

            if (!string.IsNullOrEmpty(y.Bazzi)) yCount++;
            if (!string.IsNullOrEmpty(y.Douri)) yCount++;
            if (!string.IsNullOrEmpty(y.Qaloun)) yCount++;
            if (!string.IsNullOrEmpty(y.Qunbul)) yCount++;
            if (!string.IsNullOrEmpty(y.Shuba)) yCount++;
            if (!string.IsNullOrEmpty(y.Sousi)) yCount++;
            if (!string.IsNullOrEmpty(y.Warsh)) yCount++;

            return yCount - xCount;
        }
    }
}
