﻿class NotVerbPage : Page {
    string selectedForm;
    string indexMa;
    StringBuilder builder = new();
    List<NotVerb> source, simpleSource, currentSource;
    List<IGrouping<string, NotVerb>> tagGroup, formGroups;
    ICollectionView verbView;

    CancellationTokenSource terminator;
    Grid content;
    ProgressBar progress;
    TagCount tenses, forms;
    ListBox list;
    Run morphCount, morphTotal;
    TextBlockEnglish meaningCount, verbCount;
    ListBox morphList, listMeaning;
    WaterBox rootQuery, verbQuery;
    MultiState cases;
    DependencyPropertyDescriptor caseDescriptor;

    NotVerb selected;
    public NotVerb Selected {
        get { return selected; }
        set { selected = value; listMorph(); }
    }

    public override PageType Type => PageType.NotVerb;
    public override UIElement Content => content;

    public NotVerbPage() {
        indexMa = "|" + ((App)Application.Current).indexMa;
        terminator = new CancellationTokenSource();
        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };
        tenses = new TagCount() {
            Margin = new Thickness(0, 0, 0, 5),
            FlowDirection = FlowDirection.LeftToRight
        };
        forms = new TagCount() {
            Margin = new Thickness(0, 0, 0, 5),
            FlowDirection = FlowDirection.LeftToRight
        };
        var toggle = new Toggle() {
            VerticalAlignment = VerticalAlignment.Top,
            Margin = new Thickness(5, 5, 0, 0),
            OnIcon = Icons.DoorClose,
            OffIcon = Icons.DoorOpen,
            OnTip = "hide left panel",
            OffTip = "show left panel",
            Command = () => {
                var col = content.ColumnDefinitions[1];
                col.Width = col.Width.Value == 0 ? new GridLength(1, GridUnitType.Star) : new GridLength(0);
            }
        };
        rootQuery = new WaterBox() {
            Margin = new Thickness(0, 0, 0, 5),
            FlowDirection = FlowDirection.LeftToRight,
            Icon = Icons.Search,
            Hint = "Root (pattern eg. _w_)"
        };
        verbQuery = new WaterBox() {
            Margin = new Thickness(0, 0, 0, 5),
            FlowDirection = FlowDirection.LeftToRight,
            Icon = Icons.Search,
            Hint = "Word (pattern eg. _a_a_a)"
        };
        var buckwalterPop = new BuckwalterPopup();
        cases = new MultiState() {
            Icons = new string[] { Icons.Restore, Icons.ArrowLeft, Icons.ArrowTopLeft, Icons.ArrowBottomLeft },
            Tips = new string[] { "Case all", "Case Nominative", "Case Accusative", "Case Genitive" },
            VerticalAlignment = VerticalAlignment.Center
        };
        verbCount = new TextBlockEnglish() {
            Margin = new Thickness(5, 0, 0, 0),
            VerticalAlignment = VerticalAlignment.Center
        };

        Grid.SetColumn(verbQuery, 2);
        Grid.SetColumn(buckwalterPop, 3);
        Grid.SetColumn(cases, 4);
        Grid.SetColumn(verbCount, 5);

        var queryGrid = new Grid() {
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(5)},
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { rootQuery, verbQuery, buckwalterPop, cases, verbCount }
        };

        Grid.SetColumn(toggle, 1);
        Grid.SetColumnSpan(forms, 2);
        Grid.SetColumnSpan(queryGrid, 2);
        Grid.SetRow(forms, 1);
        Grid.SetRow(queryGrid, 2);
        var tagStack = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(),
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { toggle, tenses, forms, queryGrid }
        };

        list = new ListBox() {
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(ListTemplate))
            }
        };
        list.SetValue(Grid.IsSharedSizeScopeProperty, true);
        list.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        list.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
        list.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(Selected)) { Source = this });

        verbCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Mode = BindingMode.OneWay,
            Source = list,
            StringFormat = "N0"
        });

        var morphView = getRightGrid();

        Grid.SetColumnSpan(progress, 2);
        Grid.SetRowSpan(morphView, 2);
        Grid.SetColumn(morphView, 1);
        Grid.SetRow(morphView, 1);
        Grid.SetRow(tagStack, 1);
        Grid.SetRow(list, 2);
        content = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(),
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, tagStack, list, morphView }
        };

        tenses.SelectionChanged += onTenseSelectionChanged;
        forms.SelectionChanged += onFormSelectionChanged;
        morphList.SelectionChanged += onMorphSelectionChanged;
        listMeaning.MouseDoubleClick += onMeaningDoubleClick;
        rootQuery.KeyUp += onRootQuery;
        verbQuery.KeyUp += onVerbQuery;
        App.global.PropertyChanged += onTranscriptChanged;

        caseDescriptor = DependencyPropertyDescriptor.FromProperty(MultiState.StateProperty, typeof(MultiState));
        caseDescriptor.AddValueChanged(cases, onCaseChanged);
    }

    Grid getRightGrid() {
        morphCount = new Run();
        morphTotal = new Run();
        var morphCountBlock = new TextBlockEnglish() {
            IsHitTestVisible = false,
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center,
            Inlines = { morphTotal, new Run(" in "), morphCount }
        };
        meaningCount = new TextBlockEnglish() {
            IsHitTestVisible = false,
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Left
        };

        morphList = new ListBox() {
            Margin = new Thickness(0, 5, 0, 0),
            FlowDirection = FlowDirection.RightToLeft,
            Template = new ListBoxLedgerTemplate(),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MorphListTemplate))
            }
        };
        var separatorHorizontal = new Rectangle() {
            VerticalAlignment = VerticalAlignment.Bottom,
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };

        var separatorVertical = new Rectangle() {
            Margin = new Thickness(5, 0, 5, 0),
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        var splitter = new GridSplitter() {
            ResizeDirection = GridResizeDirection.Rows,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Template = new SplitterTemplate()
        };

        morphList.SetValue(Grid.IsSharedSizeScopeProperty, true);
        morphList.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        morphList.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        listMeaning = new ListBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 0, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MeaningListTemplate))
            }
        };
        listMeaning.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMeaning.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        listMeaning.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        Grid.SetRow(morphList, 1);
        Grid.SetRow(meaningCount, 2);
        Grid.SetRow(separatorHorizontal, 2);
        Grid.SetRow(splitter, 2);
        Grid.SetRow(listMeaning, 3);

        Grid.SetColumn(morphCountBlock, 1);
        Grid.SetColumn(morphList, 1);
        Grid.SetColumn(meaningCount, 1);
        Grid.SetColumn(separatorHorizontal, 1);
        Grid.SetColumn(splitter, 1);
        Grid.SetColumn(listMeaning, 1);

        Grid.SetRowSpan(separatorVertical, 4);

        morphCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = morphList,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        meaningCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMeaning,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });

        return new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition()
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(2, GridUnitType.Star) },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { morphCountBlock, morphList, separatorHorizontal, splitter, meaningCount, listMeaning, separatorVertical }
        };
    }

    public NotVerbPage(List<NotVerb> source) : this() => setTags(source);

    public void setContent(List<NotVerb> source) => setTags(source);

    void setTags(List<NotVerb> source) {
        this.source = source;
        string header = "";
        var first = source.First();

        switch (first.SubTag) {
            case "Active Participle": header = "AP - "; break;
            case "Passive Participle": header = "PP - "; break;
            case "Verbal Noun": header = "VN - "; break;
            default: header = "U - "; break;
        }
        switch (first.Gender) {
            case "Masculine": header += "M"; break;
            case "Feminine": header += "F"; break;
            default: header += "U"; break;
        }
        switch (first.Number) {
            case "Singular": header += "S"; break;
            case "Dual": header += "D"; break;
            case "Plural": header += "P"; break;
            default: header += "U"; break;
        }
        
        HeaderText = header;
        progress.IsIndeterminate = true;

        Task.Run(() => {
            selectedForm = null;
            if (App.global.Transcript == 1) {
                simpleSource = new List<NotVerb>();
                for (int i = 0; i < source.Count; i++) {
                    if (terminator.IsCancellationRequested) break;

                    var match = simpleSource.FirstOrDefault(
                        x => x.Segments[1].Equals(source[i].Segments[1]) &&
                        x.Case.Equals(source[i].Case));

                    if (match is null) simpleSource.Add(new NotVerb(source[i]));
                    else match.References.AddRange(source[i].References);
                }
                currentSource = simpleSource;
            }
            else currentSource = source;

            

            if (!terminator.IsCancellationRequested) {
                tagGroup = currentSource.GroupBy(x => x.Tag).ToList();
                App.Current.Dispatcher.Invoke(() => {
                    tenses.Items = tagGroup.Select(x => new TagCount.TagItem() { Name = x.Key, Count = x.Count() }).ToList();
                    tenses.Selected = tenses.Items.First();
                    onTenseSelectionChanged(tenses.Selected);
                    progress.IsIndeterminate = false;
                });
            }

        }, terminator.Token);
    }

    void onTenseSelectionChanged(TagCount.TagItem item) {
        formGroups = tagGroup
            .First(x => x.Key.Equals(item.Name))
            .GroupBy(x => x.Form).ToList();
        forms.Items = formGroups
            .OrderBy(x => x.Key, new RomanComparator())
            .Select(x => new TagCount.TagItem() {
                Name = x.Key,
                Count = x.Count()
            })
            .ToList();
        forms.Selected = selectedForm is null ? forms.Items.First() : forms.Items.First(x => x.Name.Equals(selectedForm));
        onFormSelectionChanged(forms.Selected);
    }

    void onFormSelectionChanged(TagCount.TagItem item) {
        if (App.global.Transcript == 0) {
            verbView = CollectionViewSource.GetDefaultView(formGroups.First(x => x.Key.Equals(item.Name)).OrderBy(x => x.Root));
        }
        else {
            var filtered = formGroups.First(x => x.Key.Equals(item.Name)).ToList();
            List<NotVerb> items = new();
            for (int i = 0; i < filtered.Count; i++) {
                var match = items.FirstOrDefault(
                    x => x.Segments[1].Equals(filtered[i].Segments[1])
                    && x.Case.Equals(filtered[i].Case));

                if (match is null) items.Add(filtered[i]);
                else match.References.AddRange(filtered[i].References);
            }
            verbView = CollectionViewSource.GetDefaultView(items.OrderBy(x => x.Root));
        }
        verbView.Filter = filter;
        list.ItemsSource = verbView; ;
    }

    bool filter(object o) {
        var v = (NotVerb)o;

        bool result = cases.State switch {
            0 => true,
            1 => v.Case.Equals("Nominative"),
            2 => v.Case.Equals("Accusative"),
            3 => v.Case.Equals("Genitive"),
        };

        if (!string.IsNullOrEmpty(rootQuery.Text)) {
            bool match = v.Root.Length == rootQuery.Text.Length;
            if (match) {
                for (int i = 0; i < v.Root.Length; i++) {
                    if (rootQuery.Text[i] == '_') continue;
                    if (rootQuery.Text[i] != v.Root[i]) {
                        match = false;
                        break;
                    }
                }
            }
            result = result && match;

        }
        if (!string.IsNullOrEmpty(verbQuery.Text)) {
            var text = App.global.Transcript == 0 ? v.Segments[0] : v.Segments[1];
            if (verbQuery.Text.StartsWith('!')) {
                var query = verbQuery.Text.Substring(2);
                if (verbQuery.Text[1] == '/') {
                    result = result && !text.StartsWith(query);
                }
                else if (verbQuery.Text[1] == '\\') {
                    result = result && !text.EndsWith(query);
                }
            }
            else if (verbQuery.Text.StartsWith('/')) {
                var query = verbQuery.Text.Substring(1);
                result = result && text.StartsWith(query);
            }
            else if (verbQuery.Text.StartsWith('\\')) {
                var query = verbQuery.Text.Substring(1);
                result = result && text.EndsWith(query);
            }
            else {
                bool match = text.Length == verbQuery.Text.Length;
                if (match) {
                    for (int i = 0; i < text.Length; i++) {
                        if (verbQuery.Text[i] == '_') continue;
                        if (verbQuery.Text[i] != text[i]) {
                            match = false;
                            break;
                        }
                    }
                }
                result = result && match;
            }
        }

        return result;
    }

    void onTranscriptChanged(object? sender, PropertyChangedEventArgs e) {
        if (!e.PropertyName.Equals(nameof(App.global.Transcript))) return;

        var selectedTense = tenses.Selected.Name;
        selectedForm = forms.Selected.Name;

        if (App.global.Transcript == 0) currentSource = source;
        else {
            if (simpleSource is null) {
                simpleSource = new List<NotVerb>();
                for (int i = 0; i < source.Count; i++) {
                    if (terminator.IsCancellationRequested) break;

                    var match = simpleSource.FirstOrDefault(
                          x => x.Segments[1].Equals(source[i].Segments[1]) &&
                          x.Case.Equals(source[i].Case));

                    if (match is null) {
                        simpleSource.Add(new NotVerb(source[i]));
                    }
                    else match.References.AddRange(source[i].References);
                }
            }
            currentSource = simpleSource;
           
        }

        tagGroup = currentSource.GroupBy(x => x.Tag).ToList();
        tenses.Items = tagGroup.Select(x => new TagCount.TagItem() { Name = x.Key, Count = x.Count() }).ToList();
        tenses.Selected = tenses.Items.First(x => x.Name.Equals(selectedTense));
        onTenseSelectionChanged(tenses.Selected);

        selectedForm = null;
    }

    void listMorph() {
        if (selected is null) {
            return;
        }
        progress.IsIndeterminate = true;
        Task.Run(() => {
            var morphs = new List<Morph>();

            var iterator = App.links.GetEnumerator();
            iterator.MoveNext();

            if (!selected.IsSorted) {
                selected.References.Sort(new SurahAyahWordNoComparator());
                selected.IsSorted = true;
            }


            for (int i = 0; i < selected.References.Count; i++) {
                if (terminator.IsCancellationRequested) break;
                while (!iterator.Current.Reference.Equals(selected.References[i])) iterator.MoveNext();
                morphs.Add(getMorph(iterator.Current));
            }

            iterator.Dispose();

            var listSource = morphs.GroupBy(x => new { Word = x.Segments[1], x.Explanation })
              .Select(x => new Morph() {
                  Segments = x.First().Segments,
                  Count = x.Count(),
                  Tags = x.First().Tags,
                  Explanation = x.Key.Explanation,
                  References = x.SelectMany(x => x.References).ToList()
              })
              .OrderByDescending(x => x.Count)
              .ToList();

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    morphList.ItemsSource = listSource;
                    morphTotal.Text = listSource.Sum(x => x.Count).ToString();
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);

    }

    void onMorphSelectionChanged(object sender, SelectionChangedEventArgs e) {
        if (morphList.SelectedItem is null) {
            listMeaning.ItemsSource = null;
            return;
        }
        listMeaning.ItemsSource = ((Morph)morphList.SelectedItem).References;
    }

    void onMeaningDoubleClick(object sender, MouseButtonEventArgs e) {
        if (listMeaning.SelectedItem is null) return; // can be null?
        var item = (Tuple<string, string, string>)listMeaning.SelectedItem;
        ((App)Application.Current).FocusedControl.addSurahPage(item.Item1);
    }

    void onCaseChanged(object? sender, EventArgs e) => verbView.Refresh();

    void onVerbQuery(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        verbView.Refresh();
    }

    void onRootQuery(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        verbView.Refresh();
    }

    Morph getMorph(Link item) {
        string tag = "";
        string[] tags;
        string details = "";

        details = item.Details.Split(',')[Convert.ToInt32(item.RootIndex)];
        details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
        int lIndex;
        if (item.LemmaSimple.EndsWith(indexMa)) {
            // in 8 cases it ends with maA
            lIndex = 0;
        }
        else {
            lIndex = item.LemmaIndices.Contains('|') ?
               Convert.ToInt32(item.LemmaIndices.Split('|')[0]) :
               Convert.ToInt32(item.LemmaIndices);
        }

        tags = item.Tags.Split('|');
        tag = App.tags[Convert.ToInt32(tags[lIndex])].Name;

        Morph t = new() {
            Tag = tag,
            Tags = tags,
            Segments = Helper.getSegments(item),
            Spellings = getSpellings(item)
        };
        builder.Clear();
        item.explain(builder);

        t.Explanation = builder.ToString();
        t.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));

        var array = details.Split('|');

        for (int i = 0; i < array.Length; i++) {
            if (string.IsNullOrEmpty(array[i])) continue;
            if (array[i].Equals("PCPL") ||
                array[i].Equals("ACC") ||
                array[i].Equals("NOM") ||
                array[i].Equals("GEN") ||
                array[i].Equals("INDEF")) continue;

            if (array[i].Equals("ACT")) t.SubTag = "Active Participle";
            else if (array[i].Equals("PASS")) t.SubTag = "Passive Participle";
            else if (array[i].Equals("VN")) t.SubTag = "Verbal Noun";
            else if (array[i].Equals("IN")) t.SubTag = "Noun";
            else if (array[i].Equals("CN")) t.SubTag = "Noun";
            else if (array[i].Equals("IP")) t.SubTag = "Particle";
            else if (array[i].Equals("CP")) t.SubTag = "Particle";
            else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
            else t.Gender = Helper.getGender(array[i]).Name;
        }
        if (string.IsNullOrEmpty(t.Form)) t.Form = "I";


        return t;

        string[] getSpellings(Link item) {
            int lIndex;
            if (item.LemmaSimple.EndsWith(indexMa)) {
                // in 8 cases it ends with maA
                lIndex = 0;
            }
            else {
                if (string.IsNullOrEmpty(item.LemmaIndices)) {
                    return new string[] {
                    item.SpellingGroupCorpus,
                    item.SpellingGroupSimple
                };
                }

                lIndex = item.LemmaIndices.Contains('|') ?
                   Convert.ToInt32(item.LemmaIndices.Split('|')[0]) :
                   Convert.ToInt32(item.LemmaIndices);
            }
            return new string[] {
                item.SpellingGroupCorpus.Split('|')[lIndex],
                item.SpellingGroupSimple.Split('|')[lIndex]
            };
        }
    }

    protected override void unload() {
        tenses.SelectionChanged -= onTenseSelectionChanged;
        forms.SelectionChanged -= onFormSelectionChanged;
        App.global.PropertyChanged -= onTranscriptChanged;
        morphList.SelectionChanged -= onMorphSelectionChanged;
        listMeaning.MouseDoubleClick -= onMeaningDoubleClick;
        rootQuery.KeyUp -= onRootQuery;
        verbQuery.KeyUp -= onVerbQuery;
        caseDescriptor.RemoveValueChanged(cases, onCaseChanged);
        terminator.Cancel();
        terminator.Dispose();
        base.unload();
    }

    class ListTemplate : Grid {
        TextBlockArabic verb, root;
        TextBlockEnglish count;

        public ListTemplate() {
            verb = new TextBlockArabic();
            root = new TextBlockArabic() { Foreground = Brushes.Gray };
           
            count = new TextBlockEnglish() { VerticalAlignment = VerticalAlignment.Center };

            SetColumn(root, 1);
           
            SetColumn(count, 3);

            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col3" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col4" });

            Children.Add(verb);
            Children.Add(root);
          
            Children.Add(count);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (NotVerb)DataContext;
            verb.Text = App.global.Transcript == 0 ? c.Segments[0].toArabic() : c.Segments[1].toArabic();

            if (!string.IsNullOrEmpty(c.Case)) {
                var icon = c.Case switch {
                    "Nominative" => Helper.getIcon(Icons.ArrowLeft, Brushes.Gray),
                    "Accusative" => Helper.getIcon(Icons.ArrowTopLeft, Brushes.Gray),
                    "Genitive" => Helper.getIcon(Icons.ArrowBottomLeft, Brushes.Gray),
                };
                icon.ToolTip = c.Case;
                icon.Margin = new Thickness(2.5, 0, 2.5, 0);
                SetColumn(icon, 2);
                Children.Add(icon);
            }
            
            root.Text = c.Root.toArabic();
            count.Text = c.References.Count.ToString("N0");
        }
    }

    class RomanComparator : Comparer<string> {
        public override int Compare(string? x, string? y) {
            return getRomanInt(x) - getRomanInt(y);
        }
        int getRomanInt(string x) {
            return x switch {
                "I" => 0,
                "II" => 1,
                "III" => 2,
                "IV" => 3,
                "V" => 4,
                "VI" => 5,
                "VII" => 6,
                "VIII" => 7,
                "IX" => 8,
                "X" => 9,
                "XI" => 10,
                "XII" => 11
            };
        }
    }
}
