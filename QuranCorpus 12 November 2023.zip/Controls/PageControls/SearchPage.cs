﻿class SearchPage : Page, ISwitch {
    public override PageType Type => PageType.Search;
    public override UIElement Content => content;

    public bool IsHoverPopupEnabled { get; set; }
    public bool HasColor { get; set; }
    public event Action IsColored;
    public string englishQuery;

    string[] selectedTranslators;
    int matchCount;
    bool searchModeIsEqual;
    List<Ayah> ayahs;

    Grid content;
    WaterBox queryArabic, queryEnglish;
    CheckGroup checkGroup;
    TextBlock count;
    Toggle popToggle, colorToggle, isArabic;
    Translators translators;
    ProgressBar progress;
    ListBox ayahListBox;
    Copier copier;
    CancellationTokenSource terminator;
    DependencyPropertyDescriptor translatorDescriptor;

    public SearchPage() {
        HeaderText = "Search " + ((App)(Application.Current)).FocusedControl.searchPageCount;
        terminator = new CancellationTokenSource();
        queryArabic = new WaterBox() {
            Hint = "Search (arabic)",
            Icon = Icons.Search,
            IsArabic = true
        };
        checkGroup = new CheckGroup() {
            Icons = new string[] { Icons.Approximate, Icons.Equal },
            Tips = new string[] { "contains", "exact" },
            Margin = new Thickness(10, 0, 0, 0),
            VerticalAlignment = VerticalAlignment.Bottom,
        };

        queryEnglish = new WaterBox() {
            VerticalAlignment = VerticalAlignment.Bottom,
            Hint = "Search (english)",
            Icon = Icons.Search,
            Visibility = Visibility.Collapsed
        };
        isArabic = new Toggle() {
            Margin = new Thickness(7, 0, 0, 0),
            VerticalAlignment = VerticalAlignment.Bottom,
            OnIcon = Icons.AB,
            OffIcon = Icons.CopyArabic,
            OnTip = "input english",
            OffTip = "input arabic",
            Command = () => {
                if (isArabic.IsOn) {
                    queryEnglish.Visibility = Visibility.Collapsed;
                    queryArabic.Visibility = Visibility.Visible;
                    checkGroup.Visibility = Visibility.Visible;
                    queryArabic.Focus();
                }
                else {
                    queryArabic.Visibility = Visibility.Collapsed;
                    checkGroup.Visibility = Visibility.Collapsed;
                    queryEnglish.Visibility = Visibility.Visible;
                    queryEnglish.Focus();
                }
            }
        };
        count = new TextBlock() {
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(7, 0, 7, 0)
        };
        popToggle = new Toggle() {
            Margin = new Thickness(0, 0, 7, 0),
            VerticalAlignment = VerticalAlignment.Bottom,
            OnIcon = Icons.EyeOff,
            OffIcon = Icons.Eye,
            OnTip = "enable popup on hover",
            OffTip = "disable popup on hover",
            Command = () => IsHoverPopupEnabled = !IsHoverPopupEnabled
        };
        colorToggle = new Toggle() {
            Margin = new Thickness(0, 0, 7, 0),
            VerticalAlignment = VerticalAlignment.Bottom,
            OnIcon = Icons.BrushOff,
            OffIcon = Icons.Brush,
            OnTip = "color segments",
            OffTip = "remove color",
            Command = () => {
                HasColor = !HasColor;
                IsColored?.Invoke();
            }
        };
        translators = new Translators() {
            FlowDirection = FlowDirection.LeftToRight,
            HorizontalAlignment = HorizontalAlignment.Left,
            VerticalAlignment = VerticalAlignment.Bottom
        };
        Grid.SetColumn(checkGroup, 1);
        Grid.SetColumn(isArabic, 2);
        Grid.SetColumn(count, 3);
        Grid.SetColumn(popToggle, 4);
        Grid.SetColumn(colorToggle, 5);
        Grid.SetColumn(translators, 6);
        var toolGrid = new Grid() {
            Margin = new Thickness(0, 0, 0, 10),
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { queryArabic, queryEnglish, checkGroup, isArabic, count, popToggle, colorToggle, translators }
        };
        ayahListBox = new ListBox() {
            DataContext = this,
            FlowDirection = FlowDirection.RightToLeft,
            SelectionMode = SelectionMode.Extended,
            ItemTemplate = new AyahSearchTemplate()
        };
        ayahListBox.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        ayahListBox.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };
        Grid.SetRow(toolGrid, 1);
        Grid.SetRow(ayahListBox, 2);
        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, toolGrid, ayahListBox }
        };

        copier = new Copier(ayahListBox, progress, terminator);

        translatorDescriptor = DependencyPropertyDescriptor.FromProperty(Translators.SelectedProperty, typeof(Translators));
        translatorDescriptor.AddValueChanged(translators, onTranslationChanged);

        queryArabic.KeyUp += onArabicQuery;
        queryEnglish.KeyUp += onEnglishQuery;
        ayahListBox.MouseDoubleClick += onDoubleClick;
        TabView.Split += onSplit;
        selectedTranslators = translators.Selected;

        App.Current.Dispatcher.InvokeAsync(queryArabic.Focus, DispatcherPriority.Background);
    }

    void onSplit() => ayahListBox.Items.Refresh();

    void onDoubleClick(object sender, MouseButtonEventArgs e) {
        if (e.ChangedButton != MouseButton.Left) return;

        var match = (Ayah)ayahListBox.SelectedItem; // null check?
        ((App)Application.Current).FocusedControl.addSurahPage(match.SurahNo + ":" + match.AyahNo);
    }

    void onTranslationChanged(object? sender, EventArgs e) {
        selectedTranslators = translators.Selected;
        updateTranslation();

        if (ayahListBox.SelectedItems.Count == 0 || ayahListBox.SelectedItems.Count > 1) return;
        ayahListBox.ScrollIntoView(ayahListBox.SelectedItem);
    }

    void updateTranslation() {
        if (ayahs is null) return;
        if (selectedTranslators.Length == 0) {
            for (int i = 0; i < ayahs.Count; i++) {
                ayahs[i].Translations = null;
                ayahs[i].OnPropertyChanged(nameof(Ayah.Translations));
            }
            return;
        }

        var iterators = new IEnumerator<string>[selectedTranslators.Length];
        var translatorIds = new int[selectedTranslators.Length];
        var liranslatorsName = App.global.TranslationDictionary.Keys.ToList();

        int index = 0;
        foreach (var item in selectedTranslators) {
            var file = App.global.TranslationDictionary[item];
            var lines = System.IO.File.ReadLines("Resources/Tanzil/" + file);
            var iterator = lines.GetEnumerator();
            iterator.MoveNext();
            iterators[index] = iterator;
            translatorIds[index] = liranslatorsName.IndexOf(item);
            index++;
        }

        for (int i = 0; i < ayahs.Count; i++) {
            var translations = new Translation[iterators.Length];

            for (int j = 0; j < iterators.Length; j++) {
                var reference = ayahs[i].SurahNo + "|" + ayahs[i].AyahNo + "|";
                while (!iterators[j].Current.StartsWith(reference)) iterators[j].MoveNext();

                translations[j] = new Translation() {
                    TranslatorId = translatorIds[j],
                    Content = iterators[j].Current.Substring(reference.Length)
                };
            }
            ayahs[i].Translations = translations;
            ayahs[i].OnPropertyChanged(nameof(Ayah.Translations));
        }
        foreach (var iterator in iterators) iterator.Dispose();
    }

    void onArabicQuery(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        englishQuery = "";
        if (string.IsNullOrWhiteSpace(queryArabic.Text)) return;

        searchModeIsEqual = checkGroup.Selected == 1;
        var query = queryArabic.Text.Trim();
        progress.IsIndeterminate = true;
        matchCount = 0;
        Task.Run(() => {
            ayahs = getAyahs(query);
            App.Current.Dispatcher.Invoke(() => {
                count.Text = matchCount.ToString("N0") + " matches in " + ayahs.Count.ToString("N0") + " ayahs";
                ayahListBox.ItemsSource = ayahs;
                if (ayahs.Count > 0) ayahListBox.ScrollIntoView(ayahs[0]);
                progress.IsIndeterminate = false;
            });
        }, terminator.Token);
    }

    void onEnglishQuery(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        if (string.IsNullOrWhiteSpace(queryEnglish.Text)) return;
        if (translators.Selected.Length == 0) return;

        englishQuery = queryEnglish.Text;
        progress.IsIndeterminate = true;
        Task.Run(() => {
            var linkIterator = App.links.GetEnumerator();
            linkIterator.MoveNext();

            var iterators = new IEnumerator<string>[selectedTranslators.Length];
            var translatorIds = new int[selectedTranslators.Length];
            var liranslatorsName = App.global.TranslationDictionary.Keys.ToList();

            int index = 0;
            foreach (var translator in selectedTranslators) {
                var file = App.global.TranslationDictionary[translator];
                var lines = System.IO.File.ReadLines("Resources/Tanzil/" + file);
                var iterator = lines.GetEnumerator();
                iterator.MoveNext();
                iterators[index] = iterator;
                translatorIds[index] = liranslatorsName.IndexOf(translator);
                index++;
            }

            ayahs = new List<Ayah>();
            StringBuilder builder = new();

            for (int i = 0; i < 6236; i++) {
                var translations = new Translation[iterators.Length];
                string surah = "";
                string ayah = "";
                bool isMatch = false;

                for (int j = 0; j < iterators.Length; j++) {
                    var parts = iterators[j].Current.Split('|');
                    if (!parts[2].Contains(englishQuery, StringComparison.InvariantCultureIgnoreCase)) continue;
                    surah = parts[0];
                    ayah = parts[1];
                    isMatch = true;
                    break;
                }

                if (isMatch) {
                    var reference = surah + ":" + ayah + ":";
                    for (int j = 0; j < iterators.Length; j++) {
                        translations[j] = new Translation() {
                            TranslatorId = translatorIds[j],
                            Content = iterators[j].Current.Substring(reference.Length)
                        };
                    }

                    while (!linkIterator.Current.Reference.StartsWith(reference)) linkIterator.MoveNext();

                    var item = linkIterator.Current;
                    List<Word> words = new();
                    while (linkIterator.Current.Reference.StartsWith(reference)) {
                        var segments = App.global.Transcript == 0 ?
                            item.SegmentsCorpus.Split('|') :
                            item.SegmentsSimple.Split('|');

                        for (int j = 0; j < segments.Length; j++) {
                            segments[j].toArabic(segments, builder);
                        }
                        builder.Append(' ');

                        words.Add(new Word() {
                            Reference = item.Reference,
                            Transliteration = App.transliterations[Convert.ToInt32(item.Transliteration)],
                            Tags = item.Tags,
                            Segments = Helper.getSegments(item),
                            Lemmas = Helper.getLemmas(item),
                            LemmaIndices = item.LemmaIndices,
                            Spellings = Helper.getSpellings(item),
                            Meaning = App.meanings[Convert.ToInt32(item.Meaning)],
                            Explanation = item.Explanation,
                            Root = item.Root,
                            RootIndex = item.RootIndex,
                            Details = item.Details
                        });
                        linkIterator.MoveNext();
                        item = linkIterator.Current;
                        if (item is null) break;
                    }

                    ayahs.Add(new Ayah() {
                        SurahNo = surah,
                        AyahNo = ayah,
                        Words = words,
                        Translations = translations
                    });
                }

                for (int j = 0; j < iterators.Length; j++) {
                    iterators[j].MoveNext();
                }
            }

            foreach (var iterator in iterators) iterator.Dispose();
            linkIterator.Dispose();

            App.Current.Dispatcher.Invoke(() => {
                count.Text = ayahs.Count.ToString("N0") + " ayahs";
                ayahListBox.ItemsSource = ayahs;
                if (ayahs.Count > 0) ayahListBox.ScrollIntoView(ayahs[0]);
                progress.IsIndeterminate = false;
            });
        }, terminator.Token);
    }

    List<Ayah> getAyahs(string query) {
        var list = new List<Ayah>();

        IEnumerator<string>[] iterators = null;
        int[] translatorIds = null;

        if (selectedTranslators.Length > 0) {
            iterators = new IEnumerator<string>[selectedTranslators.Length];
            translatorIds = new int[selectedTranslators.Length];
            var translatorNames = App.global.TranslationDictionary.Keys.ToList();

            int index = 0;
            foreach (var item in selectedTranslators) {
                var file = App.global.TranslationDictionary[item];
                var lines = System.IO.File.ReadLines("Resources/Tanzil/" + file);
                var iterator = lines.GetEnumerator();
                iterator.MoveNext();
                iterators[index] = iterator;
                translatorIds[index] = translatorNames.IndexOf(item);
                index++;
            }
        }

        var linkIterator = App.links.GetEnumerator();
        linkIterator.MoveNext();

        StringBuilder builder = new();
        int linkIndex = 0;

        while (linkIndex < App.links.Count) {
            if (terminator.IsCancellationRequested) break;

            var item = linkIterator.Current;
            var ayah = item.Reference.Substring(0, item.Reference.LastIndexOf(':') + 1);
            List<Word> tempWords = new();

            while (linkIterator.Current.Reference.StartsWith(ayah)) {
                var segments = App.global.Transcript == 0 ?
                    item.SegmentsCorpus.Split('|') :
                    item.SegmentsSimple.Split('|');

                for (int i = 0; i < segments.Length; i++) {
                    segments[i].toArabic(segments, builder);
                }
                builder.Append(' ');

                tempWords.Add(new Word() {
                    Reference = item.Reference,
                    Transliteration = App.transliterations[Convert.ToInt32(item.Transliteration)],
                    Tags = item.Tags,
                    Segments = Helper.getSegments(item),
                    Lemmas = Helper.getLemmas(item),
                    LemmaIndices = item.LemmaIndices,
                    Spellings = Helper.getSpellings(item),
                    Meaning = App.meanings[Convert.ToInt32(item.Meaning)],
                    Explanation = item.Explanation,
                    Root = item.Root,
                    RootIndex = item.RootIndex,
                    Details = item.Details
                });
                linkIterator.MoveNext();
                item = linkIterator.Current;
                linkIndex++;
                if (linkIndex == App.links.Count) break;
            }

            ayah = builder.ToString();
            builder.Clear();

            if (ayah.Contains(query)) {
                var parts = query.Split(' ');
                var words = ayah.Split(' ');
                int count = 0;

                if (!searchModeIsEqual) {
                    if (parts.Length > 1) {
                        while (count < words.Length) {
                            while (!words[count].EndsWith(parts[0], StringComparison.Ordinal)) {
                                count++;
                                if (count == words.Length) break;
                            }
                            if (count == words.Length) break;

                            int index = count + 1;
                            int length = count + parts.Length - 1;
                            bool isMatch = true;
                            int partIndex = 1;
                            for (int j = index; j < length; j++) {
                                if (words[j].Equals(parts[partIndex++])) continue;
                                isMatch = false;
                                break;
                            }
                            if (isMatch) {
                                if (words[length].StartsWith(parts[parts.Length - 1], StringComparison.Ordinal)) {
                                    length++;
                                    for (int j = count; j < length; j++) {
                                        tempWords[j].IsHighlighted = true;
                                    }
                                    matchCount++;
                                }
                            }
                            count += parts.Length;
                        }
                    }
                    else {
                        for (int j = 0; j < words.Length; j++) {
                            if (!words[j].Contains(query)) continue;
                            tempWords[j].IsHighlighted = true;
                            matchCount++;
                        }
                    }

                    parts = tempWords[0].Reference.Split(':');
                    list.Add(new Ayah() {
                        SurahNo = parts[0],
                        AyahNo = parts[1],
                        Words = tempWords
                    });
                    if (selectedTranslators.Length > 0) {
                        var reference = parts[0] + "|" + parts[1] + "|";
                        var translations = new Translation[iterators.Length];
                        for (int j = 0; j < iterators.Length; j++) {
                            while (!iterators[j].Current.StartsWith(reference)) iterators[j].MoveNext();
                            translations[j] = new Translation() {
                                TranslatorId = translatorIds[j],
                                Content = iterators[j].Current.Substring(reference.Length)
                            };
                        }
                        list[list.Count - 1].Translations = translations;
                    }
                }
                else {
                    bool isEqual = false;

                    if (parts.Length > 1) {
                        while (count < words.Length) {
                            while (!words[count].Equals(parts[0])) {
                                count++;
                                if (count == words.Length) break;
                            }
                            if (count == words.Length) break;

                            int index = count + 1;
                            int length = count + parts.Length - 1;
                            bool isMatch = true;
                            int partIndex = 1;
                            for (int j = index; j < length; j++) {
                                if (words[j].Equals(parts[partIndex++])) continue;
                                isMatch = false;
                                break;
                            }
                            if (isMatch) {
                                if (words[length].Equals(parts[parts.Length - 1])) {
                                    length++;
                                    for (int j = count; j < length; j++) {
                                        tempWords[j].IsHighlighted = true;
                                    }
                                    matchCount++;
                                    isEqual = true;
                                }
                            }
                            count += parts.Length;
                        }
                    }
                    else {
                        for (int j = 0; j < words.Length; j++) {
                            if (!words[j].Equals(query)) continue;
                            tempWords[j].IsHighlighted = true;
                            matchCount++;
                            isEqual = true;
                        }
                    }
                    if (isEqual) {
                        parts = tempWords[0].Reference.Split(':');
                        list.Add(new Ayah() {
                            SurahNo = parts[0],
                            AyahNo = parts[1],
                            Words = tempWords
                        });
                        if (selectedTranslators.Length > 0) {
                            var reference = parts[0] + "|" + parts[1] + "|";
                            var translations = new Translation[iterators.Length];
                            for (int j = 0; j < iterators.Length; j++) {
                                while (!iterators[j].Current.StartsWith(reference)) iterators[j].MoveNext();
                                translations[j] = new Translation() {
                                    TranslatorId = translatorIds[j],
                                    Content = iterators[j].Current.Substring(reference.Length)
                                };
                            }
                            list[list.Count - 1].Translations = translations;
                        }
                    }
                }
            }
        }

        if (iterators is not null) {
            foreach (var iterator in iterators) iterator.Dispose();
        }

        linkIterator.Dispose();
        return list;
    }

    protected override void unload() {
        queryArabic.KeyUp -= onArabicQuery;
        queryEnglish.KeyUp -= onEnglishQuery;
        ayahListBox.MouseDoubleClick -= onDoubleClick;
        TabView.Split -= onSplit;
        translatorDescriptor.RemoveValueChanged(translators, onTranslationChanged);
        copier.unload();
        base.unload();
    }
}
