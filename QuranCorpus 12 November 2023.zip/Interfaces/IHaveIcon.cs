﻿public interface IHaveIcon
{
    string Icon { get; }
    UIElement Tip { get; }
    bool OverridesToolTip { get; }
}

