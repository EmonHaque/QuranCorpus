﻿class MorphView : Grid {
    TextBlockEnglish treeCount, meaningCount;
    Run morphCount, morphTotal;
    TreeView tree;
    ListBox listMorph, listMeaning;
    List<Morph> source;

    public MorphView() {
        treeCount = new TextBlockEnglish();
        morphCount = new Run();
        morphTotal = new Run();
        var listCountBlock = new TextBlockEnglish() {
            HorizontalAlignment = HorizontalAlignment.Left,
            FlowDirection = FlowDirection.LeftToRight,
            Inlines = { morphTotal, new Run(" in "), morphCount }
        };
        tree = new TreeView() {
            //FlowDirection = FlowDirection.LeftToRight,
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            // if you set HorizontalScrollBarVisibilityProperty here and disable the 
                            // tree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
                            // it will mess up when scrollbar appears and disappears
                            //new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()),
                        }
                    }
                }}
        };
        tree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        var separator = new Rectangle() {
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        listMorph = new ListBox() {
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MorphListTemplate))
            },
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()),
                        }
                    }
                }}
        };
        listMorph.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMorph.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        listMorph.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        var splitter = new GridSplitter() {
            Margin = new Thickness(0, 5, 0, 0),
            ResizeDirection = GridResizeDirection.Rows,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Template = new SplitterTemplate()
        };

        meaningCount = new TextBlockEnglish() { HorizontalAlignment = HorizontalAlignment.Left };
        listMeaning = new ListBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 0, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MeaningListTemplate))
            }
        };
        listMeaning.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        listMeaning.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        SetColumn(treeCount, 2);
        SetColumn(separator, 1);
        SetColumn(tree, 2);

        SetRow(tree, 1);
        SetRow(listMorph, 1);
        SetRow(splitter, 2);
        SetRow(meaningCount, 2);
        SetRow(listMeaning, 3);

        SetRowSpan(tree, 4);
        SetRowSpan(separator, 4);

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(10) });
        ColumnDefinitions.Add(new ColumnDefinition());

        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = new GridLength(2.5, GridUnitType.Star) });
        RowDefinitions.Add(new RowDefinition() { Height = new GridLength(15) });
        RowDefinitions.Add(new RowDefinition());

        Children.Add(treeCount);
        Children.Add(listCountBlock);
        Children.Add(separator);
        Children.Add(tree);
        Children.Add(listMorph);
        Children.Add(splitter);
        Children.Add(meaningCount);
        Children.Add(listMeaning);

        treeCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = tree,
            Mode = BindingMode.OneWay
        });
        morphCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMorph,
            Mode = BindingMode.OneWay
        });
        meaningCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMeaning,
            Mode = BindingMode.OneWay
        });

        tree.SelectedItemChanged += onTreeSelectionChanged;
        listMorph.SelectionChanged += onMorphSelectionChanged;
        listMeaning.MouseDoubleClick += onMeaningDoubleClick;
        App.global.PropertyChanged += onTranscriptChanged;
    }

    public void Update(List<Morph> source) {
        this.source = source;
        tree.Items.Clear();
        createTree();
    }

    public void Unload() {
        tree.SelectedItemChanged -= onTreeSelectionChanged;
        listMorph.SelectionChanged -= onMorphSelectionChanged;
        listMeaning.MouseDoubleClick -= onMeaningDoubleClick;
        App.global.PropertyChanged -= onTranscriptChanged;
    }

    void createTree() {
        var groups = source.GroupBy(x => x.Spellings[App.global.Transcript]);
        foreach (var group in groups) {
            List<string> tags = new();
            var root = new TreeViewItem();
            int rootChildCount = 0;

            foreach (var item in group) {
                bool hasIt = false;
                for (int i = 0; i < root.Items.Count; i++) {
                    var added = (Morph)root.Items[i];
                    if (added.Tag.Equals(item.Tag) &&
                        added.SubTag.Equals(item.SubTag) &&
                        added.Gender.Equals(item.Gender) &&
                        added.Form.Equals(item.Form)) {
                        hasIt = true;
                        added.Count++;
                        break;

                    }
                }
                if (!hasIt) {
                    item.Count = 1;
                    root.Items.Add(item);
                    if (!tags.Contains(item.Tag)) {
                        tags.Add(item.Tag);
                    }
                    rootChildCount++;
                }
            }

            if (rootChildCount > 1) {
                root.HeaderTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(TreeHeaderTemplateMultiple))
                };
                root.ItemTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(TreeItemTemplate))
                };
                root.Header = new Tuple<string, string, string>(
                group.Key,
                string.Join(" | ", tags),
                rootChildCount.ToString());
            }
            else {
                root.Header = (Morph)root.Items[0];
                root.Items.Clear();
                root.HeaderTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(TreeHeaderTemplateSingle))
                };
            }
            tree.Items.SortDescriptions.Add(new SortDescription("Items.Count", ListSortDirection.Descending));
            tree.Items.Add(root);
        }
        listMorph.ItemsSource = null;
    }

    void onTranscriptChanged(object? sender, PropertyChangedEventArgs e) {
        if (!e.PropertyName.Equals(nameof(App.global.Transcript))) return;
        if (source is null) return;

        tree.Items.Clear();
        createTree();

        listMorph.ItemsSource = null;
    }

    void onTreeSelectionChanged(object sender, RoutedPropertyChangedEventArgs<object> e) {
        if (e.NewValue is null) {
            morphTotal.Text = "0";
            return;
        }

        var value = e.NewValue as Morph;
        if (value is null) {
            value = ((TreeViewItem)e.NewValue).Header as Morph;
            if (value is null) return;
        }

        var listSource = source
              .Where(
                  x => x.Spellings[App.global.Transcript].Equals(value.Spellings[App.global.Transcript]) &&
                  x.Tag.Equals(value.Tag) &&
                  x.SubTag.Equals(value.SubTag) &&
                  x.Form.Equals(value.Form) &&
                  x.Gender.Equals(value.Gender))
              .GroupBy(x => new { Word = x.Segments[App.global.Transcript], x.Explanation })
              .Select(x => new Morph() {
                  Segments = x.First().Segments,
                  Count = x.Count(),
                  Tags = x.First().Tags,
                  Explanation = x.Key.Explanation,
                  References = x.SelectMany(x => x.References).ToList()
              })
              .OrderByDescending(x => x.Count)
              .ToList();

        listMorph.ItemsSource = listSource;
        morphTotal.Text = listSource.Sum(x => x.Count).ToString();
    }

    void onMorphSelectionChanged(object sender, SelectionChangedEventArgs e) {
        if (listMorph.SelectedItem is null) {
            listMeaning.ItemsSource = null;
            return;
        }
        var iterator = App.links.GetEnumerator();
        iterator.MoveNext();

        listMeaning.ItemsSource = ((Morph)listMorph.SelectedItem).References;
    }

    void onMeaningDoubleClick(object sender, MouseButtonEventArgs e) {
        if (listMeaning.SelectedItem is null) return; // can be null?
        var item = (Tuple<string, string, string>)listMeaning.SelectedItem;
        ((App)Application.Current).Pages.addSurahPage(item.Item1);
    }

    class TreeHeaderTemplateMultiple : Grid {
        TextBlockArabic arabic;
        TextBlockEnglish tags, count;

        public TreeHeaderTemplateMultiple() {
            arabic = new TextBlockArabic();
            tags = new TextBlockEnglish() {
                FlowDirection = FlowDirection.LeftToRight,
                TextWrapping = TextWrapping.Wrap,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            count = new TextBlockEnglish() {
                FlowDirection = FlowDirection.LeftToRight,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            SetColumn(tags, 1);
            SetColumn(count, 2);
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(60) });
            Children.Add(arabic);
            Children.Add(tags);
            Children.Add(count);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Tuple<string, string, string>)DataContext;
            arabic.Text = App.spellings[Convert.ToInt32(c.Item1)].toArabic();
            tags.Text = c.Item2;
            count.Text = c.Item3;
        }
    }

    class TreeHeaderTemplateSingle : Grid {
        TextBlockArabic arabic;
        TextBlockEnglish tag, gender, subTag, form, count;
        public TreeHeaderTemplateSingle() {
            arabic = new TextBlockArabic();
            tag = new TextBlockEnglish();
            gender = new TextBlockEnglish();
            subTag = new TextBlockEnglish() { TextWrapping = TextWrapping.Wrap };
            form = new TextBlockEnglish();
            count = new TextBlockEnglish() { HorizontalAlignment = HorizontalAlignment.Right };
            SetColumn(tag, 1);
            SetColumn(form, 2);
            SetColumn(gender, 3);
            SetColumn(subTag, 4);
            SetColumn(count, 5);
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(70) });
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(60) });
            Children.Add(arabic);
            Children.Add(tag);
            Children.Add(form);
            Children.Add(gender);
            Children.Add(subTag);
            Children.Add(count);

            Resources.Add(typeof(TextBlockEnglish), new Style() {
                Setters = {
                        new Setter(VerticalAlignmentProperty, VerticalAlignment.Center),
                        new Setter(FlowDirectionProperty, FlowDirection.LeftToRight)
                    }
            });
        }
        public override void EndInit() {
            base.EndInit();
            var c = (Morph)DataContext;

            arabic.Text = 
                int.TryParse(c.Spellings[App.global.Transcript], out int index) ?
                App.spellings[index].toArabic() :
                c.Spellings[App.global.Transcript].toArabic();

            tag.Text = c.Tag;
            form.Text = c.Form;
            subTag.Text = c.SubTag;
            gender.Text = c.Gender;
            count.Text = c.Count.ToString();
        }
    }

    class TreeItemTemplate : Grid {
        TextBlockEnglish tag, gender, subTag, form, count;

        public TreeItemTemplate() {
            FlowDirection = FlowDirection.LeftToRight;
            tag = new TextBlockEnglish();
            gender = new TextBlockEnglish();
            subTag = new TextBlockEnglish() { TextWrapping = TextWrapping.Wrap };
            form = new TextBlockEnglish();
            count = new TextBlockEnglish() { HorizontalAlignment = HorizontalAlignment.Right };
            SetColumn(form, 1);
            SetColumn(gender, 2);
            SetColumn(subTag, 3);
            SetColumn(count, 4);
            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(70) });
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(60) });
            Children.Add(tag);
            Children.Add(form);
            Children.Add(gender);
            Children.Add(subTag);
            Children.Add(count);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Morph)DataContext;
            tag.Text = c.Tag;
            form.Text = c.Form;
            subTag.Text = c.SubTag;
            gender.Text = c.Gender;
            count.Text = c.Count.ToString();
        }
    }

    class MorphListTemplate : Grid {
        TextBlockArabic arabic;
        TextBlockEnglish explanation, count;

        public MorphListTemplate() {
            arabic = new TextBlockArabic();
            explanation = new TextBlockEnglish() {
                Margin = new Thickness(10, 0, 10, 0),
                FlowDirection = FlowDirection.LeftToRight,
                TextWrapping = TextWrapping.Wrap,
                VerticalAlignment = VerticalAlignment.Center
            };
            count = new TextBlockEnglish() {
                Foreground = Brushes.Gray,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Right
            };

            SetColumn(explanation, 1);
            SetColumn(count, 2);

            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col1" });
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col3" });

            Children.Add(arabic);
            Children.Add(explanation);
            Children.Add(count);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Morph)DataContext;
            StringBuilder builder = new();
            explanation.Text = c.Explanation;
            count.Text = c.Count.ToString();

            var segments = c.Segments[App.global.Transcript].Split('|');
            int index = 0;
            int pronCount, otherCount;
            pronCount = otherCount = 0;
            string lastPos = "";
            foreach (var segment in segments) {
                segment.toArabic(segments, builder);
                var run = new Run(builder.ToString());
                builder.Clear();

                var tag = App.tags[Convert.ToInt32(c.Tags[index])].Name;
                switch (tag) {
                    case "DET": run.Foreground = Foregrounds.DET_Brush; break;
                    case "V": run.Foreground = Foregrounds.V_Brush; break;
                    case "N":
                    case "PN":
                    case "ADJ": run.Foreground = Foregrounds.N_PN_ADJ_Brush; break;
                    case "REL":
                    case "DEM": run.Foreground = Foregrounds.DEM_REL_Brush; break;
                    case "P": run.Foreground = Foregrounds.P_Brush; break;
                    case "CONJ": run.Foreground = Foregrounds.CONJ_Brush; break;
                    case "INTG": run.Foreground = Foregrounds.INTG_Brush; break;
                    case "NEG": run.Foreground = Foregrounds.NEG_Brush; break;
                    case "PRON":
                        if (lastPos.Equals("PRON")) pronCount++;
                        if (pronCount == 1) run.Foreground = Foregrounds.PRON1_Brush;
                        else if (pronCount == 2) run.Foreground = Foregrounds.PRON2_Brush;
                        else run.Foreground = Foregrounds.PRON3_Brush;
                        break;
                    default:
                        if (!Foregrounds.Defined.Contains(lastPos)) otherCount++;
                        if (otherCount == 1) run.Foreground = Foregrounds.OTHER1_Brush;
                        else if (otherCount == 2) run.Foreground = Foregrounds.OTHER2_Brush;
                        else run.Foreground = Foregrounds.OTHER3_Brush;
                        break;
                }
                lastPos = tag;
                arabic.Inlines.Add(run);
                index++;
            }
        }
    }

    class MeaningListTemplate : Grid {
        TextBlockEnglish reference, transliteration, meaning;
        public MeaningListTemplate() {
            reference = new TextBlockEnglish();
            transliteration = new TextBlockEnglish();
            meaning = new TextBlockEnglish() { TextWrapping = TextWrapping.Wrap };

            SetColumn(transliteration, 1);
            SetColumn(meaning, 2);
            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(100) });
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(1.5, GridUnitType.Star) });

            Children.Add(reference);
            Children.Add(transliteration);
            Children.Add(meaning);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Tuple<string, string, string>)DataContext;
            reference.Text = c.Item1;
            transliteration.Text = App.transliterations[Convert.ToInt32(c.Item2)];
            meaning.Text = App.meanings[Convert.ToInt32(c.Item3)];
        }
    }
}
