﻿class PageControl : Grid {
    Page selectedPage;
    HeaderPanel headerPanel;
    ContentControl pageControl;
    ObservableCollection<Page> pages;
    public int searchPageCount;

    public Page SelectedPage {
        get { return (Page)GetValue(SelectedPageProperty); }
        set { SetValue(SelectedPageProperty, value); }
    }

    public static readonly DependencyProperty SelectedPageProperty =
        DependencyProperty.Register("SelectedPage", typeof(Page), typeof(PageControl), new PropertyMetadata(null));

    public PageControl() {
        FlowDirection = FlowDirection.RightToLeft;
        pages = new ObservableCollection<Page>();
        headerPanel = new HeaderPanel();
        pageControl = new ContentControl();

        Grid.SetRow(pageControl, 1);
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition());
        Children.Add(headerPanel);
        Children.Add(pageControl);
        pages.CollectionChanged += onPageAdded;

        var page = new SurahPage(1);
        pages.Add(page);
        onSelectionChanged(page);
        SelectedPage = page;

        TagVM.Tagged += onTagged;
    }

    void onTagged(string name) {
        foreach (var page in pages) {
            if (page.Type != PageType.Tag) continue;
            var curent = (TagPage)page;
            if (!curent.selectedTag.Name.Equals(name)) continue;
            curent.updatePage();
        }
    }

    public void addSurahPage(int no) {
        var page = new SurahPage(no);
        pages.Add(page);
        onSelectionChanged(page);
    }

    public void addSurahPage(string reference) {
        var page = new SurahPage(reference);
        pages.Add(page);
        onSelectionChanged(page);
    }

    public void addMatchPage(Word w) {
        var page = new MatchPage(w);
        pages.Add(page);
        onSelectionChanged(page);
    }

    public void addLemmaPage(object l) {
        var page = new LemmaPage(l);
        pages.Add(page);
        onSelectionChanged(page);
    }

    public void addSegmentPage(Segment s) {
        var page = new SegmentPage(s);
        pages.Add(page);
        onSelectionChanged(page);
    }

    public void addTagPage(TagItem item) {
        var page = new TagPage(item);
        pages.Add(page);
        onSelectionChanged(page);
    }

    public void addSearchPage() {
        searchPageCount++;
        var page = new SearchPage();
        pages.Add(page);
        onSelectionChanged(page);
    }

    void onPageAdded(object? sender, NotifyCollectionChangedEventArgs e) {
        if (e.Action != NotifyCollectionChangedAction.Add) return;
        var page = (Page)e.NewItems[0];
        page.SelectionChanged += onSelectionChanged;
        page.CloseRequested += onCloseRequested;
        headerPanel.Children.Add(page.Tab);
    }

    void onCloseRequested(Page page) {
        page.SelectionChanged -= onSelectionChanged;
        page.CloseRequested -= onCloseRequested;
        int index = headerPanel.Children.IndexOf(page.Tab);
        headerPanel.Children.Remove(page.Tab);
        pages.Remove(page);

        if (pages.Count == 0) Application.Current.Shutdown();
        else {
            if (selectedPage != page) return;
            if (index == 0) onSelectionChanged(pages[0]);
            else onSelectionChanged(pages[index - 1]);
        }
    }
    
    void onSelectionChanged(Page page) {
        if (selectedPage != null)
            selectedPage.Tab.IsSelected = false;
        selectedPage = page;
        selectedPage.Tab.IsSelected = true;
        pageControl.Content = page.Content;
        SelectedPage = page;
    }
}
