﻿class RootLemmaLessVM : Notifiable {
    List<RLFRee> sources;
    Lemma selected;
    public Lemma Selected {
        get { return selected; }
        set {
            if (value is null) return;
            if (!value.Equals(selected)) {
                selected = value;
            }
            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).Pages.SelectedPage is LemmaPage page) {
                page.setContent(value);
            }
        }
    }

    public string Covered { get; set; }
    public bool WasRightClicked { get; set; }
    public string Count { get; set; }
    public ObservableCollection<Lemma> Items { get; set; }

    public RootLemmaLessVM() {
        Items = new ObservableCollection<Lemma>();
        
        Task.Run(() => {
            sources = new List<RLFRee>();
            int count = 0;
            foreach (var item in App.links) {
                if (!string.IsNullOrEmpty(item.LemmaCorpus)) continue;
                count++;
                var corpus = string.Join("", item.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)]));
                var simple = string.Join("", item.SegmentsSimple.Split('|').Select(x => App.segments[Convert.ToInt32(x)]));
                sources.Add(new RLFRee() {
                    Spellings = new string[]{ corpus, simple },
                    Reference = item.Reference
                });
            }

            var groups = sources
               .GroupBy(x => x.Spellings[App.global.Transcript])
               .ToList();

            App.Current.Dispatcher.Invoke(() => {
                foreach (var item in groups) {
                    var transcripts = new string[2];
                    transcripts[App.global.Transcript] = item.Key;
                    Items.Add(new Lemma() {
                        Transcripts = transcripts,
                        References = item.Select(x => x.Reference).ToList(),
                    });
                }
                Covered = count.ToString("N0") + " words covered";
                Count = groups.Count.ToString("N0");
                OnPropertyChanged(nameof(Count));
                OnPropertyChanged(nameof(Covered));
            });
        });

        App.global.PropertyChanged += onTranscriptChanged;
    }

    void onTranscriptChanged(object? sender, PropertyChangedEventArgs e) {
        if (!e.PropertyName.Equals(nameof(App.global.Transcript))) return;
        var groups = sources
               .GroupBy(x => x.Spellings[App.global.Transcript])
               .ToList();
        Items.Clear();
        foreach (var item in groups) {
            var transcripts = new string[2];
            transcripts[App.global.Transcript] = item.Key;
            Items.Add(new Lemma() {
                Transcripts = transcripts,
                References = item.Select(x => x.Reference).ToList(),
            });
        }
        Count = groups.Count.ToString("N0");
        OnPropertyChanged(nameof(Count));
    }

    class RLFRee {
        public string[] Spellings { get; set; }
        public string Reference { get; set; }
    }
}
