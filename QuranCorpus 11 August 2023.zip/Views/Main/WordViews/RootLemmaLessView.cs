﻿class RootLemmaLessView : CardView {
    public override string Icon => Icons.SeedOff;

    Run count;
    TextBlockEnglish coveredBlock;
    ListBox list;
    PageControl pages;
    RootLemmaLessVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new RootLemmaLessVM();
        DataContext = vm;
        pages = ((App)Application.Current).Pages;
        initializeUI();
        bind();
    }

    void initializeUI() {
        count = new Run();
        var countBlock = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            TextAlignment = TextAlignment.Right,
            Inlines = {
                count,
                new Run(" words without root or lemma")
            }
        };
        coveredBlock = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            TextAlignment = TextAlignment.Right
        };
      
        list = new ListBox() {
            FlowDirection = FlowDirection.RightToLeft,
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(RLFreeTemplate))
            }
        };
        list.PreviewMouseRightButtonDown += onRightButtonDown;
        list.MouseRightButtonUp += onRightButtonUp;
        Grid.SetRow(coveredBlock, 1);
        Grid.SetRow(list, 2);
        var content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { countBlock, coveredBlock, list }
        };
        setContent(content);
    }

    void bind() {
        count.SetBinding(Run.TextProperty, new Binding(nameof(vm.Count)));
        coveredBlock.SetBinding(TextBlockEnglish.TextProperty, new Binding(nameof(vm.Covered)));
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Items)));
        list.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.Selected)));
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) => pages.addLemmaPage(vm.Selected);

    void onRightButtonDown(object sender, MouseButtonEventArgs e) => vm.WasRightClicked = true;
}
