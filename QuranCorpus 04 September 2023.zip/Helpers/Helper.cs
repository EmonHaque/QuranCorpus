﻿public class Helper
{
    public static Path getIcon(string data, Brush fill = null) => new Path() {
        Data = Geometry.Parse(data),
        Fill = fill == null ? Brushes.Black : fill,
        Width = 12,
        Height = 12,
        Stretch = Stretch.Uniform
    };

    public static T FindParentOfType<T>(DependencyObject child) where T : DependencyObject {
        DependencyObject parentDepObj = child;
        do {
            parentDepObj = VisualTreeHelper.GetParent(parentDepObj);
            T parent = parentDepObj as T;
            if (parent != null) return parent;
        }
        while (parentDepObj != null);
        return null;
    }

    public static T FindVisualChild<T>(DependencyObject o) where T : DependencyObject {
        for (int i = 0; i < VisualTreeHelper.GetChildrenCount(o); i++) {
            var child = VisualTreeHelper.GetChild(o, i);
            if (child != null && child is T) return (T)child;
            else {
                T grandChild = FindVisualChild<T>(child);
                if (grandChild != null) return grandChild;
            }
        }
        return null;
    }

    public static IEnumerable<T> FindVisualChildren<T>(DependencyObject o) where T : DependencyObject {
        if (o != null) {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(o); i++) {
                DependencyObject child = VisualTreeHelper.GetChild(o, i);
                if (child != null && child is T) {
                    yield return (T)child;
                }

                foreach (T childOfChild in FindVisualChildren<T>(child)) {
                    yield return childOfChild;
                }
            }
        }
    }

    public static string[] getSegments(Link link) => new string[] {
        link.SegmentsCorpus,
        link.SegmentsSimple
    };
    public static string[] getLemmas(Link link) => new string[] {
        link.LemmaCorpus,
        link.LemmaSimple
    };
    public static string[] getSpellings(Link link) => new string[] {
        link.SpellingGroupCorpus,
        link.SpellingGroupSimple
    };

    public static string getTagName(Tag tag, string detail) {
        var tagName = tag.Value;
        if (string.IsNullOrEmpty(detail)) return tagName;

        var details = string.Join('|', detail.Split('|').Select(x => App.details[Convert.ToInt32(x)].Name));

        if (tag.Name.Equals("N") || tag.Name.Equals("ADJ") || tag.Name.Equals("PN")) {
            if (details.Contains("ACT|PCPL")) tagName = "active participle";
            else if (details.Contains("PASS|PCPL")) tagName = "passive participle";
            else if (details.Contains("VN")) tagName = "verbal noun";
        }
        else if (tag.Name.Equals("LOC")) {
            if (details.Contains("ACT|PCPL")) tagName = "active participle";
            else if (details.Contains("PASS|PCPL")) tagName = "passive participle";
        }
        else if (tag.Name.Equals("VOC")) {
            if (details.StartsWith('+')) tagName = "vocative suffix";
        }
        else if (tag.Name.Equals("EMPH")) {
            if (details.StartsWith('+')) tagName = "emphatic suffix";
            else tagName = "emphatic prefix";
        }
        else if (tag.Name.Equals("COND")) {
            if (details.StartsWith("CN")) tagName = "conditional noun";
            else tagName = "conditional particle";
        }
        else if (tag.Name.Equals("INTG")) {
            if (details.StartsWith("A:")) tagName = "interrogative alif";
            else if (details.StartsWith("IN")) tagName = "interrogative noun";
            else if (details.StartsWith("IP")) tagName = "interrogative particle";
        }
        else if (tag.Name.Equals("CONJ")) {
            if (string.IsNullOrEmpty(details)) tagName = "coordinating conjunction";
        }
        else if (tag.Name.Equals("PRON")) {
            if (details.StartsWith("PER")) tagName = "personal pronoun";
            else if (details.StartsWith("SUB")) tagName = "subject pronoun";
            else if (details.StartsWith("OBJ")) tagName = "object pronoun";
            else if (details.StartsWith("POS")) tagName = "possessive pronoun";
        }
        return tagName;
    }

    public static Tuple<string, string> getExplanations(string explanation, string query) {
        var index = explanation.IndexOf(query);
        if (index == -1) return null;

        int startIndex = 0;
        for (int i = index; i > 0; i--) {
            if (explanation[i] != '.') continue;
            startIndex = i;
            break;
        }
        string first, second;
        if (startIndex == 0) {
            first = explanation;
            second = null;
        }
        else {
            first = explanation.Substring(0, startIndex);
            second = explanation.Substring(startIndex + 2);
        }
        return new Tuple<string, string>(first, second);
    }

    public static Detail getGender(string input) {
        switch (input) {
            case "P":
            case "2D":
            case "3D":
            case "M":
            case "MS":
            case "MD":
            case "2MD":
            case "3MD":
            case "MP":
            case "2MS":
            case "2MP":
            case "3MS":
            case "3MP":
            case "1S":
            case "1P":
            case "F":
            case "FS":
            case "FP":
            case "2FS":
            case "FD":
            case "2FD":
            case "3FD":
            case "3FS":
            case "2FP":
            case "3FP": return App.details.First(x => x.Name.Equals(input));
        }
        return null;
    }

    public static Detail getForm(string input) {
        switch (input) {
            case "(II)":
            case "(III)":
            case "(IV)":
            case "(V)":
            case "(VI)":
            case "(VII)":
            case "(VIII)":
            case "(IX)":
            case "(X)":
            case "(XI)":
            case "(XII)": return App.details.First(x => x.Name.Equals(input));
        }
        return null;
    }

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    internal static extern bool GetCursorPos(ref Win32Point pt);

    [StructLayout(LayoutKind.Sequential)]
    internal struct Win32Point {
        public Int32 X;
        public Int32 Y;
    };
    public static Point GetMousePosition() {
        var w32Mouse = new Win32Point();
        GetCursorPos(ref w32Mouse);

        return new Point(w32Mouse.X, w32Mouse.Y);
    }
}

