﻿class TafsirPage : Page {
    Grid content, leftGrid;

    WaterBox query;
    ListBox verseBox;
    StackPanel tafsirPanel;
    ScrollViewer tafsirScroll;
    List<Tafsir> explanation;
    ICollectionView verseView;

    public override PageType Type => PageType.Tafsir;
    public override UIElement Content => content;

    public TafsirPage() {
        query = new WaterBox() {
            Margin = new Thickness(0,0,5,0),
            Icon = Icons.Search,
            Hint = "Verse"
        };
        var count = new TextBlockEnglish() { HorizontalAlignment = HorizontalAlignment.Right };
        Grid.SetColumn(count, 1);
        var queryGrid = new Grid() {
            Margin = new Thickness(0,0,0,5),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = GridLength.Auto }
            },
            Children = { query, count }
        };
        verseBox = new ListBox() {
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(VerseTemplate))
            }
        };
        verseBox.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        verseBox.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
        count.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Mode = BindingMode.OneWay,
            Source = verseBox
        });
        var verticalSeparator = new Rectangle() {
            Margin = new Thickness(2.5, 0, 2.5, 0),
            HorizontalAlignment = HorizontalAlignment.Right,
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        Grid.SetRow(verseBox, 1);
        Grid.SetColumn(verticalSeparator, 1);
        Grid.SetRowSpan(verticalSeparator, 2);
        leftGrid = new Grid() {
            Width = 150,
            RowDefinitions = {
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = GridLength.Auto}
            },
            Children = { queryGrid, verseBox, verticalSeparator}
        };

        tafsirPanel = new StackPanel();
        tafsirPanel.Resources.Add(typeof(TextBlockEnglish), new Style() {
            Setters = {
                    new Setter(TextBlockEnglish.TextWrappingProperty, TextWrapping.Wrap),
                    new Setter(TextBlockEnglish.MarginProperty, new Thickness(0,5,0,5))
                }
        });
        tafsirPanel.Resources.Add(typeof(TextBlockArabic), new Style() {
            Setters = {
                    new Setter(TextBlockEnglish.FlowDirectionProperty, FlowDirection.RightToLeft),
                    new Setter(TextBlockArabic.TextWrappingProperty, TextWrapping.Wrap),
                    new Setter(TextBlockArabic.MarginProperty, new Thickness(0,5,0,5))
                }
        });
        tafsirScroll = new ScrollViewer() {
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Padding = new Thickness(2.5, 0, 5, 0),
            Content = tafsirPanel
        };
        
        Grid.SetColumn(tafsirScroll, 1);
        content = new Grid() {
            FlowDirection = FlowDirection.LeftToRight,
            
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition()
            },
            Children = { leftGrid, tafsirScroll }
        };

        verseBox.SelectionChanged += onVerseSelectionChanged;
        query.KeyUp += onQueryKeyUp;
    }

    public TafsirPage(int surahNo) : this() => updateUI(surahNo);

    public void setContent(int surahNo) => updateUI(surahNo);

    void updateUI(int surahNo) {
        HeaderText = surahNo + ") " + App.surahs.First(x => x.Id == surahNo).Transliteration + " | " + "Tafsir";
        verseBox.SelectedItem = null;
        var tafs = System.IO.File.ReadLines("Resources/Tafsir/en-ibn-kathir-qurancom.txt");
        var rator = tafs.GetEnumerator();

        explanation = new List<Tafsir>();
        int no = surahNo == 105 ? 104 : surahNo;
        int count = 0;
        int ayahNo = 0;
        int surahIndex = 0;
        int sum = App.surahs[surahIndex].Verses;

        while (true) {
            rator.MoveNext();
            if (rator.Current is null) break;
            if (string.IsNullOrEmpty(rator.Current)) continue;

            if (rator.Current.StartsWith("# ")) {
                count++;
                if (count > sum) {
                    surahIndex++;
                    sum += App.surahs[surahIndex].Verses;
                    ayahNo = 1;
                }
                else ayahNo++;
                continue;
            }
            if (App.surahs[surahIndex].Id < no) continue;
            if (App.surahs[surahIndex].Id > no) break;

            if (rator.Current.Equals("<!-- TODO:MISSING -->")) {
                explanation.Last().Ayahs += (", " + ayahNo.ToString());
            }
            else {
                if (explanation.Count == 0) {
                    explanation.Add(new Tafsir() {
                        SurahNo = App.surahs[surahIndex].Id,
                        Ayahs = ayahNo.ToString(),
                        Lines = new List<string>()
                    });
                }
                else {
                    var last = explanation.Last();
                    if (last.SurahNo == App.surahs[surahIndex].Id) {
                        var ayahs = last.Ayahs.Split(",", StringSplitOptions.TrimEntries);
                        if (!ayahs.Contains(ayahNo.ToString())) {
                            explanation.Add(new Tafsir() {
                                SurahNo = App.surahs[surahIndex].Id,
                                Ayahs = ayahNo.ToString(),
                                Lines = new List<string>()
                            });
                        }
                    }
                    else {
                        explanation.Add(new Tafsir() {
                            SurahNo = App.surahs[surahIndex].Id,
                            Ayahs = ayahNo.ToString(),
                            Lines = new List<string>()
                        });
                    }
                }

                explanation.Last().Lines.Add(rator.Current);
            }
        }

        rator.Dispose();

        if(surahNo == 105) {
            string ayahs = "";
            for (int i = 0; i < App.surahs[104].Verses; i++) {
                ayahs += (i + 1) + ", ";
            }
            ayahs = ayahs.Remove(ayahs.LastIndexOf(", "));
            explanation[0].Ayahs = ayahs;
        }

        var source = explanation.Select(x => x.Ayahs).ToList();
        
        if(source.Count == 1) {
            leftGrid.Visibility = Visibility.Collapsed;
            query.Text = "";
        }
        else {
            leftGrid.Visibility = Visibility.Visible;
        }
        verseView = CollectionViewSource.GetDefaultView(source);
        verseView.Filter = filter;
        verseBox.ItemsSource = verseView;
    }

    void onVerseSelectionChanged(object sender, SelectionChangedEventArgs e) {
        tafsirPanel.Children.Clear();
        if (verseBox.SelectedItem is null) return;

        var lines = explanation.First(x => x.Ayahs.Equals(verseBox.SelectedItem));
        
        for (int i = 0; i < lines.Lines.Count; i++) {
            var text = lines.Lines[i].Replace("\\", "").Replace("`", "'");
            if (text.StartsWith("«") || text.EndsWith("»")) {
                var arabic = new TextBlockArabic() {
                    Text = text.Replace("«", "").Replace("»", "")
                };
                tafsirPanel.Children.Add(arabic);
            }
            else {
                if (text.StartsWith("###")) {
                    tafsirPanel.Children.Add(new TextBlockEnglish() {
                        Text = text.Substring(3),
                        Foreground = Brushes.Gray,
                        FontWeight = FontWeights.Bold
                    });
                }
                else if (text.StartsWith("##")) {
                    tafsirPanel.Children.Add(new TextBlockEnglish() {
                        Text = text.Substring(2),
                        Foreground = Brushes.Gray,
                        FontWeight = FontWeights.Bold
                    });
                }
                else {
                    bool isArabic = true;
                    var length = text.Length > 10 ? 10 : text.Length;
                    for (int j = 0; j < length; j++) {
                        var ch = text[j];
                        if ((ch >= 'A' && ch <= 'Z') ||
                            (ch >= 'a' && ch <= 'z') ||
                            (ch >= '0' && ch <= '9')) {
                            isArabic = false;
                            break;
                        }
                    }
                    if (isArabic) {
                        tafsirPanel.Children.Add(new TextBlockArabic() {
                            Text = text
                        });
                    }
                    else {
                        tafsirPanel.Children.Add(new TextBlockEnglish() {
                            Text = text.Replace("`", "'")
                        }); ;
                    }
                }
            }
        }
       
        tafsirScroll.ScrollToTop();
    }

    void onQueryKeyUp(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        verseView.Refresh();
    }

    bool filter(object o) {
        if (string.IsNullOrEmpty(query.Text)) return true;
        var verses = o.ToString().Split(',', StringSplitOptions.TrimEntries);
        return verses.Contains(query.Text);
    }

    protected override void unload() {
        verseBox.SelectionChanged -= onVerseSelectionChanged;
        query.KeyUp -= onQueryKeyUp;
        base.unload();
    }

    class VerseTemplate : TextBlockEnglish {
        public VerseTemplate() {
            TextWrapping = TextWrapping.Wrap;
            SetBinding(TextProperty, new Binding());
        }
    }
}