﻿
//using System.IO;
//using System.Data;
//using System.Diagnostics;
//using System.Drawing;
//using System.Net.Sockets;
//using System.Reflection.PortableExecutable;
//using System.Reflection;

class Tafsir {
    public int SurahNo { get; set; }
    public string Ayahs { get; set; }
    public List<string> Lines { get; set; }
    public Tafsir() {
        Lines = new List<string>();
    }
}
