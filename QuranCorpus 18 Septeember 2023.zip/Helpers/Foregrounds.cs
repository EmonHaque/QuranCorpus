﻿class Foregrounds {
    public static string[] Defined = new string[] { "", "DET", "V", "N", "PN", "ADJ", "REL", "DEM", "P", "PRON", "CONJ", "INTG", "NEG" };
    public static SolidColorBrush DET_Brush = Brushes.Gray;
    public static SolidColorBrush V_Brush = Brushes.Aqua;
    public static SolidColorBrush N_PN_ADJ_Brush = Brushes.White;
    public static SolidColorBrush DEM_REL_Brush = Brushes.LightGreen;
    public static SolidColorBrush P_Brush = Brushes.PaleTurquoise;
    public static SolidColorBrush CONJ_Brush = Brushes.Coral;
    public static SolidColorBrush INTG_Brush = Brushes.PapayaWhip;
    public static SolidColorBrush NEG_Brush = Brushes.Olive;
    public static SolidColorBrush PRON1_Brush = Brushes.Green;
    public static SolidColorBrush PRON2_Brush = Brushes.Lime;
    public static SolidColorBrush PRON3_Brush = Brushes.CadetBlue;
    public static SolidColorBrush OTHER1_Brush = Brushes.Gray;
    public static SolidColorBrush OTHER2_Brush = Brushes.Lime;
    public static SolidColorBrush OTHER3_Brush = Brushes.LightSkyBlue;
}
