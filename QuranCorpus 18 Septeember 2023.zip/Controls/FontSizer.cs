﻿class FontSizer : Grid {
    ActionButton increase, decrease;
    TextBlock headerBlock, numberBlock;
    private string header;

    public string Header {
        get { return header; }
        set { headerBlock.Text = value; }
    }
    private double current;

    public double Current {
        get { return current; }
        set { 
            current = value; 
            numberBlock.Text = value.ToString();
            if (current == Maximum) increase.IsEnabled = false;
            if (current == Minimum) decrease.IsEnabled = false;
        }
    }

    public double Minimum { get; set; }
    public double Maximum { get; set; }
    public Action IncreaseCommand { get; set; }
    public Action DecreaseCommand { get; set; }

    public FontSizer() {
        Margin = new Thickness(0, 5, 0, 5);
        headerBlock = new TextBlock() { 
            Margin = new Thickness(0,0,0,5),
            HorizontalAlignment = HorizontalAlignment.Center 
        };
        numberBlock = new TextBlock() { Margin = new Thickness(5,0,5,0)};
        increase = new ActionButton() {
            Icon = Icons.Plus,
            Command = increaseSize,
            HorizontalAlignment = HorizontalAlignment.Left
        };
        decrease = new ActionButton() {
            Icon = Icons.Minus,
            Command = decreaseSize,
            HorizontalAlignment = HorizontalAlignment.Right
        };

        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });
        RowDefinitions.Add(new RowDefinition() { Height = GridLength.Auto });

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        ColumnDefinitions.Add(new ColumnDefinition());

        SetColumnSpan(headerBlock, 3);
        SetRow(decrease, 1);
        SetRow(numberBlock, 1);
        SetRow(increase, 1);
        SetColumn(numberBlock, 1);
        SetColumn(increase, 2);

        Children.Add(headerBlock);
        Children.Add(decrease);
        Children.Add(numberBlock);
        Children.Add(increase);
    }

    void increaseSize() {
        if (IncreaseCommand is null) return;
        IncreaseCommand.Invoke();
        current++;
        numberBlock.Text = current.ToString();
        if (current == Maximum) increase.IsEnabled = false;
        if (!decrease.IsEnabled) decrease.IsEnabled = true;
    }

    void decreaseSize() {
        if (DecreaseCommand is null) return;
        DecreaseCommand.Invoke();
        current--;
        numberBlock.Text = current.ToString();
        if (current == Minimum) decrease.IsEnabled = false;
        if (!increase.IsEnabled) increase.IsEnabled = true;
    }
}
