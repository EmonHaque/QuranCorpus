﻿class WindowBorder : Border {
    double radius = 5;
    public WindowBorder() {
        CornerRadius = new CornerRadius(radius);
        BorderThickness = new Thickness(0.75);
    }
}
