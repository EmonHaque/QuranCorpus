﻿class NavBorder : Border {
    public double navWidth = 24;
    public Grid container;
    
    public NavBorder() {
        Width = navWidth;
        CornerRadius = new CornerRadius(0, 5, 5, 0);
        container = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            }
        };
        Child = container;
    }
}
