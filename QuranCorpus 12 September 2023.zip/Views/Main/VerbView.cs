﻿class VerbView : CardView {
    public override string Icon => Icons.AlphaV;
    public override bool OverridesToolTip => true;
    public override UIElement Tip => getTip();

    VerbVM vm;
    TextBlockEnglish count;
    ProgressBar progress;
    ListBox list;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new VerbVM();
        DataContext = vm;
        initializeUI();
        bind();
        list.PreviewMouseRightButtonDown += onRightButtonDown;
        list.MouseRightButtonUp += onRightButtonUp;
    }

    void initializeUI() {
        progress = new ProgressBar() {
            Height = 1.5,
            FlowDirection = FlowDirection.RightToLeft
        };
        list = new ListBox() {
            GroupStyle = {
                new GroupStyle() {
                    ContainerStyle = new Style(typeof(GroupItem)) {
                        Setters = {
                            new Setter(GroupItem.TemplateProperty, new GroupTemplate())
                        }
                    }
                }
            },
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(NumberTemplate))
            }
        };
        Grid.SetRow(list, 1);

        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { progress, list }
        };
        setContent(grid);

        count = new TextBlockEnglish();
        addActions(new UIElement[] { count });
    }

    void bind() {
        progress.SetBinding(ProgressBar.IsIndeterminateProperty, new Binding(nameof(vm.IsInProgress)));
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Items)));
        list.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.Selected)) { Mode = BindingMode.OneWayToSource });
        count.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = list,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) {
        e.Handled = true;
        if (vm.Selected is null) return;
        ((App)Application.Current).FocusedControl.addVerbPage(vm.filtered);
        if (vm.WasRightClicked) vm.WasRightClicked = false;
    }

    void onRightButtonDown(object sender, MouseButtonEventArgs e) => vm.WasRightClicked = true;

    class GroupTemplate : ControlTemplate {
        public GroupTemplate() {
            TargetType = typeof(GroupItem);
            var grid = new FrameworkElementFactory(typeof(Grid));
            var row1 = new FrameworkElementFactory(typeof(RowDefinition));
            var row2 = new FrameworkElementFactory(typeof(RowDefinition));
            var name = new FrameworkElementFactory(typeof(TextBlockEnglish));
            var items = new FrameworkElementFactory(typeof(ItemsPresenter));

            row1.SetValue(RowDefinition.HeightProperty, GridLength.Auto);
            name.SetValue(TextBlockEnglish.FontWeightProperty, FontWeights.Bold);
            items.SetValue(Grid.RowProperty, 1);
            items.SetValue(ItemsPresenter.MarginProperty, new Thickness(7.5, 0, 0, 0));
            name.SetBinding(TextBlockEnglish.TextProperty, new Binding(nameof(GroupItem.Name)));

            grid.AppendChild(row1);
            grid.AppendChild(row2);
            grid.AppendChild(name);
            grid.AppendChild(items);

            VisualTree = grid;
        }
    }

    class NumberTemplate : Grid {
        TextBlockEnglish name, count;
        public NumberTemplate() {
            name = new TextBlockEnglish();
            count = new TextBlockEnglish();
            SetColumn(count, 1);
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

            Children.Add(name);
            Children.Add(count);

            name.SetBinding(TextBlockEnglish.TextProperty, new Binding(nameof(VerbGroup.Number)));
            count.SetBinding(TextBlockEnglish.TextProperty, new Binding(nameof(VerbGroup.Count)) { StringFormat = "N0" });
        }
    }

    Grid getTip() {
        var header = new TextBlockEnglish() {
            Text = "Verbs",
            FontWeight = FontWeights.Bold
        };
        var separator = new Rectangle() {
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var description = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Text = "See verbs."
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(description, 2);
        return new Grid() {
            MaxWidth = 200,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(10) },
                new RowDefinition()
            },
            Children = { header, separator, description }
        };
    }
}
