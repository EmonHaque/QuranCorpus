﻿class Morph {
    public string Tag { get; set; }
    public string[] Tags { get; set; }
    public string[] Segments { get; set; }
    public string[] Spellings { get; set; }
    public string Form { get; set; }
    public string SubTag { get; set; }
    public string Gender { get; set; }
    public int Count { get; set; }
    public string Explanation { get; set; }
    
    public List<Tuple<string, string, string>> References { get; set; }

    public Morph() {
        Form = "";
        SubTag = "";
        Gender = "";
        References = new List<Tuple<string, string, string>>();
    }
}
