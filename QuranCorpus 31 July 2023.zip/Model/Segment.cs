﻿class Segment {
    public string[] Tags { get; set; }
    public string[] Segments { get; set; }
    public List<Link>[] References { get; set; }
}

