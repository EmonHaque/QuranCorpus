﻿class Character {
    public char English { get; set; }
    public string Arabic { get; set; }
}
