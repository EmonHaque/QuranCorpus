﻿class Ayah : Notifiable {
    public string SurahNo { get; set; }
    public string AyahNo { get; set; }
    public List<Word> Words { get; set; }

	Translations[] translations;
	public Translations[] Translations {
		get { return translations; }
		set { translations = value; }
	}
}

class Translations {
    public int TranslatorId { get; set; }
    public string Content { get; set; }
}

