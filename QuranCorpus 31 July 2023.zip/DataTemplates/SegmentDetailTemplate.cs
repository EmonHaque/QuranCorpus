﻿class SegmentDetailTemplate : Grid {
    TextBlockEnglish reference, meaning;

    public SegmentDetailTemplate() {
        reference = new TextBlockEnglish();
        meaning = new TextBlockEnglish();

        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(100) });
        ColumnDefinitions.Add(new ColumnDefinition());

        SetColumn(meaning, 1);

        Children.Add(reference);
        Children.Add(meaning);
    }

    public override void EndInit() {
        base.EndInit();
        var link = (Link)DataContext;
        reference.Text = link.Reference;
        meaning.Text = App.meanings[Convert.ToInt32(link.Meaning)];
    }
}
