﻿static class Extensions {
    static StringBuilder builder = new();

    public static string toArabic(this string transcription) {
        builder.Clear();
        foreach (var character in transcription) {
            if (character == ' ') {
                builder.Append(' '); // happens only once in case of prophet il yas, eg. 37:130
                continue;
            } 
            char c = (char)uint.Parse(App.characters.First(x => x.English == character).Arabic, NumberStyles.HexNumber);
            builder.Append(c);
        }
        return builder.ToString();
    }

    public static void toArabic(this string transcription, string[] segments, StringBuilder sb) {
        var characters = App.segments[Convert.ToInt32(transcription)];
        foreach (var character in characters) {
            if (character == ' ') {
                sb.Append(' '); // happens only once in case of prophet il yas, eg. 37:130
                continue;
            }
            char c = (char)uint.Parse(App.characters.First(x => x.English == character).Arabic, NumberStyles.HexNumber);
            sb.Append(c);
        }
    }

    public static void toArabic(this string[] segments, StringBuilder sb) {
        foreach (var segment in segments) {
            var characters = App.segments[Convert.ToInt32(segment)];
            foreach (var character in characters) {
                if (character == ' ') {
                    sb.Append(' '); // happens only once in case of prophet il yas, eg. 37:130
                    continue;
                }
                char c = (char)uint.Parse(App.characters.First(x => x.English == character).Arabic, NumberStyles.HexNumber);
                sb.Append(c);
            }
        }
    }

    public static string toArabicNo(this string value) {
        return value.Replace('0', '\u0660')
              .Replace('1', '\u0661')
              .Replace('2', '\u0662')
              .Replace('3', '\u0663')
              .Replace('4', '\u0664')
              .Replace('5', '\u0665')
              .Replace('6', '\u0666')
              .Replace('7', '\u0667')
              .Replace('8', '\u0668')
              .Replace('9', '\u0669');
    }
}
