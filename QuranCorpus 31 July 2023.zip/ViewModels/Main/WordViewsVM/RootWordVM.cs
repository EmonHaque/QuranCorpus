﻿class RootWordVM : Notifiable {
    List<GroupedLemma> corpusGroups, simpleGroups;
    CancellationTokenSource terminator;
    Task task;

    int scriptState;
    public int ScriptState {
        get { return scriptState; }
        set { scriptState = value; regroup(); }
    }

    object selected;
    public object Selected {
        get { return selected; }
        set {
            if (value is null) selected = null;
            if (value is not Lemma lemma) return;
            if (lemma.Items is not null) return;
            if (value.Equals(selected)) return;

            selected = value;

            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).Pages.SelectedPage is LemmaPage page) {
                page.setContent(lemma);
            }
        }
    }
    string query;
    public string Query {
        get { return query; }
        set {
            query = value is null ? "" : value;
            if (task != null && !task.IsCompleted) {
                // will it ever come here?
                // if it does what'll be the state of terminator in the next task?
                // will IsCancellationRequested be true
                terminator.Cancel();
            }
            regroup();
        }
    }

    public bool WasRightClicked { get; set; }
    public string Count { get; set; }
    public bool IsInProgress { get; set; }
    public List<LemmaHeader> Lemmas { get; set; }

    public RootWordVM() {
        IsInProgress = true;
        terminator = new CancellationTokenSource();
        
        Task.Run(() => {
            var simpleList = new List<Lemma>();
            var corpusList = new List<Lemma>();
            foreach (var link in App.links) {
                if (string.IsNullOrEmpty(link.Root)) continue;

                var tags = link.Tags.Split('|');
                var indices = link.LemmaIndices.Split('|');
                var simple = link.LemmaSimple.Split('|');
                var corpus = link.LemmaCorpus.Split('|');
                // 20:94:2 - yabnaumma has multiple roots
                string root =
                    link.Root.Contains('|') ? 
                    string.Join(" | ", link.Root.Split('|').Select(x => App.roots[Convert.ToInt32(x)])) :
                    App.roots[Convert.ToInt32(link.Root)];

                for (int i = 0; i < indices.Length; i++) {
                    if (simple[i].Equals("64")) {
                        /*
                         * bi}osa|maA - root bAs
                         * baEod|maA - root bEd
                         * niEoma|maA - root nEm
                         * kul~amaA|maA - root kll
                         */
                        continue;
                    }
                    var pos = App.tags[Convert.ToInt32(tags[Convert.ToInt32(indices[i])])];
                    var simpleLemma = App.lemmas[Convert.ToInt32(simple[i])];
                    var corpusLemma = App.lemmas[Convert.ToInt32(corpus[i])];

                    bool simpleFound = false;
                    bool corpusFound = false;
                    foreach (var item in simpleList) {
                        if (item.Transcription.Equals(simpleLemma) &&
                            item.POS.Equals(pos) &&
                            item.Root.Equals(root)) {
                            simpleFound = true;
                            item.References.Add(link.Reference);
                            break;
                        }
                    }

                    foreach (var item in corpusList) {
                        if (item.Transcription.Equals(corpusLemma) &&
                            item.POS.Equals(pos) &&
                            item.Root.Equals(root)) {
                            corpusFound = true;
                            item.References.Add(link.Reference);
                            break;
                        }
                    }

                    if (!simpleFound) {
                        var references = new List<string>();
                        references.Add(link.Reference);
                        simpleList.Add(new Lemma() {
                            Transcription = simpleLemma,
                            POS = pos,
                            Root = root,
                            References = references
                        });
                    }
                    if (!corpusFound) {
                        var references = new List<string>();
                        references.Add(link.Reference);
                        corpusList.Add(new Lemma() {
                            Transcription = corpusLemma,
                            POS = pos,
                            Root = root,
                            References = references
                        });
                    }
                }
            }

            simpleGroups = simpleList.GroupBy(x => x.Root)
            .Select(x => new GroupedLemma {
                Root = x.Key,
                Lemmas = x.GroupBy(x => x.Transcription).ToList()
            }).ToList();
            corpusGroups = corpusList.GroupBy(x => x.Root)
            .Select(x => new GroupedLemma {
                Root = x.Key,
                Lemmas = x.GroupBy(x => x.Transcription).ToList()
            }).ToList();

            corpusFilter("");
        });
    }

    void regroup() {
        if(ScriptState == 0) corpusFilter(query);
        else simpleFilter(query);
    }

    void simpleFilter(string query) {
        if (simpleGroups is null) return;

        IsInProgress = true;
        OnPropertyChanged(nameof(IsInProgress));

        task = Task.Run(() => {
            int rootCount = 0;
            int formCount = 0;

            var lemmas = new List<LemmaHeader>();

            foreach (var group in simpleGroups) {
                if (terminator.IsCancellationRequested) break;
                if (!group.Root.Contains(query)) continue;

                rootCount++;
                var header = new LemmaHeader() { Root = group.Root };
                header.Items = new List<Lemma>();
                foreach (var subGroup in group.Lemmas) {
                    if (terminator.IsCancellationRequested) break;

                    if (subGroup.Count() == 1) {
                        header.Items.Add(subGroup.First());
                        formCount++;
                        continue;
                    }
                    foreach (var item in subGroup) {
                        bool hasFound = false;
                        foreach (var x in header.Items) {
                            if (terminator.IsCancellationRequested) break;

                            if (x.Transcription.Equals(item.Transcription)) {
                                hasFound = true;
                                x.Items.Add(item);
                                break;
                            }
                        }
                        if (!hasFound) {
                            header.Items.Insert(0, item);
                            item.Items = new List<Lemma> {
                                new Lemma(item)
                            };
                            formCount++;
                        }
                    }
                }
                lemmas.Add(header);
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    Lemmas = lemmas;
                    Count = $"{formCount.ToString("N0")} lemma in {rootCount.ToString("N0")} root";
                    IsInProgress = false;
                    OnPropertyChanged(nameof(Count));
                    OnPropertyChanged(nameof(IsInProgress));
                    OnPropertyChanged(nameof(Lemmas));
                });
            }
            else {
                App.Current.Dispatcher.Invoke(() => {
                    IsInProgress = false;
                    OnPropertyChanged(nameof(IsInProgress));
                });
            }
        }, terminator.Token);
    }

    void corpusFilter(string query) {
        if (corpusGroups is null) return;

        IsInProgress = true;
        OnPropertyChanged(nameof(IsInProgress));

        task = Task.Run(() => {
            int rootCount = 0;
            int formCount = 0;

            var lemmas = new List<LemmaHeader>();

            foreach (var group in corpusGroups) {
                if (terminator.IsCancellationRequested) break;
                if (!group.Root.Contains(query)) continue;

                rootCount++;
                var header = new LemmaHeader() { Root = group.Root };
                header.Items = new List<Lemma>();
                foreach (var subGroup in group.Lemmas) {
                    if (terminator.IsCancellationRequested) break;

                    if (subGroup.Count() == 1) {
                        header.Items.Add(subGroup.First());
                        formCount++;
                        continue;
                    }
                    foreach (var item in subGroup) {
                        bool hasFound = false;
                        foreach (var x in header.Items) {
                            if (terminator.IsCancellationRequested) break;

                            if (x.Transcription.Equals(item.Transcription)) {
                                hasFound = true;
                                x.Items.Add(item);
                                break;
                            }
                        }
                        if (!hasFound) {
                            header.Items.Insert(0, item);
                            item.Items = new List<Lemma> {
                                new Lemma(item)
                            };
                            formCount++;
                        }
                    }
                }
                lemmas.Add(header);
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    Lemmas = lemmas;
                    Count = $"{formCount.ToString("N0")} lemma in {rootCount.ToString("N0")} root";
                    IsInProgress = false;
                    OnPropertyChanged(nameof(Count));
                    OnPropertyChanged(nameof(IsInProgress));
                    OnPropertyChanged(nameof(Lemmas));
                });
            }
            else {
                App.Current.Dispatcher.Invoke(() => {
                    IsInProgress = false;
                    OnPropertyChanged(nameof(IsInProgress));
                });
            }
        }, terminator.Token);
    }
}
