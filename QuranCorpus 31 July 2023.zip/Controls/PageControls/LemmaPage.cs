﻿class LemmaPage : Page {
    public override PageType Type => PageType.Lemma;
    public override UIElement Content => content;

    Grid content;
    ProgressBar progress;
    MultiState groupState;
    DragListBox ayahListBox;
    TreeView tree;
    CancellationTokenSource terminator;
    DependencyPropertyDescriptor groupStateDescriptor;

    List<IGrouping<string, Match>> groups;
    List<Match> matches;

    public LemmaPage() {
        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };
        groupState = new MultiState() {
            Icons = new string[] { Icons.Group, Icons.Ungroup },
            IsIconInfront = true,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(10, 0, 0, 10)
        };
        ayahListBox = new DragListBox() { 
            ItemTemplate = new MatchTemplate()
        };
        ayahListBox.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        tree = new TreeView() {
            FlowDirection = FlowDirection.RightToLeft,
            Visibility = Visibility.Hidden,
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            // if you set HorizontalScrollBarVisibilityProperty here and disable the 
                            // tree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
                            // it will mess up when scrollbar appears and disappears
                            //new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()),
                        }
                    }
                }
            }
        };
        tree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        tree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true);

        Grid.SetRow(groupState, 1);
        Grid.SetRow(tree, 2);
        Grid.SetRow(ayahListBox, 2);

        content = new Grid() {
            RowDefinitions = {
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, groupState, ayahListBox, tree }
        };
        terminator = new CancellationTokenSource();
        groupStateDescriptor = DependencyPropertyDescriptor.FromProperty(MultiState.StateProperty, typeof(MultiState));
        groupStateDescriptor.AddValueChanged(groupState, onGroupStateChanged);
        ayahListBox.MouseDoubleClick += onDoubleLick;
        tree.MouseDoubleClick += onDoubleLick;
    }

    public LemmaPage(Lemma lemma) : this() {
        setHeader(lemma);
        Task.Run(() => {
            matches = getMatches(lemma);
            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    ayahListBox.ItemsSource = matches;
                    createTree();
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    public void setContent(Lemma lemma) {
        setHeader(lemma);
        Task.Run(() => {
            matches = getMatches(lemma);
            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    ayahListBox.ItemsSource = matches;
                    createTree();
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    void setHeader(Lemma lemma) {
        HeaderText = "(" + lemma.References.Count.ToString("N0") + ") " + lemma.Transcription.toArabic();
        progress.IsIndeterminate = true;
    }

    List<Match> getMatches(Lemma lemma) {
        var matches = new List<Match>();
        var fileName = App.global.TranslationDictionary[App.global.Translation];
        var lines = System.IO.File.ReadLines("Resources/Tanzil/" + fileName);
        var iterator = lines.GetEnumerator();
        iterator.MoveNext();
        string line = iterator.Current;

        var linkIterator = App.links.GetEnumerator();
        linkIterator.MoveNext();
        var item = linkIterator.Current;

        foreach (var reference in lemma.References) {
            if (terminator.IsCancellationRequested) break;

            var ayahNo = reference.Substring(0, reference.LastIndexOf(':') + 1);
            var wordNo = reference.Substring(reference.LastIndexOf(':'));
            var ayahTxt = ayahNo.Substring(0, ayahNo.Length - 1).Replace(':', '|');

            if (!line.StartsWith(ayahTxt)) {
                while (!iterator.Current.StartsWith(ayahTxt)) iterator.MoveNext();
                line = iterator.Current;
            }

            var no = Convert.ToInt32(wordNo.Substring(1));
            int count = 1;

            bool hasLeading = no != 1;
            bool hasTrailing = false;
            bool fromBeginning = no == 1;

            if (!item.Reference.Equals(reference)) {
                while (!linkIterator.Current.Reference.StartsWith(reference)) linkIterator.MoveNext();
                item = linkIterator.Current;
            }

            string segmentIndex, transcription;
            if (item.LemmaIndices.Contains('|')) {
                // 20:94:2 - yabnaumma hass multiple roots
                var indices = item.LemmaIndices.Split('|');
                var segments = App.global.Transcript == 0 ?
                    item.SegmentsCorpus.Split('|') :
                    item.SegmentsSimple.Split('|');
      
                transcription = App.segments[Convert.ToInt32(indices[0])];
                transcription += App.segments[Convert.ToInt32(indices[1])];
            }
            else {
                segmentIndex = App.global.Transcript == 0 ?
                    item.SegmentsCorpus.Split('|')[Convert.ToInt32(item.LemmaIndices)] :
                    item.SegmentsSimple.Split('|')[Convert.ToInt32(item.LemmaIndices)];
                transcription = App.segments[Convert.ToInt32(segmentIndex)];
            }

            List<Word> words = new();
            var index = App.links.IndexOf(item);
            int startIndex = index - no + 1;

            if (hasLeading && no < 6) {
                index = startIndex;
                fromBeginning = true;
            }

            while (true) {
                words.Add(new Word() {
                    Reference = App.links[index].Reference,
                    Segments = Helper.getSegments(App.links[index])
                });
                index++;
                if (index == App.links.Count) {
                    hasTrailing = false;
                    break;
                }
                count++;
                if (count > 10) {
                    hasTrailing = App.links[index].Reference.StartsWith(ayahNo);
                    break;
                }

                if (!App.links[index].Reference.StartsWith(ayahNo)) {
                    if (!fromBeginning) {
                        var lastIndex = index - words.Count;
                        index = lastIndex - 10 + words.Count;
                        if (index < startIndex) {
                            index = startIndex;
                            hasLeading = false;
                        }
                        count = 0;
                        while (index < lastIndex) {
                            words.Insert(count, new Word() {
                                Reference = App.links[index].Reference,
                                Segments = Helper.getSegments(App.links[index])
                            });
                            count++;
                            index++;
                        }
                    }
                    break;
                }
            }

            if (!fromBeginning && hasLeading) words.Insert(0, new Word());
            if (hasTrailing) words.Add(new Word());

            matches.Add(new Match() {
                Reference = reference,
                WordNo = wordNo,
                Transliteration = App.transliterations[Convert.ToInt32(item.Transliteration)],
                Meaning = App.meanings[Convert.ToInt32(item.Meaning)],
                Tag = item.Tags,
                Words = words,
                Translation = line,
                Spelling = transcription.toArabic()
            });
        }
        
        groups = matches.GroupBy(x => x.Spelling).ToList();
        iterator.Dispose();
        return matches;
    }

    void createTree() {
        tree.Items.Clear();
        int count = 0;
        foreach (var group in groups) {
            count++;
            var items = group.ToList();
            var branch = new TreeViewItem() {
                Header = new Tuple<string, string>(group.Key, items.Count.ToString()),
                HeaderTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(SpellingGroupTemplate))
                },
                ItemTemplate = new MatchTemplate(),
                ItemsSource = items
            };
            tree.Items.Add(branch);
        }
        groupState.Texts = new string[] { "Group by " + count + " spelling", "Ungroup " + count + " spelling" };
    }

    //string getSpelling(string segment) {
    //    if (segment.StartsWith("_#")) segment = segment.Replace("_#", "'"); // Tatweel and HamzaAbove with Hamza
    //    if (segment.Contains('[')) segment = segment.Replace("[", ""); // SmallHighMeemIsolatedForm
    //    if (segment.Contains(']')) segment = segment.Replace("]", ""); // SmallLowMeem
    //    if (segment.ElementAt(1) == '~') segment = segment.Remove(1, 1); // Shadda
    //    if (segment.EndsWith('F') || // Fathatan
    //        segment.EndsWith('N') || // Dammatan
    //        segment.EndsWith('K') || // Kasratan
    //        segment.EndsWith('a') || // Fatha
    //        segment.EndsWith('i') || // Kasra
    //        segment.EndsWith('u')) { // Damma
    //        segment = segment.Remove(segment.Length - 1);
    //    }
    //    return segment.toArabic();
    //}

    void onGroupStateChanged(object? sender, EventArgs e) {
        if (groupState.State == 1) {
            ayahListBox.Visibility = Visibility.Hidden;
            tree.Visibility = Visibility.Visible;
        }
        else {
            tree.Visibility = Visibility.Hidden;
            ayahListBox.Visibility = Visibility.Visible;
        }
    }

    void onDoubleLick(object sender, MouseButtonEventArgs e) {
        if (e.ChangedButton != MouseButton.Left) return;
        Match selected = 
            groupState.State == 1 ?
            tree.SelectedItem as Match :
            (Match)ayahListBox.SelectedItem;

        if (selected is null) return;
        ((App)Application.Current).Pages.addSurahPage(selected.Reference);
    }

    protected override void unload() {
        ayahListBox.MouseDoubleClick -= onDoubleLick;
        tree.MouseDoubleClick -= onDoubleLick;
        groupStateDescriptor.RemoveValueChanged(groupState, onGroupStateChanged);
        terminator.Cancel();
        terminator.Dispose();
        base.unload();
    }
}
