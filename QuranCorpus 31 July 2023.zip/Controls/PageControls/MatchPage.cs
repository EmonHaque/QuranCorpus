﻿using System.Windows.Controls;

class MatchPage : Page {
    Grid content;
    ProgressBar progress;
    TextBlockArabic searchKey;
    TextBlockEnglish searchModeBlock, groupNoBlock;
    MultiState groupState;
    TreeView tagTree, lemmaTree, spellingTree, surahTree;
    CancellationTokenSource terminator;
    List<Match> matches;
    DependencyPropertyDescriptor groupStateDescriptor;
    byte searchMode;

    public override PageType Type => PageType.Match;
    public override UIElement Content => content;

    public MatchPage() {
        progress = new ProgressBar() { Height = 1.5 };
        searchKey = new TextBlockArabic();
        searchModeBlock = new TextBlockEnglish() {
            Margin = new Thickness(10, 0, 0, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        groupNoBlock = new TextBlockEnglish() {
            Foreground = Brushes.Gray,
            Margin = new Thickness(10, 0, 0, 0),
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center
        };
        groupState = new MultiState() {
            //Icons = new string[] { Icons.CopyArabic, Icons.List, Icons.Tag },
            //Texts = new string[] { "Group by spelling", "Group by surah", "Group by tag" },
            IsIconInfront = true,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(10, 0, 0, 0)
        };
        Grid.SetColumn(searchModeBlock, 1);
        Grid.SetColumn(groupNoBlock, 2);
        Grid.SetColumn(groupState, 3);
        var panel = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { searchKey, searchModeBlock, groupState, groupNoBlock }
        };
        Grid.SetRow(panel, 1);

        initializeTrees();
        content = new Grid() {
            RowDefinitions = {
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, panel, tagTree, lemmaTree, spellingTree, surahTree }
        };
        terminator = new CancellationTokenSource();
        groupStateDescriptor = DependencyPropertyDescriptor.FromProperty(MultiState.StateProperty, typeof(MultiState));
        groupStateDescriptor.AddValueChanged(groupState, onGroupStateChanged);
        tagTree.MouseDoubleClick += onDoubleLick;
        spellingTree.MouseDoubleClick += onDoubleLick;
        surahTree.MouseDoubleClick += onDoubleLick;
        lemmaTree.MouseDoubleClick += onDoubleLick;
    }

    public MatchPage(Word w) : this() {
        var word = App.links.First(x => x.Reference.Equals(w.Reference));
        var index = App.transliterations.IndexOf(w.Transliteration).ToString();

        List<Link> match;
        string header = "";
        if (string.IsNullOrEmpty(word.Root)) {
            if (string.IsNullOrEmpty(word.LemmaSimple)) {
                searchMode = 3;
                searchModeBlock.Text = "Search mode: literal";
                searchKey.Text = string.Join(" | ", word.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)].toArabic()));
                header = searchKey.Text;
                match = App.links.Where(x => x.Transliteration.Equals(index)).ToList();
            }
            else {
                searchMode = 2;
                searchModeBlock.Text = "Search mode: lemma";
                searchKey.Text = string.Join(" | ", word.LemmaSimple.Split('|').Select(x => App.lemmas[Convert.ToInt32(x)].toArabic()));
                header = searchKey.Text;
                match = App.links.Where(x => x.LemmaSimple.Equals(word.LemmaSimple)).ToList();
            }
        }
        else {
            if (word.Root.Contains('|')) {
                // in one case 20:94:2 - ya ibna umma - two roots bny and Amm
                searchMode = 3;
                searchModeBlock.Text = "Multiple roots, Search mode: literal";
                searchKey.Text = string.Join(" | ", word.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)].toArabic()));
                header = searchKey.Text;
                match = App.links.Where(x => x.Transliteration.Equals(index)).ToList();
            }
            else {
                searchMode = 1;
                searchModeBlock.Text = "Search mode: root";
                searchKey.Text = App.roots[Convert.ToInt32(word.Root)].toArabic();
                header = searchKey.Text;
                match = App.links.Where(x => x.Root.Equals(word.Root)).ToList();
            }
        }

        HeaderText = "(" + match.Count.ToString("N0") + ") " + header;
        progress.IsIndeterminate = true;

        Task.Run(() => {
            matches = new List<Match>();
            var fileName = App.global.TranslationDictionary[App.global.Translation];
            var lines = System.IO.File.ReadLines("Resources/Tanzil/" + fileName);
            var iterator = lines.GetEnumerator();
            iterator.MoveNext();
            string line = iterator.Current;
            bool hasLemma = false;
            foreach (var item in match) {
                if (terminator.IsCancellationRequested) break;

                var ayahNo = item.Reference.Substring(0, item.Reference.LastIndexOf(':') + 1);
                var wordNo = item.Reference.Substring(item.Reference.LastIndexOf(':'));
                var ayahTxt = ayahNo.Substring(0, ayahNo.Length - 1).Replace(':', '|');

                if (!line.StartsWith(ayahTxt)) {
                    while (!iterator.Current.StartsWith(ayahTxt)) iterator.MoveNext();
                    line = iterator.Current;
                }

                var no = Convert.ToInt32(wordNo.Substring(1));
                int count = 1;

                bool hasLeading = no != 1;
                bool hasTrailing = false;
                bool fromBeginning = no == 1;

                List<Word> words = new();
                var index = App.links.IndexOf(item);
                int startIndex = index - no + 1;
                if (hasLeading && no < 6) {
                    index = startIndex;
                    fromBeginning = true;
                }

                while (true) {
                    words.Add(new Word() {
                        Reference = App.links[index].Reference,
                        Segments = Helper.getSegments(App.links[index])
                    });
                    index++;
                    if (index == App.links.Count) {
                        hasTrailing = false;
                        break;
                    }
                    count++;
                    if (count > 10) {
                        hasTrailing = App.links[index].Reference.StartsWith(ayahNo);
                        break;
                    }

                    if (!App.links[index].Reference.StartsWith(ayahNo)) {
                        if (!fromBeginning) {
                            var lastIndex = index - words.Count;
                            index = lastIndex - 10 + words.Count;
                            if (index < startIndex) {
                                index = startIndex;
                                hasLeading = false;
                            }
                            count = 0;
                            while (index < lastIndex) {
                                words.Insert(count, new Word() {
                                    Reference = App.links[index].Reference,
                                    Segments = Helper.getSegments(App.links[index])
                                });
                                count++;
                                index++;
                            }
                        }
                        break;
                    }
                }

                if (!fromBeginning && hasLeading) words.Insert(0, new Word());
                if (hasTrailing) words.Add(new Word());

                string tag = "";
                string spelling = "";
                string lemma = "";

                if (searchMode == 1) {
                    var tuple = getSpelling(item);
                    tag = tuple.Item1;
                    spelling = tuple.Item2;
                    lemma = getLemma(item);
                    hasLemma = true;
                }
                else if (searchMode == 2) {
                    var indices = item.LemmaIndices.Split('|');
                    if (indices.Length == 1) {
                        var tuple = getSpelling(item);
                        tag = tuple.Item1;
                        spelling = tuple.Item2;
                        lemma = getLemma(item);
                        hasLemma = true;
                    }
                    else {
                        tag = item.Tags;
                        spelling = string.Join("", item.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)].toArabic()));
                    }
                }
                else {
                    tag = item.Tags;
                    spelling = string.Join("", item.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)].toArabic()));
                }

                matches.Add(new Match() {
                    Spelling = spelling,
                    Reference = item.Reference,
                    WordNo = wordNo,
                    Lemma = lemma,
                    Transliteration = App.transliterations[Convert.ToInt32(item.Transliteration)],
                    Meaning = App.meanings[Convert.ToInt32(item.Meaning)],
                    Tag = tag,
                    Words = words,
                    Translation = line
                });
            }
            iterator.Dispose();


            var tagGroups = matches.GroupBy(x => x.Tag).ToList();
            var spellingGroups = matches
                .GroupBy(x => x.Spelling)
                .OrderBy(x => (x.Key, StringComparison.Ordinal))
                .ToList();
            var surahGroups = matches.GroupBy(x => x.Reference.Substring(0, x.Reference.IndexOf(':'))).ToList();

            var tagItems = new List<MatchedItems>();
            var spellItems = new List<MatchedItems>();
            var surahItems = new List<MatchedItems>();

            foreach (var item in tagGroups) {
                var parts = item.Key.Split('|');
                var header = string.Join(" | ", parts.Select(x => App.tags[Convert.ToInt32(x)]));
                tagItems.Add(new MatchedItems() {
                    Header = header,
                    Items = item.ToList()
                });
            }

            foreach (var item in spellingGroups) {
                string header = item.Key;
                spellItems.Add(new MatchedItems() {
                    Header = header,
                    Items = item.ToList()
                });
            }

            foreach (var item in surahGroups) {
                var header = App.surahs.First(x => x.Id == Convert.ToInt32(item.Key)).Transliteration;
                surahItems.Add(new MatchedItems() {
                    Header = header,
                    Items = item.ToList()
                });
            }

            string[] groupTexts;
            string[] groupIcons;
            string infoText;
            List<LemmaGroup> lemmaGroups = null;
            if (hasLemma) {
                groupIcons = new string[] { Icons.Seed, Icons.CopyArabic, Icons.List, Icons.Tag };
                groupTexts = new string[] { "Group by lemma", "Group by spelling", "Group by surah", "Group by tag" };
                lemmaGroups = matches.GroupBy(x => x.Lemma)
                        .Select(x => new LemmaGroup {
                            Lemma = x.Key,
                            Spelling = x.GroupBy(x => x.Spelling).ToList()
                        }).ToList();
                infoText = tagGroups.Count + " tag | " + lemmaGroups.Count + " lemma | " + spellingGroups.Count + " spelling | " + surahGroups.Count + " surah";
            }
            else {
                infoText = tagGroups.Count + " tag | " + spellingGroups.Count + " spelling | " + surahGroups.Count + " surah";
                groupIcons = new string[] { Icons.CopyArabic, Icons.List, Icons.Tag };
                groupTexts = new string[] { "Group by spelling", "Group by surah", "Group by tag" };
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    groupState.resetStates(groupIcons, groupTexts);

                    if (hasLemma) {
                        foreach (var lemma in lemmaGroups) {
                            var root = new TreeViewItem() {
                                HeaderTemplate = new MatchHeaderArabicTemplate()
                            };
                            lemmaTree.Items.Add(root);
                            if (lemma.Spelling.Count == 1) {
                                root.Header = new Tuple<string, string>(lemma.Lemma.toArabic(), lemma.Spelling[0].Count().ToString());
                                root.ItemTemplate = new MatchTemplate();
                                root.ItemsSource = lemma.Spelling[0];
                            }
                            else {
                                int total = 0;
                                int grandTotal = 0;
                                foreach (var spell in lemma.Spelling) {
                                    var items = spell.ToList();
                                    root.Items.Add(new TreeViewItem() {
                                        Header = new Tuple<string, string>(spell.Key, spell.Count().ToString()),
                                        HeaderTemplate = new MatchHeaderArabicTemplate(),
                                        ItemsSource = items,
                                        ItemTemplate = new MatchTemplate()
                                    });
                                    total++;
                                    grandTotal += items.Count;
                                }
                                root.Header = new Tuple<string, string>(lemma.Lemma.toArabic(), total + " | " + grandTotal);
                            }
                        }
                    }

                    foreach (var item in tagItems) {
                        tagTree.Items.Add(new TreeViewItem() {
                            Header = new Tuple<string, string>(item.Header, item.Items.Count.ToString()),
                            ItemsSource = item.Items,
                            HeaderTemplate = new MatchHeaderTemplate(),
                            ItemTemplate = new MatchTemplate()
                        });
                    }
                    foreach (var item in spellItems) {
                        spellingTree.Items.Add(new TreeViewItem() {
                            Header = new Tuple<string, string>(item.Header, item.Items.Count.ToString()),
                            ItemsSource = item.Items,
                            HeaderTemplate = new DataTemplate() {
                                VisualTree = new FrameworkElementFactory(typeof(SpellingGroupTemplate))
                            },
                            ItemTemplate = new MatchTemplate()
                        });
                    }
                    foreach (var item in surahItems) {
                        surahTree.Items.Add(new TreeViewItem() {
                            Header = new Tuple<string, string>(item.Header, item.Items.Count.ToString()),
                            ItemsSource = item.Items,
                            HeaderTemplate = new MatchHeaderTemplate(),
                            ItemTemplate = new MatchTemplate()
                        });
                    }
                    groupNoBlock.Text = infoText;
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    void initializeTrees() {
        tagTree = new TreeView() {
            FlowDirection = FlowDirection.LeftToRight,
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            // if you set HorizontalScrollBarVisibilityProperty here and disable the 
                            // tree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
                            // it will mess up when scrollbar appears and disappears
                            //new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()),
                        }
                    }
                }
            }
        };
        tagTree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        tagTree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true); // no default virtualization
        spellingTree = new TreeView() {
            Visibility = Visibility.Hidden,
            FlowDirection = FlowDirection.RightToLeft,
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = { new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()) }
                    }
                }
            }
        };
        spellingTree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        spellingTree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true); // no default virtualization
        surahTree = new TreeView() {
            Visibility = Visibility.Hidden,
            FlowDirection = FlowDirection.LeftToRight,
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = { new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()) }
                    }
                }
            }
        };
        surahTree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        surahTree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true); // no default virtualization
        lemmaTree = new TreeView() {
            Visibility = Visibility.Hidden,
            FlowDirection = FlowDirection.RightToLeft,
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = { new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()) }
                    }
                }
            }
        };
        lemmaTree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        lemmaTree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true); // no default virtualization
        Grid.SetRow(tagTree, 2);
        Grid.SetRow(spellingTree, 2);
        Grid.SetRow(surahTree, 2);
        Grid.SetRow(lemmaTree, 2);
    }

    Tuple<string, string> getSpelling(Link item) {
        int lIndex;
        if (item.LemmaSimple.EndsWith("|64")) {
            // in 8 cases it ends with maA
            lIndex = 0;
        }
        else lIndex = Convert.ToInt32(item.LemmaIndices);
        var tag = item.Tags.Split('|')[lIndex];
        string segment;
        if (App.global.Transcript == 0) {
            var spellIndex = Convert.ToInt32(item.SpellingGroupCorpus.Split('|')[lIndex]);
            segment = App.spellings[spellIndex];
        }
        else {
            var spellIndex = Convert.ToInt32(item.SpellingGroupSimple.Split('|')[lIndex]);
            segment = App.spellings[spellIndex];
        }
        return new Tuple<string, string>(tag, segment.toArabic());
    }

    string getLemma(Link item) {
        int lIndex;

        if (item.LemmaSimple.EndsWith("|64")) {
            // in 8 cases it ends with maA
            lIndex = App.global.Transcript == 0 ?
                Convert.ToInt32(item.LemmaCorpus.Split('|')[0]) :
                Convert.ToInt32(item.LemmaSimple.Split('|')[0]);

        }
        else lIndex = App.global.Transcript == 0 ?
                Convert.ToInt32(item.LemmaCorpus.Split('|')[0]) :
                Convert.ToInt32(item.LemmaSimple.Split('|')[0]);
        //Convert.ToInt32(item.LemmaIndices);
        //var lemmaIndex = Convert.ToInt32(item.LemmaIndices.Split('|')[lIndex]);

        return App.lemmas[Convert.ToInt32(lIndex)];

    }

    void onGroupStateChanged(object? sender, EventArgs e) {
        if(groupState.Texts.Length == 3) {
            if (groupState.State == 0) {
                surahTree.Visibility = Visibility.Hidden;
                tagTree.Visibility = Visibility.Visible;
            }
            else if (groupState.State == 1) {
                tagTree.Visibility = Visibility.Hidden;
                spellingTree.Visibility = Visibility.Visible;
            }
            else {
                spellingTree.Visibility = Visibility.Hidden;
                surahTree.Visibility = Visibility.Visible;
            }
        }
        else {
            if (groupState.State == 0) {
                surahTree.Visibility = Visibility.Hidden;
                tagTree.Visibility = Visibility.Visible;
            }
            else if (groupState.State == 1) {
                tagTree.Visibility = Visibility.Hidden;
                lemmaTree.Visibility = Visibility.Visible;
            }
            else if (groupState.State == 2) {
                lemmaTree.Visibility = Visibility.Hidden;
                spellingTree.Visibility = Visibility.Visible;
            }
            else {
                spellingTree.Visibility = Visibility.Hidden;
                surahTree.Visibility = Visibility.Visible;
            }
        }
    }

    void onDoubleLick(object sender, MouseButtonEventArgs e) {
        if (e.ChangedButton != MouseButton.Left) return;

        Match match;
        if(groupState.Texts.Length == 3) {
            if (groupState.State == 0) {
                if (tagTree.SelectedItem == null) return;
                if (tagTree.SelectedItem is not Match) return;
                match = (Match)tagTree.SelectedItem;
            }
            else if (groupState.State == 1) {
                if (spellingTree.SelectedItem == null) return;
                if (spellingTree.SelectedItem is not Match) return;
                match = (Match)spellingTree.SelectedItem;
            }
            else {
                if (surahTree.SelectedItem == null) return;
                if (surahTree.SelectedItem is not Match) return;
                match = (Match)surahTree.SelectedItem;
            }
        }
        else {
            if (groupState.State == 0) {
                if (tagTree.SelectedItem == null) return;
                if (tagTree.SelectedItem is not Match) return;
                match = (Match)tagTree.SelectedItem;
            }
            else if (groupState.State == 1) {
                if (lemmaTree.SelectedItem == null) return;
                if (lemmaTree.SelectedItem is not Match) return;
                match = (Match)lemmaTree.SelectedItem;
            }
            else if (groupState.State == 2) {
                if (spellingTree.SelectedItem == null) return;
                if (spellingTree.SelectedItem is not Match) return;
                match = (Match)spellingTree.SelectedItem;
            }
            else {
                if (surahTree.SelectedItem == null) return;
                if (surahTree.SelectedItem is not Match) return;
                match = (Match)surahTree.SelectedItem;
            }
        }
       
        ((App)Application.Current).Pages.addSurahPage(match.Reference);
    }

    protected override void unload() {
        tagTree.MouseDoubleClick -= onDoubleLick;
        spellingTree.MouseDoubleClick -= onDoubleLick;
        surahTree.MouseDoubleClick -= onDoubleLick;
        lemmaTree.MouseDoubleClick -= onDoubleLick;
        groupStateDescriptor.RemoveValueChanged(groupState, onGroupStateChanged);
        terminator.Cancel();
        terminator.Dispose();
        base.unload();
    }

    class LemmaGroup {
        public string Lemma { get; set; }
        public List<IGrouping<string, Match>> Spelling { get; set; }
    }
}
