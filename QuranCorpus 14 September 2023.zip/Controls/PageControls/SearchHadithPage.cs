﻿
class SearchHadithPage : Page {
    Grid content;
    List<HadithContent> source;
    ProgressBar progress;
    WaterBox arabicBox, englishBox;
    TextBlock count;
    TreeView tree;
    CancellationTokenSource terminator;

    public string query;
    public Toggle isEnglish, isContent;

    public override PageType Type => PageType.SearchHadith;
    public override UIElement Content => content;

    public SearchHadithPage() {
        HeaderText = "Hadith";
        source = new List<HadithContent>();
        terminator = new CancellationTokenSource();
        progress = new ProgressBar() {
            Margin = new Thickness(0, 0, 0, 2.5),
            Height = Constants.ProgressBarHeight
        };
        arabicBox = new WaterBox() {
            Hint = "Search (arabic)",
            Icon = Icons.Search,
            IsArabic = true,
            Visibility = Visibility.Collapsed
        };
        englishBox = new WaterBox() {
            VerticalAlignment = VerticalAlignment.Bottom,
            Hint = "Search (english)",
            Icon = Icons.Search
        };
        isEnglish = new Toggle() {
            Margin = new Thickness(7, 0, 0, 0),
            VerticalAlignment = VerticalAlignment.Bottom,
            OnIcon = Icons.CopyArabic,
            OffIcon = Icons.AB,
            OnTip = "input arabic",
            OffTip = "input english",
            Command = () => {
                if (isEnglish.IsOn) {
                    arabicBox.Visibility = Visibility.Collapsed;
                    englishBox.Visibility = Visibility.Visible;
                }
                else {
                    englishBox.Visibility = Visibility.Collapsed;
                    arabicBox.Visibility = Visibility.Visible;
                }
            }
        };
        isContent = new Toggle() {
            Margin = new Thickness(7, 0, 7, 0),
            VerticalAlignment = VerticalAlignment.Bottom,
            OnIcon = Icons.AccountGroup,
            OffIcon = Icons.WaveForm,
            OnTip = "search in sanad",
            OffTip = "search in matan"
        };
        count = new TextBlock() {
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(0, 0, 7, 0)
        };
        Grid.SetColumn(isEnglish, 1);
        Grid.SetColumn(isContent, 2);
        Grid.SetColumn(count, 3);
        var toolGrid = new Grid() {
            Margin = new Thickness(0, 0, 0, 10),
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { arabicBox, englishBox, isEnglish, isContent, count }
        };
        tree = new TreeView() {
            DataContext = this,
            FlowDirection = FlowDirection.LeftToRight,
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            // if you set HorizontalScrollBarVisibilityProperty here and disable the 
                            // tree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
                            // it will mess up when scrollbar appears and disappears
                            //new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()),
                        }
                    }
                }
            }
        };
        tree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        tree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true); // no default virtualization

        Grid.SetRow(toolGrid, 1);
        Grid.SetRow(tree, 2);
        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(),
            },
            Children = { progress, toolGrid, tree }
        };

        englishBox.KeyUp += onEnglishQuery;
        arabicBox.KeyUp += onArabicQuery;

        if (App.hadithChapters is null) {
            initializeHadithCollections();
        }

    }

    void onArabicQuery(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        if (string.IsNullOrEmpty(arabicBox.Text)) return;
        query = arabicBox.Text;
        progress.IsIndeterminate = true;
        bool isContent = this.isContent.IsOn;

        Task.Run(() => {
            source.Clear();
            var file = System.IO.File.ReadLines("Resources/Hadith/contents.txt");
            var iterator = file.GetEnumerator();
            iterator.MoveNext();

            if (isContent) {
                while (iterator.Current is not null) {
                    if (terminator.IsCancellationRequested) break;

                    var parts = iterator.Current.Split('\t');
                    var matan = parts[6];
                    if (matan.Contains(query)) addToSource(parts);
                    iterator.MoveNext();
                }
            }
            else {
                while (iterator.Current is not null) {
                    if (terminator.IsCancellationRequested) break;

                    var parts = iterator.Current.Split('\t');
                    var isnad = parts[4];
                    if (isnad.Contains(query)) addToSource(parts);
                    iterator.MoveNext();

                }
            }
            App.Current.Dispatcher.Invoke(() => {
                resetTree();
                progress.IsIndeterminate = false;
            });
        }, terminator.Token);
    }

    void onEnglishQuery(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        if (string.IsNullOrEmpty(englishBox.Text)) return;
        query = englishBox.Text.ToLower();
        progress.IsIndeterminate = true;
        bool isContent = this.isContent.IsOn;

        Task.Run(() => {
            source.Clear();
            var file = System.IO.File.ReadLines("Resources/Hadith/contents.txt");
            var iterator = file.GetEnumerator();
            iterator.MoveNext();

            if (isContent) {
                while (iterator.Current is not null) {
                    if (terminator.IsCancellationRequested) break;

                    var parts = iterator.Current.Split('\t');
                    var matan = parts[7];
                    if (matan.ToLower().Contains(query)) addToSource(parts);
                    iterator.MoveNext();
                }
            }
            else {
                while (iterator.Current is not null) {
                    if (terminator.IsCancellationRequested) break;

                    var parts = iterator.Current.Split('\t');
                    var isnad = parts[5];
                    if (isnad.ToLower().Contains(query)) addToSource(parts);
                    iterator.MoveNext();
                }
            }
           
            App.Current.Dispatcher.Invoke(() => {
                resetTree();
                progress.IsIndeterminate = false;
            });
        }, terminator.Token);
    }

    void resetTree() {
        tree.Items.Clear();
        int bookCount = 0;
        int matchCount = 0;
        var groups = source.GroupBy(x => x.BookId).ToList();
        for (int i = 0; i < groups.Count; i++) {
            var header = App.hadithBooks.First(x => x.Id == groups[i].Key).TitleEnglish;
            var items = groups[i].ToList();
            tree.Items.Add(new TreeViewItem() {
                Header = new Tuple<string, string>(header, items.Count.ToString("N0")),
                ItemsSource = items,
                HeaderTemplate = new HeaderTemplate(),
                ItemTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(HadithTemplate))
                }
            });
            bookCount++;
            matchCount += items.Count;
        }
        count.Text = matchCount.ToString("N0") + " hadith in " + bookCount + " book";
    }

    void addToSource(string[] parts) {
        source.Add(new HadithContent() {
            BookId = Convert.ToInt32(parts[0]),
            Number = parts[1],
            ChapterId = Convert.ToInt32(parts[2]),
            SectionId = Convert.ToInt32(parts[3]),
            ArabicIsnad = parts[4],
            EnglishIsnad = parts[5],
            ArabicMatan = parts[6],
            EnglishMatan = parts[7],
            ArabicGrade = parts[8],
            EnglishGrade = parts[9].Equals("nan") ? "" : parts[9],
            ArabicComment = parts[10].Equals("nan") ? "" : parts[10]
        });
    }

    void initializeHadithCollections() {
        App.hadithChapters =
             System.IO.File.ReadAllLines("Resources/Hadith/chapters.txt")
             .Skip(1)
             .Select(x => x.Split('\t'))
             .Select(x => new HadithChapter() {
                 Id = Convert.ToInt32(x[0]),
                 Chapter = Convert.ToInt32(x[1]),
                 Arabic = x[2],
                 English = x[3]
             }).ToList();

        App.hadithSections =
             System.IO.File.ReadAllLines("Resources/Hadith/sections.txt")
            .Skip(1)
            .Select(x => x.Split('\t'))
            .Select(x => new HadithSection() {
                Id = Convert.ToInt32(x[0]),
                Section = x[1],
                Arabic = x[2],
                English = x[3]
            }).ToList();
    }

    protected override void unload() {
        englishBox.KeyUp -= onEnglishQuery;
        arabicBox.KeyUp -= onArabicQuery;
        terminator.Cancel();
        terminator.Dispose();
        base.unload();
    }

    class HeaderTemplate : DataTemplate {
        public HeaderTemplate() {
            VisualTree = new FrameworkElementFactory(typeof(Header));
        }

        class Header : Grid {
            TextBlockEnglish header, count;
            public Header() {
                header = new TextBlockEnglish();
                count = new TextBlockEnglish();

                SetColumn(count, 1);
                ColumnDefinitions.Add(new ColumnDefinition());
                ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

                Children.Add(header);
                Children.Add(count);
            }
            public override void EndInit() {
                base.EndInit();
                var data = (Tuple<string, string>)DataContext;
                header.Text = data.Item1;
                count.Text = data.Item2;
            }
        }
    }

    class HadithTemplate : Border {
        RichArabic arIsnad, arMatan;
        RichEnglish enIsnad, enMatan;
        TextBoxArabic arGrade, arSection, comment;
        TextBoxEnglish enGrade, enSection;
        SolidColorBrush hiBrush;

        public HadithTemplate() {
            FlowDirection = FlowDirection.RightToLeft;
            Padding = new Thickness(0, 2.5, 0, 2.5);
            BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, Constants.BottomLineThickness);

            hiBrush = Brushes.Brown;
            arSection = new TextBoxArabic() { Foreground = Brushes.Wheat };
            arIsnad = new RichArabic() { Foreground = Brushes.Gray };
            arMatan = new RichArabic();
            arGrade = new TextBoxArabic() { Foreground = Brushes.LightSkyBlue };
            comment = new TextBoxArabic() { Foreground = Brushes.Gray };

            enSection = new TextBoxEnglish() { Foreground = Brushes.Wheat };
            enIsnad = new RichEnglish() { Foreground = Brushes.Gray };
            enMatan = new RichEnglish();
            enGrade = new TextBoxEnglish() { Foreground = Brushes.LightSkyBlue };

            Grid.SetColumn(enSection, 1);
            Grid.SetColumn(enIsnad, 1);
            Grid.SetColumn(enMatan, 1);
            Grid.SetColumn(enGrade, 1);

            Grid.SetRow(arIsnad, 1);
            Grid.SetRow(arMatan, 2);
            Grid.SetRow(arGrade, 3);
            Grid.SetRow(enIsnad, 1);
            Grid.SetRow(enMatan, 2);
            Grid.SetRow(enGrade, 3);
            Grid.SetRow(comment, 4);

            Grid.SetColumnSpan(comment, 2);

            Child = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){ Width = new GridLength(1.25, GridUnitType.Star) },
                    new ColumnDefinition()
                },
                RowDefinitions = {
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition(),
                    new RowDefinition() { Height = GridLength.Auto },
                    new RowDefinition() { Height = GridLength.Auto }
                },
                Children = { arSection, enSection, arIsnad, arMatan, arGrade, enIsnad, enMatan, enGrade, comment },
                Resources = {
                    { typeof(TextBoxArabic), new Style() {
                        Setters = {
                            new Setter(TextBoxArabic.ForegroundProperty, Brushes.LightGray),
                            new Setter(TextBoxArabic.TextWrappingProperty, TextWrapping.Wrap),
                            new Setter(TextBoxArabic.VerticalContentAlignmentProperty, VerticalAlignment.Center)
                        }
                    } },
                     { typeof(TextBoxEnglish), new Style() {
                        Setters = {
                            new Setter(TextBoxEnglish.ForegroundProperty, Brushes.LightGray),
                            new Setter(TextBoxEnglish.TextWrappingProperty, TextWrapping.Wrap),
                            new Setter(TextBoxEnglish.VerticalContentAlignmentProperty, VerticalAlignment.Center),
                            new Setter(TextBoxEnglish.FlowDirectionProperty, FlowDirection.LeftToRight)
                        }
                    } }
                }
            };
        }

        public override void EndInit() {
            base.EndInit();
            var c = (HadithContent)DataContext;
            var s = App.hadithSections.First(x => x.Id == c.SectionId);

            comment.Visibility = string.IsNullOrEmpty(c.ArabicComment) ? Visibility.Collapsed : Visibility.Visible;
            enSection.Visibility = s.English.Equals("nan") ? Visibility.Collapsed : Visibility.Visible;
            arSection.Visibility = s.Arabic.Equals("nan") ? Visibility.Collapsed : Visibility.Visible;

            arIsnad.Document.Blocks.Add(new Paragraph(new Run(c.ArabicIsnad)));
            arMatan.Document.Blocks.Add(new Paragraph(new Run(c.ArabicMatan)));
            arGrade.Text = c.ArabicGrade;

            enIsnad.Document.Blocks.Add(new Paragraph(new Run(c.EnglishIsnad)));
            enMatan.Document.Blocks.Add(new Paragraph(new Run(c.EnglishMatan)));
            enGrade.Text = c.EnglishGrade + "\nHadith no. " + c.Number + "\nChapter: " + App.hadithChapters.First(x => x.Id == c.ChapterId).Chapter;
            comment.Text = c.ArabicComment;

            enSection.Text = s.English;
            arSection.Text = s.Arabic;

            var context = (SearchHadithPage)Helper.FindParentOfType<TreeView>(this).DataContext;
            if (context.isEnglish.IsOn) 
                hilightMatch(context.query, context.isContent.IsOn ? enMatan.Document : enIsnad.Document);  
            else 
                hilightMatch(context.query, context.isContent.IsOn ? arMatan.Document : arIsnad.Document);
            
        }

        void hilightMatch(string query, FlowDocument doc) {
            var start = doc.ContentStart;
            while (start != null && start.CompareTo(doc.ContentEnd) < 0) {
                if (start.GetPointerContext(LogicalDirection.Forward) == TextPointerContext.Text) {
                    var index = start.GetTextInRun(LogicalDirection.Forward).IndexOf(query, StringComparison.OrdinalIgnoreCase);
                    if (index > 0) {
                        var range = new TextRange(start.GetPositionAtOffset(index, LogicalDirection.Forward), start.GetPositionAtOffset(index + query.Length, LogicalDirection.Backward));
                        range.ApplyPropertyValue(TextElement.BackgroundProperty, hiBrush);
                        start = range.End;
                    }
                }
                start = start.GetNextContextPosition(LogicalDirection.Forward);
            }
        }
    }

    class RichArabic : RichTextBox {
        ContextPopup context;

        public RichArabic() {
            ContextMenu = null;
            IsReadOnly = true;
            SelectionBrush = new SolidColorBrush(Color.FromArgb(150, 0, 0, 0));
            FlowDirection = FlowDirection.RightToLeft;

            SetBinding(FontSizeProperty, new Binding() {
                Path = new PropertyPath(nameof(Global.ArabicFontSize)),
                Source = App.global
            });
            SetBinding(FontFamilyProperty, new Binding() {
                Path = new PropertyPath(nameof(Global.ArabicFontFamily)),
                Source = App.global
            });
            context = new ContextPopup(new List<ContextItem>() {
                new ContextItem(){ Icon = Icons.Copy, Text = "copy", Command =  () => ApplicationCommands.Copy.Execute(null, null) }
            });
        }

        protected override void OnMouseRightButtonUp(MouseButtonEventArgs e) {
            base.OnMouseRightButtonUp(e);
            context.IsOpen = true;
        }
    }

    class RichEnglish : RichTextBox {
        ContextPopup context;
        public RichEnglish() {
            ContextMenu = null;
            IsReadOnly = true;
            SelectionBrush = new SolidColorBrush(Color.FromArgb(150, 0, 0, 0));
            FlowDirection = FlowDirection.LeftToRight;
            SetBinding(FontSizeProperty, new Binding() {
                Path = new PropertyPath(nameof(Global.EnglishFontSize)),
                Source = App.global
            });
            context = new ContextPopup(new List<ContextItem>() {
                new ContextItem(){ Icon = Icons.Copy, Text = "copy", Command =  () => ApplicationCommands.Copy.Execute(null, null) }
            });
        }

        protected override void OnMouseRightButtonUp(MouseButtonEventArgs e) {
            base.OnMouseRightButtonUp(e);
            context.IsOpen = true;
        }
    }
}
