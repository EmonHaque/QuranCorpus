﻿class SistersView : View {
    public override string Icon => Icons.Sisters;
    public override bool OverridesToolTip => true;
    public override UIElement Tip => getTip();
    public override FrameworkElement container => grid;

    Grid grid;

    public SistersView() {
        grid = new Grid() { 
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(),
                new RowDefinition()
            }
        };
        AddVisualChild(grid);
    }

    public override void OnFirstSight() {
        base.OnFirstSight();
        var inna = new Inna();
        var kada = new Kada();
        var kana = new Kana();

        Grid.SetRow(kada, 1);
        Grid.SetRow(kana, 2);
        grid.Children.Add(inna);
        grid.Children.Add(kana);
        grid.Children.Add(kada);

        inna.OnFirstSight();
        kana.OnFirstSight();
        kada.OnFirstSight();
    }

    Grid getTip() {
        var header = new TextBlockEnglish() {
            Text = "Sisters'",
            FontWeight = FontWeights.Bold
        };
        var separator = new Rectangle() {
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var description = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Text = "See inna, kana, kada and their sisters."
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(description, 2);
        return new Grid() {
            MaxWidth = 200,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(10) },
                new RowDefinition()
            },
            Children = { header, separator, description }
        };
    }
}
