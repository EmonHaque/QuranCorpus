﻿class Toggle : ActionButton {
    bool isLoaded;
    public string OnIcon { get; set; }
    public string OffIcon { get; set; }
    public string OnTip { get; set; }
    public string OffTip { get; set; }

    public Toggle() {
        Loaded += onLoaded;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        if (isLoaded) return;
        Icon = OnIcon;
        ToolTip = OnTip;
        isLoaded = true;
    }

    protected override void OnPreviewMouseLeftButtonUp(MouseButtonEventArgs e) {
        base.OnPreviewMouseLeftButtonUp(e);
        if (IsOn) {
            Icon = OffIcon;
            ToolTip = OffTip;
            IsOn = false;
        }
        else {
            Icon = OnIcon;
            ToolTip = OnTip;
            IsOn = true;
        }
    }

    public bool IsOn {
        get { return (bool)GetValue(IsOnProperty); }
        set { SetValue(IsOnProperty, value); }
    }

    public static readonly DependencyProperty IsOnProperty =
        DependencyProperty.Register("IsOn", typeof(bool), typeof(Toggle), new PropertyMetadata(true));
}
