﻿class DragDropListBox : ListBox {
    Point dragStart;
    bool isBeingDragged;
    Popup dragPop;
    TextBlock dragBlock;
    DragDropListItem dragSource, dropTarget;
    double offset;

    public Action<object, IList, bool> DropAction { get; set; }

    public DragDropListBox() {
        AllowDrop = true;
        SelectionMode = SelectionMode.Extended;
        dragBlock = new TextBlock() { Foreground = Brushes.LightGray };
        dragPop = new Popup() {
            AllowsTransparency = true,
            Child = new Border() {
                Background = Brushes.Black,
                BorderBrush = Brushes.LightGray,
                BorderThickness = new Thickness(0.5),
                CornerRadius = new CornerRadius(5),
                Padding = new Thickness(5),
                Child = dragBlock
            }
        };
    }

    protected override void OnPreviewMouseDown(MouseButtonEventArgs e) {
        base.OnMouseDown(e);
        if (Keyboard.IsKeyDown(Key.LeftCtrl)) return;
        isBeingDragged = false;
        dragStart = e.GetPosition(null);
    }

    protected override void OnMouseMove(MouseEventArgs e) {
        base.OnMouseMove(e);
        if (e.LeftButton != MouseButtonState.Pressed) return;

        var source = (FrameworkElement)e.Source;
        var hitItem = source.InputHitTest(e.GetPosition(source)) as FrameworkElement;
        if (hitItem is null) return;

        dragSource = Helper.FindParentOfType<DragDropListItem>(hitItem);
        if (dragSource is null) return;
        
        if (!isBeingDragged && CanBeDragged(e)) {
            var ayah = SelectedItems.Count == 1 ? " ayah" : " ayahs";
            isBeingDragged = true;
            dragBlock.Text = "Moving " + SelectedItems.Count + ayah;
            dragPop.IsOpen = true;

            offset = 5;

            var dragData = new DataObject(typeof(IList), SelectedItems);
            dragData.SetData("source", this);
            DragDrop.AddQueryContinueDragHandler(this, onDragQuery);
            DragDrop.DoDragDrop(this, dragData, DragDropEffects.Move);
        }
    }

    protected override void OnDragOver(DragEventArgs e) {
        base.OnDragOver(e);
        var sv = Helper.FindVisualChild<ScrollViewer>(this);

        double tolerance = 10;
        double verticalPos = e.GetPosition(this).Y;

        if (offset < 30) offset += 5;

        // Top of visible list?
        if (verticalPos < tolerance) {
            sv.ScrollToVerticalOffset(sv.VerticalOffset - offset); //Scroll up.
        }
        //Bottom of visible list?
        else if (verticalPos > ActualHeight - tolerance) {
            sv.ScrollToVerticalOffset(sv.VerticalOffset + offset); //Scroll down.    
        }

        bool canBeDropped = true;
        var source = e.Data.GetData("source");
        if (source is not DragDropListBox) canBeDropped = false;

        var dataObj = e.Data as DataObject;
        var dragged = dataObj.GetData(typeof(IList)) as IList;

        if (dragged is null) canBeDropped = false;
        else {
            dropTarget = e.OriginalSource is Run? 
                Helper.FindParentOfType<DragDropListItem>(((Run)e.OriginalSource).Parent) :
                Helper.FindParentOfType<DragDropListItem>((DependencyObject)e.OriginalSource);

            if (dropTarget is null) canBeDropped = false;
            else {
                foreach (var item in dragged) {
                    if (item.Equals(dropTarget.DataContext)) {
                        canBeDropped = false;
                        break;
                    }
                }
            }
        }
        if(canBeDropped) e.Effects = DragDropEffects.Scroll;
        else {
            e.Effects = DragDropEffects.None;
            e.Handled = true;
        }
    }

    protected override void OnDrop(DragEventArgs e) {
        base.OnDrop(e);
        e.Handled = true;
        var dataObj = e.Data as DataObject;
        var dragged = dataObj.GetData(typeof(IList)) as IList;
        if (dragged is null) return;

        var pos = e.GetPosition(dropTarget);
        var mid = dropTarget.ActualHeight / 2;

        DropAction?.Invoke(dropTarget.DataContext, dragged, pos.Y < mid);
    }

    protected override DependencyObject GetContainerForItemOverride() {
        return new DragDropListItem();
    }

    void onDragQuery(object sender, QueryContinueDragEventArgs e) {
        var drag = Helper.GetMousePosition();
        dragPop.PlacementRectangle = new Rect(drag, drag);
        if (e.Action == DragAction.Continue && e.KeyStates != DragDropKeyStates.LeftMouseButton) {
            dragPop.IsOpen = false;
            DragDrop.RemoveQueryContinueDragHandler(this, onDragQuery);
        }
    }

    bool CanBeDragged(MouseEventArgs e) {
        if (dragSource == null) return false;
        var pos = e.GetPosition(null);
        return
            Math.Abs(pos.Y - dragStart.Y) > SystemParameters.MinimumVerticalDragDistance ||
            Math.Abs(pos.X - dragStart.X) > SystemParameters.MinimumHorizontalDragDistance;
    }

    // https://github.com/daszat/MultiSelectionDragger
    class DragDropListItem : ListBoxItem {
        private bool _deferSelection = false;

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e) {
            if (e.ClickCount == 1 && IsSelected) {
                // the user may start a drag by clicking into selected items
                // delay destroying the selection to the Up event
                _deferSelection = true;
            }
            else {
                base.OnMouseLeftButtonDown(e);
            }
        }

        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
            if (_deferSelection) {
                try {
                    base.OnMouseLeftButtonDown(e);
                }
                finally {
                    _deferSelection = false;
                }
            }
            base.OnMouseLeftButtonUp(e);
        }

        protected override void OnMouseLeave(MouseEventArgs e) {
            // abort deferred Down
            _deferSelection = false;
            base.OnMouseLeave(e);
        }
    }
}
