﻿
class SegmentPage : Page {
    public override PageType Type => PageType.Segment;
    public override UIElement Content => content;

    const string plus = "  +  ";
    Thickness boxMargin = new Thickness(0, 10, 0, 0);

    Grid content;
    TextBlockArabic word1Block, word2Block;
    TextBlockEnglish word1MorphBlock, word2MorphBlock;
    ListBox word1List, word2List;

    public SegmentPage() {
        word1Block = new TextBlockArabic() { HorizontalAlignment = HorizontalAlignment.Center };
        word2Block = new TextBlockArabic() { HorizontalAlignment = HorizontalAlignment.Center };
        word1MorphBlock = new TextBlockEnglish() { TextWrapping = TextWrapping.Wrap };
        word2MorphBlock = new TextBlockEnglish() { TextWrapping = TextWrapping.Wrap };

        var template = new DataTemplate() {
            VisualTree = new FrameworkElementFactory(typeof(SegmentDetailTemplate))
        };

        word1List = new ListBox() {
            ItemTemplate = template,
            Margin = boxMargin
        };
        word2List = new ListBox() {
            ItemTemplate = template,
            Margin = boxMargin
        };

        var separator = new Rectangle() {
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };

        Grid.SetRow(word1MorphBlock, 1);
        Grid.SetRow(word2MorphBlock, 1);
        Grid.SetRow(word1List, 2);
        Grid.SetRow(word2List, 2);

        Grid.SetColumn(separator, 1);
        Grid.SetRowSpan(separator, 3);
        Grid.SetColumn(word2Block, 2);
        Grid.SetColumn(word2MorphBlock, 2);
        Grid.SetColumn(word2List, 2);

        content = new Grid() {
            FlowDirection = FlowDirection.LeftToRight,
            RowDefinitions = {
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition(),
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(10) },
                new ColumnDefinition()
            },
            Children = { separator, word1Block, word2Block, word1MorphBlock, word2MorphBlock, word1List, word2List }
        };

        word1List.MouseDoubleClick += onDoubleClick;
        word2List.MouseDoubleClick += onDoubleClick;
    }

    public SegmentPage(Segment segment) : this() => populateUI(segment);

    public void setContent(Segment segment) {
        word1Block.Inlines.Clear();
        word2Block.Inlines.Clear();
        populateUI(segment);
    }

    void populateUI(Segment segment) {
        var split = segment.Segments[0].Split('|');
        HeaderText = string.Join("", split.Select(x => App.segments[Convert.ToInt32(x)].toArabic()));

        split = segment.Spellings[0].Split('|');
        foreach (var item in split) {
            word1Block.Inlines.Add(new Run(App.spellings[Convert.ToInt32(item)].toArabic()));
            word1Block.Inlines.Add(new Run(plus));
        }
        word1Block.Inlines.Remove(word1Block.Inlines.Last());

        var tags = segment.Tags[0].Split('|');
        var details = segment.Details[0].Split(',');
        var morphs = segment.References[0].First().Explanation.Split('|');

        StringBuilder builder = new();
        buildString(builder, tags, details, morphs);
        word1MorphBlock.Text = builder.ToString();

        split = segment.Spellings[1].Split('|');
        foreach (var item in split) {
            word2Block.Inlines.Add(new Run(App.spellings[Convert.ToInt32(item)].toArabic()));
            word2Block.Inlines.Add(new Run(plus));
        }
        word2Block.Inlines.Remove(word2Block.Inlines.Last());

        tags = segment.Tags[1].Split('|');
        details = segment.Details[1].Split(',');
        morphs = segment.References[1].First().Explanation.Split('|');

        builder.Clear();
        buildString(builder, tags, details, morphs);
        word2MorphBlock.Text = builder.ToString();

        word1List.ItemsSource = segment.References[0];
        word2List.ItemsSource = segment.References[1];
    }

    void buildString(StringBuilder builder, string[] tags, string[] details, string[] morphs) {
        if (tags.Length > 1) {
            builder
                .Append("is divided into ")
                .Append(tags.Length)
                .Append(" segments. ");
            for (int i = 0; i < tags.Length; i++) {
                var tag = App.tags[Convert.ToInt32(tags[i])];
                var tagName = Helper.getTagName(tag, details[i]);
                if (i == 0) {
                    builder.Append(
                        (tagName.StartsWith('a') || tagName.StartsWith('e') || tagName.StartsWith('i')) ?
                        "An " : "A ");
                }
                else if (i == tags.Length - 1) builder.Append(" and ");
                else builder.Append(", ");
                builder.Append(tagName);
            }
            builder.Append(".");
        }
        for (int i = 0; i < morphs.Length; i++) {
            if (string.IsNullOrEmpty(morphs[i])) continue;
            builder
                .Append(' ')
                .Append(App.explanations[Convert.ToInt32(morphs[i])])
                .Append('.');
        }
    }

    void onDoubleClick(object sender, MouseButtonEventArgs e) {
        if (e.ChangedButton != MouseButton.Left) return;
        var item = ((ListBox)sender).SelectedItem as Link;
        if (item is null) return;
        ((App)Application.Current).Pages.addSurahPage(item.Reference);
    }

    protected override void unload() {
        word1List.MouseDoubleClick -= onDoubleClick;
        word2List.MouseDoubleClick -= onDoubleClick;
        base.unload();
    }
}
