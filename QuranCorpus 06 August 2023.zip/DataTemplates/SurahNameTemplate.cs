﻿class SurahName : Grid {
    Run arabic, english, arabicNo, englishNo;
    DependencyPropertyDescriptor fontDescriptor;

    public SurahName() {
        arabic = new Run();
        english = new Run();
        arabicNo = new Run();
        englishNo = new Run();

        var arabicBlock = new TextBlockArabic() {
            FlowDirection = FlowDirection.RightToLeft,
            Inlines = { arabicNo, arabic }
        };
        var englishBlock = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            Inlines = { englishNo, new Run(") "), english }
        };

        SetRow(englishBlock, 1);
        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition());
        Children.Add(arabicBlock);
        Children.Add(englishBlock);

        Loaded += onLoaded;
        Unloaded += onUnloaded;
        fontDescriptor = DependencyPropertyDescriptor.FromProperty(Run.FontFamilyProperty, typeof(Run));
    }

    public override void EndInit() {
        base.EndInit();
        var name = (Surah)DataContext;
        var id = name.Id.ToString();
        arabicNo.Text = id.toArabicNo();
        arabic.Text = " " + name.Arabic;
        englishNo.Text = id;
        english.Text = name.Transliteration;

        if (!(App.global.ArabicFont.Equals("KFGQPC Uthmanic HAFS") ||
                App.global.ArabicFont.Equals("me quran"))) {
            arabicNo.Text += ')';
        }
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        fontDescriptor.AddValueChanged(arabicNo, onFontChanged);
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        fontDescriptor.RemoveValueChanged(arabicNo, onFontChanged);
    }

    void onFontChanged(object? sender, EventArgs e) {
        if (App.global.ArabicFont.Equals("KFGQPC Uthmanic HAFS") ||
            App.global.ArabicFont.Equals("me quran")) {
            if (arabicNo.Text.EndsWith(')')) {
                arabicNo.Text = arabicNo.Text.Remove(arabicNo.Text.Length - 1);
            }
        }
        else {
            if (!arabicNo.Text.EndsWith(')')) {
                arabicNo.Text += ')';
            }
        }
    }
}
class SurahNameTemplate : DataTemplate {
    public SurahNameTemplate() {
        VisualTree = new FrameworkElementFactory(typeof(SurahName));
    }
}
