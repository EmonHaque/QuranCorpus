﻿class LemmaView : CardView {
    public override string Icon => Icons.Seed;
    EditText query;
    TextBlockEnglish countBlock;
    TreeView tree;
    ProgressBar progress;
    MultiState scriptState;
    PageControl pages;
    LemmaVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new LemmaVM();
        DataContext = vm;
        pages = ((App)Application.Current).Pages;
        initializeUI();
        bind();

        tree.SelectedItemChanged += onSelectionChange;
        tree.MouseRightButtonUp += onRightButtonUp;
        tree.PreviewMouseRightButtonDown += OnPreviewMouseRightButtonDown;
    }

    void onSelectionChange(object sender, RoutedPropertyChangedEventArgs<object> e) {
        vm.Selected = e.NewValue;
    }

    void initializeUI() {
        query = new EditText() {
            Icon = Icons.Search,
            Hint = "TAG",
            IsTrimBottomRequested = true
        };
        scriptState = new MultiState() {
            Icons = new string[] { Icons.CopyArabic, Icons.List },
            Texts = new string[] { "Corpus script", "Simple script" },
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(10, 0, 0, 0)
        };
        progress = new ProgressBar() {
            Height = 1.5,
            FlowDirection = FlowDirection.RightToLeft
        };
        countBlock = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            TextAlignment = TextAlignment.Right
        };
        tree = new TreeView() {
            FlowDirection = FlowDirection.RightToLeft,
            ItemTemplate = new LemmaTemplate()
        };
        tree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        tree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true);

        Grid.SetRow(progress, 1);
        Grid.SetRow(scriptState, 2);
        Grid.SetRow(countBlock, 3);
        Grid.SetRow(tree, 4);

        var content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { query, progress, scriptState, countBlock, tree }
        };
        setContent(content);
    }

    void bind() {
        query.SetBinding(EditText.TextProperty, new Binding(nameof(vm.Query)) {
            Mode = BindingMode.OneWayToSource,
            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
        });
        scriptState.SetBinding(MultiState.StateProperty, new Binding(nameof(vm.ScriptState)));
        progress.SetBinding(ProgressBar.IsIndeterminateProperty, new Binding(nameof(vm.IsInProgress)));
        countBlock.SetBinding(TextBlockEnglish.TextProperty, new Binding(nameof(vm.Count)));
        tree.SetBinding(TreeView.ItemsSourceProperty, new Binding(nameof(vm.Lemmas)));
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) {
        if (vm.Selected is null) return;
        pages.addLemmaPage((Lemma)vm.Selected);
    }

    void OnPreviewMouseRightButtonDown(object sender, MouseButtonEventArgs e) {
        var item = VisualUpwardSearch(e.OriginalSource as DependencyObject);
        if (item is null) return;
        if (item.Items.Count > 0) {
            vm.Selected = null;
            return;
        }
        vm.WasRightClicked = true;
        item.Focus();
        item.IsSelected = true;
        e.Handled = true;
    }

    TreeViewItem VisualUpwardSearch(DependencyObject source) {
        while (source != null && !(source is TreeViewItem))
            source = VisualTreeHelper.GetParent(source);

        return source as TreeViewItem;
    }
}
