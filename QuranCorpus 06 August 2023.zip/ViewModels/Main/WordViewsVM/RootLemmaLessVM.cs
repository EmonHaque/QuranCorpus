﻿class RootLemmaLessVM : Notifiable {
    RootLemmaFree selected;
    public RootLemmaFree Selected {
        get { return selected; }
        set {
            if (value is null) return;
            if (!value.Equals(selected)) {
                selected = value;
            }
            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).Pages.SelectedPage is LemmaLessPage page) {
                page.setContent(value);
            }
        }
    }
    int scriptState;
    public int ScriptState {
        get { return scriptState; }
        set { scriptState = value; regroup(); }
    }

    public bool WasRightClicked { get; set; }
    public string Count { get; set; }
    public ObservableCollection<RootLemmaFree> Items { get; set; }

    public RootLemmaLessVM() {
        Items = new ObservableCollection<RootLemmaFree>();
        
        Task.Run(() => {
            var newList = new List<Link>();
            StringBuilder builder = new();
            
            foreach (var item in App.links) {
                if (!string.IsNullOrEmpty(item.LemmaCorpus)) continue;

                item.SegmentsCorpus.Split('|').toArabic(builder);
                var first = builder.ToString();
                builder.Clear();
                newList.Add(new Link() {
                    LemmaCorpus = first,
                    Reference = item.Reference
                });
            }

            var groups = newList
               .GroupBy(x => x.LemmaCorpus)
               .ToList();

            App.Current.Dispatcher.Invoke(() => {
                foreach (var item in groups) {
                    Items.Add(new RootLemmaFree() {
                        Content = item.Key,
                        References = item.Select(x => x.Reference).ToList(),
                        Count = item.Count()
                    });
                }
                Count = groups.Count.ToString("N0");
                OnPropertyChanged(nameof(Count));
            });
        });
    }

    void regroup() {
        var newList = new List<Link>();
        IEnumerable<IGrouping<string, Link>> groups;
        StringBuilder builder = new();
        if(ScriptState == 0) {
            foreach (var item in App.links) {
                if (!string.IsNullOrEmpty(item.LemmaCorpus)) continue;

                item.SegmentsCorpus.Split('|').toArabic(builder);
                var first = builder.ToString();
                builder.Clear();
                newList.Add(new Link() {
                    LemmaCorpus = first,
                    Reference = item.Reference
                });
            }
            groups = newList.GroupBy(x => x.LemmaCorpus);
        }
        else {
            foreach (var item in App.links) {
                if (!string.IsNullOrEmpty(item.LemmaSimple)) continue;

                item.SegmentsSimple.Split('|').toArabic(builder);
                var first = builder.ToString();
                builder.Clear();
                newList.Add(new Link() {
                    LemmaSimple = first,
                    Reference = item.Reference
                });
            }
            groups = newList.GroupBy(x => x.LemmaSimple);
        }

        App.Current.Dispatcher.Invoke(() => {
            int count = 0;
            Items.Clear();
            foreach (var item in groups) {
                count++;
                Items.Add(new RootLemmaFree() {
                    Content = item.Key,
                    References = item.Select(x => x.Reference).ToList(),
                    Count = item.Count()
                });
            }
            Count = count.ToString("N0");
            OnPropertyChanged(nameof(Count));
        });
    }
}
