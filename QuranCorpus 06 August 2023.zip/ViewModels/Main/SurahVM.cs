﻿class SurahVM : Notifiable {
    Surah selectedSurah;
    public Surah SelectedSurah {
        get { return selectedSurah; }
        set {
            if (value is null) return;
            if (!value.Equals(selectedSurah)) {
                selectedSurah = value;
            }
            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).Pages.SelectedPage is SurahPage page) {
                page.setContent(value.Id);
            }
        }
    }

    string query;
    public string Query {
        get { return query; }
        set { query = value; Surahs.Refresh(); }
    }

    public bool WasRightClicked { get; set; }
    public ICollectionView Surahs { get; set; }

    public SurahVM() {
        Surahs = CollectionViewSource.GetDefaultView(App.surahs);
        Surahs.Filter = filter;
    }

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((Surah)o).Transliteration.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }
}
