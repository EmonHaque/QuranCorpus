﻿class ErabWordPrimary {
    public string Reference { get; set; }
    public string Word { get; set; }
    public string Spelling { get; set; }
    public string Simple { get; set; }
    public string Tag { get; set; }
    public string Gender { get; set; }
    public string Erab { get; set; }
    public string Detail { get; set; }
    public string Root { get; set; }
    public string SubTag { get; set; }
    public string Form { get; set; }
    public bool HasDet { get; set; }
    public string Explanation { get; set; }
}
