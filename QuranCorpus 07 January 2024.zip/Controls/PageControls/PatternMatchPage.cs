﻿class PatternMatchPage : Page {
    Grid content;
    StringBuilder builder = new();

    string query;
    Run morphCount, morphTotal;
    TextBlockEnglish listCount, meaningCount;
    WaterBox queryBox;
    List<Morph> morphs;
    ContentListBox list, morphList;
    ListBox listMeaning;
    ICollectionView wordView;
    
    public override PageType Type => PageType.PatternMatch;
    public override UIElement Content => content;

    public PatternMatchPage() {
        queryBox = new WaterBox() {
            Icon = Icons.Search,
            Hint = "Root (buckwalter)"
        };
        var buckwalterPop = new BuckwalterPopup() {
            Margin = new Thickness(5, 0, 5, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        listCount = new TextBlockEnglish() { 
            HorizontalAlignment = HorizontalAlignment.Right ,
            VerticalAlignment = VerticalAlignment.Center,
        };
        Grid.SetColumn(buckwalterPop, 1);
        Grid.SetColumn(listCount, 2);
        var queryGrid = new Grid() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0,0,0,5),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { queryBox, buckwalterPop, listCount }
        };

        list = new ContentListBox() {
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(SpellingTemplate))
            }
        };

        listCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = list,
            StringFormat = "N0"
        });

        var rightGrid = getRightGrid();
        Grid.SetRow(list, 1);
        Grid.SetColumn(rightGrid, 1);
        Grid.SetRowSpan(rightGrid, 2);

        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(1.75, GridUnitType.Star)}
            },
            Children = { queryGrid, list, rightGrid }
        };

        list.Fired += onListFired;
        morphList.Fired += onMorphFired;
        listMeaning.MouseDoubleClick += onMeaningDoubleClick;
        queryBox.KeyUp += onQuery;
    }

    Grid getRightGrid() {
        morphCount = new Run();
        morphTotal = new Run();
        var morphCountBlock = new TextBlockEnglish() {
            IsHitTestVisible = false,
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center,
            Inlines = { morphTotal, new Run(" in "), morphCount }
        };
        meaningCount = new TextBlockEnglish() {
            IsHitTestVisible = false,
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Right,
        };

        morphList = new ContentListBox() {
            Margin = new Thickness(0, 5, 0, 0),
            FlowDirection = FlowDirection.RightToLeft,
            Template = new ListBoxLedgerTemplate(),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MorphListTemplate))
            }
        };
        var separatorHorizontal = new Rectangle() {
            VerticalAlignment = VerticalAlignment.Bottom,
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };

        var separatorVertical = new Rectangle() {
            Margin = new Thickness(5, 0, 5, 0),
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        var splitter = new GridSplitter() {
            ResizeDirection = GridResizeDirection.Rows,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Template = new SplitterTemplate()
        };

        morphList.SetValue(Grid.IsSharedSizeScopeProperty, true);
        morphList.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

        listMeaning = new ListBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 0, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MeaningListTemplate))
            }
        };
        listMeaning.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMeaning.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

        Grid.SetRow(morphList, 1);
        Grid.SetRow(meaningCount, 2);
        Grid.SetRow(separatorHorizontal, 2);
        Grid.SetRow(splitter, 2);
        Grid.SetRow(listMeaning, 3);

        Grid.SetColumn(morphCountBlock, 1);
        Grid.SetColumn(morphList, 1);
        Grid.SetColumn(meaningCount, 1);
        Grid.SetColumn(separatorHorizontal, 1);
        Grid.SetColumn(splitter, 1);
        Grid.SetColumn(listMeaning, 1);

        Grid.SetRowSpan(separatorVertical, 4);

        morphCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = morphList,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        meaningCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMeaning,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });

        return new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition()
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(2, GridUnitType.Star) },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { morphCountBlock, morphList, separatorHorizontal, splitter, meaningCount, listMeaning, separatorVertical }
        };
    }

    public PatternMatchPage(string pattern, List<PatternReference> references) : this() {
        HeaderText = pattern;
        wordView = CollectionViewSource.GetDefaultView(references.OrderBy(x => x.Root));
        wordView.Filter = filter;
        list.ItemsSource = wordView;
    }

    void onListFired(object item) {
        var selected = (PatternReference)item;
        int index = 0;
        morphs = new List<Morph>();
        for (int i = 0; i < selected.References.Count; i++) {
            while (!App.links[index].Reference.Equals(selected.References[i])) index++;
            morphs.Add(App.links[index].toMorph(builder));
        }
        var listSource = morphs
            .GroupBy(x => new { Word = x.Segments[App.global.Transcript], x.Explanation })
              .Select(x => new Morph() {
                  Segments = x.First().Segments,
                  Count = x.Count(),
                  Tags = x.First().Tags,
                  Explanation = x.Key.Explanation,
                  References = x.SelectMany(x => x.References).ToList()
              })
              .OrderByDescending(x => x.Count)
              .ToList();
        morphTotal.Text = listSource.Sum(x => x.Count).ToString();
        morphList.ItemsSource = listSource;
        morphList.ScrollIntoView(listSource[0]);
    }

    void onMorphFired(object item) {
        var meaningSource = ((Morph)item).References;
        listMeaning.ItemsSource = meaningSource;
        listMeaning.ScrollIntoView(meaningSource[0]);
    }

    void onMeaningDoubleClick(object sender, MouseButtonEventArgs e) {
        if (listMeaning.SelectedItem is null) return; // can be null?
        var item = (Tuple<string, string, string>)listMeaning.SelectedItem;
        ((App)Application.Current).FocusedControl.addSurahPage(item.Item1);
    }

    void onQuery(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        query = queryBox.Text.Trim();
        wordView.Refresh();
    }

    bool filter(object o) {
        return (string.IsNullOrEmpty(query)) ?
            true :
            ((PatternReference)o).Root.Contains(query);
    }

    protected override void unload() {
        base.unload();
        list.Fired -= onListFired;
        morphList.Fired -= onMorphFired;
        listMeaning.MouseDoubleClick -= onMeaningDoubleClick;
        queryBox.KeyUp -= onQuery;
    }

    class SpellingTemplate : Grid {
        TextBlockArabic spelling, root;
        TextBlockEnglish tags, count;

        public SpellingTemplate() {
            spelling = new TextBlockArabic();
            root = new TextBlockArabic() { Foreground = Brushes.Gray };
            tags = new TextBlockEnglish() {
                Margin = new Thickness(0,0,10,0),
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Center
            };
            count = new TextBlockEnglish() {
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Center
            };

            SetColumn(root, 1);
            SetColumn(tags, 2);
            SetColumn(count, 3);

            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(40) });

            Children.Add(spelling);
            Children.Add(root);
            Children.Add(tags);
            Children.Add(count);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (PatternReference)DataContext;
            spelling.Text = c.Spelling.toArabic();
            root.Text = c.Root.toArabic();
            tags.Text = string.Join(", ", c.Tags);
            count.Text = c.References.Count.ToString("N0");
        }
    }
}
