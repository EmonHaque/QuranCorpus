﻿class ContentTreeView : TreeView {
    object current;
    public event Action<object> Fired;

    protected override void OnKeyUp(KeyEventArgs e) {
        base.OnKeyUp(e);
        if (e.Key != Key.Enter) return;
        fire();
    }
    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
        base.OnMouseLeftButtonUp(e);
        fire();
    }

    void fire() {
        if (SelectedItem is null) return;
        if (current is not null && current.Equals(SelectedItem)) return;
        current = SelectedItem;
        Fired?.Invoke(current);
    }

    public void RaiseFireEvent() {
        ((TreeViewItem)Items.GetItemAt(0)).IsSelected = true;
        Helper.FindVisualChild<ScrollViewer>(this)?.ScrollToTop();
        fire();
    }
}
