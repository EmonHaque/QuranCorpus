﻿class DragListBox : ListBox {
    Point dragStart;
    bool isBeingDragged;
    Popup dragPop;
    TextBlock dragBlock;
    DragListItem dragSource;

    public DragListBox() {
        SelectionMode = SelectionMode.Extended;
        dragBlock = new TextBlock() { Foreground = Constants.Foreground };
        dragPop = new Popup() {
            AllowsTransparency = true,
            Child = new Border() {
                Background = Brushes.Black,
                BorderBrush = Brushes.LightGray,
                BorderThickness = new Thickness(0.5),
                CornerRadius = new CornerRadius(5),
                Padding = new Thickness(5),
                Child = dragBlock
            }
        };
    }

    protected override void OnPreviewMouseDown(MouseButtonEventArgs e) {
        base.OnMouseDown(e);
        isBeingDragged = false;
        dragStart = e.GetPosition(null);
    }

    protected override void OnMouseMove(MouseEventArgs e) {
        base.OnMouseMove(e);
        if (e.LeftButton != MouseButtonState.Pressed) return;

        var source = (FrameworkElement)e.Source;
        var hitItem = source.InputHitTest(e.GetPosition(source)) as FrameworkElement;
        if (hitItem is null) return;

        dragSource = Helper.FindParentOfType<DragListItem>(hitItem);
        if (dragSource is null) return;

        if (!isBeingDragged && CanBeDragged(e)) {
            var ayah = SelectedItems.Count == 1 ? " ayah" : " ayahs";
            isBeingDragged = true;
            dragBlock.Text = "Moving " + SelectedItems.Count + ayah;
            dragPop.IsOpen = true;

            var dragData = new DataObject(typeof(IList), SelectedItems);
            dragData.SetData("source", this);
            DragDrop.AddQueryContinueDragHandler(this, onDragQuery);
            DragDrop.DoDragDrop(this, dragData, DragDropEffects.Move);
        }
    }
    
    protected override DependencyObject GetContainerForItemOverride() {
        return new DragListItem();
    }

    void onDragQuery(object sender, QueryContinueDragEventArgs e) {
        var drag = Helper.GetMousePosition();
        dragPop.PlacementRectangle = new Rect(drag, drag);
        if (e.Action == DragAction.Continue && e.KeyStates != DragDropKeyStates.LeftMouseButton) {
            dragPop.IsOpen = false;
            DragDrop.RemoveQueryContinueDragHandler(this, onDragQuery);
        }
    }

    bool CanBeDragged(MouseEventArgs e) {
        if (dragSource == null) return false;
        var pos = e.GetPosition(null);
        return
            Math.Abs(pos.Y - dragStart.Y) > SystemParameters.MinimumVerticalDragDistance ||
            Math.Abs(pos.X - dragStart.X) > SystemParameters.MinimumHorizontalDragDistance;
    }

    // https://github.com/daszat/MultiSelectionDragger
    class DragListItem : ListBoxItem {
        private bool _deferSelection = false;

        protected override void OnMouseLeftButtonDown(MouseButtonEventArgs e) {
            if (e.ClickCount == 1 && IsSelected) {
                // the user may start a drag by clicking into selected items
                // delay destroying the selection to the Up event
                _deferSelection = true;
            }
            else {
                base.OnMouseLeftButtonDown(e);
            }
        }

        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
            if (_deferSelection) {
                try {
                    base.OnMouseLeftButtonDown(e);
                }
                finally {
                    _deferSelection = false;
                }
            }
            base.OnMouseLeftButtonUp(e);
        }

        protected override void OnMouseLeave(MouseEventArgs e) {
            // abort deferred Down
            _deferSelection = false;
            base.OnMouseLeave(e);
        }
    }
}

