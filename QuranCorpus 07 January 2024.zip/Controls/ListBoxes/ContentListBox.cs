﻿class ContentListBox : ListBox {
    object current;
    public event Action<object> Fired;
    
    protected override void OnKeyUp(KeyEventArgs e) {
        base.OnKeyUp(e);
        if (e.Key != Key.Enter) return;
        fire();
    }
    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
        base.OnMouseLeftButtonUp(e);
        fire();
    }
    protected override void OnItemsSourceChanged(IEnumerable oldValue, IEnumerable newValue) {
        base.OnItemsSourceChanged(oldValue, newValue);
        if (newValue is null) return;
        fire();
    }

    void fire() {
        if (SelectedItem is null) return;
        if (current is not null && current.Equals(SelectedItem)) return;
        current = SelectedItem;
        Fired?.Invoke(current);
    }
}
