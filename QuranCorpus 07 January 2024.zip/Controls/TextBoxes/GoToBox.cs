﻿class GoToBox : TextBox {
    ContextPopup context;

    public GoToBox() {
        ContextMenu = null;
        TextAlignment = TextAlignment.Right;
        VerticalContentAlignment = VerticalAlignment.Bottom;
        CaretBrush = Brushes.LightGray;
        BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness);
        SelectionBrush = Constants.SelectionBrush;
        context = new ContextPopup(new List<ContextItem>() {
            new ContextItem(){ Icon = Icons.Cut, Text = "cut", Command =  () => ApplicationCommands.Cut.Execute(null, null) },
            new ContextItem(){ Icon = Icons.Copy, Text = "copy", Command =  () => ApplicationCommands.Copy.Execute(null, null) },
            new ContextItem(){ Icon = Icons.Paste, Text = "paste", Command =  () => ApplicationCommands.Paste.Execute(null, null) }
        });
    }

    protected override void OnMouseRightButtonUp(MouseButtonEventArgs e) {
        base.OnMouseRightButtonUp(e);
        context.IsOpen = true;
    }

    protected override void OnPreviewDragOver(DragEventArgs e) {
        e.Handled = true;
    }
}
