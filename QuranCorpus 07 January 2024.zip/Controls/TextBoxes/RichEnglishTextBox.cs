﻿class RichEnglishTextBox : RichTextBox {
    ContextPopup context;
    public RichEnglishTextBox() {
        ContextMenu = null;
        IsReadOnly = true;
        SelectionBrush = Constants.SelectionBrush;
        FlowDirection = FlowDirection.LeftToRight;
        SetBinding(FontSizeProperty, new Binding() {
            Path = new PropertyPath(nameof(Global.EnglishFontSize)),
            Source = App.global
        });
        context = new ContextPopup(new List<ContextItem>() {
                new ContextItem(){ Icon = Icons.Copy, Text = "copy", Command =  () => ApplicationCommands.Copy.Execute(null, null) }
            });
        Document.Blocks.Clear();
    }

    protected override void OnMouseRightButtonUp(MouseButtonEventArgs e) {
        base.OnMouseRightButtonUp(e);
        context.IsOpen = true;
    }
}
