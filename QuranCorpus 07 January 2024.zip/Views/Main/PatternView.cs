﻿
class PatternView : CardView {
    public override string Icon => Icons.OneToOneOrMany;
    public override bool OverridesToolTip => true;
    public override UIElement Tip => getTip();

    PatternVM vm;
    ActionButton consolidated, unique;
    WaterBox queryBox;
    PageListBox list;
    ProgressBar progress;
    Run patternCount, rootCount, referenceCount;
    Grid queryGrid;
    TextBlockEnglish counts;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new PatternVM();
        DataContext = vm;
        initializeUI();
        bind();
        queryBox.KeyUp += onQuery;
    }

    void onQuery(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        vm.Filter(queryBox.Text.Trim());
    }

    void initializeUI() {
        patternCount = new Run();
        rootCount = new Run();
        referenceCount = new Run();
        counts = new TextBlockEnglish() { 
            HorizontalAlignment = HorizontalAlignment.Right,
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
                patternCount,
                new Run(" pattern, "),
                rootCount,
                new Run(" root, "),
                referenceCount,
                new Run(" reference")
            }
        };
        consolidated = new ActionButton() {
            Margin = new Thickness(0,0,5,0),
            Icon = Icons.Sum,
            ToolTip = "consolidated",
            Command = vm.AddConsolidatedPage
        };
        unique = new ActionButton() {
            Icon = Icons.SetAll,
            ToolTip = "unique",
            Command = vm.AddUniquePage
        };
        queryBox = new WaterBox() {
            Margin = new Thickness(0,0,5,0),
            Icon = Icons.Search,
            Hint = "Pattern (eg. +w+)"
        };
        Grid.SetColumn(consolidated, 1);
        Grid.SetColumn(unique, 2);
        queryGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() {Width = GridLength.Auto},
                new ColumnDefinition() {Width = GridLength.Auto}
            },
            Children = { queryBox, consolidated, unique }
        };
        progress = new ProgressBar() {
            Margin = new Thickness(0, 2.5, 0, 2.5),
            Height = Constants.ProgressBarHeight,
            FlowDirection = FlowDirection.RightToLeft
        };
        list = new PageListBox() {
            Margin = new Thickness(0,5,0,0),
            FlowDirection = FlowDirection.RightToLeft,
            Context = vm,
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(PatternTemplate))
            }
        };

        Grid.SetRow(progress, 1);
        Grid.SetRow(queryGrid, 2);
        Grid.SetRow(list, 3);

        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition()
            },
            Children = { counts, progress, queryGrid, list }
        };
        setContent(grid);
    }

    void bind() {
        progress.SetBinding(ProgressBar.IsIndeterminateProperty, new Binding(nameof(vm.IsInProgress)));
        queryGrid.SetBinding(Grid.IsEnabledProperty, new Binding() {
            Path = new PropertyPath(nameof(vm.IsInProgress)),
            Converter = new IsEnabledConverter()
        });
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Patterns)));
        patternCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = list,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        rootCount.SetBinding(Run.TextProperty, new Binding(nameof(vm.RootCount)) { StringFormat = "N0" });
        referenceCount.SetBinding(Run.TextProperty, new Binding(nameof(vm.ReferenceCount)) { StringFormat = "N0" });
    }

    Grid getTip() {
        var header = new TextBlockEnglish() {
            Text = "Patterns",
            FontWeight = FontWeights.Bold
        };
        var separator = new Rectangle() {
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var description = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Text = "See root patterns."
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(description, 2);
        return new Grid() {
            MaxWidth = 200,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(10) },
                new RowDefinition()
            },
            Children = { header, separator, description }
        };
    }

    class PatternTemplate : Grid {
        TextBlockArabic pattern;
        TextBlockEnglish rootCount, refCount;
        
        public PatternTemplate() {
            pattern = new TextBlockArabic() { VerticalAlignment = VerticalAlignment.Center };
            rootCount = new TextBlockEnglish() { 
                HorizontalAlignment = HorizontalAlignment.Right
            };
            refCount = new TextBlockEnglish() { 
                Foreground = Brushes.Gray,
                HorizontalAlignment = HorizontalAlignment.Right
            };
            var countPanel = new StackPanel() {
                VerticalAlignment = VerticalAlignment.Center,
                Children = { rootCount, refCount }
            };
            SetColumn(countPanel, 1);

            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

            Children.Add(pattern);
            Children.Add(countPanel);

            Loaded += onLoaded;
            Unloaded += onUnloaded;
        }

        void onLoaded(object sender, RoutedEventArgs e) {
            App.global.PropertyChanged += onTatweelLengthChanged;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            App.global.PropertyChanged -= onTatweelLengthChanged;
        }

        void onTatweelLengthChanged(object? sender, PropertyChangedEventArgs e) {
            if (!e.PropertyName.Equals(nameof(App.global.TatweelLength))) return;
            pattern.Inlines.Clear();
            addSegments();
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Pattern)DataContext;
            rootCount.Text = c.Roots.Count.ToString("N0");
            refCount.Text = c.Roots.Sum(x => x.Item2.Count).ToString("N0");
            addSegments();
        }

        void addSegments() {
            var c = (Pattern)DataContext;
            if (c.Root.Length == 3) {
                if (c.Root[1] == '~') {
                    pattern.Inlines.Add(new Run((PatternHelper.leadingTatweel + '~' + PatternHelper.trailingTatweel).toArabic()) { Foreground = Foregrounds.R1 });
                    pattern.Inlines.Add(new Run((PatternHelper.leadingTatweel + PatternHelper.trailingTatweel).toArabic()) { Foreground = Foregrounds.R3 });
                }
                else if (c.Root[2] == '~') {
                    var shadda = c.Root[1] == '+' ?
                        (PatternHelper.leadingTatweel + '~' + PatternHelper.trailingTatweel).toArabic()
                        : (c.Root[1].ToString() + '~' ).toArabic();

                    var other = c.Root[0] == '+' ? 
                        (PatternHelper.leadingTatweel + PatternHelper.trailingTatweel).toArabic() 
                        : c.Root[0].ToString().toArabic();
                    pattern.Inlines.Add(new Run(other) { Foreground = Foregrounds.R1 });
                    pattern.Inlines.Add(new Run(shadda) { Foreground = Foregrounds.R2 });
                }
                else {
                    for (int i = 0; i < c.Root.Length; i++) {
                        if (c.Root[i] == '+') {
                            pattern.Inlines.Add(new Run((PatternHelper.leadingTatweel + PatternHelper.trailingTatweel).toArabic()) {
                                Foreground = i == 0 ?
                                    Foregrounds.R1 :
                                    i == 1 ?
                                    Foregrounds.R2 :
                                    Foregrounds.R3
                            });
                        }
                        else {
                            var character = c.Root[i] == 'A' ? ">".ToString() : c.Root[i].ToString();
                            pattern.Inlines.Add(new Run(character.toArabic()) {
                                Foreground = i == 0 ?
                                    Foregrounds.R1 :
                                    i == 1 ?
                                    Foregrounds.R2 :
                                    Foregrounds.R3
                            });
                        }
                    }
                }
            }
            else {
                var content = (PatternHelper.leadingTatweel + PatternHelper.trailingTatweel).toArabic();
                if (c.Root.StartsWith('-')) {
                    pattern.Inlines.Add(new Run(content) { Foreground = Foregrounds.R1 });
                    pattern.Inlines.Add(new Run(content) { Foreground = Foregrounds.R2 });
                    pattern.Inlines.Add(new Run(content) { Foreground = Foregrounds.R1 });
                    pattern.Inlines.Add(new Run(content) { Foreground = Foregrounds.R2 });
                }
                else {
                    pattern.Inlines.Add(new Run(content) { Foreground = Foregrounds.R1 });
                    pattern.Inlines.Add(new Run(content) { Foreground = Foregrounds.R2 });
                    pattern.Inlines.Add(new Run(content) { Foreground = Foregrounds.R3 });
                    pattern.Inlines.Add(new Run(content) { Foreground = Foregrounds.R4 });
                }
            }
        }
    }

    class IsEnabledConverter : IValueConverter {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
            return !(bool)value;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) {
            throw new NotImplementedException();
        }
    }
}
