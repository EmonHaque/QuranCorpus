﻿class UsageView : CardView {
    public override string Icon => Icons.HelpIcon;
    public override UIElement Tip => new TextBlockEnglish() { 
        Text = "Usage", 
        Foreground = Constants.Foreground 
    };

    public override void OnFirstSight() {
        base.OnFirstSight();
        var box = new RichEnglishTextBox();
        var blocks = box.Document.Blocks;
        blocks.Add(new Paragraph() {
            Margin = new Thickness(0,0,0,5),
            Foreground = Brushes.Gray,
            FontWeight = FontWeights.Black,
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
            BorderBrush = Constants.Foreground,
            Inlines = { new Run("Usage") }
        });
        blocks.Add(new Paragraph() {
            Margin = new Thickness(0),
            Inlines = {
                new Run("In the Home Page, there're two panels, left panel is for pages and the right one is to show twelve views. In between those panels, there're twelve icons to change view on the right panel. First one, selected by default, is "),
                new BoldRun("Surah view"),
                new Run(". When you right click a Surah, a page is added in the left panel and when you left click a Surah, Surah page will be updated if it is focused or selected."),
                new Run(" If you, however, make Surah selection with keyboard Up/Down arrow keys, make sure you hit enter key of the keyboard after making selection with keyboard. This, hitting enter key after making selection with Up/Down arrow keys, applies to all ListBox/TreeView where you've Left/Right click functionalities to update page fully or partially."){ Foreground = Brushes.Bisque }
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("Second is "),
                new BoldRun("Words view"),
                new Run(" and it's three subviews. By default, words/sentences that's root are shown in the first sub view  and you can change these sub views by clicking the three icons in the bottom. When you right click on a branch or leaf of the tree, a page will be added in the left panel and when you left click, page will be updated if it's a lemma page and selected. The second sub view is for words without root and grouped by lemma and the third sub view is for words which don't have either. Same left/right click functionalities are available for these subviews. All words (separated by space) of the Quran are covered in these three sub views.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("There're 1,642 distinct roots in \"Quranic Arabic Corpus\" and there's one word that's 2 roots. I've listed that, 20:94:2 - yabnaumma, separately with '|' so altogether 1643 roots are shown. There're 4,648 unique Root-Lemma pairs in \"Quranic Arabic Corpus\" and the one, with 2 roots, have 2 more reference so altogether number of lemma's become 4,650 in the first sub view. There're 175 distinct lemmas for words which don't have root of which 2 ends with character 2, \"maE2\" and \"<i*aA2\", that '2' has been removed, altogether 173 lemmas are shown in the second sub view. There're 152 words that don't have root or lemma. These numbers will vary if you switch to simple transcript in global settings."),
                new Run(" I've added some roots for some words, some of those roots could be wrong and the numbers above will not match in views. To see the list of all the roots I've added, go to About view."){ Foreground = Brushes.Bisque }
            }
        });
        
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("Third is "),
                new BoldRun("Unequals view"),
                new Run(" and it's two sub views. There are few words which have been spelled out in the same way but segmented differently and in the first sub view, those words have been listed. Same left right click functionality is available to open or update a SegmentPage in this sub view. In the bottom of the segment page, word reference and probable meanings have been listed. To get into the context, double click the reference/meaning in the list, it'll take you to that ayah of surah. The second sub view for words with multiple tags and only right click functionality is there to open a MatchPage. On top of this sub view, there're two items in a CheckGroup - the second one is for words which have N and ADJ tags and the first one is for the rest."),
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("Fourth is "),
                new BoldRun("Tags view"),
                new Run(". You can give a name and create Tag, eg. Musa tag for listing all verses related to Musa. You can select one or more verses from Surah or flat list of Lemma pages only and drag selected Ayah(s) on top of your tag and drop to get those added in your tag. Similar left/right clicking functionalities are there to open and update Tag page. You can reorder verses by dragging and dropping verses in Tag page and can remove by right clicking on verse. Tags are created in a separate Tag folder in the Resources folder of the application. To save your tags, store that folder somewhere else before updating code or application.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("Fifth is "),
                new BoldRun("Sisters' view"),
                new Run(" and is for inna, kada, kana and their sisters. You can right click on a list item in those three sub views to open a match page. Sixth is "),
                new BoldRun("POS view"),
                new Run(" and it groups words, particles, etc. by Tag. Seventh is "),
                new BoldRun("Forms view"),
                new Run(" and it groups words which have root in form I through XII. Word that doesn't have a form has been grouped into I. Eighth is "),
                new BoldRun("Matrix view"),
                new Run(" and it presents words with same root in a matrix, highlights duplicate spellings and if you double click a word in the matrix, it'll take you to MorphPage and if you double click on meaning in MorphPage, it'll take you to the surah. Same left and right click fucntionality is available to add or update POSPage, FormPage and RootMatrixPage.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("Nineth is "),
                new BoldRun("Case and Moods view"),
                new Run(". The top view is for cases, ie. accusative, nominative and genitive and the bottom view is for moods, ie. indicative, subjunctive and jussive. Noun, Proper Noun and Adjectives tags have been considered for cases and moods are found in imperfect verbs. Both cases and moods have been grouped by genders and the same left and right click functionality is also available for this view to add or update CasePage or MoodPage. There're 7 text boxes in CasePage, 1 for root and six for case endings. In root box you can type buckwalter, eg. smw, and hit enter to filter out words which don't have that root. In 6 other boxes you can type one or more ending characters in buckwalter and hit enter to filter. For example, in genitive box you can type i to see words that ends with kesra or to negate you can type !i to see words which don't end with kesra. All cases have been divided into two - definite and indefinite. Words that have prefixed DET, Al, have been classfied as Definite, otherwise Indefinite. In MoodPage there're 4 text boxes to filter, 1 for root and other 3 for ending character(s).")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("Tenth is "),
                new BoldRun("Pronoun view"),
                new Run(" and is for words that have atleast two things and one of them is pronoun. There're 4 possibilities for these pronouns - subject, object, personal and possessive. Same left and right click functionality is available to add or update PronounPage. There're 3 sections, separated by vertical lines, in the PronounPage. The right section list the forms/spellings as the first branch of tree. If you select a leaf in the tree, the middle section will be populated with words to which the pronoun is attached and if you change selection in the middle section the left section will be populated with detail and probable meaning. There're 4 buttons on top of PronounView to see attached, detached, relative and demonstrative pronouns in a matrix in PronounMatrixPage. Double click on a pronoun in PronounMatrixPage will take you to MatchPage and match count may vary compared to other matching techniques. For exampla, dha/ja has been tagged as Noun (18 times) and Demonstrative pronoun (5 times). When you double click dha/ja in a SurahPage, MatchPage will show you all 23 but you'll get only 5 if you double click ja on PronounMatrixPage.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("Eleventh is "),
                new BoldRun("Verb and Others view"),
                new Run(" and is divided into two parts, top part is only for verbs and the bottom is for anything that has root and not a verb. Left/right click functionality is available to add or update VerbPage/NotVerbPage. On the right side of VerbPage there're two WaterBox for query and two MultiState for voice (active/passive) and mood (indicative/subjunctive/jussive). You click those MultiState to apply filter. In Query boxes plus sign (+) is the wildcard. If you want to find all quadriliteral roots, type 4 plus in Root query box and hit enter. In Verb query box, you can type +a+~a+a in and hit enter to find 'faala' pattern in Third person Masculine Singular - Form II. In these kind of pattern search the suffixed subject pronoun is ignored and the length of the pattern has to match the length of verb. In Verb query box you can also have starts with, ends with and negate those starts and ends with query pattern. For starts with query, the first character has to be '/', for ends with query the first character has to be '\\'. To negate starts with or ends with use '!/' or '!\\'. For example, to see all First person Plural that starts with 'na', type '/na' and hit enter and to see those which don't starts with 'na', type '!/na' and hit enter. Ends with query checks attached subject pronoun, if there's any. For NotVerbPage, there's no Active/Passive state and functionalities of rest of the controls are identical to VerbPage")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("Twelfth is "),
                new BoldRun("Patterns view"),
                new Run(" and it groups triliteral roots based on position of weak or repeated letters in composition. Left/Right click fuctionality is available to open/update all patterns in a Matrix in Pattern page. Some of these patterns may take a while to load eg. if you right click the first (strong +++, represented by 3 tatweel) pattern it'll take several seconds to process. Each pattern block in the Matrix can have 3 things - 3 stacked numbers on the left are for number of roots, number of words and number of occurence and on the right you can have another number in a circle. On hover, the number in the circle displays list of places having same pattern in a popup. If you left click an item in the popup list, it'll take you to that place and to close the popup click somwehere else. Double click a pattern to see all words in that pattern. To adjust the length of tatweel in the pattern go to Settings view and adjust \"Tatweel length in pattern\". On top right corner there're two more buttons - first one to see all patterns in one matrix and it takes long time to load and the other to see unique patterns in a list. In the unique pattern list query box you can prepend '\\' or '/' for starts with or ends with filter.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("Thirteenth is "),
                new BoldRun("Reciters/Readings view"),
                new Run(" and is for eight different recitations/teadings. Left/right click functionality is there to add or update ReciterPage. These readings need special fonts to render characters properly so the global font change does not affect the text. The thirteenth view is for six hadith books, you can right click to add and left click to update HadithPage. There're 3 buttons on top right corner of HadithPage to group hadith by chapter, narrator (isnad/sanad) and grade. A WaterBox to bring a hadith, by number, into view and a search button to search hadith by content (matan) or isnad. If you click the search icon a SearchHadithPage will be added. By default search page will search tokens in the english content (matan). Click the right most button to search in english narration chain (isnad/sanad). Click the other button for arabic input. Hit enter after entering some characters to find matches.")
            }
        });
        blocks.Add(new Paragraph() {
            Inlines = {
                new Run("Last one is "),
                new BoldRun("Settings view"),
                new Run(" and is global settings for font, font size, translations and script, etc.")
            }
        });
        blocks.Add(new Paragraph(new Run("By hovering over a word in Surah or Tag page you can see relevant information, parsed from the \"Quranic Arabic Corpus\". When you double click a word, a Match page with matching words will be added in the left panel. You can group those matching verses by Tag/Parts of Speech, Spelling variation and Surah. On the top right corner it'll display the mode of searching. First it searches by root, if there's no root it goes with lemma and if neither exist, it goes with the literal. Probable meaning of the word, parsed from \"Quranic Arabic Corpus\", is displayed on third column from the left and when you hover over the arabic, a tooltip will pop up to display the translation, selected in settings view. When you doble click a verse - it will take you to that Surah to read in context.")));
        blocks.Add(new Paragraph(new Run("In Surah or Tag page, there's a Pentip icon for selecting more than one translation for that page. In SurahPage, there're three search icons, one for searching locally, ie. in that surah, another for finding in entire Quran and the last one for Hadith. If you click the global search, a search page will be added in the left panel. Both arabic and english search is supported. For arabic spelling has to be exactly like what's rendered. To copy an arabic word you can hold down left control button on keyboard and left mouse click to select a word. If you want to select multiple words - select a word first, hold down left control and left shift keys of keyboard together and left mouse click on another word in the same ayah - it'll select all words in between, right mouse click and click \"copy word(s)\" in the context menu. If you've only one ayah selected and some word(s) in that ayah are also selected,  right click will let you copy words. If you've multiple ayahs selected - it'll let you copy all selected ayahs. To copy a single ayah - make sure no word is selected in that ayah. To deselect word(s), hold down left control button of keyboard and left mouse click on any selected word - it'll clear selection.")));
        blocks.Add(new Paragraph(new Run("There's a wave icon in Surah page to see all spelling groups that you see on popup on hover over words. There's a text box to search by pattern, eg. malayikah, type in +a+`}i with Simple script and hit enter and it'll show all words that start with that pattern. Next to the query box, there's a toggle to limit the length of matching words by the length of pattern. If you copy an arabic word from SurahPage and paste on the query box, it'll transform the arabic into english transcript and you can make adjustment by additing or deleting characters. If you right click on a spelling, it'll add a LemmaPage.")));
        blocks.Add(new Paragraph(new Run("For english search, click the ab/ayn toggle next to search box and you've to have at least one translator selected. You can select/deselect all translations by clicking the toggle on top right corner of the Translator popup. There's a go to box in Surah page where you can enter an ayah number and hit enter to bring that ayah of that surah into view or you can enter a surah no and ayah no, separated by colon, to go there. There're two more icons in SurahPage, TagPage and SearchPage to enable/disable segments' color and word morphology popup on hover. By default colorized segments and word morphology popup is disabled. SurahPage has an additional icon for Tafsir Ibn Kathir, if you click that - a TafsirPage will be added. If TafsirPage is focused and you change selection in SurahView, TafsirPage will be updated.")));
        blocks.Add(new Paragraph(new Run("On the left pane 4 pages can be viewed simultaneously. For example, you've two SurahPage on the left pane - Al-Fatiha and Al-Alaq. Drag the header Al-Alaq on the body of surah and drop, you'll have surah Alaq on the left and Fatiha on the Right. Left lick on the header Al-Alaq, to get that side focused, and right click on Al-Baqara in Surah View, it'll be added next to Alaq. Drag Al-Baqara header and drop on the body of the surah on left side, Al-Baqara will be on the bottom left. Left click on Al-Fatiha header to get that side focused and right click An-Nisa in Surah View to get that added on that side. Drag An-Nisa header and drop on the body of surah on the right side, An-Nisa will be on bottom right.")));
        blocks.Add(new Paragraph(new Run("I haven't tested the application thoroughly so there could be some anomalies. There're two global exception handler - one to trap UI exceptions and the other for trapping exceptions in Tasks. You can add, edit code for your own research and education. If you face any issue in understanding code, contact me at emon-haque@hotmail.com for help.")));
        setContent(new ScrollViewer() {
            Template = new ScrollViewerTemplate(),
            Content = box
        });
    }

    class BoldRun : Run {
        public BoldRun(string content) {
            Foreground = Brushes.SkyBlue;
            FontWeight = FontWeights.Bold;
            Text = content;
        }
    }
}
