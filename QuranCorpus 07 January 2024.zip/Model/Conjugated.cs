﻿class Conjugated {
    public string Person { get; set; }
    public string As { get; set; }
    public string To { get; set; }
    public string[] Word { get; set; }
    public string[] Pronoun { get; set; }
    public bool IsSorted { get; set; }
    public List<string> References { get; set; }

    public Conjugated() {
        References = new List<string>();
    }

    public Conjugated (Conjugated rhs) {
        Person = rhs.Person;
        As = rhs.As;
        To = rhs.To;
        Word = new string[] { rhs.Word[0], rhs.Word[1] };
        Pronoun = new string[] { rhs.Pronoun[0], rhs.Pronoun[1] };
        References = new List<string>(rhs.References);
    }
}
