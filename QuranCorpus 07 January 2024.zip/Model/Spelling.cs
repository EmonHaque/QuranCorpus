﻿class Spelling {
    public string Spell { get; set; }
    public bool HasRoot { get; set; }
    public string RootOrLemma { get; set; }
    public List<string> Tags { get; set; }
    public List<string> Reference { get; set; }
}

