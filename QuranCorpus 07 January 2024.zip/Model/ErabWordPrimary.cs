﻿class ErabWordPrimary {
    public string Reference { get; set; }
    public string[] Spellings { get; set; }
    public string[] Segments { get; set; }
    public string Gender { get; set; }
    public string Erab { get; set; }
    public string Root { get; set; }
    public bool HasDet { get; set; }
}
