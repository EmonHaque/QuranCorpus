﻿class PatternSegment {
    public string Tag { get; set; }
    public string Spelling { get; set; }
    public string Form { get; set; }
    public string SubTag { get; set; }
    public string Pattern { get; set; }
    public string Root { get; set; }
    public string Number { get; set; }
    public List<string> Reference { get; set; }

    public PatternSegment()
    {
        Form = "";
        SubTag = "";
        Number = "";
    }
}