﻿class RootLemmaFree {
    public string Content { get; set; }
    //public string Segments { get; set; }
    public int Count { get; set; }
    public List<string> References { get; set; }
}
