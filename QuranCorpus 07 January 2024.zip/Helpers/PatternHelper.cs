﻿class PatternHelper {
    public static string trailingTatweel;
    public static string leadingTatweel;
    char[] tatweels = ['a', 'i', 'u', 'o', 'F', 'K', 'N', '@'];
    List<string> possibleTags = new() {
        "Perfect",
        "Perfect Passive",
        "Imperfect",
        "Imperfect Passive",
        "Imperative",
        "Active Participle",
        "Passive Participle",
        "Verbal Noun",
        "Other",
        "Other Dual",
        "Other Plural"
    };

    public List<string> PossibleTags => possibleTags;

    public static void updateTatweelLength() {
        switch (App.global.TatweelLength) {
            case 1:
                leadingTatweel = "__";
                trailingTatweel = "_";
                break;
            case 2:
                leadingTatweel = "__";
                trailingTatweel = "__";
                break;
            case 3:
                leadingTatweel = "__";
                trailingTatweel = "___";
                break;
            case 4:
                leadingTatweel = "___";
                trailingTatweel = "____";
                break;
            case 5:
                leadingTatweel = "___";
                trailingTatweel = "_____";
                break;
            case 6:
                leadingTatweel = "___";
                trailingTatweel = "______";
                break;
        }
    }

    public List<RootForm> normal(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root; ;
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (pos.Tag.Equals("V")) {
                if (pos.SubTag.Contains("imperfect", StringComparison.InvariantCultureIgnoreCase)) {
                    if (pos.Form.Equals("VIII") && root.Equals("*xr")) {
                        index = 5;
                        rootIndex = 1;
                        segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                    }
                    else if (pos.Form.Equals("X") && root.StartsWith('s')) {
                        index = 6;
                        segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                    }
                    else if (root.StartsWith('t') && spell.StartsWith('t')
                        || root.StartsWith('n') && spell.StartsWith('n')) {
                        index = 2;
                        segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                    }
                    else if (spell.Equals("tafot")) spell = "tafotin";
                }
                else if (pos.Form.Equals("I") && pos.SubTag.Equals("Perfect")) {
                    if (spell.Equals("niE")) spell = "niEim";
                    else if (spell.Equals("Ean")) spell = "Eanit";
                    else if (spell.Equals("fat")) spell = "fatan";
                    else if (spell.Equals("laE")) spell = "laEan";
                }
                else if (pos.Form.Equals("II") && pos.SubTag.Equals("Perfect")) {
                    if (spell.Equals("mak~")) spell = "mak~an";
                }
                else if (pos.Form.Equals("IV")) {
                    if (pos.SubTag.Equals("Perfect") && spell.Equals(">asok")) {
                        spell = ">asokan";
                    }
                    else if (pos.SubTag.Equals("Perfect Passive")) {
                        if (spell.Equals(">uHoS")) spell = ">uHoSin";
                        else if (spell.StartsWith("'u")) spell = '>' + spell.Substring(1);
                    }
                }
                else if(pos.Form.Equals("VIII") && root.Equals("*kr")) {
                    index = 4;
                    rootIndex = 1;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                }
            }
            else if (pos.SubTag.Equals("active participle", StringComparison.InvariantCultureIgnoreCase)) {
                if (pos.Form.Equals("II") &&
                    root.Equals("sTr")) {
                    index = 6;
                    rootIndex = 1;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                }
                else if (pos.Form.Equals("X") &&
                    (root.StartsWith('s') || root.StartsWith('m'))) {
                    index = 6;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                }
                else if (pos.Form.Equals("VI") && root.StartsWith('t')) {
                    index = 4;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                }
                else if (pos.Form.Equals("IV") && root.StartsWith('m')) {
                    index = 2;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                }
                else if (pos.Form.Equals("VIII") && root.Equals("*kr")) {
                    index = 5;
                    rootIndex = 1;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                }
            }
            else if (pos.SubTag.Equals("passive participle", StringComparison.InvariantCultureIgnoreCase)) {
                if (pos.Form.Equals("I") &&
                    root.StartsWith('m') &&
                    spell[0] == 'm' &&
                    spell[2] == 'm') {
                    index = 2;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                }
                else if (pos.Form.Equals("II") && root.StartsWith('m')) {
                    index = 2;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                }
            }
            else if (pos.SubTag.Equals("verbal noun", StringComparison.InvariantCultureIgnoreCase)) {
                if (pos.Form.Equals("II") &&
                    root[0] =='t' &&
                    spell.StartsWith("tat")) {
                    index = 2;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                }

            }
            else if (pos.Form.Equals("I") && pos.SubTag.Equals("Other")) {
                if (spell.Equals("ladun~")) spell = "ladun";
            }

            do {
                var current = spell[index];
                if (current == '_') goto next;

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                        if(rootIndex == 1) {
                            if(pos.SubTag.Equals("Other") && 
                               root.Equals("bsT") &&
                               spell.StartsWith("baS")) {
                                rootIndex++;
                            }
                        }
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> shaddaPlus(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root; ;
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            do {
                var current = spell[index];
                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> plusShadda(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root; ;
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (pos.Form.Equals("I")) {
                if(pos.SubTag.Equals("Perfect") &&
                  (spell.Equals("man") || spell.Equals("Zan"))) {
                    spell = spell + "an";
                }
                else if (pos.SubTag.Equals("Passive Participle")
                         && root.StartsWith('m')) {
                    index = 2;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                }
                
            }
            else if(pos.Form.Equals("II")) {
                if (pos.SubTag.Equals("Active Participle")
                    && root[0] == 'm') {
                    index = 2;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                }
                else if (pos.SubTag.Equals("Passive Participle")
                    && root[0] == 'm') {
                    index = 2;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                }
                else if(pos.SubTag.Equals("Verbal Noun")
                        && root[0] == 't') {
                    index = 2;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                }
            }
            else if (pos.Form.Equals("IV")) {
                if (pos.SubTag.Equals("Active Participle")
                    && root[0] == 'm') {
                    index = 2;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                }
            }
            else if (pos.Form.Equals("X")
                && pos.SubTag.Equals("Active Participle")
                && root.StartsWith('m')) {
                index = 2;
                segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
            }

            do {
                if (rootIndex < root.Length) {
                    if (spell[index] == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> wawPlusPlus(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;

            int rootIndex = 0;
            string root = pos.Root;
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (pos.Tag.Equals("V")) {
                if (pos.SubTag.Equals("imperfect", StringComparison.InvariantCultureIgnoreCase)) {
                    if (pos.Form.Equals("I")) {
                        if (!root.Equals("wjl")) {
                            index = 2;
                            rootIndex = 1;
                            segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                        }
                    }
                    else if (pos.Form.Equals("V")) {
                        index = 4;
                        segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                    }
                }
                else if (pos.SubTag.Equals("imperative", StringComparison.InvariantCultureIgnoreCase)) {
                    if (pos.Form.Equals("I")) {
                        rootIndex = 1;
                    }
                }
                else if (pos.SubTag.Equals("perfect", StringComparison.InvariantCultureIgnoreCase)) {
                    if (pos.Form.Equals("VIII")) {
                        rootIndex = 1;
                        index = 4;
                        segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                    }
                }
                else if (pos.SubTag.Equals("perfect passive", StringComparison.InvariantCultureIgnoreCase)) {
                    if (pos.Form.Equals("II") && spell[0] == '>') {
                        rootIndex = 1;
                        index = 2;
                        segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                    }
                }
            }
            else if (pos.SubTag.Equals("other", StringComparison.InvariantCultureIgnoreCase)) {
                if (pos.Form.Equals("I")) {
                    if (spell.StartsWith("mi")) {
                        rootIndex = 1;
                        index = 2;
                        segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                    }
                    else if (root.Equals("wsn")) {
                        rootIndex = 1;
                    }
                    else if(root.Equals("wsE") && spell.Equals("saE")) {
                        rootIndex = 1;
                    }
                    else if (spell.StartsWith('t')) {
                        rootIndex = 1;
                        index = 2;
                        segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                    }
                    else if (spell.StartsWith("mu")) {
                        rootIndex = 1;
                        index = 4;
                        segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                    }
                }
            }

            do {
                if (spell[index] == '_') goto next;
                var current = spell[index];
                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> plusWawPlus(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;

            int rootIndex = 0;
            string root = pos.Root;
            string spell = pos.Spelling;
            List<RootSegment> segments = new();
            if(pos.Form.Equals("I") && pos.SubTag.Equals("Perfect")) {
                if(spell.Equals("k") && root.Equals("kwn")) {
                    spell = "kun";
                }
            }
            else if (pos.SubTag.Equals("Imperfect")
                && pos.Form.Equals("I")
                && root.StartsWith('t')
                && spell.StartsWith('t')) {
                index = 2;
                segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
            }
            else if (pos.SubTag.Equals("Other")
                && pos.Form.Equals("I")
                && spell.Equals("mamaAt")) {
                index = 2;
                segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
            }

            do {
                if (spell[index] == '_') goto next;
                var current = spell[index];

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                        if (rootIndex == 1 &&
                            !(pos.Form.Equals("III") || pos.Form.Equals("VI"))) {
                            if (index < spell.Length - 1 && spell[index + 1] != root[rootIndex]) rootIndex++;
                            if (pos.Form.Equals("I")) {
                                if (pos.SubTag.Equals("Other Plural") && (spell.Equals(">asaAwir") || spell.Equals("mutaja`wir"))) rootIndex--;
                                else if (pos.SubTag.Equals("Other")) {
                                    if (spell.Equals("daAwu,d") ||
                                        spell.Equals("qay~uwm") ||
                                        spell.Equals(">aqaAwiyl")) rootIndex--;
                                }
                            }
                        }
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> plusPlusWaw(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root; ;
            string spell = pos.Spelling.Replace("_!", "n");
            List<RootSegment> segments = new();

            if (pos.SubTag.Contains("Imperfect")) {
                if ((spell.StartsWith("tat") && root[0] == 't') ||
                    (spell.StartsWith("tut") && root[0] == 't') ||
                    (spell.StartsWith("nan") && root[0] == 'n') ||
                    (spell.StartsWith("nun") && root[0] == 'n')) {
                    segments.Add(new RootSegment() { Token = spell.Substring(0, 2) });
                    index = 2;
                }
            }

            do {
                var current = spell[index];
                if (current == '_') goto next;

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> yaPlusPlus(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root; ;
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (pos.SubTag.Contains("Imperfect")) {
                if ((spell.StartsWith("yuw") && root[0] == 'y') ||
                    (spell.StartsWith("tuw") && root[0] == 'y')) {
                    segments.Add(new RootSegment() { Token = spell.Substring(0, 3) });
                    index = 3;
                    rootIndex = 1;
                }
                else if (spell.StartsWith("yasota") && root[0] == 'y') {
                    segments.Add(new RootSegment() { Token = spell.Substring(0, 6) });
                    index = 6;
                }
            }
            else if (pos.SubTag.Equals("Active Participle")) {
                if (spell.StartsWith("muw") && root[0] == 'y') {
                    segments.Add(new RootSegment() { Token = spell.Substring(0, 3) });
                    index = 3;
                    rootIndex = 1;
                }
            }

            do {
                var current = spell[index];
                if (current == '_') goto next;

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> plusYaPlus(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root;
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (pos.Form.Equals("I") && spell.Equals("yol")) {
                spell = "la" + spell;
            }
            else if (pos.Form.Equals("IV")) {
                if (pos.SubTag.Equals("Perfect") && spell.Equals(">al")) spell = ">alan";
                else if (pos.SubTag.Equals("Imperfect") && spell.Equals("tuzig")) {
                    segments.Add(new RootSegment() { Token = spell.Substring(0, 2) });
                    segments.Add(new RootSegment() {
                        IsRoot = true,
                        SegmentNo = 1,
                        Token = "+i"
                    });
                    segments.Add(new RootSegment() {
                        IsRoot = true,
                        SegmentNo = 3,
                        Token = "+"
                    });
                    index = spell.Length;
                    addMatch(pos, segments, list);
                    continue;
                }
            }
            else if (pos.Form.Equals("X")) {
                if (pos.SubTag.Equals("Perfect")) {
                    segments.Add(new RootSegment() { Token = spell.Substring(0, 5) });
                    index = 6;
                    segments.Add(new RootSegment() {
                        IsRoot = true,
                        SegmentNo = 1,
                        Token = "+" + spell[index]
                    });
                    index++;
                    rootIndex = 2;
                }
            }

            do {
                var current = spell[index];
                if (current == '_') goto next;

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                        if (rootIndex == 1) {
                            if (pos.Form.Equals("I") && index < spell.Length - 1) {
                                if(!(root.Equals("Ey$") && pos.SubTag.Equals("Other Plural")) 
                                    && spell[index + 1] != root[rootIndex])
                                    rootIndex++;
                            }
                            else if (pos.Form.Equals("VIII")) rootIndex++;
                            else if (pos.Form.Equals("IV") && spell[index] == 'a') rootIndex++;
                        }
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> plusPlusYa(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root; ;
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (pos.Form.Equals("VIII") &&
                pos.SubTag.Equals("Active Participle") &&
                root.StartsWith("m")) {
                segments.Add(new RootSegment() { Token = spell.Substring(0, 2) });
                index = 2;
            }
            else if (pos.Form.Equals("X") &&
                pos.SubTag.Equals("Perfect") &&
                root.StartsWith("s")) {
                segments.Add(new RootSegment() { Token = spell.Substring(0, 5) });
                index = 5;
            }
            else if (pos.SubTag.Equals("Imperfect") &&
                (spell.StartsWith("nun") || spell.StartsWith("nan")) &&
                root.StartsWith("n")) {
                segments.Add(new RootSegment() { Token = spell.Substring(0, 2) });
                index = 2;
            }
            else if (pos.Form.Equals("IV") &&
                    pos.SubTag.Equals("Perfect Passive") &&
                    spell.StartsWith("'u")) {
                spell = '>' + spell.Substring(1);
            }

            do {
                var current = spell[index];
                if (current == '_') goto next;
                
                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> hamzaPlusPlus(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root.Replace("A", "'");
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (pos.Form.Equals("I")) {
                if (pos.SubTag.Equals("Imperfect") && spell.EndsWith('~')) {
                    spell = spell.Substring(0, spell.Length - 1);
                }
                else if (pos.SubTag.Equals("Imperative")) {
                    if (spell[1] == 'u') rootIndex = 1;
                    else if (spell[0] == '{') {
                        index = 1;
                        segments.Add(new RootSegment() { Token = "{" });
                    }
                }
            }
            else if (pos.Form.Equals("IV")) {
                if (pos.SubTag.Equals("Perfect") &&
                    (root[2] == 'n' && !spell.EndsWith('n'))) {
                    spell += "an";
                }
                else if (pos.SubTag.Equals("Imperfect") &&
                    (root[2] == 'n' && !spell.EndsWith('n'))) {
                    spell += "in";
                }
            }
            else if (pos.Form.Equals("VIII")) {
                bool isWasl = spell.StartsWith('{');
                var ta = isWasl ? spell.Substring(1, 2) : spell.Substring(2, 2);
                if (ta.Equals("t~")) {
                    index = isWasl ? 4 : 5;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                    rootIndex = 1;
                }
                else if (spell[1] == '&') {
                    index = 1;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });

                }
                else if (spell.StartsWith(">o")) {
                    index = 2;
                    segments.Add(new RootSegment() {
                        IsRoot = true,
                        SegmentNo = 1,
                        Token = "+o"
                    });
                    rootIndex = 1;
                }
                else if (spell.Equals("taxa*")) {
                    rootIndex = 1;
                }
            }
            else if (pos.Form.Equals("X") &&
                (pos.SubTag.Equals("Perfect") || pos.SubTag.Equals("Imperative"))) {
                segments.Add(new RootSegment() { Token = spell.Substring(0, 5) });
                index = 5;
            }

            if (spell[1] == '^') {
                spell = spell[0] + "aA" + spell.Substring(2);
            }

            bool hamzaPast = false;
            do {
                var current = spell[index];
                if (current == '_') goto next;
                if (!hamzaPast) current = getHamzaReplacement(current);

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        if (rootIndex == 0 && root[rootIndex] == '\'') hamzaPast = true;
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> plusHamzaPlus(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root.Replace("A", "'");
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (pos.Form.Equals("I")) {
                if (pos.SubTag.Equals("Imperfect") && spell.StartsWith(">a")) {
                    index = 2;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, 2) });
                }
            }

            bool hamzaPast = false;
            do {
                var current = spell[index];
                if (current == '_') goto next;
                if (!hamzaPast) current = getHamzaReplacement(current);

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        if (!hamzaPast && root[rootIndex] == '\'') hamzaPast = true;
                        rootIndex++;
                        if (rootIndex == 1) {
                            if (pos.SubTag.Equals("Imperative") && spell[rootIndex] == 'a') rootIndex++;
                        }

                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            if (pos.SubTag.Equals("Other Plural") && segments[0].Token[0] == '\'') {
                segments[0].Token = '>' + segments[0].Token.Substring(1);
            }
            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> plusPlusHamza(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root.Replace("A", "'");
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (pos.SubTag.Equals("Imperfect")) {
                if (pos.Form.Equals("I") && spell.StartsWith(">a")) {
                    index = 2;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, 2) });
                }
                else if(pos.Form.Equals("II")) {
                    if (spell.StartsWith("nu")) {
                        index = 2;
                        segments.Add(new RootSegment() { Token = spell.Substring(0, 2) });
                    }
                    else if (spell.StartsWith("'u")) {
                        index = 2;
                        segments.Add(new RootSegment() { Token = ">u" });
                    }
                }
                else if (pos.Form.Equals("IV") && spell.StartsWith("nu") && root[0] == 'n') {
                    index = 2;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, 2) });
                }
            }


            bool hamzaPast = false;
            do {
                var current = spell[index];
                if (current == '_') goto next;
                if (!hamzaPast) current = getHamzaReplacement(current);

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        if (!hamzaPast && root[rootIndex] == '\'') hamzaPast = true;
                        rootIndex++;
                        if (rootIndex == 1) {
                            if (pos.SubTag.Equals("Imperative") &&
                                !pos.Form.Equals("V") &&
                                spell[rootIndex] == 'a') rootIndex++;
                        }

                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);
            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> hamzaWawPlus(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root.Replace("A", "'");
            string spell = pos.Spelling;
            List<RootSegment> segments = new();
            if(pos.Form.Equals("I") && pos.SubTag.Equals("Other")) {
                if (spell.Equals(">^n")) {
                    spell = "'aAn";
                }
            }

            bool hamzaPast = false;
            
            do {
                var current = spell[index];
                if (current == '_') goto next;
                if (!hamzaPast) current = getHamzaReplacement(current);

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        if (!hamzaPast && root[rootIndex] == '\'') hamzaPast = true;
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                        if (rootIndex == 1 && pos.SubTag.Equals("Other")) {
                            if (spell[index + 1] != root[rootIndex]) rootIndex++;
                        }
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> hamzaYaPlus(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root.Replace("A", "'");
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            bool hamzaPast = false;
            do {
                var current = spell[index];
                if (current == '_') goto next;
                if (!hamzaPast) current = getHamzaReplacement(current);

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        if (!hamzaPast && root[rootIndex] == '\'') hamzaPast = true;
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> yaHamzaPlus(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root.Replace("A", "'");
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (pos.Form.Equals("X")) {
                index = 5;
                segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
            }
            else if (pos.SubTag.Equals("Imperfect") && spell.StartsWith("ya")) {
                index = 4;
                segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
            }

            bool hamzaPast = false;
            do {
                var current = spell[index];
                if (!hamzaPast) current = getHamzaReplacement(current);

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        if (!hamzaPast && root[rootIndex] == '\'') hamzaPast = true;
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> wawHamzaPlus(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root.Replace('A', '\'');
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            bool hamzaPast = false;
            do {
                var current = spell[index];
                if (!hamzaPast) current = getHamzaReplacement(current);

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        if (!hamzaPast && root[rootIndex] == '\'') hamzaPast = true;
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> yaWawPlus(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root;
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (spell.Equals(">ay~aY`m")) spell = ">ay~aAm";

            do {
                var current = spell[index];
                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                        if (rootIndex == 1 && spell[index + 1] != root[rootIndex]) rootIndex++;
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> wawPlusYa(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root;
            string spell = pos.Spelling.Replace("_(", "y");
            List<RootSegment> segments = new();

            if (pos.Form.Equals("I")) {
                if (pos.SubTag.Equals("Imperfect") && spell[1] == 'a') rootIndex = 1;
                else if (pos.SubTag.Equals("Imperative")) rootIndex = 1;
                else if (pos.SubTag.Equals("Verbal Noun")) rootIndex = 1;
                else if (pos.SubTag.Equals("Other") || pos.SubTag.Equals("Other Plural")) {
                    if (root.Equals("wqy") || root.Equals("w$y")) rootIndex = 1;
                    else if (spell.Equals("diy")) rootIndex = 1;
                }
            }
            else if (pos.Form.Equals("VIII")) rootIndex = 1;

            do {
                var current = spell[index];
                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> hamzaPlusYa(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root.Replace("A", "'");
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (pos.Form.Equals("I")
                && pos.SubTag.Equals("Imperative")
                && spell.StartsWith("{")) {
                segments.Add(new RootSegment() { Token = "{" });
                index = 1;
            }
            if (spell[1] == '^') {
                spell = spell[0] + "aA" + spell.Substring(2);
            }
            bool hamzaPast = false;
            do {
                var current = spell[index];
                if (current == '_') goto next;
                if (!hamzaPast) current = getHamzaReplacement(current);

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        if (!hamzaPast && root[rootIndex] == '\'') hamzaPast = true;
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> yaPlusYa(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root;
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            do {
                var current = spell[index];
                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> hamzaPlusWaw(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root.Replace("A", "'");
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (spell[1] == '^') {
                spell = spell[0] + "aA" + spell.Substring(2);
            }

            bool hamzaPast = false;
            do {
                var current = spell[index];
                if (current == '_') goto next;
                if (!hamzaPast) current = getHamzaReplacement(current);

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        if (!hamzaPast && root[rootIndex] == '\'') hamzaPast = true;
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> wawPlusHamza(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;

            int rootIndex = 0;
            string root = pos.Root.Replace("A", "'");
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (pos.Form.Equals("I") && pos.SubTag.Equals("Imperfect")) rootIndex = 1;
            else if (pos.Form.Equals("V")) {
                index = 4;
                segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
            }
            else if (pos.Form.Equals("VIII")) rootIndex = 1;

            do {
                if (spell[index] == '_') goto next;
                var current = spell[index];
                if (rootIndex != 2) current = getHamzaReplacement(current);

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> plusWawYa(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;

            int rootIndex = 0;
            string root = pos.Root;
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            do {
                if (spell[index] == '_') goto next;
                var current = spell[index];
                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                        if (rootIndex == 1 && pos.Form.Equals("I")) {
                            if (pos.SubTag.Equals("Verbal Noun") &&
                                spell.Equals("lay~")) rootIndex++;
                            else if (pos.SubTag.Equals("Other") &&
                                (spell.Equals("gay~") || spell.Equals("Tay~"))) {
                                rootIndex++;
                            }
                        }
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> plusWawHamza(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;

            int rootIndex = 0;
            string root = pos.Root.Replace("A", "'");
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (pos.Form.Equals("IV")) {
                if (pos.SubTag.Equals("Perfect")) {
                    index = 2;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                }
            }

            do {
                if (spell[index] == '_') goto next;
                var current = spell[index];
                if (index != 0) current = getHamzaReplacement(current);

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                        if (rootIndex == 1) {
                            if (pos.Form.Equals("I") && spell[index + 1] != root[rootIndex]) rootIndex++;
                            else if (pos.Form.Equals("IV")) rootIndex++;
                        }
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> plusYaHamza(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;

            int rootIndex = 0;
            string root = pos.Root.Replace("A", "'");
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            do {
                if (spell[index] == '_') goto next;
                var current = spell[index];
                if (index != 0) current = getHamzaReplacement(current);
                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                        if (rootIndex == 1) {
                            if (pos.Form.Equals("I")) {
                                if (!(pos.SubTag.Equals("Perfect Passive") || pos.SubTag.Equals("Other"))) {
                                    if (spell[index + 1] != root[rootIndex]) rootIndex++;
                                }

                            }
                            else if (pos.Form.Equals("IV")) rootIndex++;
                        }
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> plusHamzaYa(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;

            int rootIndex = 0;
            string root = pos.Root.Replace("A", "'");
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            do {
                if (spell[index] == '_') goto next;
                var current = spell[index];
                if (index != 0) current = getHamzaReplacement(current);

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                        if (rootIndex == 1) {
                            if (pos.Form.Equals("I") && !(root.Equals("m'y") || root.Equals("n'y"))) {
                                if (index < spell.Length - 1 &&
                                    !(spell[index + 1] == root[rootIndex] || spell[index + 1] == '>')) rootIndex++;
                            }
                            else if (pos.Form.Equals("III") && pos.SubTag.Equals("Imperfect")) rootIndex = 3;
                            else if (pos.Form.Equals("IV") && !pos.SubTag.Equals("Imperative")) {
                                if (!spell.Equals("yur")) rootIndex++;
                            }
                            else if (pos.Form.Equals("VI")) rootIndex = 3;
                        }
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> hamzaPlusShadda(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root.Replace("A", "'");
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (pos.Form.Equals("I") && pos.SubTag.Equals("Other Plural")) {
                if (spell.Equals(">a}im~")) {
                    index = 2;
                    segments.Add(new RootSegment() { Token = spell.Substring(0, index) });
                }
            }
            bool hamzaPast = false;
            do {
                var current = spell[index];
                if (current == '_') goto next;
                if (!hamzaPast) current = getHamzaReplacement(current);

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        if (!hamzaPast && root[rootIndex] == '\'') hamzaPast = true;
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> wawPlusShadda(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;

            int rootIndex = 0;
            string root = pos.Root;
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            do {
                if (spell[index] == '_') goto next;
                var current = spell[index];
                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> yaPlusShadda(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root; ;
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            do {
                var current = spell[index];
                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);

        }
        return list;
    }

    public List<RootForm> hamzaYaShadda(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root.Replace("A", "'");
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            if (spell[1] == '^') {
                spell = spell[0] + "aA" + spell.Substring(2);
            }

            bool hamzaPast = false;
            do {
                var current = spell[index];
                if (current == '_') goto next;

                if (!hamzaPast) current = getHamzaReplacement(current);

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        if (!hamzaPast && root[rootIndex] == '\'') hamzaPast = true;
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> plusWawShadda(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root;
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            do {
                var current = spell[index];
                if (current == '_') goto next;
                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> plusYaShadda(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root;
            string spell = pos.Spelling.Replace("_(", "y").Replace('.', 'y');
            List<RootSegment> segments = new();

            do {
                var current = spell[index];
                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> alifWawYa(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = "'" + pos.Root.Substring(1);
            string spell = pos.Spelling;
            List<RootSegment> segments = new();

            do {
                if (spell[index] == '_') goto next;
                var current = spell[index];
                if (current == '_') continue;
                if (current == '>' || current == '#') current = '\'';

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    public List<RootForm> quad(List<PatternSegment> source) {
        List<RootForm> list = new();
        for (int i = 0; i < source.Count; i++) {
            var pos = source[i];
            setSubTag(pos);
            int index = 0;
            int rootIndex = 0;
            string root = pos.Root.Replace("A", "'");
            string spell = pos.Spelling.Replace("w)", "'").Replace('&', '\'');
            List<RootSegment> segments = new();

            do {
                if (spell[index] == '_') goto next;
                var current = spell[index];

                if (rootIndex < root.Length) {
                    if (current == root[rootIndex]) {
                        rootIndex++;
                        segments.Add(addRootSegment(spell, rootIndex, ref index));
                    }
                    else segments.Add(addNonRootSegment(spell, ref index));
                }
                else segments.Add(addNonRootSegment(spell, ref index));

                next: index++;
            } while (index < spell.Length);

            addMatch(pos, segments, list);
        }
        return list;
    }

    int getMaddaLength(string spell, int index) {
        if (index == spell.Length) return 0;
        int length = 0;
        do {
            if (spell[index] == '`' || spell[index] == '^') length++;
            index++;
        } while (index < spell.Length);
        return length;
    }

    char getHamzaReplacement(char character) {
        return character switch {
            '#' => '\'',
            '<' => '\'',
            '>' => '\'',
            '&' => '\'',
            '{' => '\'',
            '}' => '\'',
            _ => character
        };
    }

    RootSegment addRootSegment(string spell, int no, ref int index) {
        string token;
        if (index < spell.Length - 1 && tatweels.Contains(spell[index + 1])) {
            token = "+" + spell[index + 1];
            index++;
        }
        else if (index < spell.Length - 1 && spell[index + 1] == '^') {
            token = "+" + spell[index + 1];
            index++;
        }
        else if (index < spell.Length - 2 && spell[index + 1] == '~') {
            var sub = "+" + spell.Substring(index + 1, 2);
            token = sub;
            index += 2;
        }
        else if (index == spell.Length - 2 && spell[index + 1] == '~') {
            token = "+" + spell[index + 1];
            index++;
        }
        else token = "+";
        return new RootSegment() {
            IsRoot = true,
            SegmentNo = no,
            Token = token
        };
    }

    RootSegment addNonRootSegment(string spell, ref int index) {
        char current = spell[index];

        if (current == '`') {
            current = spell[index - 1] switch {
                'Y' => '`',
                _ => 'A'
            };
        }
        else if (current == '.' || current == '(') current = 'y';
        else if (current == ',') current = 'w';

        string content;
        bool hasContent = index < spell.Length - 1;
        if (hasContent && tatweels.Contains(spell[index + 1])) {
            content = current.ToString() + spell[index + 1];
            index++;
        }
        else if (hasContent && (current == 'y' && spell[index + 1] == '^')) {
            content = current.ToString() + spell[index + 1];
            index++;
        }
        else if (hasContent && (current == 'w' && spell[index + 1] == '^')) {
            content = current.ToString() + spell[index + 1];
            index++;
        }
        else if (hasContent && (current == 'A' && spell[index + 1] == '^')) {
            content = current.ToString() + spell[index + 1];
            index++;
        }
        else if (current == 'Y') {
            int length = getMaddaLength(spell, index++);
            content = current + spell.Substring(index, length);
            index += length;
        }
        else if (hasContent && spell[index + 1] == '~' &&
                 index + 2 < spell.Length && tatweels.Contains(spell[index + 2])) {
            content = spell.Substring(index, 3);
            index += 2;
        }
        else if (hasContent && spell[index + 1] == '~') {
            content = current.ToString() + spell[index + 1];
            index++;
        }
        else content = current.ToString();
        return new RootSegment() { Token = content };
    }

    void setSubTag(PatternSegment pos) {
        if (possibleTags.Contains(pos.SubTag)) return;
        pos.SubTag = "Other";
        if (!string.IsNullOrEmpty(pos.Number)) {
            pos.SubTag = pos.SubTag + " " + pos.Number;
        }
    }

    void addMatch(PatternSegment pos, List<RootSegment> segments, List<RootForm> list) {
        var text = string.Join("", segments.Select(x => x.Token));
        int i = 0, j = list.Count - 1;
        RootForm match = null;
        while (i <= j) {
            if (list[i].Pattern.Equals(text) &&
                list[i].Root.Equals(pos.Root) &&
                list[i].Tag.Equals(pos.Tag) &&
                list[i].SubTag.Equals(pos.SubTag) &&
                list[i].Form.Equals(pos.Form)) {
                match = list[i];
                break;
            }
            if (list[j].Pattern.Equals(text) &&
                list[j].Root.Equals(pos.Root) &&
                list[j].Tag.Equals(pos.Tag) &&
                list[j].SubTag.Equals(pos.SubTag) &&
                list[j].Form.Equals(pos.Form)) {
                match = list[j];
                break;
            }
            i++;
            j--;
        }

        if (match is null) list.Add(new RootForm() {
            Root = pos.Root,
            Segments = segments,
            Tag = pos.Tag,
            SubTag = pos.SubTag,
            Form = pos.Form,
            Count = 1,
            References = new List<PatternReference>() {
                    new PatternReference() {
                        Spelling = pos.Spelling,
                        Root = pos.Root,
                        Tags = new List<string>(){ pos.Tag },
                        References = new List<string>(pos.Reference)
                    }
                }
        });
        else {
            match.Count++;
            var refMatch = match.References.FirstOrDefault(x => x.Spelling.Equals(pos.Spelling));
            if (refMatch is null) {
                match.References.Add(new PatternReference() {
                    Spelling = pos.Spelling,
                    Root = pos.Root,
                    Tags = new List<string>() { pos.Tag },
                    References = new List<string>(pos.Reference)
                });
            }
            else {
                if (!refMatch.Tags.Contains(pos.Tag)) {
                    refMatch.Tags.Add(pos.Tag);
                }
            }
        }
    }
}
