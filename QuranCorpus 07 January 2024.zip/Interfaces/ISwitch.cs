﻿interface ISwitch {
    string Query { get; set; }
    bool IsHoverPopupEnabled { get; set; }
    bool HasColor { get; set; }
    bool HasTransliteration { get; set; }
    bool HasWordByWordTranslation { get; set; }
    event Action ColorChanged;
    event Action TransliterationChanged;
    event Action WordByWordTranslationChanged;
}
