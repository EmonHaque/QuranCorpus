﻿interface IAddPage {
    List<PageType> Types { get; }
    void UpdateSource(object item);
    void AddPage();
    void ResetPage();
}
