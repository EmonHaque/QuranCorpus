﻿class PronounMatrixPage : Page {
    Grid content, masculineGrid, feminineGrid, undefinedGrid;
    TextBlockEnglish feminineSecond;

    public override PageType Type => PageType.PronounMatrix;
    public override UIElement Content => content;

    public PronounMatrixPage(bool isDemonstrative, bool isAttached) {
        if (!isDemonstrative) makePronounMatrix(isAttached);
        else makeDemonstrativeMatrix();
    }

    void makePronounMatrix(bool isAttached) {
        addPronounGrid();
        List<Pronoun> source = null;
        if (isAttached) {
            source = getAttached();
            HeaderText = "Attached";
            feminineSecond.Visibility = Visibility.Visible;
        }
        else {
            HeaderText = "Detached";
            source = getDetached();
            feminineSecond.Visibility = Visibility.Collapsed;
        }

        var groups = source
            .GroupBy(x => x.Gender)
            .Select(x => new {
                x.Key,
                Value = x
                    .GroupBy(x => x.Person)
                    .Select(x => new {
                        x.Key,
                        Value = x
                            .GroupBy(x => x.Form)
                            .Select(x => new {
                                x.Key,
                                Value = x
                                    .GroupBy(x => x.Spelling)
                                    .Select(x => new {
                                        x.Key,
                                        Tags = x.Select(x => x.Tag).Distinct().ToArray(),
                                        Value = x.SelectMany(x => x.References).ToList()
                                    })
                                    .ToList()
                            })
                            .ToList()
                    }).ToList()
                .ToList()
            }).ToList();

        List<PronounGrid> added = new();

        foreach (var gender in groups) {
            var grid = gender.Key switch {
                "Masculine" => masculineGrid,
                "Feminine" => feminineGrid,
                "Undefined" => undefinedGrid
            };

            foreach (var person in gender.Value) {
                var row = gender.Key.Equals("Undefined") ?
                    person.Key switch {
                        "First" => 0,
                        "Second" => 1,
                        "Third" => 2
                    } :
                    person.Key switch {
                        "Second" => 0,
                        "Third" => 1
                    };

                foreach (var form in person.Value) {
                    var column = form.Key switch {
                        "Singular" => 0,
                        "Dual" => 1,
                        "Plural" => 2
                    };

                    var stack = grid.Children.OfType<StackPanel>()
                       .First(e => Grid.GetRow(e) == row && Grid.GetColumn(e) == column);

                    foreach (var spell in form.Value) {
                        var formGrid = new PronounGrid() {
                            Content = spell.Key,
                            References = spell.Value,
                            Tags = spell.Tags.ToArray()
                        };
                        stack.Children.Add(formGrid);
                        added.Add(formGrid);
                    }
                }
            }
        }

        var duplicateGroups = added
            .GroupBy(x => x.Content)
            .Where(x => x.Count() > 1)
            .ToList();
        for (int i = 0; i < duplicateGroups.Count; i++) {
            Random rand = new();
            var brush = new SolidColorBrush(Color.FromRgb((byte)rand.Next(127, 255), (byte)rand.Next(127, 255), (byte)rand.Next(127, 255)));
            int count = duplicateGroups[i].Count();
            for (int j = 0; j < count; j++) {
                duplicateGroups[i].ElementAt(j).DuplicateBrush = brush;
                duplicateGroups[i].ElementAt(j).DuplicateCount = count;
            }
        }
    }

    void makeDemonstrativeMatrix() {
        HeaderText = "Demonstrative";

        addDemonstrativeGrid();
        var pronIndex = App.tags.IndexOf(App.tags.First(x => x.Name.Equals("DEM"))).ToString();
        List<Demonstrative> source = new();

        for (int i = 0; i < App.links.Count; i++) {
            var tas = App.links[i].Tags.Split('|');
            for (int j = 0; j < tas.Length; j++) {
                if (!tas[j].Equals(pronIndex)) continue;

                var link = App.links[i];
                var detailArray = link.Details.Split(',')[j].Split('|');

                var form = string.IsNullOrEmpty(detailArray[0]) ?
                    new Detail() { Name = "", Value = "" } :
                    App.details[Convert.ToInt32(detailArray[0])];

                var word = new Demonstrative() {
                    Spelling = App.spellings[Convert.ToInt32(link.SpellingGroupSimple.Split('|')[j])]
                };

                if (form.Value.Contains("masculine")) word.Gender = "Masculine";
                else if (form.Value.Contains("feminine")) word.Gender = "Feminine";
                else word.Gender = "Undefined";

                if (form.Value.Contains("singular")) word.Form = "Singular";
                else if (form.Value.Contains("plural")) word.Form = "Plural";
                else if (form.Value.Contains("dual")) word.Form = "Dual";
                else word.Form = "Undefined";

                source.Add(word);
                word.References.Add(link.Reference);
            }
        }

        var groups = source
            .GroupBy(x => x.Gender)
            .Select(x => new {
                x.Key,
                Value = x
                     .GroupBy(x => x.Form)
                     .Select(x => new {
                         x.Key,
                         Value = x
                             .GroupBy(x => x.Spelling)
                             .Select(x => new {
                                 x.Key,
                                 Value = x.SelectMany(x => x.References).ToList()
                             })
                             .ToList()
                     })
                     .ToList()
            })
            .ToList();

        foreach (var gender in groups) {
            var grid = gender.Key switch {
                "Masculine" => masculineGrid,
                "Feminine" => feminineGrid,
                "Undefined" => undefinedGrid
            };

            foreach (var form in gender.Value) {
                var column = form.Key switch {
                    "Singular" => 0,
                    "Dual" => 1,
                    "Plural" => 2,
                    "Undefined" => 3
                };

                var stack = grid.Children.OfType<StackPanel>()
                   .First(e => Grid.GetColumn(e) == column);

                foreach (var spell in form.Value) {
                    var formGrid = new DemonstrativeGrid() {
                        Content = spell.Key,
                        References = spell.Value
                    };
                    stack.Children.Add(formGrid);
                }
            }

        }
    }

    List<Pronoun> getAttached() {
        var pronIndex = App.tags.IndexOf(App.tags.First(x => x.Name.Equals("PRON"))).ToString();
        List<Pronoun> list = new();
        for (int i = 0; i < App.links.Count; i++) {
            var tas = App.links[i].Tags.Split('|');
            if (tas.Length == 1) continue;

            for (int j = 0; j < tas.Length; j++) {
                if (!tas[j].Equals(pronIndex)) continue;

                var link = App.links[i];
                var detailArray = link.Details.Split(',')[j].Split('|');
                var tag = "";
                Detail form = null;
                if (detailArray.Length > 1) {
                    tag = App.details[Convert.ToInt32(detailArray[0])].Value;
                    form = App.details[Convert.ToInt32(detailArray[1])];
                }
                else {
                    tag = "Undefined";
                    form = App.details[Convert.ToInt32(detailArray[0])];
                }

                var word = new Pronoun() {
                    Tag = tag,
                    Spelling = App.spellings[Convert.ToInt32(link.SpellingGroupSimple.Split('|')[j])]
                };

                if (form.Value.Contains("masculine")) word.Gender = "Masculine";
                else if (form.Value.Contains("feminine")) word.Gender = "Feminine";
                else word.Gender = "Undefined";

                if (form.Value.Contains("singular")) word.Form = "Singular";
                else if (form.Value.Contains("plural")) word.Form = "Plural";
                else if (form.Value.Contains("dual")) word.Form = "Dual";

                if (form.Name.StartsWith("1")) word.Person = "First";
                else if (form.Name.StartsWith("2")) word.Person = "Second";
                else if (form.Name.StartsWith("3")) word.Person = "Third";
                else word.Person = "Undefined";

                list.Add(word);
                word.References.Add(link.Reference);
            }
        }

        return list;
    }

    List<Pronoun> getDetached() {
        var pronIndex = App.tags.IndexOf(App.tags.First(x => x.Name.Equals("PRON"))).ToString();
        List<Pronoun> list = new();

        for (int i = 0; i < App.links.Count; i++) {
            var tas = App.links[i].Tags.Split('|');
            if (tas.Length > 1) continue;

            if (!tas[0].Equals(pronIndex)) continue;

            var link = App.links[i];
            var detailArray = link.Details.Split('|');
            var tag = "";
            Detail form = null;
            if (detailArray.Length > 1) {
                tag = App.details[Convert.ToInt32(detailArray[0])].Value;
                form = App.details[Convert.ToInt32(detailArray[1])];
            }
            else {
                tag = "Undefined";
                form = App.details[Convert.ToInt32(detailArray[0])];
            }

            var word = new Pronoun() {
                Tag = tag,
                Spelling = App.spellings[Convert.ToInt32(link.SpellingGroupSimple)]
            };

            if (form.Value.Contains("masculine")) word.Gender = "Masculine";
            else if (form.Value.Contains("feminine")) word.Gender = "Feminine";
            else word.Gender = "Undefined";

            if (form.Value.Contains("singular")) word.Form = "Singular";
            else if (form.Value.Contains("plural")) word.Form = "Plural";
            else if (form.Value.Contains("dual")) word.Form = "Dual";

            if (form.Name.StartsWith("1")) word.Person = "First";
            else if (form.Name.StartsWith("2")) word.Person = "Second";
            else if (form.Name.StartsWith("3")) word.Person = "Third";
            else word.Person = "Undefined";

            list.Add(word);
            word.References.Add(link.Reference);
        }

        return list;
    }

    void addPronounGrid() {
        double personWidth = 70;
        var singularBlock = new TextBlockEnglish() {
            Text = "Singular",
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Center
        };
        var dualBlock = new TextBlockEnglish() {
            Text = "Dual",
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Center
        };
        var pluralBlock = new TextBlockEnglish() {
            Text = "Plural",
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Center
        };

        var masculineBlock = new TextBlockEnglish() {
            Text = "Masculine",
            FontWeight = FontWeights.Bold,
            VerticalAlignment = VerticalAlignment.Center
        };
        var feminineBlock = new TextBlockEnglish() {
            Text = "Feminine",
            FontWeight = FontWeights.Bold,
            VerticalAlignment = VerticalAlignment.Center
        };
        var undefinedBlock = new TextBlockEnglish() {
            Text = "Undefined",
            FontWeight = FontWeights.Bold,
            VerticalAlignment = VerticalAlignment.Center
        };

        var masculineSecond = new TextBlockEnglish() {
            Text = "Second Person",
            TextWrapping = TextWrapping.Wrap,
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center
        };
        var masculineThird = new TextBlockEnglish() {
            Text = "Third Person",
            TextWrapping = TextWrapping.Wrap,
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center
        };
        feminineSecond = new TextBlockEnglish() {
            Visibility = Visibility.Collapsed,
            Text = "Second Person",
            TextWrapping = TextWrapping.Wrap,
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center
        };
        var feminineThird = new TextBlockEnglish() {
            Text = "Third Person",
            TextWrapping = TextWrapping.Wrap,
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center
        };
        var undefinedFirst = new TextBlockEnglish() {
            Text = "First Person",
            TextWrapping = TextWrapping.Wrap,
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center
        };
        var undefinedSecond = new TextBlockEnglish() {
            Text = "Second Person",
            TextWrapping = TextWrapping.Wrap,
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center
        };
        var undefinedThird = new TextBlockEnglish() {
            Text = "Third Person",
            TextWrapping = TextWrapping.Wrap,
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Right,
            VerticalAlignment = VerticalAlignment.Center
        };

        Grid.SetColumn(masculineSecond, 3);
        Grid.SetColumn(masculineThird, 3);
        Grid.SetRow(masculineThird, 1);
        masculineGrid = new Grid() {
            ShowGridLines = true,
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(personWidth) }
            },
            Children = { masculineSecond, masculineThird }
        };

        Grid.SetColumn(feminineSecond, 3);
        Grid.SetColumn(feminineThird, 3);
        Grid.SetRow(feminineThird, 1);
        feminineGrid = new Grid() {
            ShowGridLines = true,
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(personWidth) }
            },
            Children = { feminineSecond, feminineThird }
        };

        Grid.SetColumn(undefinedFirst, 3);
        Grid.SetColumn(undefinedSecond, 3);
        Grid.SetColumn(undefinedThird, 3);
        Grid.SetRow(undefinedSecond, 1);
        Grid.SetRow(undefinedThird, 2);
        undefinedGrid = new Grid() {
            ShowGridLines = true,
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(),
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition() { Width = new GridLength(personWidth) }
            },
            Children = { undefinedFirst, undefinedSecond, undefinedThird }
        };

        for (int row = 0; row < 3; row++) {
            for (int column = 0; column < 3; column++) {
                var stack = new StackPanel() {
                    VerticalAlignment = VerticalAlignment.Center
                };
                Grid.SetRow(stack, row);
                Grid.SetColumn(stack, column);
                undefinedGrid.Children.Add(stack);
            }
        }

        for (int row = 0; row < 2; row++) {
            for (int column = 0; column < 3; column++) {
                var stack = new StackPanel() {
                    VerticalAlignment = VerticalAlignment.Center
                };
                Grid.SetRow(stack, row);
                Grid.SetColumn(stack, column);
                masculineGrid.Children.Add(stack);

                stack = new StackPanel() {
                    VerticalAlignment = VerticalAlignment.Center
                };
                Grid.SetRow(stack, row);
                Grid.SetColumn(stack, column);
                feminineGrid.Children.Add(stack);
            }
        }

        Grid.SetColumn(singularBlock, 1);
        Grid.SetColumn(dualBlock, 2);
        Grid.SetColumn(pluralBlock, 3);

        Grid.SetRow(feminineBlock, 1);
        Grid.SetRow(undefinedBlock, 2);

        Grid.SetColumn(masculineGrid, 1);
        Grid.SetColumnSpan(masculineGrid, 4);

        Grid.SetRow(feminineGrid, 1);
        Grid.SetColumn(feminineGrid, 1);
        Grid.SetColumnSpan(feminineGrid, 4);

        Grid.SetRow(undefinedGrid, 2);
        Grid.SetColumn(undefinedGrid, 1);
        Grid.SetColumnSpan(undefinedGrid, 4);

        var headerGrid = new Grid() {
            Margin = new Thickness(5, 5, 5 + Constants.ScrollBarThickness, 0),
            ShowGridLines = true,
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto}
            },
            ColumnDefinitions = {
                new ColumnDefinition() { Width = new GridLength(100) },
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition() { Width = new GridLength(personWidth) }
            },
            Children = { singularBlock, dualBlock, pluralBlock }
        };

        var contentGrid = new Grid() {
            Margin = new Thickness(5, 0, 5, 5),
            ShowGridLines = true,
            ColumnDefinitions = {
                new ColumnDefinition() { Width = new GridLength(100) },
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition() { Width = new GridLength(personWidth) }
            },
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(),
                new RowDefinition()
            },
            Children = {
                masculineBlock, masculineGrid,
                feminineBlock, feminineGrid,
                undefinedBlock, undefinedGrid }
        };

        var scroll = new ScrollViewer() { Content = contentGrid };
        Grid.SetRow(scroll, 1);
        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { headerGrid, scroll }
        };
    }

    void addDemonstrativeGrid() {
        var singularBlock = new TextBlockEnglish() {
            Text = "Singular",
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Center
        };
        var dualBlock = new TextBlockEnglish() {
            Text = "Dual",
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Center
        };
        var pluralBlock = new TextBlockEnglish() {
            Text = "Plural",
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Center
        };
        var undefinedNumberBlock = new TextBlockEnglish() {
            Text = "Undefined",
            FontWeight = FontWeights.Bold,
            HorizontalAlignment = HorizontalAlignment.Center
        };

        var masculineBlock = new TextBlockEnglish() {
            Text = "Masculine",
            FontWeight = FontWeights.Bold,
            VerticalAlignment = VerticalAlignment.Center
        };
        var feminineBlock = new TextBlockEnglish() {
            Text = "Feminine",
            FontWeight = FontWeights.Bold,
            VerticalAlignment = VerticalAlignment.Center
        };
        var undefinedBlock = new TextBlockEnglish() {
            Text = "Undefined",
            FontWeight = FontWeights.Bold,
            VerticalAlignment = VerticalAlignment.Center
        };

        masculineGrid = new Grid() {
            ShowGridLines = true,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition()
            },
        };

        feminineGrid = new Grid() {
            ShowGridLines = true,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition()
            }
        };

        undefinedGrid = new Grid() {
            ShowGridLines = true,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition()
            }
        };

        for (int column = 0; column < 4; column++) {
            var stack = new StackPanel() {
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(stack, column);
            masculineGrid.Children.Add(stack);

            stack = new StackPanel() {
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(stack, column);
            feminineGrid.Children.Add(stack);

            stack = new StackPanel() {
                VerticalAlignment = VerticalAlignment.Center
            };
            Grid.SetColumn(stack, column);
            undefinedGrid.Children.Add(stack);
        }

        Grid.SetColumn(singularBlock, 1);
        Grid.SetColumn(dualBlock, 2);
        Grid.SetColumn(pluralBlock, 3);
        Grid.SetColumn(undefinedNumberBlock, 4);

        Grid.SetRow(feminineBlock, 1);
        Grid.SetRow(undefinedBlock, 2);

        Grid.SetColumn(masculineGrid, 1);
        Grid.SetColumnSpan(masculineGrid, 4);

        Grid.SetRow(feminineGrid, 1);
        Grid.SetColumn(feminineGrid, 1);
        Grid.SetColumnSpan(feminineGrid, 4);

        Grid.SetRow(undefinedGrid, 2);
        Grid.SetColumn(undefinedGrid, 1);
        Grid.SetColumnSpan(undefinedGrid, 4);

        var HeaderGrid = new Grid() {
            Margin = new Thickness(5, 5, 5 + Constants.ScrollBarThickness, 0),
            ShowGridLines = true,
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(){Height = GridLength.Auto}
            },
            ColumnDefinitions = {
                new ColumnDefinition() { Width = new GridLength(100) },
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition()
            },
            Children = { singularBlock, dualBlock, pluralBlock, undefinedNumberBlock }
        };

        var contentGrid = new Grid() {
            Margin = new Thickness(5, 0, 5, 5),
            ShowGridLines = true,
            ColumnDefinitions = {
                new ColumnDefinition() { Width = new GridLength(100) },
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition(),
                new ColumnDefinition()
            },
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(),
                new RowDefinition()
            },
            Children = {
                masculineBlock, masculineGrid,
                feminineBlock, feminineGrid,
                undefinedBlock, undefinedGrid }
        };

        var scroll = new ScrollViewer() { Content = contentGrid };
        Grid.SetRow(scroll, 1);
        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { HeaderGrid, scroll }
        };
    }

    class Pronoun {
        public string Tag { get; set; }
        public string Gender { get; set; }
        public string Person { get; set; }
        public string Form { get; set; }
        public string Spelling { get; set; }
        public List<string> References { get; set; }

        public Pronoun() {
            References = new();
        }
    }

    class Demonstrative {
        public bool IsAttached { get; set; }
        public string Gender { get; set; }
        public string Form { get; set; }
        public string Spelling { get; set; }
        public List<string> References { get; set; }

        public Demonstrative() {
            References = new();
        }
    }

    class PronounGrid : Border {
        bool isSorted;
        TextBlockArabic word;
        TextBlockEnglish count, duplicateCount;
        StackPanel tagPanel;

        string content;
        public string Content {
            get { return content; }
            set { content = value; word.Text = content.toArabic(); }
        }
        List<string> references;
        public List<string> References {
            get { return references; }
            set {
                references = value;
                count.Text = value.Count.ToString("N0");
            }
        }
        public int DuplicateCount {
            set => duplicateCount.Text = value.ToString("N0");
        }
        public string[] Tags {
            set {
                for (int i = 0; i < value.Length; i++) {
                    tagPanel.Children.Add(new TextBlockEnglish() { Text = value[i] });
                }
            }
        }
        public Brush DuplicateBrush {
            set {
                word.Foreground = value;
                duplicateCount.Foreground = value;
            }
        }

        public PronounGrid() {
            FlowDirection = FlowDirection.LeftToRight;
            Margin = new Thickness(5);
            Padding = new Thickness(5);
            CornerRadius = new CornerRadius(10);
            BorderThickness = new Thickness(Constants.BottomLineThickness);
            BorderBrush = Brushes.Transparent;
            Background = Brushes.Transparent;

            word = new TextBlockArabic() {
                VerticalAlignment = VerticalAlignment.Center
            };
            duplicateCount = new TextBlockEnglish() {
                Margin = new Thickness(10, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            };
            tagPanel = new StackPanel() { VerticalAlignment = VerticalAlignment.Center };
            count = new TextBlockEnglish() {
                Margin = new Thickness(0, 0, 5, 0),
                VerticalAlignment = VerticalAlignment.Center
            };

            Grid.SetColumn(tagPanel, 1);
            Grid.SetColumn(duplicateCount, 2);
            Grid.SetColumn(word, 3);
            Child = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){ Width = new GridLength(40) },
                    new ColumnDefinition(){ Width = new GridLength(1.25, GridUnitType.Star) },
                    new ColumnDefinition(){ Width = new GridLength(40) },
                    new ColumnDefinition()
                },
                Children = { count, duplicateCount, tagPanel, word }
            };
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            base.OnMouseEnter(e);
            BorderBrush = Brushes.LightGray;
        }

        protected override void OnMouseLeave(MouseEventArgs e) {
            base.OnMouseLeave(e);
            BorderBrush = Brushes.Transparent;
        }

        protected override void OnPreviewMouseDown(MouseButtonEventArgs e) {
            base.OnPreviewMouseUp(e);
            if (e.ChangedButton != MouseButton.Left) return;
            if (e.ClickCount != 2) return;
            if (!isSorted) {
                References.Sort(new SurahAyahWordNoComparator());
                isSorted = true;
            }
            ((App)Application.Current).Pages.addMatchPage(Content, References);
        }
    }

    class DemonstrativeGrid : Border {
        bool isSorted;
        TextBlockArabic word;
        TextBlockEnglish count;

        string content;
        public string Content {
            get { return content; }
            set { content = value; word.Text = content.toArabic(); }
        }
        List<string> references;
        public List<string> References {
            get { return references; }
            set { 
                references = value;
                count.Text = value.Count.ToString("N0");
            }
        }

        public DemonstrativeGrid() {
            FlowDirection = FlowDirection.LeftToRight;
            Margin = new Thickness(5);
            Padding = new Thickness(5);
            CornerRadius = new CornerRadius(10);
            BorderThickness = new Thickness(Constants.BottomLineThickness);
            BorderBrush = Brushes.Transparent;
            Background = Brushes.Transparent;

            word = new TextBlockArabic() {
                VerticalAlignment = VerticalAlignment.Center
            };
            count = new TextBlockEnglish() {
                Margin = new Thickness(10, 0, 0, 0),
                VerticalAlignment = VerticalAlignment.Center
            };

            Grid.SetColumn(word, 1);
            Child = new Grid() {
                ColumnDefinitions = {
                    new ColumnDefinition(){ Width = new GridLength(60) },
                    new ColumnDefinition()
                },
                Children = { count, word }
            };
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            base.OnMouseEnter(e);
            BorderBrush = Brushes.LightGray;
        }

        protected override void OnMouseLeave(MouseEventArgs e) {
            base.OnMouseLeave(e);
            BorderBrush = Brushes.Transparent;
        }

        protected override void OnPreviewMouseDown(MouseButtonEventArgs e) {
            base.OnPreviewMouseUp(e);
            if (e.ChangedButton != MouseButton.Left) return;
            if (e.ClickCount != 2) return;
            if (!isSorted) {
                References.Sort(new SurahAyahWordNoComparator());
                isSorted = true;
            }
            ((App)Application.Current).Pages.addMatchPage(Content, References);
        }
    }
}
