﻿public class TransitButtonNumber : TransitButton
{
    int count;
    Border container;
    TextBlock block;
    protected override FrameworkElement element => container;
    INotify notifier;
    public INotify Notifier {
        get { return notifier; }
        set { notifier = value; notifier.CountChanged += onCountChanged; }
    }

    public TransitButtonNumber(double widthAndHeight) : base(widthAndHeight) {
        normalColor = Colors.DarkBlue;
        highlightColor = Colors.Coral;
        selectedColor = Colors.Black;
        brush = new SolidColorBrush(normalColor);

        container.CornerRadius = new CornerRadius(widthAndHeight / 2);
        container.Background = brush;
    }

    void onCountChanged(int number) {

        Application.Current.Dispatcher.InvokeAsync(() => {
            block.Text = number.ToString();
            count = number;
            if (brush.Color == normalColor) {
                var anim = new ColorAnimation() {
                    Duration = TimeSpan.FromMilliseconds(333),
                    From = Colors.Red,
                    To = normalColor,
                    RepeatBehavior = new RepeatBehavior(3)
                };
                brush.BeginAnimation(SolidColorBrush.ColorProperty, anim);
            }
        }, DispatcherPriority.Background);


    }
    protected override void initializeElement() {
        block = new TextBlock() {
            FontSize = 8,
            Text = "0",
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center
        };
        container = new Border() {
            BorderThickness = new Thickness(1),
            Child = block
        };
    }
}
