﻿class TagTemplate : Grid {
    TextBlockEnglish name, count;

    public TagTemplate() {
        name = new TextBlockEnglish();
        count = new TextBlockEnglish() { HorizontalAlignment = HorizontalAlignment.Right };
        SetColumn(count, 1);

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

        Children.Add(name);
        Children.Add(count);
        name.SetBinding(TextBlock.TextProperty, new Binding(nameof(TagItem.Name)));
        count.SetBinding(TextBlock.TextProperty, new Binding(nameof(TagItem.Count)) { StringFormat = "N0"});
    }

    protected override void OnDragEnter(DragEventArgs e) {
        base.OnDragEnter(e);
        SetValue(TextElement.FontWeightProperty, FontWeights.Bold);
        Background = Brushes.Black;
    }

    protected override void OnDragLeave(DragEventArgs e) {
        base.OnDragLeave(e);
        SetValue(TextElement.FontWeightProperty, FontWeights.Normal);
        Background = null;
    }

    protected override void OnDrop(DragEventArgs e) {
        base.OnDragOver(e);
        SetValue(TextElement.FontWeightProperty, FontWeights.Normal);
        Background = null;
    }
}

