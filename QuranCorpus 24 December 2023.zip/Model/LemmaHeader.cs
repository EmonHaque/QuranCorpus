﻿class LemmaHeader {
    public string Root { get; set; }
    public List<Lemma> Items { get; set; }
}
