﻿class PatternPage : Page {
    bool isLoaded;
    string query;
    StringBuilder builder = new();

    ProgressBar progress;
    WaterBox queryBox;
    Toggle lengthToggle;
    Run spellingCount, referenceCount;
    TextBlockEnglish meaningCount;
    Run morphCount, morphTotal;
    ContentListBox spellings, listMorph;
    ListBox listMeaning;
    List<Pattern> corpus, simple;
    List<Morph> source;
    Grid content, queryGrid;
    CancellationTokenSource terminator;
    ICollectionView spellingsView;

    public override PageType Type => PageType.Pattern;
    public override UIElement Content => content;

    public PatternPage() {
        HeaderText = "Spellings";
        terminator = new CancellationTokenSource();
        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };
        queryBox = new WaterBox() {
            Icon = Icons.Search,
            Hint = "Spelling (pattern eg. +a+a+)"
        };
        lengthToggle = new Toggle() {
            Margin = new Thickness(5, 0, 0, 0),
            VerticalAlignment = VerticalAlignment.Center,
            OnIcon = Icons.Equal,
            OffIcon = Icons.Approximate,
            OnTip = "equal length",
            OffTip = "equal or greater length"
        };
        var buckwalterPop = new BuckwalterPopup() {
            Margin = new Thickness(5, 0, 5, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        spellingCount = new Run();
        referenceCount = new Run() { Foreground = Brushes.Gray };
        var spellRefCount = new TextBlockEnglish() {
            Inlines = { spellingCount, new Run(" | ") { Foreground = Brushes.Gray }, referenceCount },
            VerticalAlignment = VerticalAlignment.Center
        };
        Grid.SetColumn(lengthToggle, 1);
        Grid.SetColumn(buckwalterPop, 2);
        Grid.SetColumn(spellRefCount, 3);
        queryGrid = new Grid() {
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { queryBox, lengthToggle, buckwalterPop, spellRefCount }
        };

        morphCount = new Run();
        morphTotal = new Run();
        var listCountBlock = new TextBlockEnglish() {
            HorizontalAlignment = HorizontalAlignment.Left,
            FlowDirection = FlowDirection.LeftToRight,
            Inlines = { morphTotal, new Run(" in "), morphCount }
        };
        spellings = new ContentListBox() {
            Margin = new Thickness(5, 5, 0, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(SpellingTemplate))
            }
        };
        spellings.SetValue(Grid.IsSharedSizeScopeProperty, true);
        spellings.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

        var separator = new Rectangle() {
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };
        listMorph = new ContentListBox() {
            Template = new ListBoxLedgerTemplate(),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MorphListTemplate))
            }
        };
        listMorph.SetValue(Grid.IsSharedSizeScopeProperty, true);

        var splitter = new GridSplitter() {
            Margin = new Thickness(0, 5, 0, 0),
            ResizeDirection = GridResizeDirection.Rows,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Template = new SplitterTemplate()
        };

        meaningCount = new TextBlockEnglish() { HorizontalAlignment = HorizontalAlignment.Left };
        listMeaning = new ListBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 5, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MeaningListTemplate))
            }
        };
        listMeaning.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMeaning.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

        Grid.SetColumn(queryGrid, 2);
        Grid.SetColumn(separator, 1);
        Grid.SetColumn(spellings, 2);

        Grid.SetRow(queryGrid, 1);
        Grid.SetRow(listCountBlock, 1);
        Grid.SetRow(separator, 1);

        Grid.SetRow(spellings, 2);
        Grid.SetRow(listMorph, 2);
        Grid.SetRow(splitter, 3);
        Grid.SetRow(meaningCount, 3);
        Grid.SetRow(listMeaning, 4);

        Grid.SetRowSpan(spellings, 5);
        Grid.SetRowSpan(separator, 5);
        Grid.SetColumnSpan(progress, 3);

        content = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition() { Width = new GridLength(10) },
                new ColumnDefinition()
            },
            RowDefinitions = {
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition() { Height = new GridLength(2.5, GridUnitType.Star) },
                new RowDefinition() { Height = new GridLength(15) },
                new RowDefinition()
            },
            Children = { progress, queryGrid, listCountBlock, separator, spellings, listMorph, splitter, meaningCount, listMeaning }
        };

        spellingCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = spellings,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        referenceCount.SetBinding(Run.TextProperty, new MultiBinding() {
            Bindings = {
                new Binding("Items.Count") { Source = spellings },
                new Binding("Items") { Source = spellings }
            },
            Mode = BindingMode.OneWay,
            StringFormat = "N0",
            Converter = new ReferenceCountConverter()
        });
        morphCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMorph,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        meaningCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMeaning,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });


        spellings.Fired += onSpellingFired;
        spellings.MouseRightButtonUp += onRightButtonUp;
        listMorph.Fired += onMorphFired;
        listMeaning.MouseDoubleClick += onMeaningDoubleClick;
        queryBox.KeyUp += onQuery;
        DataObject.AddPastingHandler(queryBox, onPste);
        App.global.PropertyChanged += onTranscriptChanged;
        content.Loaded += onLoaded;
        TabView.Split += onSplit;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        if (isLoaded) return;
        isLoaded = true; // why is this is loaded?
        updateTranscript();
    }

    void onSpellingFired(object item) {
        var pattern = (Pattern)item;
        progress.IsIndeterminate = true;

        Task.Run(() => {
            int index = 0;
            source = new List<Morph>();
            for (int i = 0; i < pattern.Reference.Count; i++) {
                if (terminator.IsCancellationRequested) break;
                while (!App.links[index].Reference.Equals(pattern.Reference[i])) index++;
                source.Add(App.links[index].toMorph(builder));
            }
            if (!terminator.IsCancellationRequested) {
                var listSource = source
                  .GroupBy(x => new { Word = x.Segments[App.global.Transcript], x.Explanation })
                  .Select(x => new Morph() {
                      Segments = x.First().Segments,
                      Count = x.Count(),
                      Tags = x.First().Tags,
                      Explanation = x.Key.Explanation,
                      References = x.SelectMany(x => x.References).ToList()
                  })
                  .OrderByDescending(x => x.Count)
                  .ToList();

                App.Current.Dispatcher.Invoke(() => {
                    listMorph.ItemsSource = listSource;
                    listMorph.ScrollIntoView(listSource[0]);
                    morphTotal.Text = listSource.Sum(x => x.Count).ToString("N0");
                    progress.IsIndeterminate = false;
                });
            }

        }, terminator.Token);
    }

    void onMorphFired(object item) {
        var meaningSource = ((Morph)item).References;
        listMeaning.ItemsSource = meaningSource;
        listMeaning.ScrollIntoView(meaningSource[0]);
    }

    void onMeaningDoubleClick(object sender, MouseButtonEventArgs e) {
        if (listMeaning.SelectedItem is null) return; // can be null?
        var item = (Tuple<string, string, string>)listMeaning.SelectedItem;
        ((App)Application.Current).FocusedControl.addSurahPage(item.Item1);
    }

    void onPste(object sender, DataObjectPastingEventArgs e) {
        var clip = e.DataObject.GetData(typeof(string)) as string;
        if (clip is null) return;
        var transcript = "";
        for (int i = 0; i < clip.Length; i++) {
            var hex = ((uint)clip[i]).ToString("X4");
            try {
                transcript += App.characters.First(x => x.Arabic.Equals(hex)).English;
            }
            catch {
                transcript += clip[i];
            }
        }
        queryBox.setText(transcript);
        e.CancelCommand();
    }

    void onQuery(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        query = queryBox.Text.Trim();
        spellingsView.Refresh();
    }

    void onTranscriptChanged(object? sender, PropertyChangedEventArgs e) {
        if (!e.PropertyName.Equals(nameof(App.global.Transcript))) return;

        spellingsView = CollectionViewSource.GetDefaultView(App.global.Transcript == 1 ? simple : corpus);
        spellingsView.Filter = filter;
        spellings.ItemsSource = spellingsView;
    }

    void onSplit() {
        spellings.Items.Refresh();
        listMorph.Items.Refresh();
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) {
        if (spellings.SelectedItem is null) return;

        var item = (Pattern)spellings.SelectedItem;
        var transcripts = new string[2];
        Lemma lemma;

        if (string.IsNullOrEmpty(item.RootOrLemma)) {
            transcripts[App.global.Transcript] = item.Spelling;
            lemma = new Lemma() {
                Transcripts = transcripts,
                References = item.Reference
            };
        }
        else {
            transcripts[App.global.Transcript] = item.RootOrLemma;
            List<Pattern> list = App.global.Transcript == 1 ? simple : corpus;

            if (item.HasRoot) {
                var references = list.Where(x => x.HasRoot && x.RootOrLemma.Equals(item.RootOrLemma)).SelectMany(x => x.Reference).ToList();
                references.Sort(new SurahAyahWordNoComparator());
                lemma = new Lemma() {
                    Transcripts = transcripts,
                    Root = new string[] { item.RootOrLemma, "" },
                    References = references
                };
            }
            else {
                var references = list.Where(x => !x.HasRoot && x.RootOrLemma.Equals(item.RootOrLemma)).SelectMany(x => x.Reference).ToList();
                references.Sort(new SurahAyahWordNoComparator());
                lemma = new Lemma() {
                    Transcripts = transcripts,
                    References = references
                };
            }
        }
        ((App)Application.Current).FocusedControl.addLemmaPage(lemma);
    }

    void updateTranscript() {
        spellings.ItemsSource = null;
        queryGrid.IsEnabled = false;
        progress.IsIndeterminate = true;

        Task.Run(() => {
            corpus = new List<Pattern>();
            simple = new List<Pattern>();
            int linkIndex = 0;

            while (linkIndex < App.links.Count) {
                if (terminator.IsCancellationRequested) break;
                var item = App.links[linkIndex];
                if (App.links[linkIndex].SpellingGroupSimple.Contains('|')) {
                    var sParts = item.SpellingGroupSimple.Split('|');
                    var cParts = item.SpellingGroupCorpus.Split('|');
                    var tParts = item.Tags.Split('|');
                    var parts = item.LemmaIndices.Split('|');

                    for (int i = 0; i < sParts.Length; i++) {
                        bool hasRoot = !string.IsNullOrEmpty(item.Root);
                        string sRootLemma = "";
                        string cRootLemma = "";

                        if (hasRoot) {
                            if (item.RootIndex.Equals(i.ToString())) {
                                if (item.Root.Contains('|')) {
                                    cRootLemma = string.Join("|", item.Root.Split('|').Select(x => App.roots[Convert.ToInt32(x)]));
                                    sRootLemma = string.Join("|", item.Root.Split('|').Select(x => App.roots[Convert.ToInt32(x)]));
                                }
                                else {
                                    cRootLemma = App.roots[Convert.ToInt32(item.Root)];
                                    sRootLemma = App.roots[Convert.ToInt32(item.Root)];
                                }
                            }
                            else {
                                if (!string.IsNullOrEmpty(item.LemmaSimple)) {

                                    int index = -1;
                                    for (int j = 0; j < parts.Length; j++) {
                                        if (parts[j].Equals(i.ToString())) {
                                            index = j;
                                            break;
                                        }
                                    }
                                    if (index != -1) {
                                        var lemmas = item.LemmaSimple.Split('|');
                                        sRootLemma = App.lemmas[Convert.ToInt32(lemmas[index])];

                                        lemmas = item.LemmaCorpus.Split('|');
                                        cRootLemma = App.lemmas[Convert.ToInt32(lemmas[index])];
                                    }
                                }
                            }
                        }
                        else {
                            if (!string.IsNullOrEmpty(item.LemmaSimple)) {

                                int index = -1;
                                for (int j = 0; j < parts.Length; j++) {
                                    if (parts[j].Equals(i.ToString())) {
                                        index = j;
                                        break;
                                    }
                                }
                                if (index != -1) {
                                    var lemmas = item.LemmaSimple.Split('|');
                                    sRootLemma = App.lemmas[Convert.ToInt32(lemmas[index])];

                                    lemmas = item.LemmaCorpus.Split('|');
                                    cRootLemma = App.lemmas[Convert.ToInt32(lemmas[index])];
                                }
                            }
                        }

                        var sSpell = App.spellings[Convert.ToInt32(sParts[i])];
                        var cSpell = App.spellings[Convert.ToInt32(cParts[i])];

                        var sMatch = getMatch(sSpell, sRootLemma, simple);
                        var cMatch = getMatch(cSpell, cRootLemma, corpus);

                        if (sMatch is null) {
                            simple.Add(new Pattern() {
                                Spelling = sSpell,
                                HasRoot = hasRoot,
                                RootOrLemma = sRootLemma,
                                Tags = new List<string>() { tParts[i] },
                                Reference = new List<string>() { item.Reference }
                            });
                        }
                        else {
                            if (!sMatch.Tags.Contains(tParts[i])) {
                                sMatch.Tags.Add(tParts[i]);
                            }
                            sMatch.Reference.Add(item.Reference);
                        }
                        if (cMatch is null) {
                            corpus.Add(new Pattern() {
                                Spelling = cSpell,
                                HasRoot = hasRoot,
                                RootOrLemma = cRootLemma,
                                Tags = new List<string>() { tParts[i] },
                                Reference = new List<string>() { item.Reference }
                            });
                        }
                        else {
                            if (!cMatch.Tags.Contains(tParts[i])) {
                                cMatch.Tags.Add(tParts[i]);
                            }
                            cMatch.Reference.Add(item.Reference);
                        }
                    }
                }
                else {
                    bool hasRoot = !string.IsNullOrEmpty(item.Root);
                    string sRootLemma = "";
                    string cRootLemma = "";
                    if (hasRoot) {
                        sRootLemma = cRootLemma = App.roots[Convert.ToInt32(item.Root)];
                    }
                    else {
                        if (!string.IsNullOrEmpty(item.LemmaSimple)) {
                            sRootLemma = App.lemmas[Convert.ToInt32(item.LemmaSimple)];
                            cRootLemma = App.lemmas[Convert.ToInt32(item.LemmaCorpus)];
                        }
                    }
                    var sSpell = App.spellings[Convert.ToInt32(item.SpellingGroupSimple)];
                    var cSpell = App.spellings[Convert.ToInt32(item.SpellingGroupCorpus)];
                    var sMatch = getMatch(sSpell, sRootLemma, simple);
                    var cMatch = getMatch(cSpell, cRootLemma, corpus);

                    if (sMatch is null) {
                        simple.Add(new Pattern() {
                            Spelling = sSpell,
                            HasRoot = hasRoot,
                            RootOrLemma = sRootLemma,
                            Tags = new List<string>() { item.Tags },
                            Reference = new List<string>() { item.Reference }
                        });
                    }
                    else {
                        if (!sMatch.Tags.Contains(item.Tags)) {
                            sMatch.Tags.Add(item.Tags);
                        }
                        sMatch.Reference.Add(item.Reference);
                    }
                    if (cMatch is null) {
                        corpus.Add(new Pattern() {
                            Spelling = cSpell,
                            HasRoot = hasRoot,
                            RootOrLemma = cRootLemma,
                            Tags = new List<string>() { item.Tags },
                            Reference = new List<string>() { item.Reference }
                        });
                    }
                    else {
                        if (!cMatch.Tags.Contains(item.Tags)) {
                            cMatch.Tags.Add(item.Tags);
                        }
                        cMatch.Reference.Add(item.Reference);
                    }
                }
                linkIndex++;
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    spellingsView = CollectionViewSource.GetDefaultView(App.global.Transcript == 1 ? simple : corpus);
                    spellingsView.Filter = filter;
                    spellings.ItemsSource = spellingsView;
                    queryGrid.IsEnabled = true;
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    Pattern getMatch(string spelling, string rootLemma, List<Pattern> list) {
        int j = 0, k = list.Count - 1;
        while (j <= k) {
            if (list[j].Spelling.Equals(spelling) && list[j].RootOrLemma.Equals(rootLemma)) return list[j];
            if (list[k].Spelling.Equals(spelling) && list[k].RootOrLemma.Equals(rootLemma)) return list[k];
            j++;
            k--;
        }
        return null;
    }

    bool filter(object o) {
        if (string.IsNullOrEmpty(query)) return true;

        var text = ((Pattern)o).Spelling;
        bool match =
            lengthToggle.IsOn ?
            query.Length <= text.Length :
            query.Length == text.Length;

        if (match) {
            for (int i = 0; i < query.Length; i++) {
                if (query[i] == '+') continue;
                if (query[i] != text[i]) {
                    match = false;
                    break;
                }
            }
        }
        return match;
    }

    protected override void unload() {
        terminator.Cancel();
        terminator.Dispose();
        queryBox.KeyUp -= onQuery;
        content.Loaded -= onLoaded;
        spellings.MouseRightButtonUp -= onRightButtonUp;
        spellings.Fired -= onSpellingFired;
        listMorph.Fired -= onMorphFired;
        listMeaning.MouseDoubleClick -= onMeaningDoubleClick;
        DataObject.RemovePastingHandler(queryBox, onPste);
        App.global.PropertyChanged -= onTranscriptChanged;
        TabView.Split -= onSplit;
        base.unload();
    }

    class SpellingTemplate : Grid {
        TextBlockArabic spelling, rootLemma;
        TextBlockEnglish tags, count;

        public SpellingTemplate() {
            spelling = new TextBlockArabic();
            rootLemma = new TextBlockArabic() {
                Margin = new Thickness(5, 0, 5, 0)
            };
            tags = new TextBlockEnglish() {
                Margin = new Thickness(0, 0, 10, 0),
                HorizontalAlignment = HorizontalAlignment.Right,
                VerticalAlignment = VerticalAlignment.Center,
                TextWrapping = TextWrapping.Wrap
            };
            count = new TextBlockEnglish() {
                VerticalAlignment = VerticalAlignment.Center,
                Foreground = Brushes.Gray
            };
            SetColumn(rootLemma, 1);
            SetColumn(tags, 2);
            SetColumn(count, 3);

            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col1" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col2" });
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col4" });

            Children.Add(spelling);
            Children.Add(rootLemma);
            Children.Add(tags);
            Children.Add(count);
        }

        public override void EndInit() {
            base.EndInit();
            var c = (Pattern)DataContext;
            var token = c.Spelling;
            if (token.StartsWith("a") || token.StartsWith('`')) {
                token = "_" + token;
            }
            spelling.Text = token.toArabic();

            if (!string.IsNullOrEmpty(c.RootOrLemma)) {
                if (c.HasRoot) {
                    if (c.RootOrLemma.Contains('|')) {
                        rootLemma.Text = string.Join(" | ", c.RootOrLemma.Split('|').Select(x => x.toArabic()));
                    }
                    else rootLemma.Text = c.RootOrLemma.toArabic();
                    rootLemma.Foreground = Brushes.Gray;
                }
                else {
                    rootLemma.Text = c.RootOrLemma.toArabic();
                    rootLemma.Foreground = Brushes.SkyBlue;
                }
            }
            tags.Text = string.Join(", ", c.Tags.Select(x => App.tags[Convert.ToInt32(x)].Name));
            count.Text = c.Reference.Count.ToString("N0");
        }
    }

    class ReferenceCountConverter : IMultiValueConverter {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture) {
            return ((ItemCollection)values[1]).Cast<Pattern>().Sum(x => x.Reference.Count);
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture) {
            throw new NotImplementedException();
        }
    }
}

