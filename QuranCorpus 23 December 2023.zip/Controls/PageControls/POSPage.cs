﻿class POSPage : Page {
    string query;
    StringBuilder builder = new();

    Grid content;
    ContentListBox listBox;
    WaterBox queryBox;
    MorphView morphView;
    ProgressBar progress;
    CancellationTokenSource terminator;
    ICollectionView spellingView;

    KeyValuePair<POSKey, List<POS>> current;
    public override PageType Type => PageType.POS;
    public override UIElement Content => content;

    public POSPage() {
        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };

        queryBox = new WaterBox() {
            Icon = Icons.Search,
            Hint = "buckwalter"
        };
        var buckwalterPop = new BuckwalterPopup() { Margin = new Thickness(5, 0, 5, 0) };
        var countBlock = new TextBlockEnglish();
        listBox = new ContentListBox() {
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(POSSpellingTemplate))
            }
        };
        countBlock.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listBox,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        Grid.SetColumn(buckwalterPop, 1);
        Grid.SetColumn(countBlock, 2);
        var leftTopGrid = new Grid() {
            Margin = new Thickness(0, 0, 0, 5),
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { queryBox, buckwalterPop, countBlock }
        };

        Grid.SetRow(listBox, 1);
        var leftGrid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { leftTopGrid, listBox }
        };

        var separator = new Rectangle() {
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };

        morphView = new MorphView();

        Grid.SetRow(leftGrid, 1);
        Grid.SetRow(separator, 1);
        Grid.SetRow(morphView, 1);
        Grid.SetColumn(separator, 1);
        Grid.SetColumn(leftGrid, 2);
        Grid.SetColumnSpan(progress, 3);
        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition() { Width = new GridLength(3.5, GridUnitType.Star) },
                new ColumnDefinition() { Width = new GridLength(10) },
                new ColumnDefinition()
            },
            Children = { progress, leftGrid, separator, morphView }
        };
        terminator = new CancellationTokenSource();
        listBox.Fired += onListFired;
        queryBox.KeyUp += onQueryKeyUp;
        App.global.PropertyChanged += onTranscriptChanged;
    }

    public POSPage(KeyValuePair<POSKey, List<POS>> p) : this() {
        current = p;
        listSpelling();
    }

    public void setContent(KeyValuePair<POSKey, List<POS>> p) {
        if (current.Equals(p)) return;
        current = p;
        listSpelling();
    }

    void listSpelling() {
        progress.IsIndeterminate = true;
        Task.Run(() => {
            var posSource = current.Value;
            List<POS> distinct = new();

            for (int i = 0; i < posSource.Count; i++) {
                if (terminator.IsCancellationRequested) break;
                POS match = null;
                int j = 0, k = distinct.Count - 1;
                while (j <= k) {
                    if (distinct[j].Spellings[App.global.Transcript]
                        .Equals(posSource[i].Spellings[App.global.Transcript])) {
                        match = distinct[j];
                        break;
                    }
                    if (distinct[k].Spellings[App.global.Transcript]
                        .Equals(posSource[i].Spellings[App.global.Transcript])) {
                        match = distinct[k];
                        break;
                    }
                    j++;
                    k--;
                }
                if (match is null) distinct.Add(new POS(posSource[i]));
                else match.References.AddRange(posSource[i].References);
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    if (string.IsNullOrEmpty(queryBox.Text)) query = "";

                    spellingView = CollectionViewSource.GetDefaultView(distinct);
                    spellingView.Filter = filterSpelling;
                    listBox.ItemsSource = spellingView;
                    HeaderText = current.Key.Name + " (" + distinct.Count.ToString("N0") + ")";
                    progress.IsIndeterminate = false;
                });
            }
        });
    }

    void onListFired(object item) {
        var selected = (POS)item;
        progress.IsIndeterminate = true;
        Task.Run(() => {
            var spelling = selected.Spellings[App.global.Transcript];
            var morphs = new List<Morph>();
            int index = 0;

            if (!selected.IsSorted) {
                selected.References.Sort(new SurahAyahWordNoComparator());
                selected.IsSorted = true;
            }

            for (int i = 0; i < selected.References.Count; i++) {
                if (terminator.IsCancellationRequested) break;
                while (!App.links[index].Reference.Equals(selected.References[i])) index++;
                morphs.Add(App.links[index].toMorph(builder));
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    morphView.Update(morphs);
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    bool filterSpelling(object o) {
        if (string.IsNullOrEmpty(query)) return true;
        var pos = (POS)o;
        return App.spellings[Convert.ToInt32(pos.Spellings[App.global.Transcript])].Contains(query);
    }

    void onQueryKeyUp(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        query = queryBox.Text.Trim();
        spellingView.Refresh();
    }

    void onTranscriptChanged(object? sender, PropertyChangedEventArgs e) {
        if (!e.PropertyName.Equals(nameof(App.global.Transcript))) return;
        listSpelling();
    }

    protected override void unload() {
        base.unload();
        listBox.Fired -= onListFired;
        queryBox.KeyUp -= onQueryKeyUp;
        App.global.PropertyChanged -= onTranscriptChanged;
        morphView.Unload();
    }
}

class POSSpellingTemplate : Grid {
    TextBlockArabic arabic;
    TextBlockEnglish count;

    public POSSpellingTemplate() {
        arabic = new TextBlockArabic();
        count = new TextBlockEnglish() { VerticalAlignment = VerticalAlignment.Center };

        SetColumn(count, 1);
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

        Children.Add(arabic);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var pos = (POS)DataContext;
        arabic.Text = App.spellings[Convert.ToInt32(pos.Spellings[App.global.Transcript])].toArabic();
        count.Text = pos.References.Count.ToString("N0");
    }
}
