﻿class MoodWord {
    public string Root { get; set; }
    public string Tag { get; set; }
    public string Spelling { get; set; }
    public string Gender { get; set; }
    public string Indicative { get; set; }
    public string Subjunctive { get; set; }
    public string Jussive { get; set; }
    public bool IsSorted { get; set; }
    public List<string> References { get; set; }
    public MoodWord() {
        Root = "";
        Spelling = "";
        Gender = "";
        Indicative = "";
        Subjunctive = "";
        Jussive = "";
        References = new List<string>();
    }
}
