﻿public class TreeViewTemplate : ControlTemplate {
    public TreeViewTemplate() {
        TargetType = typeof(TreeView);
        var scroll = new FrameworkElementFactory(typeof(ScrollViewer));
        var items = new FrameworkElementFactory(typeof(ItemsPresenter));
        //scroll.SetValue(ScrollViewer.MarginProperty, new Thickness(5, 0, 0, 0));
        scroll.SetValue(ScrollViewer.TemplateProperty, new ScrollViewerTemplate());
        scroll.SetValue(ScrollViewer.CanContentScrollProperty, true);
        scroll.AppendChild(items);
        VisualTree = scroll;
    }
}