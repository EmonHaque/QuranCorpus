﻿class FormsView : CardView {
    public override string Icon => Icons.Group;
    public override bool OverridesToolTip => true;
    public override UIElement Tip => getTip();

    ProgressBar progress;
    TextBlockEnglish status;
    PageListBox list;
    FormsVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new FormsVM();
        DataContext = vm;
        initializeUI();
        bind();
    }

    void initializeUI() {
        progress = new ProgressBar() {
            Height = Constants.ProgressBarHeight,
            FlowDirection = FlowDirection.RightToLeft
        };
        status = new TextBlockEnglish() {
            HorizontalAlignment = HorizontalAlignment.Right,
            TextWrapping = TextWrapping.Wrap
        };
        list = new PageListBox() {
            Context = vm,
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(POSFormTemplate))
            }
        };
        list.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

        Grid.SetRow(progress, 1);
        Grid.SetRow(list, 2);

        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { status, progress, list }
        };
        setContent(grid);
    }

    void bind() {
        progress.SetBinding(ProgressBar.IsIndeterminateProperty, new Binding(nameof(vm.IsInProgress)));
        status.SetBinding(TextBlockEnglish.TextProperty, new Binding(nameof(vm.Status)));
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Items)));
    }

    Grid getTip() {
        var header = new TextBlockEnglish() {
            Text = "Forms",
            FontWeight = FontWeights.Bold
        };
        var separator = new Rectangle() {
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var description = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Text = "See words with root grouped by form."
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(description, 2);
        return new Grid() {
            MaxWidth = 200,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(10) },
                new RowDefinition()
            },
            Children = { header, separator, description }
        };
    }
}