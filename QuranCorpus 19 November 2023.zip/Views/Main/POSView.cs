﻿class POSView : CardView {
    public override string Icon => Icons.HashTagOutline;
    public override bool OverridesToolTip => true;
    public override UIElement Tip => getTip();

    ProgressBar progress;
    TextBlockEnglish status;
    WaterBox query;
    ActionButton sort;
    ListBox list;
    POSVM vm;

    public override void OnFirstSight() {
        base.OnFirstSight();
        vm = new POSVM();
        DataContext = vm;
        initializeUI();
        bind();
        IsVisibleChanged += onVisibilityChange;
        list.PreviewMouseRightButtonDown += onRightButtonDown;
        list.MouseRightButtonUp += onRightButtonUp;
    }

    void onVisibilityChange(object sender, DependencyPropertyChangedEventArgs e) {
        if (!IsVisible) return;
        if (vm.currentTranscript == App.global.Transcript) return;
        vm.Regroup();
    }

    void onRightButtonUp(object sender, MouseButtonEventArgs e) {
        if (vm.Selected.Key is null) return;
        ((App)Application.Current).FocusedControl.addPOSPage(vm.Selected);
        if (vm.WasRightClicked) vm.WasRightClicked = false;
    }

    void onRightButtonDown(object sender, MouseButtonEventArgs e) => vm.WasRightClicked = true;

    void initializeUI() {
        progress = new ProgressBar() {
            Height = 1.5,
            FlowDirection = FlowDirection.RightToLeft
        };
        status = new TextBlockEnglish() { 
            HorizontalAlignment = HorizontalAlignment.Right,
            TextWrapping = TextWrapping.Wrap
        };
        query = new WaterBox() {
            Icon = Icons.Search,
            Hint = "Tag"
        };
        sort = new ActionButton() {
            Icon = Icons.SortBidirectional,
            ToolTip = "by reference",
            Command = sortAction,
            Margin = new Thickness(5, 0, 0, 0)
        };
        Grid.SetColumn(sort, 1);
        var queryGrid = new Grid() {
            Margin = new Thickness(0,5,0,5),
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { query, sort}
        };

        list = new ListBox() {
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(POSTemplate))
            }
        };
        list.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

        Grid.SetRow(progress, 1);
        Grid.SetRow(queryGrid, 2);
        Grid.SetRow(list, 3);

        var grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { status, progress, queryGrid, list }
        };
        setContent(grid);
    }

    void bind() {
        progress.SetBinding(ProgressBar.IsIndeterminateProperty, new Binding(nameof(vm.IsInProgress)));
        status.SetBinding(TextBlockEnglish.TextProperty, new Binding(nameof(vm.Status)));
        query.SetBinding(WaterBox.TextProperty, new Binding(nameof(vm.Query)) {
            Mode = BindingMode.OneWayToSource
        });
        list.SetBinding(ListBox.ItemsSourceProperty, new Binding(nameof(vm.Items)));
        list.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(vm.Selected)) { Mode = BindingMode.OneWayToSource });
    }

    void sortAction() {
        vm.Sort();
        sort.ToolTip = sort.ToolTip.Equals("by reference") ? "by form" : "by reference";
    }

    Grid getTip() {
        var header = new TextBlockEnglish() {
            Text = "POS",
            FontWeight = FontWeights.Bold
        };
        var separator = new Rectangle() {
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var description = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Text = "See words grouped by parts of speech tag."
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(description, 2);
        return new Grid() {
            MaxWidth = 200,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(10) },
                new RowDefinition()
            },
            Children = { header, separator, description }
        };
    }
}
