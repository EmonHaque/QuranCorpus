﻿class POSPage : Page {
    string indexMa, query;
    byte searchMode;
    StringBuilder builder = new();

    Grid content;
    ListBox listBox;
    WaterBox queryBox;
    MorphView morphView;
    ProgressBar progress;
    CancellationTokenSource terminator;
    ICollectionView spellingView;

    KeyValuePair<POSKey, List<POS>> current;
    POS selected;
    public POS Selected {
        get { return selected; }
        set { selected = value; listMorph(); }
    }

    public override PageType Type => PageType.POS;
    public override UIElement Content => content;

    public POSPage() {
        indexMa = "|" + ((App)Application.Current).indexMa;
        progress = new ProgressBar() { Height = 1.5 };

        queryBox = new WaterBox() {
            Icon = Icons.Search,
            Hint = "buckwalter"
        };
        var buckwalterPop = new BuckwalterPopup() { Margin = new Thickness(5, 0, 5, 0) };
        var countBlock = new TextBlockEnglish();
        listBox = new ListBox() {
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(POSSpellingTemplate))
            }
        };
        listBox.SetBinding(ListBox.SelectedItemProperty, new Binding(nameof(Selected)) {
            Mode = BindingMode.OneWayToSource,
            Source = this
        });
        countBlock.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listBox,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        Grid.SetColumn(buckwalterPop, 1);
        Grid.SetColumn(countBlock, 2);
        var leftTopGrid = new Grid() {
            Margin = new Thickness(0, 0, 0, 5),
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { queryBox, buckwalterPop, countBlock }
        };

        Grid.SetRow(listBox, 1);
        var leftGrid = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { leftTopGrid, listBox }
        };

        var separator = new Rectangle() {
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };

        morphView = new MorphView();

        Grid.SetRow(leftGrid, 1);
        Grid.SetRow(separator, 1);
        Grid.SetRow(morphView, 1);
        Grid.SetColumn(separator, 1);
        Grid.SetColumn(leftGrid, 2);
        Grid.SetColumnSpan(progress, 3);
        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = new GridLength(3.5, GridUnitType.Star) },
                new ColumnDefinition() { Width = new GridLength(10) },
                new ColumnDefinition()
            },
            Children = { progress, leftGrid, separator, morphView }
        };
        terminator = new CancellationTokenSource();
        queryBox.KeyUp += onQueryKeyUp;
        App.global.PropertyChanged += onTranscriptChanged;
    }

    public POSPage(KeyValuePair<POSKey, List<POS>> p) : this() {
        current = p;
        listSpelling();
    }

    public void setContent(KeyValuePair<POSKey, List<POS>> p) {
        current = p;
        listSpelling();
    }

    void listSpelling() {
        progress.IsIndeterminate = true;
        Task.Run(() => {
            var posSource = current.Value;
            List<POS> distinct = new();
            for (int i = 0; i < posSource.Count; i++) {
                if (terminator.IsCancellationRequested) break;

                // time consuming
                var match = distinct.FirstOrDefault(
                    x => x.Spellings[App.global.Transcript]
                    .Equals(posSource[i].Spellings[App.global.Transcript]));

                if (match is null) distinct.Add(new POS(posSource[i]));
                else match.References.AddRange(posSource[i].References);
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    if (string.IsNullOrEmpty(queryBox.Text)) query = "";

                    spellingView = CollectionViewSource.GetDefaultView(distinct);
                    spellingView.Filter = filterSpelling;
                    listBox.ItemsSource = spellingView;
                    HeaderText = current.Key.Name + " (" + distinct.Count.ToString("N0") + ")";
                    progress.IsIndeterminate = false;
                });
            }
        });
    }

    void listMorph() {
        if (selected is null) {
            return;
        }
        progress.IsIndeterminate = true;
        Task.Run(() => {
            var spelling = selected.Spellings[App.global.Transcript];
            var morphs = new List<Morph>();

            var iterator = App.links.GetEnumerator();
            iterator.MoveNext();

            if (!selected.IsSorted) {
                selected.References.Sort(new SurahAyahWordNoComparator());
                selected.IsSorted = true;
            }

            for (int i = 0; i < selected.References.Count; i++) {
                if (terminator.IsCancellationRequested) break;

                while (!iterator.Current.Reference.Equals(selected.References[i])) iterator.MoveNext();

                if (!string.IsNullOrEmpty(iterator.Current.Root)) {
                    searchMode = iterator.Current.Root.Contains('|') ? (byte)3 : (byte)1;
                }
                else if (!string.IsNullOrEmpty(iterator.Current.LemmaSimple)) searchMode = 2;
                else searchMode = 3;

                morphs.Add(getMorph(iterator.Current));
            }

            iterator.Dispose();

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    morphView.Update(morphs);
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);

    }

    Morph getMorph(Link item) {
        string tag = "";
        string[] tags;
        string details = "";

        if (searchMode == 1) {
            details = item.Details.Split(',')[Convert.ToInt32(item.RootIndex)];
            details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
            int lIndex;
            if (item.LemmaSimple.EndsWith(indexMa)) {
                // in 8 cases it ends with maA
                lIndex = 0;
            }
            else lIndex = Convert.ToInt32(item.LemmaIndices);

            tags = item.Tags.Split('|');
            tag = App.tags[Convert.ToInt32(tags[lIndex])].Name;
        }
        else if (searchMode == 2) {
            var indices = item.LemmaIndices.Split('|');
            if (indices.Length == 1) {
                details = item.Details.Split(',')[Convert.ToInt32(item.LemmaIndices)];
                details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
                int lIndex;
                if (item.LemmaSimple.EndsWith(indexMa)) {
                    // in 8 cases it ends with maA
                    lIndex = 0;
                }
                else lIndex = Convert.ToInt32(item.LemmaIndices);

                tags = item.Tags.Split('|');
                tag = App.tags[Convert.ToInt32(tags[lIndex])].Name;
            }
            else {
                builder.Clear();
                item.explain(builder);
                var m = new Morph() {
                    Segments = Helper.getSegments(item),
                    Tags = item.Tags.Split('|'),
                    Spellings = new string[] {
                                string.Join("", item.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)])),
                                string.Join("", item.SegmentsSimple.Split('|').Select(x => App.segments[Convert.ToInt32(x)]))
                            },
                    Explanation = builder.ToString(),
                    Tag = ""
                };
                m.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));
                return m;
            }
        }
        else {
            if (!item.SpellingGroupSimple.Contains('|')) {
                details = item.Details;
                details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
                tag = App.tags[Convert.ToInt32(item.Tags)].Name;
                tags = item.Tags.Split('|');
            }
            else {
                builder.Clear();
                item.explain(builder);
                var m = new Morph() {
                    Segments = Helper.getSegments(item),
                    Tags = item.Tags.Split('|'),
                    Spellings = new string[] {
                                string.Join("", item.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)])),
                                string.Join("", item.SegmentsSimple.Split('|').Select(x => App.segments[Convert.ToInt32(x)]))
                            },
                    Explanation = builder.ToString(),
                    Tag = ""
                };
                m.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));
                return m;
            }
        }

        Morph t = new() {
            Tag = tag,
            Tags = tags,
            Segments = Helper.getSegments(item),
            Spellings = getSpellings(item)
        };
        builder.Clear();
        item.explain(builder);

        t.Explanation = builder.ToString();
        t.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));

        var array = details.Split('|');
        if (App.tagArray.Contains(tag)) {
            for (int i = 0; i < array.Length; i++) {
                if (string.IsNullOrEmpty(array[i])) continue;
                if (array[i].Equals("PCPL") ||
                    array[i].Equals("ACC") ||
                    array[i].Equals("NOM") ||
                    array[i].Equals("GEN") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("ACT")) t.SubTag = "Active Participle";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive Participle";
                else if (array[i].Equals("VN")) t.SubTag = "Verbal Noun";
                else if (array[i].Equals("IN")) t.SubTag = "Noun";
                else if (array[i].Equals("CN")) t.SubTag = "Noun";
                else if (array[i].Equals("IP")) t.SubTag = "Particle";
                else if (array[i].Equals("CP")) t.SubTag = "Particle";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("V")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUBJ") ||
                    array[i].Equals("JUS") ||
                    array[i].Equals("JUSS") ||
                    array[i].Equals("SP:kaAn") ||
                    array[i].Equals("SP:kaAd") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("IMPF")) t.SubTag = "Imperfect";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive";
                else if (array[i].Equals("IMPV")) t.SubTag = "Imperative";
                else if (array[i].Equals("PERF")) t.SubTag = "Perfect";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("PRON")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUB")) t.SubTag = "Subject";
                else if (array[i].Equals("OBJ")) t.SubTag = "Object";
                else if (array[i].Equals("PER")) t.SubTag = "Personal";
                else if (array[i].Equals("POS")) t.SubTag = "Possessive";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name;
                else t.Gender = Helper.getGender(array[i]).Name;
            }
        }
        return t;

        string[] getSpellings(Link item) {
            int lIndex;
            if (item.LemmaSimple.EndsWith(indexMa)) {
                // in 8 cases it ends with maA
                lIndex = 0;
            }
            else {
                if (string.IsNullOrEmpty(item.LemmaIndices)) {
                    return new string[] {
                    item.SpellingGroupCorpus,
                    item.SpellingGroupSimple
                };
                }

                lIndex = Convert.ToInt32(item.LemmaIndices);
            }
            return new string[] {
                item.SpellingGroupCorpus.Split('|')[lIndex],
                item.SpellingGroupSimple.Split('|')[lIndex]
            };
        }
    }

    bool filterSpelling(object o) {
        if (string.IsNullOrEmpty(query)) return true;
        var pos = (POS)o;
        return App.spellings[Convert.ToInt32(pos.Spellings[App.global.Transcript])].Contains(query);
    }

    void onQueryKeyUp(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        query = queryBox.Text.Trim();
        spellingView.Refresh();
    }

    void onTranscriptChanged(object? sender, PropertyChangedEventArgs e) {
        if (!e.PropertyName.Equals(nameof(App.global.Transcript))) return;
        listSpelling();
    }

    protected override void unload() {
        base.unload();
        queryBox.KeyUp -= onQueryKeyUp;
        App.global.PropertyChanged -= onTranscriptChanged;
        morphView.Unload();
    }
}

class POSSpellingTemplate : Grid {
    TextBlockArabic arabic;
    TextBlockEnglish count;

    public POSSpellingTemplate() {
        arabic = new TextBlockArabic();
        count = new TextBlockEnglish() { VerticalAlignment = VerticalAlignment.Center };

        SetColumn(count, 1);
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

        Children.Add(arabic);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var pos = (POS)DataContext;
        arabic.Text = App.spellings[Convert.ToInt32(pos.Spellings[App.global.Transcript])].toArabic();
        count.Text = pos.References.Count.ToString("N0");
    }
}
