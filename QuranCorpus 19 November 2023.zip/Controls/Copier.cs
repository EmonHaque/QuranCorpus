﻿class Copier {
    /*
     * Copy ayah (arabic, english or both) throws exception sometimes
     * System.Runtime.InteropServices.COMException (0x800401D0): OpenClipboard Failed (0x800401D0 (CLIPBRD_E_CANT_OPEN))
     * it happens when you select many ayah eg. select 1st ayah of surah 56 waqiyah
     * scroll down, hold down shift and click on 96th ayah to get all ayah selected
     * right click on 96th ayah and copy english
     * and immediately after clicking on copy, start scrolling up real fast with wheel
     * copying action collides with scrolling action and generates that exception?
     */
    ContextPopup ayahContext, wordContext;
    ListBox ayahListBox;
    ProgressBar progress;
    CancellationTokenSource terminator;

    Popup infoPop;
    Border infoBorder;
    Path infoIcon;
    TextBlockEnglish infoText;
    
    public Copier(ListBox ayahListBox, ProgressBar progress, CancellationTokenSource terminator) {
        this.ayahListBox = ayahListBox;
        this.progress = progress;
        this.terminator = terminator;
        
        ayahContext = new ContextPopup(new List<ContextItem>() {
            new ContextItem(){ Icon = Icons.CopyArabic, Text = "copy arabic", Command = copyArabic },
            new ContextItem(){ Icon = Icons.CopyEnglish, Text = "copy english", Command = copyEnglish },
            new ContextItem(){ Icon = Icons.Copy, Text = "copy both", Command = copyBoth },
        });

        wordContext = new ContextPopup(new List<ContextItem>() {
            new ContextItem(){ Icon = Icons.CopyArabic, Text = "copy word(s)", Command = copyWord }
        });

        infoIcon = new Path() { 
            Margin = new Thickness(0,0,10,0),
            Width = 18,
            Height = 18,
            Stretch = Stretch.Uniform
        };
        infoText = new TextBlockEnglish() { Foreground = Constants.Foreground };
        Grid.SetColumn(infoText, 1);
        var infoGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){Width = GridLength.Auto},
                new ColumnDefinition()
            },
            Children = { infoIcon, infoText }
        };
        infoBorder = new Border() {
            Padding = new Thickness(10),
            CornerRadius = new CornerRadius(5),
            BorderBrush = Brushes.LightGray,
            BorderThickness = new Thickness(Constants.BottomLineThickness),
            Background = Constants.Background,
            Child = infoGrid
        };
        infoPop = new Popup() {
            FlowDirection = FlowDirection.LeftToRight,
            AllowsTransparency = true,
            PlacementTarget = ayahListBox,
            StaysOpen = false,
            Child = infoBorder
        };

        ayahListBox.MouseRightButtonUp += onRightMouseUp;
    }

    public void unload() => ayahListBox.MouseRightButtonUp -= onRightMouseUp;

    public void addAction(ContextItem item) => ayahContext.addAction(item);

    void onRightMouseUp(object sender, MouseButtonEventArgs e) {
        if (ayahListBox.SelectedItems.Count == 0) return;
        bool wordsSelected = false;
        if (ayahListBox.SelectedItems.Count == 1) {
            var ayah = (Ayah)ayahListBox.SelectedItem;
            for (int i = 0; i < ayah.Words.Count; i++) {
                if (!ayah.Words[i].IsHighlighted) continue;
                wordsSelected = true;
                break;
            }
        }
        if (wordsSelected) wordContext.IsOpen = true;
        else ayahContext.IsOpen = true;
    }

    void copyWord() {
        var ayah = (Ayah)ayahListBox.SelectedItem;
        var builder = new StringBuilder();
        for (int i = 0; i < ayah.Words.Count; i++) {
            if (!ayah.Words[i].IsHighlighted) continue;
            ayah.Words[i].Segments[App.global.Transcript].Split('|').toArabic(builder);
            builder.Append(" ");
        }
        builder.Remove(builder.Length - 1, 1);
        setClipData(builder.ToString());
    }

    void copyArabic() {
        var selected = ayahListBox.SelectedItems.Cast<Ayah>();
        progress.IsIndeterminate = true;

        Task.Run(() => {
            var builder = new StringBuilder();
            foreach (Ayah ayah in selected) {
                if (terminator.IsCancellationRequested) break; // want to check in nested loops?

                builder
                .Append(ayah.SurahNo.toArabicNo())
                .Append(':')
                .Append(ayah.AyahNo.toArabicNo())
                .Append(" - ");

                foreach (var word in ayah.Words) {
                    word.Segments[App.global.Transcript].Split('|').toArabic(builder);
                    builder.Append(" ");
                }
                builder.AppendLine();

                if (!terminator.IsCancellationRequested) {
                    App.Current.Dispatcher.Invoke(() => {
                        setClipData(builder.ToString());
                        progress.IsIndeterminate = false;
                    });
                }
            }
        }, terminator.Token);
    }

    void copyEnglish() {
        var selected = ayahListBox.SelectedItems.Cast<Ayah>();
        progress.IsIndeterminate = true;
        Task.Run(() => {
            var builder = new StringBuilder();
            foreach (Ayah ayah in selected) {
                if (terminator.IsCancellationRequested) break; // want to check in nested loops?
                builder
                .Append(ayah.SurahNo)
                .Append(':')
                .Append(ayah.AyahNo + " - ");

                if (ayah.Translations.Length == 1) {
                    builder.Append(ayah.Translations[0].Content)
                    .AppendLine();
                }
                else {
                    var translatorNames = App.global.TranslationDictionary.Keys.ToList();
                    for (int i = 0; i < ayah.Translations.Length; i++) {
                        builder.Append(translatorNames[ayah.Translations[i].TranslatorId])
                        .Append(": ")
                        .Append(ayah.Translations[i].Content)
                        .AppendLine();
                    }
                }

                if (!terminator.IsCancellationRequested) {
                    App.Current.Dispatcher.Invoke(() => {
                        setClipData(builder.ToString());
                        progress.IsIndeterminate = false;
                    });
                }
            }
        }, terminator.Token);
    }

    void copyBoth() {
        var selected = ayahListBox.SelectedItems.Cast<Ayah>();
        progress.IsIndeterminate = true;

        Task.Run(() => {
            var builder = new StringBuilder();
            foreach (Ayah ayah in selected) {
                if (terminator.IsCancellationRequested) break; // want to check in nested loops?

                builder
                .Append(ayah.SurahNo.toArabicNo())
                .Append(':')
                .Append(ayah.AyahNo.toArabicNo())
                .Append(" - ");

                foreach (var word in ayah.Words) {
                    word.Segments[App.global.Transcript].Split('|').toArabic(builder);
                    builder.Append(" ");
                }
                builder
                .AppendLine()
                .Append(ayah.SurahNo)
                .Append(':')
                .Append(ayah.AyahNo + " - ");


                if (ayah.Translations.Length == 1) {
                    builder.Append(ayah.Translations[0].Content)
                    .AppendLine();
                }
                else {
                    var translatorNames = App.global.TranslationDictionary.Keys.ToList();
                    for (int i = 0; i < ayah.Translations.Length; i++) {
                        builder.Append(translatorNames[ayah.Translations[i].TranslatorId])
                        .Append(": ")
                        .Append(ayah.Translations[i].Content)
                        .AppendLine();
                    }
                }
                if (!terminator.IsCancellationRequested) {
                    App.Current.Dispatcher.Invoke(() => {
                        setClipData(builder.ToString());
                        progress.IsIndeterminate = false;
                    });
                }
            }
        }, terminator.Token);
    }

    // setClipData is called multiple times when you copy many ayah eg. all ayah of Surah 56 waqiyah
    void setClipData(string text) {
        if (infoPop.IsOpen) infoPop.IsOpen = false;

        var data = new DataObject(DataFormats.StringFormat, text);
        try {
            Clipboard.SetDataObject(data, false);
            infoIcon.Data = Geometry.Parse(Icons.Checked);
            infoIcon.Fill = Brushes.LightGreen;
            infoText.Text = "copied successfully";
        }
        catch (COMException e) {
            const uint CLIPBRD_E_CANT_OPEN = 0x800401D0;
            if ((uint)e.ErrorCode != CLIPBRD_E_CANT_OPEN) throw;
            else {
                infoIcon.Data = Geometry.Parse(Icons.CloseCircle);
                infoIcon.Fill = Brushes.Coral;
                infoText.Text = "failed to copy, try again!";
            }
        }
        ((App)Application.Current).clipData = data;

        infoBorder.Measure(new Size(ayahListBox.ActualWidth, ayahListBox.ActualHeight));
        infoPop.PlacementRectangle = new Rect(
            ayahListBox.ActualWidth - infoBorder.DesiredSize.Width,
            ayahListBox.ActualHeight - infoBorder.DesiredSize.Height, 
            infoPop.DesiredSize.Width, 
            infoPop.DesiredSize.Height);
        infoPop.IsOpen = true;
    }
}
