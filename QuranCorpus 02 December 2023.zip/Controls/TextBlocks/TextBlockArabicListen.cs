﻿class TextBlockArabicListen : TextBlockArabic {
    public TextBlockArabicListen() {
        SetBinding(TranscriptProperty, new Binding() {
            Path = new PropertyPath(nameof(App.global.Transcript)),
            Source = App.global
        });
    }

    public int Transcript {
        get { return (int)GetValue(TranscriptProperty); }
        set { SetValue(TranscriptProperty, value); }
    }

    public static readonly DependencyProperty TranscriptProperty =
        DependencyProperty.Register("Transcript", typeof(int), typeof(TextBlockArabicListen),
            new PropertyMetadata() {
                DefaultValue = 0,
                PropertyChangedCallback = onTranscriptChanged
            });

    static void onTranscriptChanged(DependencyObject d, DependencyPropertyChangedEventArgs e) {
        var o = (TextBlockArabicListen)d;
        var word = o.Tag as Word;
        if (word is not null) {
            var segments = word.Segments[o.Transcript].Split('|');
            for (int j = 0; j < o.Inlines.Count; j++) {
                var run = (Run)o.Inlines.ElementAt(j);
                run.Text = App.segments[Convert.ToInt32(segments[j])].toArabic();
            }
            return;
        }

        var words = o.Tag as List<Word>;
        if (words is not null) {
            StringBuilder builder = new();
            for (int i = 0; i < words.Count; i++) {
                if (words[i].Reference is null) continue;
                var run = (Run)o.Inlines.ElementAt(i);
                var segments = words[i].Segments[o.Transcript].Split('|');
                segments.toArabic(builder);
                builder.Append(' ');
                run.Text = builder.ToString();
                builder.Clear();
            }
            return;
        }
    }
}
