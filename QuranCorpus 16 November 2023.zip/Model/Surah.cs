﻿public class Surah {
    public int Id { get; set; }
    public int Order { get; set; }
    public string Full { get; set; }
    public string Simple { get; set; }
    public string Transliteration { get; set; }
    public string Meaning { get; set; }
    public int Verses { get; set; }
    public string Place { get; set; }
}
