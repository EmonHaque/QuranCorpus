﻿class MoodPage : Page {
    string indexMa;
    Grid content;
    StringBuilder builder = new();

    WaterBox indicative, subjunctive, jussive, root;
    ListBox erabs;
    Run morphCount, morphTotal;
    TextBlockEnglish meaningCount;
    List<Morph> morphs;
    ListBox listMorph, listMeaning;
    ICollectionView erabView;

    public override PageType Type => PageType.Mood;
    public override UIElement Content => content;

    public MoodPage() {
        indexMa = "|" + ((App)Application.Current).indexMa;
        root = new WaterBox() {
            Width = 100,
            Margin = new Thickness(0,0,5,0),
            Icon = Icons.Sprout,
            Hint = "root"
        };
        var buckwalter = new BuckwalterPopup();
        Grid.SetColumn(buckwalter, 1);
        var rootGrid = new Grid() {
            HorizontalAlignment = HorizontalAlignment.Right,
            FlowDirection = FlowDirection.LeftToRight,
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { root, buckwalter }
        };
        var countBlock = new TextBlockEnglish();
        var header = getHeader();
        erabs = new ListBox() {
            Margin = new Thickness(0, 0, 0, 5),
            Template = new ListBoxLedgerTemplate(),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MoodTemplate))
            },
        };
        erabs.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);
        var separator = new Rectangle() {
            VerticalAlignment = VerticalAlignment.Bottom,
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var splitter = new GridSplitter() {
            ResizeDirection = GridResizeDirection.Rows,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Template = new SplitterTemplate()
        };

        morphCount = new Run();
        morphTotal = new Run();
        var morphCountBlock = new TextBlockEnglish() {
            IsHitTestVisible = false,
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center,
            Inlines = { morphTotal, new Run(" in "), morphCount }
        };
        meaningCount = new TextBlockEnglish() {
            IsHitTestVisible = false,
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Left
        };

        listMorph = new ListBox() {
            Margin = new Thickness(0, 5, 0, 0),
            FlowDirection = FlowDirection.RightToLeft,
            Template = new ListBoxLedgerTemplate(),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MorphListTemplate))
            }
        };
        listMorph.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMorph.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        listMorph.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        listMeaning = new ListBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 0, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MeaningListTemplate))
            }
        };
        listMeaning.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMeaning.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        listMeaning.SetValue(VirtualizingPanel.ScrollUnitProperty, ScrollUnit.Pixel);

        Grid.SetRow(header, 1);
        Grid.SetRow(erabs, 2);
        Grid.SetRow(separator, 2);
        Grid.SetRow(splitter, 3);
        Grid.SetRow(morphCountBlock, 3);
        Grid.SetRow(meaningCount, 3);
        Grid.SetRow(listMorph, 4);
        Grid.SetRow(listMeaning, 4);

        Grid.SetColumn(rootGrid, 1);
        Grid.SetColumn(listMorph, 1);
        Grid.SetColumn(morphCountBlock, 1);


        Grid.SetColumnSpan(header, 2);
        Grid.SetColumnSpan(erabs, 2);
        Grid.SetColumnSpan(separator, 2);
        Grid.SetColumnSpan(splitter, 2);
        content = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(),
                new ColumnDefinition(){ Width = new GridLength(1.5, GridUnitType.Star)}
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(1.5, GridUnitType.Star)},
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { rootGrid, countBlock, header, erabs, separator, splitter, morphCountBlock, listMorph, meaningCount, listMeaning }
        };

        morphCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMorph,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        meaningCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMeaning,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        countBlock.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = erabs,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        erabs.SelectionChanged += onErabSelectionChanged;
        listMorph.SelectionChanged += onMorphSelectionChanged;
        listMeaning.MouseDoubleClick += onMeaningDoubleClick;
        indicative.KeyUp += onErabKeyUp;
        subjunctive.KeyUp += onErabKeyUp;
        jussive.KeyUp += onErabKeyUp;
        root.KeyUp += onErabKeyUp;
    }

    public MoodPage(List<MoodWord> source) : this() {
        HeaderText = source.First().Gender + " (" + source.Count + ")";
        erabView = CollectionViewSource.GetDefaultView(source);
        erabView.Filter = filter;
        erabs.ItemsSource = erabView;
    }

    public void setContent(List<MoodWord> source) {
        HeaderText = source.First().Gender + " (" + source.Count + ")";
        erabView = CollectionViewSource.GetDefaultView(source);
        erabView.Filter = filter;
        erabs.ItemsSource = erabView;
    }

    bool filter(object o) {
        bool result = true;
        var erab = (MoodWord)o;
        if (!string.IsNullOrEmpty(indicative.Text)) {
            result = result && indicative.Text.StartsWith('!') ?
                !erab.Indicative.EndsWith(indicative.Text.Substring(1)) :
                erab.Indicative.EndsWith(indicative.Text);
        }
        if (!string.IsNullOrEmpty(subjunctive.Text)) {
            result = result && subjunctive.Text.StartsWith('!') ?
                !erab.Subjunctive.EndsWith(subjunctive.Text.Substring(1)) :
                erab.Subjunctive.EndsWith(subjunctive.Text);
        }
        if (!string.IsNullOrEmpty(jussive.Text)) {
            result = result && jussive.Text.StartsWith('!') ?
                !erab.Jussive.EndsWith(jussive.Text.Substring(1)) :
                erab.Jussive.EndsWith(jussive.Text);
        }
        
        if (!string.IsNullOrEmpty(root.Text)) {
            result = result && erab.Root.Contains(root.Text);
        }
        return result;
    }

    void onErabSelectionChanged(object sender, SelectionChangedEventArgs e) {
        if (erabs.SelectedItem is null) {
            listMorph.ItemsSource = null;
            morphTotal.Text = "0";
            return;
        }
        var selected = (MoodWord)erabs.SelectedItem;
        morphs = new List<Morph>();
        var iterator = App.links.GetEnumerator();
        iterator.MoveNext();
        if (!selected.IsSorted) {
            selected.References.Sort(new SurahAyahWordNoComparator());
            selected.IsSorted = true;
        }
        for (int i = 0; i < selected.References.Count; i++) {
            while (!iterator.Current.Reference.Equals(selected.References[i])) iterator.MoveNext();
            var parts = App.global.Transcript == 0 ?
                iterator.Current.SpellingGroupCorpus.Split('|') :
                iterator.Current.SpellingGroupSimple.Split('|');
            int index = 0;
            for (int j = 0; j < parts.Length; j++) {
                if (!App.spellings[Convert.ToInt32(parts[j])].Equals(selected.Spelling)) continue;
                index = j;
                break;
            }
            morphs.Add(getMorph(iterator.Current, index));

        }
        var listSource = morphs.GroupBy(x => new { Word = x.Segments[1], x.Explanation })
              .Select(x => new Morph() {
                  Segments = x.First().Segments,
                  Count = x.Count(),
                  Tags = x.First().Tags,
                  Explanation = x.Key.Explanation,
                  References = x.SelectMany(x => x.References).ToList()
              })
              .OrderByDescending(x => x.Count)
              .ToList();

        listMorph.ItemsSource = listSource;
        morphTotal.Text = listSource.Sum(x => x.Count).ToString();
    }

    void onMorphSelectionChanged(object sender, SelectionChangedEventArgs e) {
        if (listMorph.SelectedItem is null) {
            listMeaning.ItemsSource = null;
            return;
        }
        listMeaning.ItemsSource = ((Morph)listMorph.SelectedItem).References;
    }

    void onMeaningDoubleClick(object sender, MouseButtonEventArgs e) {
        if (listMeaning.SelectedItem is null) return; // can be null?
        var item = (Tuple<string, string, string>)listMeaning.SelectedItem;
        ((App)Application.Current).FocusedControl.addSurahPage(item.Item1);
    }

    void onErabKeyUp(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        erabView.Refresh();
    }

    Grid getHeader() {
        indicative = new WaterBox() {
            Hint = "Indicative",
            Icon = Icons.ArrowLeft
        };
        subjunctive = new WaterBox() {
            Hint = "Subjunctive",
            Icon = Icons.ArrowTopLeft
        };
        jussive = new WaterBox() {
            Hint = "Jussive",
            Icon = Icons.CircleOutline
        };
        Grid.SetColumn(subjunctive, 1);
        Grid.SetColumn(indicative, 2);
        return new Grid() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(Constants.ScrollBarThickness, 5, 0, 5),
            ColumnDefinitions = {
                    new ColumnDefinition(),
                    new ColumnDefinition(),
                    new ColumnDefinition()
                },
            Children = { indicative, subjunctive, jussive }
        };
    }

    Morph getMorph(Link item, int index) {
        string tag = "";
        string[] tags;
        string details = "";

        details = item.Details.Split(',')[Convert.ToInt32(index)];
        details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));
        int lIndex;
        if (item.LemmaSimple.EndsWith(indexMa)) {
            // in 8 cases it ends with maA
            lIndex = 0;
        }
        else {
            lIndex = item.LemmaIndices.Contains('|') ?
                Convert.ToInt32(item.LemmaIndices.Split('|')[0]) :
                Convert.ToInt32(item.LemmaIndices);
        }

        tags = item.Tags.Split('|');
        tag = App.tags[Convert.ToInt32(tags[lIndex])].Name;


        Morph t = new() {
            Tag = tag,
            Tags = tags,
            Segments = Helper.getSegments(item),
            Spellings = getSpellings(item)
        };
        builder.Clear();
        item.explain(builder);

        t.Explanation = builder.ToString();
        t.References.Add(new Tuple<string, string, string>(item.Reference, item.Transliteration, item.Meaning));

        var array = details.Split('|');
        if (App.tagArray.Contains(tag)) {
            for (int i = 0; i < array.Length; i++) {
                if (string.IsNullOrEmpty(array[i])) continue;
                if (array[i].Equals("PCPL") ||
                    array[i].Equals("ACC") ||
                    array[i].Equals("NOM") ||
                    array[i].Equals("GEN") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("ACT")) t.SubTag = "Active Participle";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive Participle";
                else if (array[i].Equals("VN")) t.SubTag = "Verbal Noun";
                else if (array[i].Equals("IN")) t.SubTag = "Noun";
                else if (array[i].Equals("CN")) t.SubTag = "Noun";
                else if (array[i].Equals("IP")) t.SubTag = "Particle";
                else if (array[i].Equals("CP")) t.SubTag = "Particle";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("V")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUBJ") ||
                    array[i].Equals("JUS") ||
                    array[i].Equals("JUSS") ||
                    array[i].Equals("SP:kaAn") ||
                    array[i].Equals("SP:kaAd") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("IMPF")) t.SubTag = "Imperfect";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive";
                else if (array[i].Equals("IMPV")) t.SubTag = "Imperative";
                else if (array[i].Equals("PERF")) t.SubTag = "Perfect";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("PRON")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUB")) t.SubTag = "Subject";
                else if (array[i].Equals("OBJ")) t.SubTag = "Object";
                else if (array[i].Equals("PER")) t.SubTag = "Personal";
                else if (array[i].Equals("POS")) t.SubTag = "Possessive";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name;
                else t.Gender = Helper.getGender(array[i]).Name;
            }
        }
        return t;

        string[] getSpellings(Link item) {
            int lIndex;
            if (item.LemmaSimple.EndsWith(indexMa)) {
                // in 8 cases it ends with maA
                lIndex = 0;
            }
            else {
                if (string.IsNullOrEmpty(item.LemmaIndices)) {
                    return new string[] {
                        item.SpellingGroupCorpus,
                        item.SpellingGroupSimple
                    };
                }

                lIndex = item.LemmaIndices.Contains('|') ?
                    Convert.ToInt32(item.LemmaIndices.Split('|')[0]) :
                    Convert.ToInt32(item.LemmaIndices);
            }
            return new string[] {
                item.SpellingGroupCorpus.Split('|')[lIndex],
                item.SpellingGroupSimple.Split('|')[lIndex]
            };
        }
    }

    protected override void unload() {
        erabs.SelectionChanged -= onErabSelectionChanged;
        listMorph.SelectionChanged -= onMorphSelectionChanged;
        listMeaning.MouseDoubleClick -= onMeaningDoubleClick;
        indicative.KeyUp -= onErabKeyUp;
        subjunctive.KeyUp -= onErabKeyUp;
        jussive.KeyUp -= onErabKeyUp;
        root.KeyUp -= onErabKeyUp;
        base.unload();
    }

    class MoodTemplate : Grid {
        TextBlockArabic indicative, subjunctive, jussive;

        public MoodTemplate() {
            indicative = new TextBlockArabic();
            subjunctive = new TextBlockArabic();
            jussive = new TextBlockArabic();

            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());
            ColumnDefinitions.Add(new ColumnDefinition());

            SetColumn(subjunctive, 1);
            SetColumn(jussive, 2);

            Children.Add(indicative);
            Children.Add(subjunctive);
            Children.Add(jussive);

            Resources.Add(typeof(TextBlockArabic), new Style() {
                Setters = {
                    new Setter(TextBlockArabic.MarginProperty, new Thickness(20,0,0,0))
                }
            });
        }

        public override void EndInit() {
            base.EndInit();
            var c = (MoodWord)DataContext;
            indicative.Text = string.IsNullOrEmpty(c.Indicative) ? "" : c.Indicative.toArabic();
            subjunctive.Text = string.IsNullOrEmpty(c.Subjunctive) ? "" : c.Subjunctive.toArabic();
            jussive.Text = string.IsNullOrEmpty(c.Jussive) ? "" : c.Jussive.toArabic();
        }
    }
}
