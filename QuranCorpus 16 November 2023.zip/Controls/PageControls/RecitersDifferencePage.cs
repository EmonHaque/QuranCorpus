﻿
class RecitersDifferencePage : Page {
    const double minColumnWidth = 100;
    static Brush hafsColor = Brushes.SkyBlue;

    Grid content;
    TreeView tree;
    ScrollViewer treeScroll, columnViewer;

    Run countHafs = new();
    Run countBazzi = new();
    Run countDouri = new();
    Run countQaloun = new();
    Run countQunbul = new();
    Run countShuba = new();
    Run countSousi = new();
    Run countWarsh = new();

    Run wordCountBazzi = new();
    Run wordCountDouri = new();
    Run wordCountQaloun = new();
    Run wordCountQunbul = new();
    Run wordCountShuba = new();
    Run wordCountSousi = new();
    Run wordCountWarsh = new();

    public override PageType Type => PageType.RecitersDifference;
    public override UIElement Content => content;

    public RecitersDifferencePage() {
        HeaderText = "Difference";
        tree = new TreeView() {
            ItemContainerStyle = new Style(typeof(TreeViewItem)) {
                Setters = {
                    new Setter(TreeViewItem.TemplateProperty, new TreeItemTemplate()),
                    new Setter(TextElement.ForegroundProperty, Constants.Foreground),
                    new EventSetter(TreeViewItem.RequestBringIntoViewEvent, new RequestBringIntoViewEventHandler((s,e) => e.Handled = true))
                }
            }
        };
        tree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true); // no default virtualization

        var hafs = new TextBlockEnglish() { Foreground = hafsColor, Inlines = { new Run("Hafs\n"), countHafs } };
        var bazzi = new TextBlockEnglish() { Inlines = { new Run("Bazzi\n"), countBazzi, new Run(" | "), wordCountBazzi } };
        var douri = new TextBlockEnglish() { Inlines = { new Run("Douri\n"), countDouri, new Run(" | "), wordCountDouri } };
        var qaloun = new TextBlockEnglish() { Inlines = { new Run("Qaloun\n"), countQaloun, new Run(" | "), wordCountQaloun } };
        var qunbul = new TextBlockEnglish() { Inlines = { new Run("Qunbul\n"), countQunbul, new Run(" | "), wordCountQunbul } };
        var shuba = new TextBlockEnglish() { Inlines = { new Run("Shuba\n"), countShuba, new Run(" | "), wordCountShuba } };
        var sousi = new TextBlockEnglish() { Inlines = { new Run("Sousi\n"), countSousi, new Run(" | "), wordCountSousi } };
        var warsh = new TextBlockEnglish() { Inlines = { new Run("Warsh\n"), countWarsh, new Run(" | "), wordCountWarsh } };

        Grid.SetColumn(bazzi, 1);
        Grid.SetColumn(douri, 2);
        Grid.SetColumn(qaloun, 3);
        Grid.SetColumn(qunbul, 4);
        Grid.SetColumn(shuba, 5);
        Grid.SetColumn(sousi, 6);
        Grid.SetColumn(warsh, 7);

        var leftMargin = 
            2 * Constants.TreeExpansionWidth + 
            5 + // 5 for scroll margin in TreeViewTemplate
            3;  // 3 for headerBorder padding in TreeItemTemplate

        var header = new Grid() {
            ShowGridLines = true,
            Margin = new Thickness(leftMargin, 0, 0, 1.5),
            ColumnDefinitions = {
                new ColumnDefinition() { SharedSizeGroup = "col1", MinWidth = minColumnWidth },
                new ColumnDefinition() { SharedSizeGroup = "col2", MinWidth = minColumnWidth },
                new ColumnDefinition() { SharedSizeGroup = "col3", MinWidth = minColumnWidth },
                new ColumnDefinition() { SharedSizeGroup = "col4", MinWidth = minColumnWidth },
                new ColumnDefinition() { SharedSizeGroup = "col5", MinWidth = minColumnWidth },
                new ColumnDefinition() { SharedSizeGroup = "col6", MinWidth = minColumnWidth },
                new ColumnDefinition() { SharedSizeGroup = "col7", MinWidth = minColumnWidth },
                new ColumnDefinition() { SharedSizeGroup = "col8", MinWidth = minColumnWidth }
            },
            Children = { hafs, bazzi, douri, qaloun, qunbul, shuba, sousi, warsh },
            Resources = {
                {
                    typeof(TextBlockEnglish), new Style() {
                        Setters = {
                            new Setter(TextBlockEnglish.HorizontalAlignmentProperty, HorizontalAlignment.Center),
                            new Setter(TextBlockEnglish.TextAlignmentProperty, TextAlignment.Center)
                        }
                    }
                } }
        };

        columnViewer = new ScrollViewer() {
            Margin = new Thickness(0, 0, Constants.ScrollBarThickness, 0),
            VerticalScrollBarVisibility = ScrollBarVisibility.Disabled,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Hidden,
            Content = new Border() {
                Child = header,
                BorderThickness = new Thickness(0,0,0, Constants.BottomLineThickness),
                BorderBrush = Brushes.LightGray
            }
        };

        var groups = getDifferences().GroupBy(x => x.Type).ToList();
        foreach (var group in groups) {
            var list = group.ToList();

            int countHafs = 0;
            int countBazzi = 0;
            int countDouri = 0;
            int countQaloun = 0;
            int countQunbul = 0;
            int countShuba = 0;
            int countSousi = 0;
            int countWarsh = 0;

            int wordCountBazzi = 0;
            int wordCountDouri = 0;
            int wordCountQaloun = 0;
            int wordCountQunbul = 0;
            int wordCountShuba = 0;
            int wordCountSousi = 0;
            int wordCountWarsh = 0;

            foreach (var e in list) {
                countHafs++;
                if (!string.IsNullOrEmpty(e.Bazzi)) {
                    countBazzi += Convert.ToInt32(e.CountBazzi);
                    wordCountBazzi++;
                }
                if (!string.IsNullOrEmpty(e.Douri)) {
                    countDouri += Convert.ToInt32(e.CountDouri);
                    wordCountDouri++;
                }
                if (!string.IsNullOrEmpty(e.Qaloun)) {
                    countQaloun += Convert.ToInt32(e.CountQaloun);
                    wordCountQaloun++;
                }
                if (!string.IsNullOrEmpty(e.Qunbul)) {
                    countQunbul += Convert.ToInt32(e.CountQunbul);
                    wordCountQunbul++;
                }
                if (!string.IsNullOrEmpty(e.Shuba)) {
                    countShuba += Convert.ToInt32(e.CountShuba);
                    wordCountShuba++;
                }
                if (!string.IsNullOrEmpty(e.Sousi)) {
                    countSousi += Convert.ToInt32(e.CountSousi);
                    wordCountSousi++;
                }
                if (!string.IsNullOrEmpty(e.Warsh)) {
                    countWarsh += Convert.ToInt32(e.CountWarsh);
                    wordCountWarsh++;
                }
            }

            var groupCount = new GroupCount() {
                Name = group.Key,
                Hafs = countHafs.ToString(),
                Bazzi = countBazzi == 0 ? "-" : countBazzi + " | " + wordCountBazzi,
                Douri = countDouri == 0 ? "-" : countDouri + " | " + wordCountDouri,
                Qaloun = countQaloun == 0 ? "-" : countQaloun + " | " + wordCountQaloun,
                Qunbul = countQunbul == 0 ? "-" : countQunbul + " | " + wordCountQunbul,
                Shuba = countShuba == 0 ? "-" : countShuba + " | " + wordCountShuba,
                Sousi = countSousi == 0 ? "-" : countSousi + " | " + wordCountSousi,
                Warsh = countWarsh == 0 ? "-" : countWarsh + " | " + wordCountWarsh
            };

            var item = new TreeViewItem() {
                Header = groupCount,
                HeaderTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(HeaderTemplate))
                },
                ItemsSource = list,
                ItemTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(DifferenceTemplate))
                }
            };
            tree.Items.Add(item);
        }

        var info = new TextBoxEnglish() {
            Margin = new Thickness(0, 5, 0, 0),
            Visibility = Visibility.Collapsed,
            FlowDirection = FlowDirection.LeftToRight,
            TextWrapping = TextWrapping.Wrap,
            Text = System.IO.File.ReadAllText("Resources/KFGQPC/differntiationProcess.txt")
        };
        info.Resources.Add(typeof(ScrollBar), new Style() {
            Setters = {
                new Setter(ScrollBar.TemplateProperty, new VScrollTemplate())
            }
        });
        info.SetValue(ScrollViewer.VerticalScrollBarVisibilityProperty, ScrollBarVisibility.Auto);

        var infoButton = new ActionButton() {
            ToolTip = "toggle info",
            HorizontalAlignment = HorizontalAlignment.Left,
            Icon = Icons.Info,
            Command = () => {
                if (info.Visibility == Visibility.Visible) {
                    info.Visibility = Visibility.Collapsed;
                    content.RowDefinitions[1].Height = new GridLength(0);
                }
                else {
                    info.Visibility = Visibility.Visible;
                    content.RowDefinitions[1].Height = new GridLength(1, GridUnitType.Star);
                }
            }
        };

        Grid.SetRow(tree, 1);
        var aGrid = new Grid() {
            Margin = new Thickness(0, 5, 0, 0),
            FlowDirection = FlowDirection.LeftToRight,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { columnViewer, tree }
        };
        aGrid.SetValue(Grid.IsSharedSizeScopeProperty, true);

        Grid.SetRow(info, 1);
        Grid.SetRow(aGrid, 2);

        content = new Grid() {
            RowDefinitions = {
                new RowDefinition(){Height = GridLength.Auto},
                new RowDefinition(){ Height = new GridLength(0)},
                new RowDefinition(),
            },
            Children = { infoButton, info, aGrid }
        };

        tree.Loaded += onLoaded;
        tree.Unloaded += onUnloaded;
    }

    void onLoaded(object sender, RoutedEventArgs e) {
        treeScroll = Helper.FindVisualChild<ScrollViewer>(tree);
        treeScroll.ScrollChanged += onContentScroll;
    }

    void onUnloaded(object sender, RoutedEventArgs e) {
        treeScroll.ScrollChanged -= onContentScroll;
    }

    void onContentScroll(object sender, ScrollChangedEventArgs e) {
        columnViewer.ScrollToHorizontalOffset(e.HorizontalOffset);
    }

    List<Difference> getDifferences() {
        var list = new List<Difference>();
        var lines = System.IO.File.ReadAllLines("Resources/KFGQPC/differences.txt").Skip(1);

        int countHafs = 0;
        int countBazzi = 0;
        int countDouri = 0;
        int countQaloun = 0;
        int countQunbul = 0;
        int countShuba = 0;
        int countSousi = 0;
        int countWarsh = 0;

        int wordCountBazzi = 0;
        int wordCountDouri = 0;
        int wordCountQaloun = 0;
        int wordCountQunbul = 0;
        int wordCountShuba = 0;
        int wordCountSousi = 0;
        int wordCountWarsh = 0;

        foreach (var line in lines) {
            var parts = line.Split("\t");
            list.Add(new Difference() {
                Hafs = parts[0],
                Bazzi = parts[1],
                Douri = parts[2],
                Qaloun = parts[3],
                Qunbul = parts[4],
                Shuba = parts[5],
                Sousi = parts[6],
                Warsh = parts[7],
                CountBazzi = parts[8],
                CountDouri = parts[9],
                CountQaloun = parts[10],
                CountQunbul = parts[11],
                CountShuba = parts[12],
                CountSousi = parts[13],
                CountWarsh = parts[14],
                RefBazzi = parts[15],
                RefDouri = parts[16],
                RefQaloun = parts[17],
                RefQunbul = parts[18],
                RefShuba = parts[19],
                RefSousi = parts[20],
                RefWarsh = parts[21],
                Type = parts[22]
            });

            countHafs++;
            if (!string.IsNullOrEmpty(parts[8])) {
                countBazzi += Convert.ToInt32(parts[8]);
                wordCountBazzi++;
            }
            if (!string.IsNullOrEmpty(parts[9])) {
                countDouri += Convert.ToInt32(parts[9]);
                wordCountDouri++;
            }
            if (!string.IsNullOrEmpty(parts[10])) {
                countQaloun += Convert.ToInt32(parts[10]);
                wordCountQaloun++;
            }
            if (!string.IsNullOrEmpty(parts[11])) {
                countQunbul += Convert.ToInt32(parts[11]);
                wordCountQunbul++;
            }
            if (!string.IsNullOrEmpty(parts[12])) {
                countShuba += Convert.ToInt32(parts[12]);
                wordCountShuba++;
            }
            if (!string.IsNullOrEmpty(parts[13])) {
                countSousi += Convert.ToInt32(parts[13]);
                wordCountSousi++;
            }
            if (!string.IsNullOrEmpty(parts[14])) {
                countWarsh += Convert.ToInt32(parts[14]);
                wordCountWarsh++;
            }
        }

        list.Sort(new DifferenceComparer());

        this.countHafs.Text = countHafs.ToString("N0");
        this.countBazzi.Text = countBazzi.ToString("N0");
        this.countDouri.Text = countDouri.ToString("N0");
        this.countQaloun.Text = countQaloun.ToString("N0");
        this.countQunbul.Text = countQunbul.ToString("N0");
        this.countShuba.Text = countShuba.ToString("N0");
        this.countSousi.Text = countSousi.ToString("N0");
        this.countWarsh.Text = countWarsh.ToString("N0");

        this.wordCountBazzi.Text = wordCountBazzi.ToString();
        this.wordCountDouri.Text = wordCountDouri.ToString();
        this.wordCountQaloun.Text = wordCountQaloun.ToString();
        this.wordCountQunbul.Text = wordCountQunbul.ToString();
        this.wordCountShuba.Text = wordCountShuba.ToString();
        this.wordCountSousi.Text = wordCountSousi.ToString();
        this.wordCountWarsh.Text = wordCountWarsh.ToString();

        return list;
    }

    protected override void unload() {
        tree.Loaded -= onLoaded;
        tree.Unloaded -= onUnloaded;
        treeScroll.ScrollChanged -= onContentScroll;
        base.unload();
    }

    class HeaderTemplate : Grid {
        TextBlockEnglish hafs, bazzi, douri, qaloun, qunbul, shuba, sousi, warsh;

        public HeaderTemplate() {
            ShowGridLines = true;
            Margin = new Thickness(Constants.TreeExpansionWidth,0,0,0);
            hafs = new TextBlockEnglish() { 
                HorizontalAlignment = HorizontalAlignment.Left,
                Margin = new Thickness(-Constants.TreeExpansionWidth, 0, 0, 0)
            };
            bazzi = new TextBlockEnglish();
            douri = new TextBlockEnglish();
            qaloun = new TextBlockEnglish();
            qunbul = new TextBlockEnglish();
            shuba = new TextBlockEnglish();
            sousi = new TextBlockEnglish();
            warsh = new TextBlockEnglish();

            SetColumn(bazzi, 1);
            SetColumn(douri, 2);
            SetColumn(qaloun, 3);
            SetColumn(qunbul, 4);
            SetColumn(shuba, 5);
            SetColumn(sousi, 6);
            SetColumn(warsh, 7);

            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col1", MinWidth = minColumnWidth });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col2", MinWidth = minColumnWidth });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col3", MinWidth = minColumnWidth });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col4", MinWidth = minColumnWidth });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col5", MinWidth = minColumnWidth });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col6", MinWidth = minColumnWidth });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col7", MinWidth = minColumnWidth });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col8", MinWidth = minColumnWidth });

            Children.Add(hafs);
            Children.Add(bazzi);
            Children.Add(douri);
            Children.Add(qaloun);
            Children.Add(qunbul);
            Children.Add(shuba);
            Children.Add(sousi);
            Children.Add(warsh);

            Resources.Add(typeof(TextBlockEnglish), new Style() {
                Setters = {
                    new Setter(TextBlockEnglish.HorizontalAlignmentProperty, HorizontalAlignment.Center)
                }
            });
        }

        public override void EndInit() {
            base.EndInit();
            var d = (GroupCount)DataContext;

            hafs.Inlines.Add(new Run(d.Name));// = d.Name + " (" + d.Hafs + ")";
            hafs.Inlines.Add(new Run(" (" + d.Hafs + ")") { Foreground = hafsColor });
            bazzi.Text = d.Bazzi;
            douri.Text = d.Douri;
            qaloun.Text = d.Qaloun;
            qunbul.Text = d.Qunbul;
            shuba.Text = d.Shuba;
            sousi.Text = d.Sousi;
            warsh.Text = d.Warsh;
        }
    }

    class DifferenceTemplate : Grid {
        TextBlock hafs;
        DifferenceStak bazzi, douri, qaloun, qunbul, shuba, sousi, warsh;

        public DifferenceTemplate() {
            ShowGridLines = true;
            bazzi = new DifferenceStak();
            douri = new DifferenceStak();
            qaloun = new DifferenceStak();
            qunbul = new DifferenceStak();
            shuba = new DifferenceStak();
            sousi = new DifferenceStak();
            warsh = new DifferenceStak();
            hafs = new TextBlock() {
                Foreground = hafsColor,
                HorizontalAlignment = HorizontalAlignment.Center,
                FontFamily = Helper.getReciterFont("Hafs")
            };
            hafs.SetBinding(TextBlock.FontSizeProperty, new Binding() {
                Path = new PropertyPath(nameof(Global.ArabicFontSize)),
                Source = App.global
            });
            SetColumn(bazzi, 1);
            SetColumn(douri, 2);
            SetColumn(qaloun, 3);
            SetColumn(qunbul, 4);
            SetColumn(shuba, 5);
            SetColumn(sousi, 6);
            SetColumn(warsh, 7);


            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col1" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col2" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col3" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col4" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col5" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col6" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col7" });
            ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col8" });

            Children.Add(hafs);
            Children.Add(bazzi);
            Children.Add(douri);
            Children.Add(qaloun);
            Children.Add(qunbul);
            Children.Add(shuba);
            Children.Add(sousi);
            Children.Add(warsh);
        }

        public override void EndInit() {
            base.EndInit();
            var d = (Difference)DataContext;
            hafs.Text = d.Hafs;
            bazzi.setContent(new Tuple<string, string, string, string>("Bazzi", d.Bazzi, d.CountBazzi, d.RefBazzi));
            douri.setContent(new Tuple<string, string, string, string>("Douri", d.Douri, d.CountDouri, d.RefDouri));
            qaloun.setContent(new Tuple<string, string, string, string>("Qaloun", d.Qaloun, d.CountQaloun, d.RefQaloun));
            qunbul.setContent(new Tuple<string, string, string, string>("Qunbul", d.Qunbul, d.CountQunbul, d.RefQunbul));
            shuba.setContent(new Tuple<string, string, string, string>("Shuba", d.Shuba, d.CountShuba, d.RefShuba));
            sousi.setContent(new Tuple<string, string, string, string>("Sousi", d.Sousi, d.CountSousi, d.RefSousi));
            warsh.setContent(new Tuple<string, string, string, string>("Warsh", d.Warsh, d.CountWarsh, d.RefWarsh));
        }
    }

    class DifferenceStak : StackPanel {
        Tuple<string, string, string, string> item;
        TextBlock text;
        TextBlockEnglish count;
        PopupDraggable pop;

        public DifferenceStak() {
            Margin = new Thickness(2.5, 0, 2.5, 0);
            Background = Brushes.Transparent;
            HorizontalAlignment = HorizontalAlignment.Center;
            Orientation = Orientation.Horizontal;
            text = new TextBlock() { IsHitTestVisible = false };
            count = new TextBlockEnglish() {
                VerticalAlignment = VerticalAlignment.Center,
                Foreground = Brushes.Gray,
                Margin = new Thickness(2.5, 0, 0, 0),
                IsHitTestVisible = false
            };

            text.SetBinding(TextBlock.FontSizeProperty, new Binding() {
                Path = new PropertyPath(nameof(Global.ArabicFontSize)),
                Source = App.global
            });
            Children.Add(text);
            Children.Add(count);

            pop = new PopupDraggable() {
                Width = 200,
                MaxHeight = 300
            };
        }

        public void setContent(Tuple<string, string, string, string> d) {
            item = d;
            if (!string.IsNullOrEmpty(item.Item2)) {
                text.FontFamily = Helper.getReciterFont(item.Item1);
                text.Text = item.Item2;
                count.Text = item.Item3;
            }
        }

        protected override void OnMouseEnter(MouseEventArgs e) {
            base.OnMouseEnter(e);
            count.Foreground = Brushes.LightCoral;
        }

        protected override void OnMouseLeave(MouseEventArgs e) {
            base.OnMouseLeave(e);
            if (pop.IsOpen) return;
            count.Foreground = Brushes.Gray;
        }

        protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
            base.OnMouseLeftButtonUp(e);
            if (!pop.IsOpen) {
                var close = new ActionButton() {
                    HorizontalAlignment = HorizontalAlignment.Right,
                    Icon = Icons.CloseCircle,
                    Command = () => {
                        pop.IsOpen = false;
                        count.Foreground = Brushes.Gray;
                    }
                };

                var hafs = new TextBlockEnglish() { Text = "Hafs" };
                var other = new TextBlockEnglish() { Text = item.Item1 };
                var contentGrid = new Grid() {
                    ColumnDefinitions = {
                        new ColumnDefinition(),
                        new ColumnDefinition(),
                    },
                };
                var scroll = new ScrollViewer() {
                    Content = contentGrid,
                    Template = new ScrollViewerTemplate(),
                    HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
                    VerticalScrollBarVisibility = ScrollBarVisibility.Auto
                };

                Grid.SetRow(hafs, 1);
                Grid.SetRow(other, 1);
                Grid.SetRow(scroll, 2);
                Grid.SetColumn(other, 1);
                Grid.SetColumn(close, 1);
                Grid.SetColumnSpan(scroll, 2);

                var grid = new Grid() {
                    RowDefinitions = {
                        new RowDefinition(){ Height = GridLength.Auto },
                        new RowDefinition(){ Height = GridLength.Auto },
                        new RowDefinition()
                    },
                    ColumnDefinitions = {
                        new ColumnDefinition(),
                        new ColumnDefinition(),
                    },
                    Children = { close, hafs, other, scroll },
                    Resources = {
                        {typeof(TextBlockEnglish), new Style() {
                            Setters = {
                                new Setter(TextBlockEnglish.ForegroundProperty, Constants.Foreground)
                            }
                        } }
                    }
                };

                var refs = item.Item4.Split(",", StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < refs.Length; i++) {
                    var parts = refs[i].Trim().Split('|');
                    contentGrid.RowDefinitions.Add(new RowDefinition());
                    var h = new TextBoxEnglish() { Text = parts[0] };
                    var o = new TextBoxEnglish() { Text = parts[1] };
                    Grid.SetColumn(o, 1);
                    Grid.SetRow(h, i);
                    Grid.SetRow(o, i);
                    contentGrid.Children.Add(h);
                    contentGrid.Children.Add(o);
                }

                pop.Child = new Border() {
                    Padding = new Thickness(10),
                    CornerRadius = new CornerRadius(5),
                    BorderBrush = Brushes.LightGray,
                    BorderThickness = new Thickness(Constants.BottomLineThickness),
                    Background = Constants.Background,
                    Child = grid
                };
                pop.IsOpen = true;
            }
            else pop.IsOpen = false;
        }
    }

    class Difference {
        public string Hafs { get; set; }
        public string Bazzi { get; set; }
        public string Douri { get; set; }
        public string Qaloun { get; set; }
        public string Qunbul { get; set; }
        public string Shuba { get; set; }
        public string Sousi { get; set; }
        public string Warsh { get; set; }

        public string CountBazzi { get; set; }
        public string CountDouri { get; set; }
        public string CountQaloun { get; set; }
        public string CountQunbul { get; set; }
        public string CountShuba { get; set; }
        public string CountSousi { get; set; }
        public string CountWarsh { get; set; }

        public string RefBazzi { get; set; }
        public string RefDouri { get; set; }
        public string RefQaloun { get; set; }
        public string RefQunbul { get; set; }
        public string RefShuba { get; set; }
        public string RefSousi { get; set; }
        public string RefWarsh { get; set; }
        public string Type { get; set; }
    }

    class DifferenceComparer : IComparer<Difference> {
        public int Compare(Difference? x, Difference? y) {
            int xCount = 0, yCount = 0;
            if (!string.IsNullOrEmpty(x.Bazzi)) xCount++;
            if (!string.IsNullOrEmpty(x.Douri)) xCount++;
            if (!string.IsNullOrEmpty(x.Qaloun)) xCount++;
            if (!string.IsNullOrEmpty(x.Qunbul)) xCount++;
            if (!string.IsNullOrEmpty(x.Shuba)) xCount++;
            if (!string.IsNullOrEmpty(x.Sousi)) xCount++;
            if (!string.IsNullOrEmpty(x.Warsh)) xCount++;

            if (!string.IsNullOrEmpty(y.Bazzi)) yCount++;
            if (!string.IsNullOrEmpty(y.Douri)) yCount++;
            if (!string.IsNullOrEmpty(y.Qaloun)) yCount++;
            if (!string.IsNullOrEmpty(y.Qunbul)) yCount++;
            if (!string.IsNullOrEmpty(y.Shuba)) yCount++;
            if (!string.IsNullOrEmpty(y.Sousi)) yCount++;
            if (!string.IsNullOrEmpty(y.Warsh)) yCount++;

            return yCount - xCount;
        }
    }

    class GroupCount {
        public string Name { get; set; }
        public string Hafs { get; set; }
        public string Bazzi { get; set; }
        public string Douri { get; set; }
        public string Qaloun { get; set; }
        public string Qunbul { get; set; }
        public string Shuba { get; set; }
        public string Sousi { get; set; }
        public string Warsh { get; set; }
    }
}
