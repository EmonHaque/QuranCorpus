﻿public class TreeViewLedgerTemplate : ControlTemplate {
    public TreeViewLedgerTemplate() {
        TargetType = typeof(TreeView);
        var scroll = new FrameworkElementFactory(typeof(ScrollViewer));
        var items = new FrameworkElementFactory(typeof(ItemsPresenter));
        scroll.SetValue(ScrollViewer.MarginProperty, new Thickness(5, 0, 0, 0));
        scroll.SetValue(ScrollViewer.TemplateProperty, new LedgerScrollTemplate());
        scroll.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        scroll.AppendChild(items);
        VisualTree = scroll;
    }
}
