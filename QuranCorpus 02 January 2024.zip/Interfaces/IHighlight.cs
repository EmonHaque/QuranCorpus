﻿interface IHighlight {
    event Action<string> Highlighted;
}
