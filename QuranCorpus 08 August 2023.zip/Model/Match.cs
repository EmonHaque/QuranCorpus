﻿class Match : Notifiable {
    public string Reference { get; set; }
    public string WordNo { get; set; }
    public string Transliteration { get; set; }
    public string Meaning { get; set; }
    public string Tag { get; set; }
    public string Spelling { get; set; }
    public string Lemma { get; set; }
    public List<Word> Words { get; set; }

    string translation;
    public string Translation {
        get { return translation; }
        set { translation = value; }
    }
}
