﻿public class TransitButtonPath : TransitButton
{
    Path iconPath;
    string icon;
    public string Icon {
        get { return icon; }
        set { icon = value; iconPath.Data = Geometry.Parse(value); }
    }
    protected override FrameworkElement element => iconPath;

    public TransitButtonPath(double widthAndHeight) : base(widthAndHeight) {
        normalColor = Colors.LightGray;
        highlightColor = Colors.Coral;
        selectedColor = Colors.CornflowerBlue;
        brush = new SolidColorBrush(normalColor);

        iconPath.Fill = brush;
    }

    protected override void initializeElement() {
        iconPath = new Path() {
            Stretch = Stretch.Uniform,
            HorizontalAlignment = HorizontalAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center
        };
    }
}
