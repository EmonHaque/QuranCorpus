﻿class CheckGroup : StackPanel {
    //set icons first, tips second and orientation third
    Icon[] array;
    string[] icons;
    public string[] Icons {
        get { return icons; }
        set { icons = value; arrangeIcons(); }
    }
    string[] tips;
    public string[] Tips {
        get { return tips; }
        set { tips = value; setTips(); }
    }

    DependencyPropertyDescriptor descriptor;
    public CheckGroup() {
        Orientation = Orientation.Horizontal;
        descriptor = DependencyPropertyDescriptor.FromProperty(OrientationProperty, typeof(CheckGroup));
        descriptor.AddValueChanged(this, onOrientationChanged);
    }

    void onOrientationChanged(object? sender, EventArgs e) {
        if (array is null) return;
        if(Orientation == Orientation.Horizontal) {
            for (int i = 0; i < array.Length; i++) {
                array[i].Holder.Padding = new Thickness(2.5, 0, 2.5, 0);
            }
        }
        else {
            for (int i = 0; i < array.Length; i++) {
                array[i].Holder.Padding = new Thickness(0, 2.5, 0, 2.5);
            }
        }
    }

    void arrangeIcons() {
        array = new Icon[icons.Length];
        for (int i = 0; i < icons.Length; i++) {
            var icon = new Icon() {
                Id = i,
                Path = Helper.getIcon(icons[i], Brushes.LightGray)
            };
            Children.Add(icon.Holder);

            array[i] = icon;
            icon.Holder.MouseLeftButtonUp += onClick;
        }
        array[0].Path.Fill = Brushes.CornflowerBlue;
    }

    void setTips() {
        for (int i = 0; i < array.Length; i++) {
            array[i].Holder.ToolTip = tips[i];
        }
    }

    void onClick(object sender, MouseButtonEventArgs e) {
        var border = (Border)sender;
        Icon icon = null;
        for (int i = 0; i < array.Length; i++) {
            if (array[i].Holder.Equals(border)) {
                icon = array[i];
                if (Selected == icon.Id) return;
                icon.Path.Fill = Brushes.CornflowerBlue;
                continue;
            }
            ((Path)array[i].Holder.Child).Fill = Brushes.LightGray;
        }
        Selected = icon.Id;
    }


    public int Selected {
        get { return (int)GetValue(SelectedProperty); }
        set { SetValue(SelectedProperty, value); }
    }

    public static readonly DependencyProperty SelectedProperty =
        DependencyProperty.Register("Selected", typeof(int), typeof(CheckGroup), new PropertyMetadata(0));

    class Icon {
        public int Id { get; set; }
        public Border Holder { get; set; }
        Path path;
        public Path Path {
            get { return path; }
            set { path = value; Holder.Child = value; }
        }
        public Icon() {
            Holder = new Border() {
                Padding = new Thickness(2.5, 0, 2.5, 0),
                Background = Brushes.Transparent
            };
        }
    }
}
