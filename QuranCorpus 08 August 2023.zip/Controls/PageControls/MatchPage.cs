﻿
partial class MatchPage : Page {
    string indexMa;
    Grid content;
    ProgressBar progress;
    TextBlockArabic searchKey;
    TextBlockEnglish searchModeBlock, groupNoBlock;
    CheckGroup checkGroup;
    TreeView tagTree, lemmaTree, spellingTree, surahTree;
    CancellationTokenSource terminator;
    List<Match> matches;
    MorphView testBox;
    DependencyPropertyDescriptor groupStateDescriptor;
    byte searchMode;
    string[] anArray = { "N", "PN", "ADJ", "LOC", "INTG", "T", "COND" };
    StringBuilder builder = new();

    public override PageType Type => PageType.Match;
    public override UIElement Content => content;

    public MatchPage() {
        indexMa = "|" + ((App)Application.Current).indexMa;
        progress = new ProgressBar() { Height = 1.5 };
        searchKey = new TextBlockArabic();
        searchModeBlock = new TextBlockEnglish() {
            Margin = new Thickness(10, 0, 0, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        groupNoBlock = new TextBlockEnglish() {
            Foreground = Brushes.Gray,
            Margin = new Thickness(10, 0, 0, 0),
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center
        };
        checkGroup = new CheckGroup() {
            FlowDirection = FlowDirection.LeftToRight,
            HorizontalAlignment = HorizontalAlignment.Right,
            Icons = new string[] { Icons.Tag, Icons.Seed, Icons.CopyArabic, Icons.List, Icons.WorkPlace },
            Tips = new string[] { "tag", "lemma", "spelling", "surah", "morph" }
        };
        Grid.SetColumn(searchModeBlock, 1);
        Grid.SetColumn(groupNoBlock, 2);
        Grid.SetColumn(checkGroup, 3);
        var panel = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition()/*{ Width = GridLength.Auto }*/
            },
            Children = { searchKey, searchModeBlock, checkGroup, groupNoBlock }
        };
        Grid.SetRow(panel, 1);

        initializeTrees();
        testBox = new MorphView() { Visibility = Visibility.Hidden };

        Grid.SetRow(testBox, 2);
        content = new Grid() {
            RowDefinitions = {
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, panel, tagTree, lemmaTree, spellingTree, surahTree, testBox }
        };
        terminator = new CancellationTokenSource();
        groupStateDescriptor = DependencyPropertyDescriptor.FromProperty(CheckGroup.SelectedProperty, typeof(CheckGroup));
        groupStateDescriptor.AddValueChanged(checkGroup, onCheckStateChanged);
        tagTree.MouseDoubleClick += onDoubleLick;
        spellingTree.MouseDoubleClick += onDoubleLick;
        surahTree.MouseDoubleClick += onDoubleLick;
        lemmaTree.MouseDoubleClick += onDoubleLick;
    }

    public MatchPage(Word w) : this() {
        var word = App.links.First(x => x.Reference.Equals(w.Reference));
        var index = App.transliterations.IndexOf(w.Transliteration).ToString();

        List<Link> match;
        string header = "";
        if (string.IsNullOrEmpty(word.Root)) {
            if (string.IsNullOrEmpty(word.LemmaSimple)) {
                searchMode = 3;
                searchModeBlock.Text = "Search mode: literal";
                searchKey.Text = string.Join(" | ", word.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)].toArabic()));
                header = searchKey.Text;
                match = App.links.Where(x => x.Transliteration.Equals(index)).ToList();
            }
            else {
                searchMode = 2;
                searchModeBlock.Text = "Search mode: lemma";
                searchKey.Text = string.Join(" | ", word.LemmaSimple.Split('|').Select(x => App.lemmas[Convert.ToInt32(x)].toArabic()));
                header = searchKey.Text;
                match = App.links.Where(x => x.LemmaSimple.Equals(word.LemmaSimple)).ToList();
            }
        }
        else {
            if (word.Root.Contains('|')) {
                // in one case 20:94:2 - ya ibna umma - two roots bny and Amm
                searchMode = 3;
                searchModeBlock.Text = "Multiple roots, Search mode: literal";
                searchKey.Text = string.Join(" | ", word.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)].toArabic()));
                header = searchKey.Text;
                match = App.links.Where(x => x.Transliteration.Equals(index)).ToList();
            }
            else {
                searchMode = 1;
                searchModeBlock.Text = "Search mode: root";
                searchKey.Text = App.roots[Convert.ToInt32(word.Root)].toArabic();
                header = searchKey.Text;
                match = App.links.Where(x => x.Root.Equals(word.Root)).ToList();
            }
        }

        HeaderText = "(" + match.Count.ToString("N0") + ") " + header;
        progress.IsIndeterminate = true;

        Task.Run(() => {
            matches = new List<Match>();
            var fileName = App.global.TranslationDictionary[App.global.Translation];
            var lines = System.IO.File.ReadLines("Resources/Tanzil/" + fileName);
            var iterator = lines.GetEnumerator();
            iterator.MoveNext();
            string line = iterator.Current;
            bool hasLemma = false;
            List<Morph> list = new();
            string detIndex = "";
            for (int i = 0; i < App.tags.Count; i++) {
                if (!App.tags[i].Name.Equals("DET")) continue;
                detIndex = i.ToString();
                break;
            }

            foreach (var item in match) {
                if (terminator.IsCancellationRequested) break;

                var ayahNo = item.Reference.Substring(0, item.Reference.LastIndexOf(':') + 1);
                var wordNo = item.Reference.Substring(item.Reference.LastIndexOf(':'));
                var ayahTxt = ayahNo.Substring(0, ayahNo.Length - 1).Replace(':', '|');

                if (!line.StartsWith(ayahTxt)) {
                    while (!iterator.Current.StartsWith(ayahTxt)) iterator.MoveNext();
                    line = iterator.Current;
                }

                var no = Convert.ToInt32(wordNo.Substring(1));
                int count = 1;

                bool hasLeading = no != 1;
                bool hasTrailing = false;
                bool fromBeginning = no == 1;

                List<Word> words = new();
                var index = App.links.IndexOf(item);
                int startIndex = index - no + 1;
                if (hasLeading && no < 6) {
                    index = startIndex;
                    fromBeginning = true;
                }

                while (true) {
                    words.Add(new Word() {
                        Reference = App.links[index].Reference,
                        Segments = Helper.getSegments(App.links[index])
                    });
                    index++;
                    if (index == App.links.Count) {
                        hasTrailing = false;
                        break;
                    }
                    count++;
                    if (count > 10) {
                        hasTrailing = App.links[index].Reference.StartsWith(ayahNo);
                        break;
                    }

                    if (!App.links[index].Reference.StartsWith(ayahNo)) {
                        if (!fromBeginning) {
                            var lastIndex = index - words.Count;
                            index = lastIndex - 10 + words.Count;
                            if (index < startIndex) {
                                index = startIndex;
                                hasLeading = false;
                            }
                            count = 0;
                            while (index < lastIndex) {
                                words.Insert(count, new Word() {
                                    Reference = App.links[index].Reference,
                                    Segments = Helper.getSegments(App.links[index])
                                });
                                count++;
                                index++;
                            }
                        }
                        break;
                    }
                }

                if (!fromBeginning && hasLeading) words.Insert(0, new Word());
                if (hasTrailing) words.Add(new Word());

                string tag = "";
                string spelling = "";
                string lemma = "";

                if (searchMode == 1) {
                    var tuple = getSpelling(item);
                    tag = tuple.Item1;
                    spelling = tuple.Item2;
                    lemma = getLemma(item);
                    hasLemma = true;

                    var details = item.Details.Split(',')[Convert.ToInt32(item.RootIndex)];
                    details = string.Join('|', details.Split('|').Select(x => App.details[Convert.ToInt32(x)].Name));

                    var t = App.tags[Convert.ToInt32(tag)];
                    var morph = getMorph(t.Name, details);
                    morph.Segments = Helper.getSegments(item);
                    morph.Spellings = getSpellings(item);
                    morph.Tags = item.Tags.Split('|');

                    builder.Clear();
                    item.explain(builder);

                    morph.Explanation = builder.ToString();
                    morph.References.Add(item.Reference);
                    list.Add(morph);
                }
                else if (searchMode == 2) {
                    var indices = item.LemmaIndices.Split('|');
                    if (indices.Length == 1) {
                        var tuple = getSpelling(item);
                        tag = tuple.Item1;
                        spelling = tuple.Item2;
                        lemma = getLemma(item);
                        hasLemma = true;

                        var details = item.Details.Split(',')[Convert.ToInt32(item.LemmaIndices)];
                        details = string.Join('|', details.Split('|', StringSplitOptions.RemoveEmptyEntries).Select(x => App.details[Convert.ToInt32(x)].Name));

                        var t = App.tags[Convert.ToInt32(tag)];
                        var morph = getMorph(t.Name, details);
                        morph.Segments = Helper.getSegments(item);
                        morph.Spellings = getSpellings(item);
                        morph.Tags = item.Tags.Split('|');

                        builder.Clear();
                        item.explain(builder);

                        morph.Explanation = builder.ToString();
                        morph.References.Add(item.Reference);
                        list.Add(morph);
                    }
                    else {
                        tag = item.Tags;
                        spelling = string.Join("", item.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)].toArabic()));
                    }
                }
                else {
                    tag = item.Tags;
                    spelling = string.Join("", item.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)].toArabic()));
                }

                matches.Add(new Match() {
                    Spelling = spelling,
                    Reference = item.Reference,
                    WordNo = wordNo,
                    Lemma = lemma,
                    Transliteration = App.transliterations[Convert.ToInt32(item.Transliteration)],
                    Meaning = App.meanings[Convert.ToInt32(item.Meaning)],
                    Tag = tag,
                    Words = words,
                    Translation = line
                });
            }
            iterator.Dispose();

            var tagGroups = matches.GroupBy(x => x.Tag).ToList();
            var spellingGroups = matches
                .GroupBy(x => x.Spelling)
                .OrderBy(x => (x.Key, StringComparison.Ordinal))
                .ToList();
            var surahGroups = matches.GroupBy(x => x.Reference.Substring(0, x.Reference.IndexOf(':'))).ToList();

            var tagItems = new List<MatchedItems>();
            var spellItems = new List<MatchedItems>();
            var surahItems = new List<MatchedItems>();

            foreach (var item in tagGroups) {
                var parts = item.Key.Split('|');
                var header = string.Join(" | ", parts.Select(x => App.tags[Convert.ToInt32(x)].Name));
                tagItems.Add(new MatchedItems() {
                    Header = header,
                    Items = item.ToList()
                });
            }

            foreach (var item in spellingGroups) {
                string header = item.Key;
                spellItems.Add(new MatchedItems() {
                    Header = header,
                    Items = item.ToList()
                });
            }

            foreach (var item in surahGroups) {
                var header = App.surahs.First(x => x.Id == Convert.ToInt32(item.Key)).Transliteration;
                surahItems.Add(new MatchedItems() {
                    Header = header,
                    Items = item.ToList()
                });
            }

            string infoText;
            List<LemmaGroup> lemmaGroups = null;
            if (hasLemma) {
                lemmaGroups = matches.GroupBy(x => x.Lemma)
                        .Select(x => new LemmaGroup {
                            Lemma = x.Key,
                            Spelling = x.GroupBy(x => x.Spelling).ToList()
                        }).ToList();
                infoText = tagGroups.Count + " tag | " + lemmaGroups.Count + " lemma | " + spellingGroups.Count + " spelling | " + surahGroups.Count + " surah";
            }
            else {
                infoText = tagGroups.Count + " tag | " + spellingGroups.Count + " spelling | " + surahGroups.Count + " surah";
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    testBox.Update(list);
                    if (hasLemma) {
                        foreach (var lemma in lemmaGroups) {
                            var root = new TreeViewItem() {
                                HeaderTemplate = new MatchHeaderArabicTemplate()
                            };
                            lemmaTree.Items.Add(root);
                            if (lemma.Spelling.Count == 1) {
                                root.Header = new Tuple<string, string>(lemma.Lemma.toArabic(), lemma.Spelling[0].Count().ToString());
                                root.ItemTemplate = new MatchTemplate();
                                root.ItemsSource = lemma.Spelling[0];
                            }
                            else {
                                int total = 0;
                                int grandTotal = 0;
                                foreach (var spell in lemma.Spelling) {
                                    var items = spell.ToList();
                                    root.Items.Add(new TreeViewItem() {
                                        Header = new Tuple<string, string>(spell.Key, spell.Count().ToString()),
                                        HeaderTemplate = new MatchHeaderArabicTemplate(),
                                        ItemsSource = items,
                                        ItemTemplate = new MatchTemplate()
                                    });
                                    total++;
                                    grandTotal += items.Count;
                                }
                                root.Header = new Tuple<string, string>(lemma.Lemma.toArabic(), total + " | " + grandTotal);
                            }
                        }
                    }
                    else lemmaTree.Items.Clear();

                    foreach (var item in tagItems) {
                        tagTree.Items.Add(new TreeViewItem() {
                            Header = new Tuple<string, string>(item.Header, item.Items.Count.ToString()),
                            ItemsSource = item.Items,
                            HeaderTemplate = new MatchHeaderTemplate(),
                            ItemTemplate = new MatchTemplate()
                        });
                    }
                    foreach (var item in spellItems) {
                        spellingTree.Items.Add(new TreeViewItem() {
                            Header = new Tuple<string, string>(item.Header, item.Items.Count.ToString()),
                            ItemsSource = item.Items,
                            HeaderTemplate = new DataTemplate() {
                                VisualTree = new FrameworkElementFactory(typeof(SpellingGroupTemplate))
                            },
                            ItemTemplate = new MatchTemplate()
                        });
                    }
                    foreach (var item in surahItems) {
                        surahTree.Items.Add(new TreeViewItem() {
                            Header = new Tuple<string, string>(item.Header, item.Items.Count.ToString()),
                            ItemsSource = item.Items,
                            HeaderTemplate = new MatchHeaderTemplate(),
                            ItemTemplate = new MatchTemplate()
                        });
                    }
                    groupNoBlock.Text = infoText;
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    void initializeTrees() {
        tagTree = new TreeView() {
            FlowDirection = FlowDirection.LeftToRight,
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            // if you set HorizontalScrollBarVisibilityProperty here and disable the 
                            // tree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
                            // it will mess up when scrollbar appears and disappears
                            //new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()),
                        }
                    }
                }
            }
        };
        tagTree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        tagTree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true); // no default virtualization
        spellingTree = new TreeView() {
            Visibility = Visibility.Hidden,
            FlowDirection = FlowDirection.RightToLeft,
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = { new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()) }
                    }
                }
            }
        };
        spellingTree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        spellingTree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true); // no default virtualization
        surahTree = new TreeView() {
            Visibility = Visibility.Hidden,
            FlowDirection = FlowDirection.LeftToRight,
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = { new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()) }
                    }
                }
            }
        };
        surahTree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        surahTree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true); // no default virtualization
        lemmaTree = new TreeView() {
            Visibility = Visibility.Hidden,
            FlowDirection = FlowDirection.RightToLeft,
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = { new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()) }
                    }
                }
            }
        };
        lemmaTree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        lemmaTree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true); // no default virtualization
        Grid.SetRow(tagTree, 2);
        Grid.SetRow(spellingTree, 2);
        Grid.SetRow(surahTree, 2);
        Grid.SetRow(lemmaTree, 2);
    }

    Morph getMorph(string tag, string detail) {
        Morph t = new() { Tag = tag };
        var array = detail.Split('|');
        if (anArray.Contains(tag)) {
            for (int i = 0; i < array.Length; i++) {
                if (string.IsNullOrEmpty(array[i])) continue;
                if (array[i].Equals("PCPL") ||
                    array[i].Equals("ACC") ||
                    array[i].Equals("NOM") ||
                    array[i].Equals("GEN") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("ACT")) t.SubTag = "Active Participle";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive Participle";
                else if (array[i].Equals("VN")) t.SubTag = "Verbal Noun";
                else if (array[i].Equals("IN")) t.SubTag = "Noun";
                else if (array[i].Equals("CN")) t.SubTag = "Noun";
                else if (array[i].Equals("IP")) t.SubTag = "Particle";
                else if (array[i].Equals("CP")) t.SubTag = "Particle";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("V")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUBJ") ||
                    array[i].Equals("JUS") ||
                    array[i].Equals("JUSS") ||
                    array[i].Equals("SP:kaAn") ||
                    array[i].Equals("SP:kaAd") ||
                    array[i].Equals("INDEF")) continue;

                if (array[i].Equals("IMPF")) t.SubTag = "Imperfect";
                else if (array[i].Equals("PASS")) t.SubTag = "Passive";
                else if (array[i].Equals("IMPV")) t.SubTag = "Imperative";
                else if (array[i].Equals("PERF")) t.SubTag = "Perfect";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name.Replace("(", "").Replace(")", "");
                else t.Gender = Helper.getGender(array[i]).Name;
            }
            if (string.IsNullOrEmpty(t.Form)) t.Form = "I";
        }
        else if (tag.Equals("PRON")) {
            for (int i = 0; i < array.Length; i++) {
                if (array[i].Equals("SUB")) t.SubTag = "Subject";
                else if (array[i].Equals("OBJ")) t.SubTag = "Object";
                else if (array[i].Equals("PER")) t.SubTag = "Personal";
                else if (array[i].Equals("POS")) t.SubTag = "Possessive";
                else if (array[i].StartsWith('(')) t.Form = Helper.getForm(array[i]).Name;
                else t.Gender = Helper.getGender(array[i]).Name;
            }
        }
        return t;
    }

    string[] getSpellings(Link item) {
        int lIndex;
        if (item.LemmaSimple.EndsWith(indexMa)) {
            // in 8 cases it ends with maA
            lIndex = 0;
        }
        else lIndex = Convert.ToInt32(item.LemmaIndices);
        return new string[] {
            item.SpellingGroupCorpus.Split('|')[lIndex],
            item.SpellingGroupSimple.Split('|')[lIndex]
        };
    }

    Tuple<string, string> getSpelling(Link item) {
        int lIndex;
        if (item.LemmaSimple.EndsWith(indexMa)) {
            // in 8 cases it ends with maA
            lIndex = 0;
        }
        else lIndex = Convert.ToInt32(item.LemmaIndices);
        var tag = item.Tags.Split('|')[lIndex];
        string segment;
        if (App.global.Transcript == 0) {
            var spellIndex = Convert.ToInt32(item.SpellingGroupCorpus.Split('|')[lIndex]);
            segment = App.spellings[spellIndex];
        }
        else {
            var spellIndex = Convert.ToInt32(item.SpellingGroupSimple.Split('|')[lIndex]);
            segment = App.spellings[spellIndex];
        }
        return new Tuple<string, string>(tag, segment.toArabic());
    }

    string getLemma(Link item) {
        int lIndex;

        if (item.LemmaSimple.EndsWith(indexMa)) {
            // in 8 cases it ends with maA
            lIndex = App.global.Transcript == 0 ?
                Convert.ToInt32(item.LemmaCorpus.Split('|')[0]) :
                Convert.ToInt32(item.LemmaSimple.Split('|')[0]);

        }
        else lIndex = App.global.Transcript == 0 ?
                Convert.ToInt32(item.LemmaCorpus.Split('|')[0]) :
                Convert.ToInt32(item.LemmaSimple.Split('|')[0]);

        return App.lemmas[Convert.ToInt32(lIndex)];

    }

    void onCheckStateChanged(object? sender, EventArgs e) {
        if (checkGroup.Selected == 0) {
            testBox.Visibility = Visibility.Hidden;
            hideTrees(new TreeView[] { surahTree, lemmaTree, spellingTree });
            tagTree.Visibility = Visibility.Visible;
        }
        else if (checkGroup.Selected == 1) {
            testBox.Visibility = Visibility.Hidden;
            hideTrees(new TreeView[] { surahTree, tagTree, spellingTree });
            lemmaTree.Visibility = Visibility.Visible;
        }
        else if (checkGroup.Selected == 2) {
            testBox.Visibility = Visibility.Hidden;
            hideTrees(new TreeView[] { surahTree, lemmaTree, tagTree });
            spellingTree.Visibility = Visibility.Visible;
        }
        else if (checkGroup.Selected == 3) {
            testBox.Visibility = Visibility.Hidden;
            hideTrees(new TreeView[] { spellingTree, lemmaTree, spellingTree });
            surahTree.Visibility = Visibility.Visible;
        }
        else {
            hideTrees(new TreeView[] { surahTree, spellingTree, lemmaTree, tagTree });
            testBox.Visibility = Visibility.Visible;
        }
    }

    void hideTrees(TreeView[] array) {
        for (int i = 0; i < array.Length; i++) {
            array[i].Visibility = Visibility.Hidden;
        }
    }

    void onDoubleLick(object sender, MouseButtonEventArgs e) {
        if (e.ChangedButton != MouseButton.Left) return;
        Match match;
        if (checkGroup.Selected == 0) {
            if (tagTree.SelectedItem == null) return;
            if (tagTree.SelectedItem is not Match) return;
            match = (Match)tagTree.SelectedItem;
        }
        else if (checkGroup.Selected == 1) {
            if (lemmaTree.SelectedItem == null) return;
            if (lemmaTree.SelectedItem is not Match) return;
            match = (Match)lemmaTree.SelectedItem;
        }
        else if (checkGroup.Selected == 2) {
            if (spellingTree.SelectedItem == null) return;
            if (spellingTree.SelectedItem is not Match) return;
            match = (Match)spellingTree.SelectedItem;
        }
        else {
            if (surahTree.SelectedItem == null) return;
            if (surahTree.SelectedItem is not Match) return;
            match = (Match)surahTree.SelectedItem;
        }

        ((App)Application.Current).Pages.addSurahPage(match.Reference);
    }

    protected override void unload() {
        tagTree.MouseDoubleClick -= onDoubleLick;
        spellingTree.MouseDoubleClick -= onDoubleLick;
        surahTree.MouseDoubleClick -= onDoubleLick;
        lemmaTree.MouseDoubleClick -= onDoubleLick;
        groupStateDescriptor.RemoveValueChanged(checkGroup, onCheckStateChanged);
        terminator.Cancel();
        terminator.Dispose();
        base.unload();
    }

    class LemmaGroup {
        public string Lemma { get; set; }
        public List<IGrouping<string, Match>> Spelling { get; set; }
    }
}
