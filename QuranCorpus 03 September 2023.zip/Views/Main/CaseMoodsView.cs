﻿class CaseMoodsView : View {
    public override string Icon => Icons.TrendingUp;
    public override bool OverridesToolTip => true;
    public override UIElement Tip => getTip();
    public override FrameworkElement container => grid;

    Grid grid;

    public CaseMoodsView() {
        grid = new Grid() {
            RowDefinitions = {
                new RowDefinition(),
                new RowDefinition(){ Height = new GridLength(1.3, GridUnitType.Star)}
            }
        };
        AddVisualChild(grid);
    }

    public override void OnFirstSight() {
        base.OnFirstSight();
        var cases = new CaseView();
        var moods = new MoodView();

        Grid.SetRow(moods, 1);
        grid.Children.Add(cases);
        grid.Children.Add(moods);

        cases.OnFirstSight();
        moods.OnFirstSight();
    }

    Grid getTip() {
        var header = new TextBlockEnglish() {
            Text = "Case and Moods",
            FontWeight = FontWeights.Bold
        };
        var separator = new Rectangle() {
            Height = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Stretch
        };
        var description = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Text = "See words with cases and imperfect verbs and their moods."
        };
        Grid.SetRow(separator, 1);
        Grid.SetRow(description, 2);
        return new Grid() {
            MaxWidth = 200,
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = new GridLength(10) },
                new RowDefinition()
            },
            Children = { header, separator, description }
        };
    }
}
