﻿class Conjugated {
    public string Person { get; set; }
    public string As { get; set; }
    public string To { get; set; }
    public string[] Word { get; set; }
    public string[] Pronoun { get; set; }
    public bool IsSorted { get; set; }
    public List<string> References { get; set; }
    public Conjugated() {
        References = new List<string>();
    }
}
