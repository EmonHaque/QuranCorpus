﻿enum PronounType {
    Normal,
    Demonstrative,
    Relative
}
