﻿class FormPage : Page {
    StringBuilder builder = new();
    POSFormKey current;
    List<POSForm> original, treeSource;

    Grid content;
    ProgressBar progress;
    TreeView tree;
    TagCount tags;
    WaterBox query;

    Run morphTotal;
    ListBox listMorph, listMeaning;

    CancellationTokenSource terminator;

    public override PageType Type => PageType.Form;
    public override UIElement Content => content;

    public FormPage() {
        progress = new ProgressBar() { Height = Constants.ProgressBarHeight };
        tags = new TagCount() {
            Margin = new Thickness(0, 0, 0, 5),
            FlowDirection = FlowDirection.LeftToRight
        };

        query = new WaterBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Icon = Icons.Search,
            Hint = "Root (buckwalter)"
        };

        var buckwalter = new BuckwalterPopup();

        var countBlock = new TextBlockEnglish() {
            VerticalAlignment = VerticalAlignment.Bottom,
            Margin = new Thickness(Constants.ScrollBarThickness + Constants.ScrollPresenterMargin, 0, 5, 0)
        };

        tree = new TreeView() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 0, 0),
            Template = new TreeViewLedgerTemplate()
        };
        tree.SetValue(Grid.IsSharedSizeScopeProperty, true);

        Grid.SetRow(query, 1);
        Grid.SetRow(buckwalter, 1);
        Grid.SetRow(countBlock, 1);
        Grid.SetRow(tree, 2);
        Grid.SetColumn(buckwalter, 1);
        Grid.SetColumn(query, 2);
        Grid.SetColumnSpan(tree, 3);
        Grid.SetColumnSpan(tags, 3);

        var leftGrid = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition()
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { tags, query, buckwalter, countBlock, tree }
        };
        countBlock.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = tree,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });

        var separator = new Rectangle() {
            Width = Constants.BottomLineThickness,
            Fill = Brushes.Gray,
            VerticalAlignment = VerticalAlignment.Stretch
        };

        var morphView = getMorphGrid();

        Grid.SetRow(separator, 1);
        Grid.SetRow(leftGrid, 1);
        Grid.SetRow(morphView, 1);
        Grid.SetColumn(separator, 1);
        Grid.SetColumn(leftGrid, 2);
        Grid.SetColumnSpan(progress, 3);
        content = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition() { Width = new GridLength(1.5, GridUnitType.Star) },
                new ColumnDefinition() { Width = new GridLength(10) },
                new ColumnDefinition()
            },
            RowDefinitions = {
                new RowDefinition(){ Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, leftGrid, separator, morphView }
        };

        terminator = new CancellationTokenSource();

        tags.SelectionChanged += onTagSelectionChanged;
        tree.SelectedItemChanged += onTreeSelectionChanged;
        listMorph.SelectionChanged += onMorphSelectionChanged;
        listMeaning.MouseDoubleClick += onMeaningDoubleClick;
        query.KeyUp += onQueryEnter;
        App.global.PropertyChanged += onTranscriptChanged;

    }

    public FormPage(POSFormKey key) : this() {
        setTags(key);
    }

    public void setContent(POSFormKey key) {
        current.PropertyChanged -= onCountChanged;
        setTags(key);
    }

    private void onCountChanged(object? sender, PropertyChangedEventArgs e) {
        if (!e.PropertyName.Equals(nameof(POSFormKey.NoOfWord))) return;
        tags.ResetNumbers(current.NoOfWord.Select(x => x.Item2).ToList());
    }

    Grid getMorphGrid() {
        var morphCount = new Run();
        morphTotal = new Run();
        var listCountBlock = new TextBlockEnglish() {
            HorizontalAlignment = HorizontalAlignment.Left,
            FlowDirection = FlowDirection.LeftToRight,
            Inlines = { morphTotal, new Run(" in "), morphCount }
        };

        listMorph = new ListBox() {
            Template = new ListBoxLedgerTemplate(),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MorphListTemplate))
            }
        };
        listMorph.SetValue(Grid.IsSharedSizeScopeProperty, true);

        var splitter = new GridSplitter() {
            Margin = new Thickness(0, 5, 0, 0),
            ResizeDirection = GridResizeDirection.Rows,
            HorizontalAlignment = HorizontalAlignment.Stretch,
            Template = new SplitterTemplate()
        };

        var meaningCount = new TextBlockEnglish() { HorizontalAlignment = HorizontalAlignment.Left };
        listMeaning = new ListBox() {
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Thickness(0, 5, 5, 0),
            ItemTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(MeaningListTemplate))
            }
        };
        listMeaning.SetValue(Grid.IsSharedSizeScopeProperty, true);
        listMeaning.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);

        morphCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMorph,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });
        meaningCount.SetBinding(TextBlockEnglish.TextProperty, new Binding() {
            Path = new PropertyPath("Items.Count"),
            Source = listMeaning,
            Mode = BindingMode.OneWay,
            StringFormat = "N0"
        });

        Grid.SetRow(listMorph, 1);
        Grid.SetRow(splitter, 2);
        Grid.SetRow(meaningCount, 2);
        Grid.SetRow(listMeaning, 3);

        return new Grid() {
            RowDefinitions = {
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition() { Height = new GridLength(2.5, GridUnitType.Star) },
                new RowDefinition() { Height = new GridLength(15) },
                new RowDefinition()
            },
            Children = { listCountBlock, listMorph, splitter, meaningCount, listMeaning }
        };
    }

    void setTags(POSFormKey key) {
        current = key;
        HeaderText = "Form " + key.Form;
        tags.Items = key.NoOfWord
            .Select(x => new TagCount.TagItem() { Name = x.Item1, Count = x.Item2 })
            .ToList();
        tags.Selected = tags.Items.First();
        onTagSelectionChanged(tags.Selected);
        current.PropertyChanged += onCountChanged;
    }

    void onQueryEnter(object sender, KeyEventArgs e) {
        if (e.Key != Key.Enter) return;
        var q = query.Text.Trim();
        if (string.IsNullOrEmpty(q)) createTree(treeSource);
        else {
            var source = treeSource.Where(x => x.Root.Contains(query.Text.Trim())).ToList();
            createTree(source);
        }
    }

    void onTagSelectionChanged(TagCount.TagItem item) {
        original = current.Items.First(x => x.Key.Equals(item.Name)).Value;
        filterSource();
        createTree(treeSource);
    }

    void filterSource() {
        var newSource = new List<POSForm>(original);
        var duplicates = newSource
            .GroupBy(x => new { Key = x.Spellings[App.global.Transcript], x.Tag, x.Root, x.Gender, x.Form })
                  .Where(x => x.Count() > 1)
                  .ToList();

        for (int i = 0; i < duplicates.Count; i++) {
            var list = duplicates[i].ToList();
            var item = new POSForm() {
                Form = list[0].Form,
                Gender = list[0].Gender,
                Root = list[0].Root,
                Spellings = list[0].Spellings,
                SubTag = list[0].SubTag,
                Tag = list[0].Tag
            };
            for (int j = 0; j < list.Count; j++) {
                newSource.Remove(list[j]);
                item.References.AddRange(list[j].References);
            }
            newSource.Add(item);
        }
        treeSource = newSource;
    }

    void onTreeSelectionChanged(object sender, RoutedPropertyChangedEventArgs<object> e) {
        if (tree.SelectedItem is null) return;
        var item = tree.SelectedItem as POSForm;
        if (item is null) {
            if (tree.SelectedItem is TreeViewItem ti) {
                item = ti.Header as POSForm;
            }
            if (item is null) {
                morphTotal.Text = "0";
                listMorph.ItemsSource = null;
                return;
            }
        }
        listPOSMorph(item);
    }

    void onMorphSelectionChanged(object sender, SelectionChangedEventArgs e) {
        if (listMorph.SelectedItem is null) {
            listMeaning.ItemsSource = null;
            return;
        }
        var meaningSource = ((Morph)listMorph.SelectedItem).References; ;
        listMeaning.ItemsSource = meaningSource;
        listMeaning.ScrollIntoView(meaningSource[0]);
    }

    void onMeaningDoubleClick(object sender, MouseButtonEventArgs e) {
        if (listMeaning.SelectedItem is null) return; // can be null?
        var item = (Tuple<string, string, string>)listMeaning.SelectedItem;
        ((App)Application.Current).FocusedControl.addSurahPage(item.Item1);
    }

    void onTranscriptChanged(object? sender, PropertyChangedEventArgs e) {
        if (!e.PropertyName.Equals(nameof(App.global.Transcript))) return;

        filterSource();
        createTree(treeSource);
    }

    void createTree(List<POSForm> source) {
        listMorph.ItemsSource = null;
        morphTotal.Text = "0";
        tree.Items.Clear();
        var groups =
            source.GroupBy(x => x.Gender)
            .Select(x => new {
                x.Key,
                Value = x.GroupBy(x => x.SubTag)
                    .OrderBy(x => x.Count())
                    .ToList()
            })
            .ToList();


        for (int i = 0; i < groups.Count; i++) {
            var key = string.IsNullOrEmpty(groups[i].Key) ? "Unidentified" : groups[i].Key;
            var branch = new TreeViewItem();
            int grandTotal = 0;

            for (int j = 0; j < groups[i].Value.Count; j++) {
                var val = groups[i].Value[j];
                var items = val.ToList();
                grandTotal += items.Count;

                if (!string.IsNullOrEmpty(val.Key)) {
                    var count = items.Sum(x => x.References.Count);
                    branch.Items.Add(new TreeViewItem() {
                        Header = new Tuple<string, string>(val.Key, items.Count + " | " + count),
                        HeaderTemplate = new DataTemplate() {
                            VisualTree = new FrameworkElementFactory(typeof(WordFormHeaderTemplate))
                        },
                        ItemsSource = items,
                        ItemTemplate = new DataTemplate() {
                            VisualTree = new FrameworkElementFactory(typeof(WordFormTemplate))
                        }
                    });
                }
                else {
                    for (int k = 0; k < items.Count; k++) {
                        branch.Items.Add(new TreeViewItem() {
                            Header = items[k],
                            HeaderTemplate = new DataTemplate() {
                                VisualTree = new FrameworkElementFactory(typeof(WordFormTemplate))
                            }
                        });
                    }
                }
            }
            branch.Header = new Tuple<string, string>(key, grandTotal.ToString("N0"));
            branch.HeaderTemplate = new DataTemplate() {
                VisualTree = new FrameworkElementFactory(typeof(WordFormHeaderTemplate))
            };
            tree.Items.Add(branch);
        }
    }

    void listPOSMorph(POSForm selected) {
        progress.IsIndeterminate = true;
        Task.Run(() => {
            if (!selected.IsSorted) {
                selected.References.Sort(new SurahAyahWordNoComparator());
                selected.IsSorted = true;
            }

            var morphs = new List<Morph>();
            var iterator = App.links.GetEnumerator();
            iterator.MoveNext();

            for (int i = 0; i < selected.References.Count; i++) {
                if (terminator.IsCancellationRequested) break;
                while (!iterator.Current.Reference.Equals(selected.References[i])) iterator.MoveNext();

                morphs.Add(iterator.Current.toMorph(builder));
            }

            iterator.Dispose();

            var listSource = morphs
              .GroupBy(x => new { Word = x.Segments[App.global.Transcript], x.Explanation })
              .Select(x => new Morph() {
                  Segments = x.First().Segments,
                  Count = x.Count(),
                  Tags = x.First().Tags,
                  Explanation = x.Key.Explanation,
                  References = x.SelectMany(x => x.References).ToList()
              })
              .OrderByDescending(x => x.Count)
              .ToList();

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    morphTotal.Text = listSource.Sum(x => x.Count).ToString("N0");
                    listMorph.ItemsSource = listSource;
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);

    }

    protected override void unload() {
        tags.SelectionChanged -= onTagSelectionChanged;
        tree.SelectedItemChanged -= onTreeSelectionChanged;
        listMorph.SelectionChanged -= onMorphSelectionChanged;
        listMeaning.MouseDoubleClick -= onMeaningDoubleClick;
        query.KeyUp -= onQueryEnter;
        App.global.PropertyChanged -= onTranscriptChanged;
        terminator.Cancel();
        terminator.Dispose();
        base.unload();
    }
}

class WordFormHeaderTemplate : Grid {
    TextBlockEnglish name, count;
    public WordFormHeaderTemplate() {
        FlowDirection = FlowDirection.LeftToRight;
        name = new TextBlockEnglish();
        count = new TextBlockEnglish() { VerticalAlignment = VerticalAlignment.Center };

        SetColumn(count, 1);

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

        Children.Add(name);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var c = (Tuple<string, string>)DataContext;
        name.Text = c.Item1;
        count.Text = c.Item2;
    }
}

class WordFormTemplate : Grid {
    TextBlockArabic word, root;
    TextBlockEnglish count;

    public WordFormTemplate() {
        word = new TextBlockArabic();
        root = new TextBlockArabic() {
            Foreground = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Left
        };
        count = new TextBlockEnglish() {
            Margin = new Thickness(0, 0, 5, 0),
            VerticalAlignment = VerticalAlignment.Center,
            HorizontalAlignment = HorizontalAlignment.Left
        };

        SetColumn(root, 1);
        SetColumn(word, 2);

        ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col1" });
        ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col2" });
        ColumnDefinitions.Add(new ColumnDefinition());

        Children.Add(word);
        Children.Add(root);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var c = (POSForm)DataContext;

        word.Text = App.spellings[Convert.ToInt32(c.Spellings[App.global.Transcript])].toArabic();
        root.Text = c.Root.toArabic();
        count.Text = c.References.Count.ToString("N0");
    }
}
