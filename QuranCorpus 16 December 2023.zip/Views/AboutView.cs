﻿class AboutView : CardView {
    public override string Icon => Icons.InfoCircle;

    public override void OnFirstSight() {
        base.OnFirstSight();
        initializeUI();
    }

    void initializeUI() {
        var externalBorder = new Border() {
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
            BorderBrush = Brushes.LightGray,
            Child = new TextBlockEnglish() {
                Text = "External resources",
                FontWeight = FontWeights.Bold
            }
        };

        var corpusLink = new Hyperlink() {
            NavigateUri = new Uri("http://corpus.quran.com"),
            TextDecorations = null,
            Inlines = {
                new Run("The Quranic Arabic Corpus"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };
        //In total 
        var corpusBlock = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
               new Run("Transcriptions, word segmentations, roots, lemmas and gramatical tags have been taken from the \"Quranic Arabic Corpus (Version 0.4)\". Visit "),
               corpusLink,
               new Run(" for more information. Transliterations, word by word translations, morphological explanations, buckwalter character maps have also been parsed from their site. All their data can be found in the Resources/Corpus folder in nine plain text files and an additional indexing \"link.txt\" file has been added there. Each of those nine files contains unique list and in the \"link.txt\" indices of those lists are stored. Some lemmas end with the character '2' in their Version 0.4 text file and that ending character '2' has been removed. The word nahnu in 2:102:31 has been classified as dual instead of plural and na in 18:38:2 has been removed so 18:38:1 has become lakinna instead of lakin plus na. ba'damA in 2:181, 8:6 and 13:37 has been split into two words so in total there're 77,432 words instead of 77,429. Pronoun alif in 2:186:11 has been removed and merged into daEa and faillam in 11:14:1 has become fa + in + lam. In total 8,907 new segments have been added:"),
               new LineBreak(),
               new LineBreak(),
               new Bullet(),
               new Run("572 'ta', at the end of third person feminine singular perfect and perfect passive verbs, has been separated and classified as subject pronoun, go to Pronoun View and right click 3FS to see those."),
               new LineBreak(),
               new LineBreak(),
               new Bullet(),
               new Run("7,925 more can be seen under SUFF tag in POS View. With simple script you'll see 25 suffix listed on the left and each of those, except the long _ta and _Y (alif maksura), has one explanation. _ta and _Y have two explanation. To see the explanation select a leaf word in the middle. These explanation could be wrong."),
               new LineBreak(),
               new LineBreak(),
               new Bullet(),
               new Run("340 more can be seen under BRID tag in POS View, each of those 3 phonetic bridges has one explanation and these could be wrong. For example - the ya in kibriyah probably is not a phonetic bridge, it probably has been used to make it noun or adjective. ahlihim and ahliyhim sound same but one has ya and the other doesn't."),
               new LineBreak(),
               new LineBreak(),
               new Bullet(),
               new Run("and the rest 70 can be seen under root 'ywm'. iz from yawmaiz and yawmiiz has been separated and yawm has been classified as noun, genitive when it's yawmi-iz and accusative when it's yawma-iz. You can see those is under root 'ywm' in Words View."),
               new LineBreak(),
               new LineBreak(),
               new Run("To see one of the words with longest segments in the popup, enter 5:44:14 in the go to box of Surah page and hover over the word."),


            }
        };

        var tanzilLink = new Hyperlink() {
            NavigateUri = new Uri("https://tanzil.net"),
            TextDecorations = null,
            Inlines = {
                new Run("Tanzil"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };
        var tanzilBlock = new TextBlockEnglish() {
            Margin = new Thickness(0, 10, 0, 0),
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
                new Run("There're 16 english translations available in "),
                tanzilLink,
                new Run(" as of 03 September 2023. All their plain text files are in Resources/Tanzil folder.")
            }
        };

        var hablullahLink = new Hyperlink() {
            NavigateUri = new Uri("https://github.com/hablullah/data-quran"),
            TextDecorations = null,
            Inlines = {
                new Run("GitHub"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };

        var quranComLink = new Hyperlink() {
            NavigateUri = new Uri("https://quran.com/1:1/tafsirs/en-tafisr-ibn-kathir"),
            TextDecorations = null,
            Inlines = {
                new Run("Quran.com"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };

        var hablullahBlock = new TextBlockEnglish() {
            Margin = new Thickness(0, 10, 0, 0),
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
                new Run("Tafsir ibn kathir has been downloaded from "),
                hablullahLink,
                new Run(" and it, probably, downloads data from "),
                quranComLink,
                new Run(". Surah 105, Al-Feel, doesn't have separate tafsir, it displayed tafsir of Surah 104, Al-Humazah in Quran.com on 04 September 2023. Verses 7-8 of Surah 60, Al-Mumtahanah, and verses 17-28 of Surah 68, Al-Qalam, don't have english. The en-ibn-kathir-qurancom.md file has been renamed to .txt, fews lins at the beginning has been removed and modified file is in Resources/Tafsir folder.")
            }
        };

        var kfgqpcLink = new Hyperlink() {
            NavigateUri = new Uri("https://qurancomplex.gov.sa/en/"),
            TextDecorations = null,
            Inlines = {
                new Run("KFGQPC"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };

        var kfgqpcBlock = new TextBlockEnglish() {
            Margin = new Thickness(0, 10, 0, 0),
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
                new Run("All eight recitations/readings have been downloaded from "),
                kfgqpcLink,
                new Run(" website. Under the Fonts menu there's a sub menu for \"The ten modes of Qur'anic reading\" and there's eight digitized version available as of 23 November 2023. Each reading comes in a MS Word Document along with a font and the word documents have been parsed with \"DocumentFormat.OpenXml 2.20\" nuget package. Bazzi, Hafs, Qunbul and Shuba includes bismillah as a separate verse of Surah Al Fatiha so it's there as a separate verse in .txt files in \"Resources/KFGQPC/Recitations\" folder. Bismillah has been removed from all other surah. Surah number, name and verse counts are in \"Resources/KFGQPC/Surah\" folder and all of their fonts are in \"Resources/KFGQPC/Fonts\" folder.")
            }
        };

        var hadithsLink = new Hyperlink() {
            NavigateUri = new Uri("https://github.com/ShathaTm/LK-Hadith-Corpus"),
            TextDecorations = null,
            Inlines = {
                new Run("GitHub"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };

        var hadithBlock = new TextBlockEnglish() {
            Margin = new Thickness(0, 10, 0, 0),
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
                new Run("All hadiths have been taken from "),
                hadithsLink,
                new Run(". There's an important note on these hadiths in their GitHub page, read that. According to their GitHub page, these csv files contains 39,038 hadith. I've used TextFieldParser of Microsoft.VisualBasic.FileIO to parse all those csv files and according to my count, there're 33,959 hadith with one hadith number, 123 hadith with 2 numbers, 5 hadith with 3 numbers and 1 hadith with 4 numbers so in total there're 34,224 hadith numbers in 34,088 hadith. Hadith with multiple hadith numbers have been found only in bukhari.")
            }
        };

        var arabicFontLink = new Hyperlink() {
            NavigateUri = new Uri("https://arabicfonts.net/"),
            TextDecorations = null,
            Inlines = {
                new Run("Arabic Fonts"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };
        var arabicFontBlock = new TextBlockEnglish() {
            Margin = new Thickness(0, 10, 0, 0),
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
                new Run("Some or all Arabic fonts (1) Al Qalam Quran Majeed Web Regular, (2) Amiri Quran Regular, (3) Scheherazade Regular, (4) KFGQPC Uthman Taha Naskh Regular (5) KFGQPC Uthmanic Script HAFS Regular (6) me quran, (7) Lateef and (8) Droid Naskh have been taken from "),
                arabicFontLink,
                new Run(".")
            }
        };

        var materialDesignLink = new Hyperlink() {
            NavigateUri = new Uri("https://materialdesignicons.com/"),
            TextDecorations = null,
            Inlines = {
                new Run("Material Design"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };
        var materialDesignBlock = new TextBlockEnglish() {
            Margin = new Thickness(0, 10, 0, 0),
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
                new Run("All svg icons have been taken from "),
                materialDesignLink,
                new Run(" and are embedded in the application.")
            }
        };

        var appRepoLink = new Hyperlink() {
            NavigateUri = new Uri("https://github.com/EmonHaque/QuranCorpus"),
            TextDecorations = null,
            Inlines = {
                new Run("GitHub"){
                    FontWeight = FontWeights.Bold,
                    Foreground = Brushes.CornflowerBlue
                }
            }
        };

        var microsoftBlock = new TextBlockEnglish() {
            Margin = new Thickness(0, 10, 0, 0),
            Inlines = {
                new Run("It's a .net 8 WPF application built with Visual Studio 2022 Community Edition on Windows 11. Visit "),
                appRepoLink,
                new Run(" to download the project.")
            }
        };

        var usageBorder = new Border() {
            Margin = new Thickness(0, 10, 0, 0),
            BorderThickness = new Thickness(0, 0, 0, Constants.BottomLineThickness),
            BorderBrush = Brushes.LightGray,
            Child = new TextBlockEnglish() {
                Text = "Usage",
                FontWeight = FontWeights.Bold
            }
        };
        var usageBlock = new TextBlockEnglish() {
            TextWrapping = TextWrapping.Wrap,
            Inlines = {
                new Run("In the Home Page, there're two panels, left panel is for pages and the right one is to show twelve views. In between those panels, there're twelve icons to change view on the right panel. First one, selected by default, is Surah View. When you right click a Surah, a page is added in the left panel and when you left click a Surah, Surah page will be updated if it is focused or selected."),
                new LineBreak(),
                new LineBreak(),
                new Run("Second view is Word view and it's three subviews. By default, words/sentences that's root are shown in the first sub view  and you can change these sub views by clicking the three icons in the bottom. When you right click on a branch or leaf of the tree, a page will be added in the left panel and when you left click, page will be updated if it's a lemma page and selected. The second sub view is for words without root and grouped by lemma and the third sub view is for words which don't have either. Same left/right click functionalities are available for these subviews. All words (separated by space) of the Quran are covered in these three sub views."),
                new LineBreak(),
                new LineBreak(),
                new Run("There're 1,642 distinct roots in \"Quranic Arabic Corpus\" and there's one word that's 2 roots. I've listed that, 20:94:2 - yabnaumma, separately with '|' so altogether 1643 roots are shown. There're 4,648 unique Root-Lemma pairs in \"Quranic Arabic Corpus\" and the one, with 2 roots, have 2 more reference so altogether number of lemma's become 4,650 in the first sub view. There're 175 distinct lemmas for words which don't have root of which 2 ends with character 2, \"maE2\" and \"<i*aA2\", that '2' has been removed, altogether 173 lemmas are shown in the second sub view. There're 152 words that don't have root or lemma. These numbers will vary if you switch to simple transcript in global settings."),
                new LineBreak(),
                new LineBreak(),
                new Run("Third view's two sub views. There are few words which have been spelled out in the same way but segmented differently and in the first sub view, those words have been listed. Same left right click functionality is available to open or update a SegmentPage in this sub view. In the bottom of the segment page, word reference and probable meanings have been listed. To get into the context, double click the reference/meaning in the list, it'll take you to that ayah of surah. The second sub view for words with multiple tags and only right click functionality is there to open a MatchPage. On top of this sub view, there're two items in a CheckGroup - the second one is for words which have N and ADJ tags and the first one is for the rest."),
                new LineBreak(),
                new LineBreak(),
                new Run("The fourth one is Tag View. You can give a name and create Tag, eg. Musa tag for listing all verses related to Musa. You can select one or more verses from Surah or flat list of Lemma pages only and drag selected Ayah(s) on top of your tag and drop to get those added in your tag. Similar left/right clicking functionalities are there to open and update Tag page. You can reorder verses by dragging and dropping verses in Tag page and can remove by right clicking on verse. Tags are created in a separate Tag folder in the Resources folder of the application. To save your tags, store that folder somewhere else before updating code or application."),
                new LineBreak(),
                new LineBreak(),
                new Run("The fifth view is for inna, kada, kana and their sisters. You can right click on a list item in those three sub views to open a match page. The sixth view groups words and particles by Tag. The seventh view groups words which have root in form I through XII. Word that doesn't have a form has been grouped into I. The eighth view presents words with same root in a matrix, highlights duplicate spellings and if you double click a word in the matrix, it'll take you to MorphPage and if you double click on meaning in MorphPage, it'll take you to the surah. Same left and right click fucntionality is available to add or update POSPage, FormPage and RootMatrixPage."),
                new LineBreak(),
                new LineBreak(),
                new Run("The ninth view is for words with cases and moods. The top view for cases, ie. accusative, nominative and genitive and the bottom view is for moods, ie. indicative, subjunctive and jussive. Cases are found in Noun, Proper Noun and Adjectives and moods are found in imperfect verbs. Both cases and moods have been grouped by genders and the same left and right click functionality is also available for this view to add or update CasePage or MoodPage. There're 7 text boxes in CasePage, 1 for root and six for case endings. In root box you can type buckwalter, eg. smw, and hit enter to filter out words which don't have that root. In 6 other boxes you can type one or more ending characters in buckwalter and hit enter to filter. For example, in genitive box you can type i to see words that ends with kesra or to negate you can type !i to see words which don't end with kesra. All cases have been divided into two - definite and indefinite. Words that have prefixed DET, Al, have been classfied as Definite, otherwise Indefinite. In MoodPage there're 4 text boxes to filter, 1 for root and other 3 for ending character(s)."),
                new LineBreak(),
                new LineBreak(),
                new Run("The tenth view is for words that have atleast two things and one of them is pronoun. There're 4 possibilities for these pronouns - subject, object, personal and possessive. Same left and right click functionality is available to add or update PronounPage. There're 3 sections, separated by vertical lines, in the PronounPage. The right section list the forms/spellings as the first branch of tree. If you select a leaf in the tree, the middle section will be populated with words to which the pronoun is attached and if you change selection in the middle section the left section will be populated with detail and probable meaning. There're 4 buttons on top of PronounView to see attached, detached, relative and demonstrative pronouns in a matrix in PronounMatrixPage. Double click on a pronoun in PronounMatrixPage will take you to MatchPage and match count may vary compared to other matching techniques. For exampla, dha/ja has been tagged as Noun (18 times) and Demonstrative pronoun (5 times). When you double click dha/ja in a SurahPage, MatchPage will show you all 23 but you'll get only 5 if you double click ja on PronounMatrixPage."),
                new LineBreak(),
                new LineBreak(),
                new Run("The eleventh view is divided into two parts, top part is only for verbs and the bottom is for anything that has root and not a verb. Left/right click functionality is available to add or update VerbPage/NotVerbPage. On the right side of VerbPage there're two WaterBox for query and two MultiState for voice (active/passive) and mood (indicative/subjunctive/jussive). You click those MultiState to apply filter. In Query boxes plus sign (+) is the wildcard. If you want to find all quadriliteral roots, type 4 plus in Root query box and hit enter. In Verb query box, you can type +a+~a+a in and hit enter to find 'faala' pattern in Third person Masculine Singular - Form II. In these kind of pattern search the suffixed subject pronoun is ignored and the length of the pattern has to match the length of verb. In Verb query box you can also have starts with, ends with and negate those starts and ends with query pattern. For starts with query, the first character has to be '/', for ends with query the first character has to be '\\'. To negate starts with or ends with use '!/' or '!\\'. For example, to see all First person Plural that starts with 'na', type '/na' and hit enter and to see those which don't starts with 'na', type '!/na' and hit enter. Ends with query checks attached subject pronoun, if there's any. For NotVerbPage, there's no Active/Passive state and functionalities of rest of the controls are identical to VerbPage"),
                new LineBreak(),
                new LineBreak(),
                new Run("The twelfth view is for eight different recitations/teadings. Left/right click functionality is there to add or update ReciterPage. These readings need special fonts to render characters properly so the global font change does not affect the text. The thirteenth view is for six hadith books, you can right click to add and left click to update HadithPage. There're 3 buttons on top right corner of HadithPage to group hadith by chapter, narrator (isnad/sanad) and grade. A WaterBox to bring a hadith, by number, into view and a search button to search hadith by content (matan) or isnad. If you click the search icon a SearchHadithPage will be added. By default search page will search tokens in the english content (matan). Click the right most button to search in english narration chain (isnad/sanad). Click the other button for arabic input. Hit enter after entering some characters to find matches."),
                new LineBreak(),
                new LineBreak(),
                new Run("Last view is global settings for font, font size, translations and script. Corpus transcript is the unmodified script in the \"Quranic Arabic Corpus\" and the Simple, uthmanic-simple, has been taken from tanzil.net. Tanzil has 1 more word than corpus, see 37:130 il yas. Some diacritics have ben added for removed, eg. a kesra has been added when words end with alif maksura but pronounced as ya."),
                new LineBreak(),
                new LineBreak(),
                new Run("By hovering over a word in Surah or Tag page you can see relevant information, parsed from the \"Quranic Arabic Corpus\". When you double click a word, a Match page with matching words will be added in the left panel. You can group those matching verses by Tag/Parts of Speech, Spelling variation and Surah. On the top right corner it'll display the mode of searching. First it searches by root, if there's no root it goes with lemma and if neither exist, it goes with the literal. Probable meaning of the word, parsed from \"Quranic Arabic Corpus\", is displayed on third column from the left and when you hover over the arabic, a tooltip will pop up to display the translation, selected in settings view. When you doble click a verse - it will take you to that Surah to read in context."),
                new LineBreak(),
                new LineBreak(),
                new Run("In Surah or Tag page, there's a Pentip icon for selecting more than one translation for that page. In SurahPage, there're three search icons, one for searching locally, ie. in that surah, another for finding in entire Quran and the last one for Hadith. If you click the global search, a search page will be added in the left panel. Both arabic and english search is supported. For arabic spelling has to be exactly like what's rendered. To copy an arabic word you can hold down left control button on keyboard and left mouse click to select a word. If you want to select multiple words - select a word first, hold down left control and left shift keys of keyboard together and left mouse click on another word in the same ayah - it'll select all words in between, right mouse click and click \"copy word(s)\" in the context menu. If you've only one ayah selected and some word(s) in that ayah are also selected,  right click will let you copy words. If you've multiple ayahs selected - it'll let you copy all selected ayahs. To copy a single ayah - make sure no word is selected in that ayah. To deselect word(s), hold down left control button of keyboard and left mouse click on any selected word - it'll clear selection."),
                new LineBreak(),
                new LineBreak(),
                new Run("There's a wave icon in Surah page to see all spelling groups that you see on popup on hover over words. There's a text box to search by pattern, eg. malayikah, type in +a+`}i with Simple script and hit enter and it'll show all words that start with that pattern. Next to the query box, there's a toggle to limit the length of matching words by the length of pattern. If you copy an arabic word from SurahPage and paste on the query box, it'll transform the arabic into english transcript and you can make adjustment by additing or deleting characters. If you right click on a spelling, it'll add a LemmaPage."),
                new LineBreak(),
                new LineBreak(),
                new Run("For english search, click the ab/ayn toggle next to search box and you've to have at least one translator selected. You can select/deselect all translations by clicking the toggle on top right corner of the Translator popup. There's a go to box in Surah page where you can enter an ayah number and hit enter to bring that ayah of that surah into view or you can enter a surah no and ayah no, separated by colon, to go there. There're two more icons in SurahPage, TagPage and SearchPage to enable/disable segments' color and word morphology popup on hover. By default colorized segments and word morphology popup is disabled. SurahPage has an additional icon for Tafsir Ibn Kathir, if you click that - a TafsirPage will be added. If TafsirPage is focused and you change selection in SurahView, TafsirPage will be updated."),
                new LineBreak(),
                new LineBreak(),
                new Run("On the left pane 4 pages can be viewed simultaneously. For example, you've two SurahPage on the left pane - Al-Fatiha and Al-Alaq. Drag the header Al-Alaq on the body of surah and drop, you'll have surah Alaq on the left and Fatiha on the Right. Left lick on the header Al-Alaq, to get that side focused, and right click on Al-Baqara in Surah View, it'll be added next to Alaq. Drag Al-Baqara header and drop on the body of the surah on left side, Al-Baqara will be on the bottom left. Left click on Al-Fatiha header to get that side focused and right click An-Nisa in Surah View to get that added on that side. Drag An-Nisa header and drop on the body of surah on the right side, An-Nisa will be on bottom right."),
                new LineBreak(),
                new LineBreak(),
                new Run("I haven't tested the application thoroughly so there could be some anomalies. There're two global exception handler - one to trap UI exceptions and the other for trapping exceptions in Tasks. You can add, edit code for your own research and education. If you face any issue in understanding code, contact me at emon-haque@hotmail.com for help.")
            }
        };

        Grid.SetRow(corpusBlock, 1);
        Grid.SetRow(tanzilBlock, 2);
        Grid.SetRow(hablullahBlock, 3);
        Grid.SetRow(kfgqpcBlock, 4);
        Grid.SetRow(hadithBlock, 5);
        Grid.SetRow(arabicFontBlock, 6);
        Grid.SetRow(materialDesignBlock, 7);
        Grid.SetRow(microsoftBlock, 8);
        Grid.SetRow(usageBorder, 9);
        Grid.SetRow(usageBlock, 10);
        var scroll = new ScrollViewer() {
            Template = new ScrollViewerTemplate(),
            HorizontalScrollBarVisibility = ScrollBarVisibility.Disabled,
            VerticalScrollBarVisibility = ScrollBarVisibility.Auto,
            Content = new Grid() {
                RowDefinitions = {
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto },
                    new RowDefinition(){ Height = GridLength.Auto }
                },
                Children = {
                    externalBorder,
                    corpusBlock,
                    tanzilBlock,
                    hablullahBlock,
                    kfgqpcBlock,
                    hadithBlock,
                    arabicFontBlock,
                    microsoftBlock,
                    materialDesignBlock,
                    usageBorder,
                    usageBlock
                }
            }
        };
        setContent(scroll);

        corpusLink.RequestNavigate += onWebRequested;
        tanzilLink.RequestNavigate += onWebRequested;
        hablullahLink.RequestNavigate += onWebRequested;
        kfgqpcLink.RequestNavigate += onWebRequested;
        hadithsLink.RequestNavigate += onWebRequested;
        quranComLink.RequestNavigate += onWebRequested;
        arabicFontLink.RequestNavigate += onWebRequested;
        materialDesignLink.RequestNavigate += onWebRequested;
        appRepoLink.RequestNavigate += onWebRequested;
    }

    void onWebRequested(object sender, RequestNavigateEventArgs e) {
        Process.Start(new ProcessStartInfo(e.Uri.AbsoluteUri) { UseShellExecute = true });
    }

    class Bullet : BulletDecorator {
        public Bullet() {
            Bullet = new Ellipse() { Height = 10, Width = 10, Fill = Constants.Foreground };
            Margin = new Thickness(25, 0, 5, 0);
        }
    }
}
