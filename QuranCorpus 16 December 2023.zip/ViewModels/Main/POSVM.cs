﻿class POSVM : Notifiable {
    byte sortOrder;
    int tagCount, segmentCount;
    public int currentTranscript;
    Dictionary<POSKey, List<POS>> source;

    KeyValuePair<POSKey, List<POS>> selected;
    public KeyValuePair<POSKey, List<POS>> Selected {
        get { return selected; }
        set {
            if (value.Key is null) {
                return;
            }
            if (value.Equals(selected)) return;

            selected = value;

            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).FocusedControl.SelectedPage is POSPage page) {
                page.setContent(selected);
            }
        }
    }
    string query;
    public string Query {
        get { return query; }
        set { query = value?.ToLower(); Items.Refresh(); }
    }

    public bool WasRightClicked { get; set; }
    public string Status { get; set; }
    public bool IsInProgress { get; set; }
    public ICollectionView Items { get; set; }

    public POSVM() {
        Items = CollectionViewSource.GetDefaultView(new List<int>());
        IsInProgress = true;
        sortOrder = 0;
        Task.Run(() => {
            source = new Dictionary<POSKey, List<POS>>();
            for (int i = 0; i < App.links.Count; i++) {
                tagCount++;
                var link = App.links[i];
                var tags = link.Tags.Split('|');
                var simple = link.SpellingGroupSimple.Split('|');
                var corpus = link.SpellingGroupCorpus.Split('|');

                for (int j = 0; j < tags.Length; j++) {
                    segmentCount++;
                    var tag = App.tags[Convert.ToInt32(tags[j])];
                    var pair = new KeyValuePair<POSKey, List<POS>>();
                    int l = 0, m = source.Count - 1;
                    while (l <= m) {
                        if (source.ElementAt(l).Key.Name.Equals(tag.Name)) {
                            pair = source.ElementAt(l);
                            break;
                        }
                        if (source.ElementAt(m).Key.Name.Equals(tag.Name)) {
                            pair = source.ElementAt(m);
                            break;
                        }
                        l++;
                        m--;
                    }

                    if (pair.Key is null) {
                        var pos = new POS() {
                            Spellings = new string[] { corpus[j], simple[j] }
                        };
                        pos.References.Add(link.Reference);
                        var list = new List<POS>() { pos };

                        var key = new POSKey() {
                            Name = tag.Name,
                            Value = tag.Name.Equals("INL") ? "initials" : tag.Value
                        };
                        source.Add(key, list);
                    }
                    else {
                        POS match = null;
                        int n = 0, o = pair.Value.Count - 1;
                        while (n <= o) {
                            if (pair.Value[n].Spellings[0].Equals(corpus[j]) &&
                                pair.Value[n].Spellings[1].Equals(simple[j])) {
                                match = pair.Value[n];
                                break;
                            }
                            if (pair.Value[o].Spellings[0].Equals(corpus[j]) &&
                                pair.Value[o].Spellings[1].Equals(simple[j])) {
                                match = pair.Value[o];
                                break;
                            }
                            n++;
                            o--;
                        }
                        if (match is null) {
                            var pos = new POS() {
                                Spellings = new string[] { corpus[j], simple[j] }
                            };
                            pos.References.Add(link.Reference);
                            pair.Value.Add(pos);
                        }
                        else match.References.Add(link.Reference);
                    }
                }

                if (tagCount % 2000 == 0) {
                    App.Current.Dispatcher.Invoke(() => {
                        Status = tagCount.ToString("N0") + " of " + App.links.Count.ToString("N0") + " processed";
                        OnPropertyChanged(nameof(Status));
                    });
                }
            }

            App.Current.Dispatcher.Invoke(() => {
                Items = CollectionViewSource.GetDefaultView(source);
                Items.Filter = filter;
                Status = "finished tagging " + tagCount.ToString("N0") + " words";
                OnPropertyChanged(nameof(Items));
                OnPropertyChanged(nameof(Status));
            });

            Thread.Sleep(500);
            Regroup();
        });
    }

    public void Regroup() {
        IsInProgress = true;
        Task.Run(() => {
            currentTranscript = App.global.Transcript;
            var formCount = 0;
            var list = new List<int>();
            for (int i = 0; i < source.Count; i++) {
                var pair = source.ElementAt(i);
                int count = 0;
                int refCount = 0;
                List<string> matched = new();
                for (int j = 0; j < pair.Value.Count; j++) {
                    if (!matched.Contains(pair.Value[j].Spellings[App.global.Transcript])) {
                        matched.Add(pair.Value[j].Spellings[App.global.Transcript]);
                        count++;
                    }
                    refCount += pair.Value[j].References.Count;
                }
                list.Add(count);
                formCount += count;
            }

            App.Current.Dispatcher.Invoke(() => {
                for (int i = 0; i < source.Count; i++) {
                    var key = source.ElementAt(i).Key;
                    key.FormCount = list[i];
                    key.OnPropertyChanged(nameof(POSKey.FormCount));
                }
                IsInProgress = false;
                Status = segmentCount.ToString("N0") + " segments, " + formCount.ToString("N0") + " forms, " + source.Count + " tags";

                OnPropertyChanged(nameof(Status));
                OnPropertyChanged(nameof(IsInProgress));
            });
        });
    }

    public void Sort() {
        if (sortOrder == 0) {
            source = source.OrderByDescending(x => x.Value.Sum(x => x.References.Count)).ToDictionary(x => x.Key, x => x.Value);
            sortOrder = 1;
        }
        else {
            source = source.OrderByDescending(x => x.Key.FormCount).ToDictionary(x => x.Key, x => x.Value);
            sortOrder = 0;
        }
        Items = CollectionViewSource.GetDefaultView(source);
        Items.Filter = filter;
        OnPropertyChanged(nameof(Items));
    }

    bool filter(object o) {
        if (string.IsNullOrEmpty(Query)) return true;
        var kv = (KeyValuePair<POSKey, List<POS>>)o;
        return kv.Key.Name.ToLower().Contains(Query);
    }
}