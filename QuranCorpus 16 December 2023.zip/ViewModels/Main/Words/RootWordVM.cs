﻿class RootWordVM : Notifiable {
    List<GroupedLemma> groups;
    List<Lemma> source;
    bool isAscending;
    public int currentTranscript;

    object selected;
    public object Selected {
        get { return selected; }
        set {
            if (value is null) {
                selected = null;
                return;
            }
            if (value.Equals(selected)) return;

            selected = value;

            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).FocusedControl.SelectedPage is LemmaPage page) {
                page.setContent(selected);
            }
        }
    }
    string query;
    public string Query {
        get { return query; }
        set {
            query = value is null ? "" : value;
            filter(query);
        }
    }

    public string Covered { get; set; }
    public bool WasRightClicked { get; set; }
    public string Count { get; set; }
    public bool IsInProgress { get; set; }
    public List<LemmaHeader> Lemmas { get; set; }

    public RootWordVM() {
        IsInProgress = true;

        var indexMa = App.indexMa.Substring(1);
        var indexIz = App.indexIz.Substring(1);

        Task.Run(() => {
            int count = 0;
            source = new List<Lemma>();
            for (int i = 0; i < App.links.Count; i++) {
                if (string.IsNullOrEmpty(App.links[i].Root)) continue;
                var link = App.links[i];
                count++;
                var tags = link.Tags.Split('|');
                var indices = link.LemmaIndices.Split('|');
                var simple = link.LemmaSimple.Split('|');
                var corpus = link.LemmaCorpus.Split('|');
                // 20:94:2 - yabnaumma has multiple roots
                string root =
                    link.Root.Contains('|') ?
                    string.Join(" | ", link.Root.Split('|').Select(x => App.roots[Convert.ToInt32(x)])) :
                    App.roots[Convert.ToInt32(link.Root)];

                for (int j = 0; j < indices.Length; j++) {
                    if (simple[j].Equals(indexMa) || simple[j].Equals(indexIz)) {
                        /*
                         * bi}osa|maA - root bAs
                         * baEod|maA - root bEd
                         * niEoma|maA - root nEm
                         * kul~amaA|maA - root kll
                         * yawma}i*
                         * yawmi}i*
                         */
                        continue;
                    }
                    var pos = App.tags[Convert.ToInt32(tags[Convert.ToInt32(indices[j])])].Name;
                    var lemmas = new string[] {
                        App.lemmas[Convert.ToInt32(corpus[j])],
                        App.lemmas[Convert.ToInt32(simple[j])]
                    };

                    bool isFound = false;
                    int k = 0, l = source.Count - 1;
                    while (k <= l) {
                        if (source[k].Transcripts[0].Equals(lemmas[0]) &&
                            source[k].Transcripts[1].Equals(lemmas[1]) &&
                            source[k].POS.Equals(pos) &&
                            source[k].Root[0].Equals(root)) {
                            source[k].References.Add(link.Reference);
                            isFound = true;
                            break;
                        }
                        if (source[l].Transcripts[0].Equals(lemmas[0]) &&
                            source[l].Transcripts[1].Equals(lemmas[1]) &&
                            source[l].POS.Equals(pos) &&
                            source[l].Root[0].Equals(root)) {
                            source[l].References.Add(link.Reference);
                            isFound = true;
                            break;
                        }
                        k++;
                        l--;
                    }

                    if (!isFound) {
                        var references = new List<string>() { link.Reference };
                        source.Add(new Lemma() {
                            Transcripts = lemmas,
                            POS = pos,
                            Root = new string[] { root, "" },
                            References = references
                        });
                    }
                }
            }
            groups = source.GroupBy(x => x.Root[0])
            .Select(x => new GroupedLemma {
                Root = x.Key,
                Lemmas = x.GroupBy(x => x.Transcripts[App.global.Transcript]).ToList()
            }).ToList();

            filter("");

            currentTranscript = App.global.Transcript;

            App.Current.Dispatcher.Invoke(() => {
                Covered = count.ToString("N0") + " words covered";
                OnPropertyChanged(nameof(Covered));
            });
        });
    }

    public void Regroup() {
        groups = source.GroupBy(x => x.Root[0])
            .Select(x => new GroupedLemma {
                Root = x.Key,
                Lemmas = x.GroupBy(x => x.Transcripts[App.global.Transcript]).ToList()
            }).ToList();

        filter(query);
        currentTranscript = App.global.Transcript;
    }

    public void Sort() {
        isAscending = !isAscending;
        filter(Query);
    }

    void filter(string query) {
        if (groups is null) return;

        IsInProgress = true;
        OnPropertyChanged(nameof(IsInProgress));

        Task.Run(() => {
            int rootCount = 0;
            int formCount = 0;
            Lemmas = new List<LemmaHeader>();

            foreach (var group in groups) {
                if (!group.Root.Contains(query)) continue;
                rootCount++;
                var header = new LemmaHeader() { Root = group.Root };
                header.Items = new List<Lemma>();
                foreach (var subGroup in group.Lemmas) {

                    if (subGroup.Count() == 1) {
                        header.Items.Add(subGroup.First());
                        formCount++;
                        continue;
                    }
                    foreach (var item in subGroup) {
                        bool hasFound = false;
                        foreach (var x in header.Items) {

                            if (x.Transcripts[App.global.Transcript].Equals(item.Transcripts[App.global.Transcript])) {
                                hasFound = true;
                                x.Items.Add(item);
                                break;
                            }
                        }
                        if (!hasFound) {
                            header.Items.Insert(0, item);
                            item.Items = new List<Lemma> {
                                new Lemma(item)
                            };
                            formCount++;
                        }
                    }
                }
                Lemmas.Add(header);
            }

            Lemmas.Sort(new Comparator(isAscending));

            App.Current.Dispatcher.Invoke(() => {
                Count = $"{formCount.ToString("N0")} lemma in {rootCount.ToString("N0")} root";
                IsInProgress = false;
                OnPropertyChanged(nameof(Count));
                OnPropertyChanged(nameof(IsInProgress));
                OnPropertyChanged(nameof(Lemmas));
            });
        });
    }

    class Comparator : IComparer<LemmaHeader> {
        bool isAscending;
        public Comparator(bool isAscending) {
            this.isAscending = isAscending;
        }

        public int Compare(LemmaHeader? x, LemmaHeader? y) {
            int sumX = 0, sumY = 0;
            for (int i = 0; i < x.Items.Count; i++) {
                if (x.Items[i].Items != null) sumX += x.Items[i].Items.Sum(x => x.References.Count);
                else sumX += x.Items[i].References.Count;
            }
            for (int i = 0; i < y.Items.Count; i++) {
                if (y.Items[i].Items != null) sumY += y.Items[i].Items.Sum(x => x.References.Count);
                else sumY += y.Items[i].References.Count;
            }
            return isAscending ? sumX - sumY : sumY - sumX;
        }
    }
}
