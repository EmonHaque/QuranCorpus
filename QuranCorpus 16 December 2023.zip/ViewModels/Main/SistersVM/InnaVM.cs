﻿class InnaVM : Notifiable {
    List<Sister> source;
    public int currentTranscript;

    public Sister Selected { get; set; }
    public List<Sister> Items { get; set; }

    public InnaVM() {
        Task.Run(() => {
            source = new List<Sister>();
            List<string> indices = new();
            for (int i = 0; i < App.explanations.Count; i++) {
                if (!App.explanations[i].Contains("inna and her sisters")) continue;
                indices.Add(i.ToString());
            }
            for (int i = 0; i < App.links.Count; i++) {
                var link = App.links[i];
                if (string.IsNullOrEmpty(link.Explanation)) continue;

                bool isMatch = false;
                var parts = link.Explanation.Split('|');
                int segmentIndex = 0;
                for (int j = 0; j < parts.Length; j++) {
                    if (!indices.Contains(parts[j])) continue;
                    isMatch = true;
                    segmentIndex = j;
                    break;
                }
                if (!isMatch) continue;

                parts = link.LemmaSimple.Split('|');
                int lemmaIndex = 0;
                for (int j = 0; j < parts.Length; j++) {
                    if (!parts[j].Equals(segmentIndex.ToString())) continue;
                    lemmaIndex = j;
                    break;
                }

                var spellings = new string[] {
                    link.SpellingGroupCorpus.Split('|')[segmentIndex],
                    link.SpellingGroupSimple.Split('|')[segmentIndex]
                };

                var lemmas = new string[] {
                    link.LemmaCorpus.Split('|')[lemmaIndex],
                    link.LemmaSimple.Split('|')[lemmaIndex]
                };

                int k = 0, l = source.Count - 1;
                Sister match = null;
                while (k <= l) {
                    if (source[k].Spellings[0].Equals(spellings[0]) &&
                        source[k].Spellings[1].Equals(spellings[1]) &&
                        source[k].Lemmas[0].Equals(lemmas[0]) &&
                        source[k].Lemmas[1].Equals(lemmas[1])) {
                        match = source[k];
                        break;
                    }
                    if (source[l].Spellings[0].Equals(spellings[0]) &&
                        source[l].Spellings[1].Equals(spellings[1]) &&
                        source[l].Lemmas[0].Equals(lemmas[0]) &&
                        source[l].Lemmas[1].Equals(lemmas[1])) {
                        match = source[l];
                        break;
                    }
                    k++;
                    l--;
                }

                if (match is null) {
                    var sister = new Sister() {
                        Spellings = spellings,
                        Lemmas = lemmas
                    };
                    sister.References.Add(link.Reference);
                    source.Add(sister);
                }
                else match.References.Add(link.Reference);
            }

            var groups = source.GroupBy(x => x.Spellings[App.global.Transcript]).ToList();
            var items = new List<Sister>();
            for (int i = 0; i < groups.Count; i++) {
                var sister = new Sister() {
                    Spellings = new string[2],
                    Lemmas = groups[i].First().Lemmas
                };
                sister.Spellings[App.global.Transcript] = groups[i].Key;
                sister.References.AddRange(groups[i].SelectMany(x => x.References));
                sister.References.Sort(new SurahAyahWordNoComparator());
                items.Add(sister);
            }
            items = items.OrderByDescending(x => x.References.Count).ToList();
            currentTranscript = App.global.Transcript;
            App.Current.Dispatcher.Invoke(() => {
                Items = items;
                OnPropertyChanged(nameof(Items));
            });
        });
    }

    public void Regroup() {
        var groups = source.GroupBy(x => x.Spellings[App.global.Transcript]).ToList();
        var items = new List<Sister>();
        for (int i = 0; i < groups.Count; i++) {
            var sister = new Sister() {
                Spellings = new string[2],
                Lemmas = groups[i].First().Lemmas
            };
            sister.Spellings[App.global.Transcript] = groups[i].Key;
            sister.References.AddRange(groups[i].SelectMany(x => x.References));
            sister.References.Sort(new SurahAyahWordNoComparator());
            items.Add(sister);
        }
        items = items.OrderByDescending(x => x.References.Count).ToList();
        Items = items;
        OnPropertyChanged(nameof(Items));
        currentTranscript = App.global.Transcript;
    }
}
