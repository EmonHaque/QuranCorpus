﻿class Tafsir {
    public int SurahNo { get; set; }
    public string Ayahs { get; set; }
    public List<TafsirLine> Lines { get; set; }

    public Tafsir(int surah, string ayahs) {
        SurahNo = surah;
        Ayahs = ayahs;
        Lines = new List<TafsirLine>();
    }
}

class TafsirLine {
    public bool IsArabic { get; set; }
    public bool IsBold { get; set; }
    public string Content { get; set; }
}
