﻿class SurahVM : Notifiable, IAddPage {
    Surah selected;
    string query;
    public string Query {
        get { return query; }
        set { query = value; Surahs.Refresh(); }
    }
    int selectedOrder;
    public int SelectedOrder {
        get { return selectedOrder; }
        set { selectedOrder = value; sort(); }
    }

    public ICollectionView Surahs { get; set; }
    public List<PageType> Types => new List<PageType>(2) { PageType.Surah, PageType.Tafsir };

    public SurahVM() {
        Surahs = new CollectionViewSource() { Source = App.surahs }.View;
        Surahs.Filter = filter;
    }

    void sort() {
        var defer = Surahs.DeferRefresh();
        Surahs.SortDescriptions.Clear();
        switch (SelectedOrder) {
            case 0: Surahs.SortDescriptions.Add(new SortDescription(nameof(Surah.Id), ListSortDirection.Ascending)); break;
            case 1: Surahs.SortDescriptions.Add(new SortDescription(nameof(Surah.Order), ListSortDirection.Ascending)); break;
            case 2: Surahs.SortDescriptions.Add(new SortDescription(nameof(Surah.Verses), ListSortDirection.Descending)); break;
        }
        defer.Dispose();
    }

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        return ((Surah)o).Transliteration.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }

    public void UpdateSource(object item) => selected = (Surah)item;

    public void AddPage() => ((App)Application.Current).FocusedControl.addSurahPage(selected.Id);

    public void ResetPage() {
        var page = ((App)Application.Current).FocusedControl.SelectedPage;
        if (page is SurahPage p) p.setContent(selected.Id);
        else ((TafsirPage)page).setContent(selected.Id);
    }
}
