﻿class OthersVM : Notifiable, IAddPage {
    NotVerbPage currentPage;
    List<NotVerb> source;
    List<NotVerbGroup> items;
    List<Tuple<int, int>> counts;

    public List<NotVerb> filtered;
    public int currentTranscript;

    public bool IsInProgress { get; set; }
    public int Total { get; set; }
    public ICollectionView Items { get; set; }

    public List<PageType> Types => new List<PageType>(1) { PageType.NotVerb };

    public OthersVM() {
        IsInProgress = true;
        Task.Run(() => {
            var verbTag = App.tags.IndexOf(App.tags.First(x => x.Name.Equals("V"))).ToString();
            var pronTag = App.tags.IndexOf(App.tags.First(x => x.Name.Equals("SUFF"))).ToString();
            source = new List<NotVerb>();

            for (int i = 0; i < App.links.Count; i++) {
                var link = App.links[i];

                if (string.IsNullOrEmpty(link.Root)) continue;
                var ts = link.Tags.Split('|');
                if (ts.Contains(verbTag)) continue;

                var index = Convert.ToInt32(link.RootIndex);
                if (link.Root.Contains('|')) {
                    var roots = link.Root.Split('|');
                    for (int j = 0; j < roots.Length; j++) {
                        var simple = link.SegmentsSimple.Split('|')[index];
                        var corpus = link.SegmentsCorpus.Split('|')[index];

                        simple = App.segments[Convert.ToInt32(simple)];
                        corpus = App.segments[Convert.ToInt32(corpus)];

                        if (simple.Length > 1 && simple[1] == '~') simple = simple.Remove(1, 1);
                        if (corpus.Length > 1 && corpus[1] == '~') corpus = corpus.Remove(1, 1);

                        if (simple.StartsWith('}')) simple = simple.Replace('}', '\'');
                        if (corpus.StartsWith("_#")) corpus = corpus.Replace("_#", "'");
                        else if (corpus.StartsWith('}')) corpus = corpus.Replace('}', '\'');
      
                        var exp = link.Explanation.Split('|')[index];
                        var det = link.Details.Split(',')[index];

                        var gender = "Undefined";
                        if (!string.IsNullOrEmpty(exp)) {
                            var explanation = App.explanations[Convert.ToInt32(exp)];
                            if (explanation.Contains("masculine")) gender = "Masculine";
                            else if (explanation.Contains("feminine")) gender = "Feminine";
                        }

                        var word = new NotVerb() {
                            Tag = App.tags[Convert.ToInt32(ts[index])].Name,
                            Simple = [simple, ""],
                            Corpus = [corpus, ""],
                            SimpleFull = simple,
                            CorpusFull = corpus,
                            Root = App.roots[Convert.ToInt32(roots[j])],
                            Gender = gender,
                            SubTag = "",
                            Form = "I",
                            Number = "Undefined"
                        };

                        setDetail(det, word);
                        var match = getMatch(word);

                        if (match is null) {
                            word.References.Add(link.Reference);
                            source.Add(word);
                        }
                        else match.References.Add(link.Reference);
                        index++;
                    }
                }
                else {
                    var simples = link.SegmentsSimple.Split('|');
                    var corpuss = link.SegmentsCorpus.Split('|');

                    var simple = App.segments[Convert.ToInt32(simples[index])];
                    var corpus = App.segments[Convert.ToInt32(corpuss[index])];
                    var exp = link.Explanation.Split('|')[index];
                    var det = link.Details.Split(',')[index];

                    if (simple.Length > 1 && simple[1] == '~') simple = simple.Remove(1, 1);
                    if (corpus.Length > 1 && corpus[1] == '~') corpus = corpus.Remove(1, 1);

                    if (simple.StartsWith('}')) simple = simple.Replace('}', '\'');
                    if (corpus.StartsWith("_#")) corpus = corpus.Replace("_#", "'");
                    else if (corpus.StartsWith('}')) corpus = corpus.Replace('}', '\'');

                    List<string> corpusList = new() { corpus };
                    List<string> simpleList = new() { simple };

                    var nextIndex = index + 1;
                    if (nextIndex < ts.Length && App.tags[Convert.ToInt32(ts[nextIndex])].Name.Equals("SUFF")) {

                        for (int j = nextIndex; j < ts.Length; j++) {
                            if (!App.tags[Convert.ToInt32(ts[j])].Name.Equals("SUFF")) break;
                            corpusList.Add(App.segments[Convert.ToInt32(corpuss[j])]);
                            simpleList.Add(App.segments[Convert.ToInt32(simples[j])]);
                        }
                    }

                    var gender = "Undefined";
                    if (!string.IsNullOrEmpty(exp)) {
                        var explanation = App.explanations[Convert.ToInt32(exp)];
                        if (explanation.Contains("masculine")) gender = "Masculine";
                        else if (explanation.Contains("feminine")) gender = "Feminine";
                    }

                    var word = new NotVerb() {
                        Tag = App.tags[Convert.ToInt32(ts[index])].Name,
                        Simple = simpleList,
                        Corpus = corpusList,
                        SimpleFull = string.Join("", simpleList),
                        CorpusFull = string.Join("", corpusList),
                        Root = App.roots[Convert.ToInt32(link.Root)],
                        Gender = gender,
                        Case = "",
                        SubTag = "",
                        Form = "I",
                        Number = "Undefined"
                    };

                    setDetail(det, word);
                    var match = getMatch(word);

                    if (match is null) {
                        word.References.Add(link.Reference);
                        source.Add(word);
                    }
                    else match.References.Add(link.Reference);
                }
            }

            var group = source
                .GroupBy(x => x.SubTag)
                .Select(x => new {
                    x.Key,
                    Value = x.GroupBy(x => x.Gender)
                        .Select(x => new {
                            x.Key,
                            Value = x.GroupBy(x => x.Number).ToList()
                        }).ToList()
                }).ToList();

            counts = new List<Tuple<int, int>>();
            items = new List<NotVerbGroup>();
            var groupName = "";
            for (int i = 0; i < group.Count; i++) {
                var subTag = group[i];
                if (string.IsNullOrEmpty(subTag.Key)) {
                    groupName = string.Join(", ", subTag.Value.SelectMany(x => x.Value.SelectMany(x => x)).Select(x => x.Tag).Distinct());
                }
                for (int j = 0; j < subTag.Value.Count; j++) {
                    var gender = subTag.Value[j];

                    for (int k = 0; k < gender.Value.Count; k++) {
                        var number = gender.Value[k];
                        var count = new Tuple<int, int>(number.Count(),
                            number.GroupBy(x => new { s = x.SimpleFull, x.Case }).Count());
                        counts.Add(count);
                        items.Add(new NotVerbGroup() {
                            SubTag = string.IsNullOrEmpty(subTag.Key) ? groupName : subTag.Key,
                            Number = number.Key,
                            Gender = gender.Key
                        });
                    }
                }
            }

            App.Current.Dispatcher.Invoke(() => {
                Regroup();
                Items = CollectionViewSource.GetDefaultView(items);
                Items.GroupDescriptions.Add(new PropertyGroupDescription(nameof(NotVerbGroup.SubTag)));
                Items.GroupDescriptions.Add(new PropertyGroupDescription(nameof(NotVerbGroup.Gender)));
                IsInProgress = false;
                OnPropertyChanged(nameof(Items));
                OnPropertyChanged(nameof(IsInProgress));
            });
        });
    }

    void setDetail(string detail, NotVerb word) {
        if (string.IsNullOrEmpty(detail)) return;

        var array = detail.Split('|').Select(x => App.details[Convert.ToInt32(x)]).ToArray();
        for (int i = 0; i < array.Length; i++) {
            if (string.IsNullOrEmpty(array[i].Name)) continue;
            if (array[i].Equals("PCPL") ||
                array[i].Name.Equals("IN") ||
                array[i].Name.Equals("CN") ||
                array[i].Name.Equals("IP") ||
                array[i].Name.Equals("CP") ||
                array[i].Equals("INDEF")) continue;

            if (array[i].Name.Equals("ACT")) word.SubTag = "Active Participle";
            else if (array[i].Name.Equals("PASS")) word.SubTag = "Passive Participle";
            else if (array[i].Name.Equals("VN")) word.SubTag = "Verbal Noun";
            else if (array[i].Name.Equals("ACC")) word.Case = "Accusative";
            else if (array[i].Name.Equals("GEN")) word.Case = "Genitive";
            else if (array[i].Name.Equals("NOM")) word.Case = "Nominative";
            else if (array[i].Name.StartsWith('(')) word.Form = Helper.getForm(array[i].Name).Name.Replace("(", "").Replace(")", "");
            else {
                string value = "";
                switch (array[i].Name) {
                    case "P":
                    case "2D":
                    case "3D":
                    case "M":
                    case "MS":
                    case "MD":
                    case "2MD":
                    case "3MD":
                    case "MP":
                    case "2MS":
                    case "2MP":
                    case "3MS":
                    case "3MP":
                    case "1S":
                    case "1P":
                    case "F":
                    case "FS":
                    case "FP":
                    case "2FS":
                    case "FD":
                    case "2FD":
                    case "3FD":
                    case "3FS":
                    case "2FP":
                    case "3FP":
                        var d = App.details.First(x => x.Name.Equals(array[i].Name));
                        value = d.Value;
                        break;
                }

                if (value.Contains("singular")) word.Number = "Singular";
                else if (value.Contains("dual")) word.Number = "Dual";
                else if (value.Contains("plural")) word.Number = "Plural";
            }
        }
    }

    NotVerb getMatch(NotVerb word) {
        int k = 0, l = source.Count - 1;

        while (k <= l) {
            if (source[k].SimpleFull.Equals(word.SimpleFull) &&
                source[k].CorpusFull.Equals(word.CorpusFull) &&
                source[k].Root.Equals(word.Root) &&
                source[k].Form.Equals(word.Form) &&
                source[k].Case.Equals(word.Case) &&
                source[k].Gender.Equals(word.Gender) &&
                source[k].Tag.Equals(word.Tag) &&
                source[k].SubTag.Equals(word.SubTag) &&
                source[k].Number.Equals(word.Number)) {
                return source[k];
            }
            if (source[l].SimpleFull.Equals(word.SimpleFull) &&
                source[l].CorpusFull.Equals(word.CorpusFull) &&
                source[l].Root.Equals(word.Root) &&
                source[l].Form.Equals(word.Form) &&
                source[l].Case.Equals(word.Case) &&
                source[l].Gender.Equals(word.Gender) &&
                source[l].Tag.Equals(word.Tag) &&
                source[l].SubTag.Equals(word.SubTag) &&
                source[l].Number.Equals(word.Number)) {
                return source[l];
            }
            k++;
            l--;
        }

        return null;
    }

    public void Regroup() {
        Total = 0;
        if (App.global.Transcript == 0) {
            for (int i = 0; i < items.Count; i++) {
                Total += counts[i].Item1;
                items[i].Count = counts[i].Item1;
                items[i].OnPropertyChanged(nameof(NotVerbGroup.Count));
            }
        }
        else {
            for (int i = 0; i < items.Count; i++) {
                Total += counts[i].Item2;
                items[i].Count = counts[i].Item2;
                items[i].OnPropertyChanged(nameof(NotVerbGroup.Count));
            }
        }
        currentTranscript = App.global.Transcript;
        OnPropertyChanged(nameof(Total));
    }

    public void UpdateSource(object item) {
        var selected = (NotVerbGroup)item;
        filtered =
           selected.SubTag.Contains(",") ? source.Where(
        x => string.IsNullOrEmpty(x.SubTag) &&
                   x.Gender.Equals(selected.Gender) &&
                   x.Number.Equals(selected.Number))
               .ToList() :
        source.Where(
                   x => x.SubTag.Equals(selected.SubTag) &&
                   x.Gender.Equals(selected.Gender) &&
                   x.Number.Equals(selected.Number))
               .ToList();
    }

    public void AddPage() => ((App)Application.Current).FocusedControl.addNotVerbPage(filtered);

    public void ResetPage() => ((NotVerbPage)((App)Application.Current).FocusedControl.SelectedPage).setContent(filtered);
}

class NotVerbGroup : Notifiable {
    public string SubTag { get; set; }
    public string Number { get; set; }
    public string Gender { get; set; }
    public int Count { get; set; }
}
