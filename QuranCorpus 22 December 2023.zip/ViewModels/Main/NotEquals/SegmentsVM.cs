﻿class SegmentsVM : Notifiable, IAddPage {
    Segment selected;
    public List<Segment> Segments { get; set; }
    public bool IsInProgress { get; set; }

    public List<PageType> Types => new List<PageType>(1) { PageType.Segment };

    public SegmentsVM() {
        IsInProgress = true;
        Task.Run(() => {
            var groups = App.links
            .GroupBy(x => new {
                x.SegmentsCorpus,
                Literal = string.Join("", x.SegmentsCorpus.Split('|').Select(x => App.segments[Convert.ToInt32(x)])),
                Value = x.Tags.Split('|').Length
            })
            .GroupBy(x => x.Key.Literal)
            .Where(x => x.Count() > 1)
            .ToList();

            Segments = new List<Segment>(groups.Count);

            foreach (var word in groups) {
                var items = word.ToList();
                var segment = new Segment() {
                    Segments = new string[items.Count],
                    Spellings = new string[items.Count],
                    Tags = new string[items.Count],
                    Details = new string[items.Count],
                    References = new List<Link>[items.Count]
                };

                for (int i = 0; i < items.Count; i++) {
                    var first = items[i].First();
                    segment.Segments[i] = first.SegmentsCorpus;
                    segment.Spellings[i] = first.SpellingGroupCorpus;
                    segment.Details[i] = first.Details;
                    segment.Tags[i] = first.Tags;
                    segment.References[i] = new List<Link>(items[i]);
                }
                Segments.Add(segment);
            }
            IsInProgress = false;
            App.Current.Dispatcher.Invoke(() => {
                OnPropertyChanged(nameof(IsInProgress));
                OnPropertyChanged(nameof(Segments));
                
            });
        });

    }

    public void UpdateSource(object item) => selected = (Segment)item;

    public void AddPage() => ((App)Application.Current).FocusedControl.addSegmentPage(selected);

    public void ResetPage() => ((SegmentPage)((App)Application.Current).FocusedControl.SelectedPage).setContent(selected);
}
