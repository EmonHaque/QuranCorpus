﻿class POSFormTemplate : Grid {
    Run wordCount;
    TextBlockEnglish form, tags, references;
    
    public POSFormTemplate() {
        wordCount = new Run();
        form = new TextBlockEnglish();
        tags = new TextBlockEnglish() { 
            HorizontalAlignment = HorizontalAlignment.Right 
        };
        var words = new TextBlockEnglish() { 
            Foreground = Brushes.Gray,
            Inlines = {wordCount, new Run(" words")}
        };
        references = new TextBlockEnglish() {
            Foreground = Brushes.Gray,
            HorizontalAlignment = HorizontalAlignment.Right
        };

        SetColumn(tags, 1);
        SetColumn(references, 1);
        SetRow(words, 1);
        SetRow(references, 1);

        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition());
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition());

        Children.Add(form);
        Children.Add(tags);
        Children.Add(words);
        Children.Add(references);

        wordCount.SetBinding(Run.TextProperty, new Binding() {
            Path = new PropertyPath(nameof(POSFormKey.NoOfWord)),
            Converter = new TupleToNumberConverter(),
            ConverterParameter = "."
        });
    }

    public override void EndInit() {
        base.EndInit();
        var c = (POSFormKey)DataContext;
        form.Text = c.Form;
        tags.Text = c.NoOfTag + " tags";
        references.Text = c.Items.Sum(x => x.Value.Sum(x => x.References.Count)).ToString("N0") + " places";
    }


}

class TupleToNumberConverter : IValueConverter {
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) {
        if (value is null) return "0";
        var tup = (List<Tuple<string, int>>)value;
        int count = 0;
        for (int i = 0; i < tup.Count; i++) {
            count += tup[i].Item2;
        }
        return count.ToString("N0");
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) {
        throw new NotImplementedException();
    }
}