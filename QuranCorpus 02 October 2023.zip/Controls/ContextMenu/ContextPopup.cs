﻿class ContextPopup : Popup {
    Border border;
    Border[] stacks;
    IEnumerable<ContextItem> items;

    public ContextPopup(IEnumerable<ContextItem> items) { 
        this.items = items;
        stacks = new Border[items.Count()];
        var grid = new Grid();
        int index = 0;
        foreach (var item in items) {
            var block = new TextBlock() { 
                Text = item.Text,
                Foreground = Brushes.LightGray,
                VerticalAlignment = VerticalAlignment.Center,
                Margin = new Thickness(5, 0, 0, 0)
            };
            var border = new Border() {
                Tag = index,
                Padding = new Thickness(2.5),
                BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, Constants.BottomLineThickness),
                Child = new StackPanel() {
                    Orientation = Orientation.Horizontal,
                    Children = {
                        Helper.getIcon(item.Icon, Brushes.LightGray),
                        block
                    }
                }
            };
            stacks[index] = border;
            grid.RowDefinitions.Add(new RowDefinition());
            Grid.SetRow(border, index++);
            grid.Children.Add(border);
        }
        border = new Border() {
            Background = Constants.Background,
            BorderBrush = Brushes.LightGray,
            BorderThickness = new Thickness(Constants.BottomLineThickness),
            Padding = new Thickness(5),
            CornerRadius = new CornerRadius(5),
            Child = grid
        };
        StaysOpen = false;
        AllowsTransparency = true;
        Placement = PlacementMode.MousePoint;
        VerticalOffset = 5;
        Child = border;
    }

    void onMouseEnter(object sender, MouseEventArgs e) {
        var stack = (Border)sender;
        stack.Background = Constants.BackgroundDark;
        stack.BorderBrush = Brushes.LightGray;
    }

    void onMouseLeave(object sender, MouseEventArgs e) {
        var stack = (Border)sender;
        stack.Background = null;
        stack.BorderBrush = null;
    }

    void onLeftClick(object sender, MouseButtonEventArgs e) {
        IsOpen = false;
        var stack = (Border)sender;
        items.ElementAt(Convert.ToInt32(stack.Tag)).Command.Invoke();
    }
    
    protected override void OnOpened(EventArgs e) {
        base.OnOpened(e);
        foreach (var stack in stacks) {
            stack.MouseEnter += onMouseEnter;
            stack.MouseLeave += onMouseLeave;
            stack.MouseLeftButtonUp += onLeftClick;
        }
    }

    protected override void OnClosed(EventArgs e) {
        base.OnClosed(e);
        foreach (var stack in stacks) {
            stack.MouseEnter -= onMouseEnter;
            stack.MouseLeave -= onMouseLeave;
            stack.MouseLeftButtonUp -= onLeftClick;
        }
    }
}
