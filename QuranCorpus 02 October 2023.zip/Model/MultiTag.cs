﻿class MultiTag {
    public string Spelling { get; set; }
    public string Tags { get; set; }
    public bool IsSorted { get; set; }
    public List<string> References { get; set; }
}
