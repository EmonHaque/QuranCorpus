﻿class MainView : View {
    public override string Icon => Icons.Home;
    public override FrameworkElement container => grid;
    public override UIElement Tip => new TextBlockEnglish() {
        Text = "Main",
        Foreground = Constants.Foreground
    };

    static Grid grid;
    public static TabView tab;

    public MainView() : base() {
        tab = new TabView() { Margin = new Thickness(0, 0, -Constants.CardMargin, 0) };
        var side = new ViewContainer(NavPosition.TopLeftVertical) {
            Children = {
                new SurahView(),
                new WordView(),
                new NotEqualView(),
                new TagView(),
                new SistersView(),
                new POSView(),
                new FormsView(),
                new RootMatrixView(),
                new CaseMoodsView(),
                new PronounView(),
                new VerbOthersView(),
                new ReciterView(),
                new HadithView(),
                new SettingsView()
            }
        };
        Grid.SetColumn(side, 1);
        grid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(){Width = new GridLength(3, GridUnitType.Star)},
                    new ColumnDefinition(){Width = new GridLength(1, GridUnitType.Star), MaxWidth = 325 },
                },
            Children = { tab, side }
        };
        AddVisualChild(grid);
    }

    public static void HideSide() {
        grid.ColumnDefinitions[1].Width = new GridLength(0);
        tab.Margin = new Thickness(0);
    }

    public static void ShowSide() {
        grid.ColumnDefinitions[1].Width = new GridLength(1, GridUnitType.Star);
        tab.Margin = new Thickness(0, 0, -Constants.CardMargin, 0);
    }
}
