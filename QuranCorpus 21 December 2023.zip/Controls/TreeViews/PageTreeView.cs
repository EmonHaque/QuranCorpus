﻿class PageTreeView : TreeView {
    object current;
    public IAddPage Context { get; set; }

    protected override void OnKeyUp(KeyEventArgs e) {
        base.OnKeyUp(e);
        if (e.Key != Key.Enter) return;
        update(true);
    }

    protected override void OnMouseRightButtonUp(MouseButtonEventArgs e) {
        base.OnMouseRightButtonUp(e);
        update(false);
    }

    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e) {
        base.OnMouseLeftButtonUp(e);
        update(true);
    }

    protected override void OnPreviewMouseRightButtonDown(MouseButtonEventArgs e) {
        base.OnPreviewMouseRightButtonDown(e);
        var item = VisualUpwardSearch(e.OriginalSource as DependencyObject);
        if (item is null) return;

        item.Focus();
        item.IsSelected = true;
        e.Handled = true;
    }

    TreeViewItem VisualUpwardSearch(DependencyObject source) {
        while (source != null && !(source is TreeViewItem))
            source = VisualTreeHelper.GetParent(source);

        return source as TreeViewItem;
    }

    void update(bool isReset) {
        if (SelectedItem is null) return;
        if (isReset) {
            var type = ((App)Application.Current).FocusedControl.SelectedPage.Type;
            if (!Context.Types.Contains(type)) return;
        }

        if (current is null || !current.Equals(SelectedItem)) {
            Context.UpdateSource(SelectedItem);
            current = SelectedItem;
        }
        if (isReset) Context.ResetPage();
        else Context.AddPage();
    }
}
