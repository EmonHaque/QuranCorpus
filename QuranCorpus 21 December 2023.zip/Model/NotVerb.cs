﻿class NotVerb {
    public List<string> Simple { get; set; }
    public List<string> Corpus { get; set; }
    public string SimpleFull { get; set; }
    public string CorpusFull { get; set; }
    public string Tag { get; set; }
    public string Gender { get; set; }
    public string Number { get; set; }
    public string Form { get; set; }
    public string Case { get; set; }
    public string SubTag { get; set; }
    public string Root { get; set; }
    public bool IsSorted { get; set; }
    public List<string> References { get; set; }

    public NotVerb() {
        References = new List<string>();
    }

    public NotVerb(NotVerb rhs) {
        Tag = rhs.Tag;
        Simple = rhs.Simple;
        Corpus = rhs.Corpus;
        SimpleFull = rhs.SimpleFull;
        CorpusFull = rhs.CorpusFull;
        Gender = rhs.Gender;
        Number = rhs.Number;
        Form = rhs.Form;
        Case = rhs.Case;
        SubTag = rhs.SubTag;
        Root = rhs.Root;
        References = new List<string>(rhs.References);
    }
}
