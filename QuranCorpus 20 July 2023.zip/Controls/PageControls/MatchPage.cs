﻿class MatchPage : Page {
    Grid content;
    ProgressBar progress;
    TextBlockArabic searchKey;
    TextBlockEnglish searchModeBlock, groupNoBlock;
    MultiState groupState;
    TreeView tagTree, spellingTree, surahTree;
    CancellationTokenSource terminator;
    List<Match> matches;
    List<IGrouping<string, Match>> tagGroups, spellingGroups, surahGroups;
    DependencyPropertyDescriptor groupStateDescriptor;
    byte searchMode;

    public override PageType Type => PageType.Match;
    public override UIElement Content => content;

    public MatchPage() {
        progress = new ProgressBar() { Height = 1.5 };
        searchKey = new TextBlockArabic();
        searchModeBlock = new TextBlockEnglish() { 
            Margin = new Thickness(10,0,0,0),
            VerticalAlignment = VerticalAlignment.Center
        };
        groupNoBlock = new TextBlockEnglish() {
            Foreground = Brushes.Gray,
            Margin = new Thickness(10, 0, 0, 0),
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center
        };
        groupState = new MultiState() {
            Icons = new string[] { Icons.CopyArabic, Icons.List, Icons.Tag },
            Texts = new string[] { "Group by spelling", "Group by surah", "Group by tag" },
            IsIconInfront = true,
            VerticalAlignment = VerticalAlignment.Center,
            Margin = new Thickness(10, 0, 0, 0)
        };
        Grid.SetColumn(searchModeBlock, 1);
        Grid.SetColumn(groupNoBlock, 2);
        Grid.SetColumn(groupState, 3);
        var panel = new Grid() {
            ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition(){ Width = GridLength.Auto }
            },
            Children = { searchKey, searchModeBlock, groupState, groupNoBlock }
        };
        Grid.SetRow(panel, 1);

        initializeTrees();
        content = new Grid() {
            RowDefinitions = {
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition() { Height = GridLength.Auto },
                new RowDefinition()
            },
            Children = { progress, panel, tagTree, spellingTree, surahTree }
        };
        terminator = new CancellationTokenSource();
        groupStateDescriptor = DependencyPropertyDescriptor.FromProperty(MultiState.StateProperty, typeof(MultiState));
        groupStateDescriptor.AddValueChanged(groupState, onGroupStateChanged);
        tagTree.MouseDoubleClick += onDoubleLick;
        spellingTree.MouseDoubleClick += onDoubleLick;
        surahTree.MouseDoubleClick += onDoubleLick;
    }

    public MatchPage(Word w) : this() {
        var word = App.links.First(x => x.Reference.Equals(w.Reference));
        var index = App.transliterations.IndexOf(w.Transliteration).ToString();

        List<Link> match;
        string header = "";
        if (string.IsNullOrEmpty(word.Root)) {
            if (string.IsNullOrEmpty(word.Lemmas)) {
                searchMode = 3;
                searchModeBlock.Text = "Search mode: literal";
                searchKey.Text = string.Join(" | ", word.Segments.Split('|').Select(x => App.segments[Convert.ToInt32(x)].toArabic()));
                header = searchKey.Text;
                match = App.links.Where(x => x.Transliteration.Equals(index)).ToList();
            }
            else {
                searchMode = 2;
                searchModeBlock.Text = "Search mode: lemma";
                searchKey.Text = string.Join(" | ", word.Lemmas.Split('|').Select(x => App.lemmas[Convert.ToInt32(x)].toArabic()));
                header = searchKey.Text;
                match = App.links.Where(x => x.Lemmas.Equals(word.Lemmas)).ToList();
            }
        }
        else {
            searchMode = 1;
            searchModeBlock.Text = "Search mode: root";
            searchKey.Text = App.roots[Convert.ToInt32(word.Root)].toArabic();
            header = searchKey.Text;
            match = App.links.Where(x => x.Root.Equals(word.Root)).ToList();
        }

        HeaderText = "(" + match.Count.ToString("N0") + ") " + header;
        progress.IsIndeterminate = true;

        Task.Run(() => {
            matches = new List<Match>();
            var fileName = App.global.TranslationDictionary[App.global.Translation];
            var lines = System.IO.File.ReadLines("Resources/Tanzil/" + fileName);
            var iterator = lines.GetEnumerator();
            iterator.MoveNext();
            string line = iterator.Current;

            foreach (var item in match) {
                if (terminator.IsCancellationRequested) break;

                var ayahNo = item.Reference.Substring(0, item.Reference.LastIndexOf(':') + 1);
                var wordNo = item.Reference.Substring(item.Reference.LastIndexOf(':'));
                var ayahTxt = ayahNo.Substring(0, ayahNo.Length - 1).Replace(':', '|');

                if (!line.StartsWith(ayahTxt)) {
                    while (!iterator.Current.StartsWith(ayahTxt)) iterator.MoveNext();
                    line = iterator.Current;
                }
                
                var no = Convert.ToInt32(wordNo.Substring(1));
                int count = 1;

                bool hasLeading = no != 1;
                bool hasTrailing = false;
                bool fromBeginning = no == 1;

                List<Word> words = new();
                var index = App.links.IndexOf(item);
                int startIndex = index - no + 1;
                if (hasLeading && no < 6) {
                    index = startIndex;
                    fromBeginning = true;
                }

                while (true) {
                    words.Add(new Word() {
                        Reference = App.links[index].Reference,
                        Segments = App.links[index].Segments
                    });
                    index++;
                    if (index == App.links.Count) {
                        hasTrailing = false;
                        break;
                    }
                    count++;
                    if (count > 10) {
                        hasTrailing = App.links[index].Reference.StartsWith(ayahNo);
                        break;
                    }

                    if (!App.links[index].Reference.StartsWith(ayahNo)) {
                        if (!fromBeginning) {
                            var lastIndex = index - words.Count;
                            index = lastIndex - 10 + words.Count;
                            if (index < startIndex) {
                                index = startIndex;
                                hasLeading = false;
                            }
                            count = 0;
                            while (index < lastIndex) {
                                words.Insert(count, new Word() {
                                    Reference = App.links[index].Reference,
                                    Segments = App.links[index].Segments
                                });
                                count++;
                                index++;
                            }
                        }
                        break;
                    }
                }

                if (!fromBeginning && hasLeading) words.Insert(0, new Word() { Segments = "..." });
                if (hasTrailing) words.Add(new Word() { Segments = "..." });

                string tag = "";
                string spelling = "";
                if (searchMode == 1) {
                    var tuple = getSpelling(item);
                    tag = tuple.Item1;
                    spelling = tuple.Item2;
                }
                else if(searchMode == 2) {
                    var indices = item.LemmaIndices.Split('|');
                    if(indices.Length == 1) {
                        var tuple = getSpelling(item);
                        tag = tuple.Item1;
                        spelling = tuple.Item2;
                    }
                    else {
                        tag = item.Tags;
                        spelling = string.Join("", item.Segments.Split('|').Select(x => App.segments[Convert.ToInt32(x)].toArabic()));
                    }
                }
                else {
                    tag = item.Tags;
                    spelling = string.Join("", item.Segments.Split('|').Select(x => App.segments[Convert.ToInt32(x)].toArabic()));
                }

                matches.Add(new Match() {
                    Spelling = spelling,
                    Reference = item.Reference,
                    WordNo = wordNo,
                    Transliteration = App.transliterations[Convert.ToInt32(item.Transliteration)],
                    Meaning = App.meanings[Convert.ToInt32(item.Meaning)],
                    Tag = tag,
                    Words = words,
                    Translation = line
                });
            }

            iterator.Dispose();

            tagGroups = matches.GroupBy(x => x.Tag).ToList();
            spellingGroups = matches
                .GroupBy(x => x.Spelling)
                .OrderBy(x => (x.Key, StringComparison.Ordinal))
                .ToList();
            surahGroups = matches.GroupBy(x => x.Reference.Substring(0, x.Reference.IndexOf(':'))).ToList();

            var tagItems = new List<MatchedItems>();
            var spellItems = new List<MatchedItems>();
            var surahItems = new List<MatchedItems>();

            foreach (var item in tagGroups) {
                var parts = item.Key.Split('|');
                string header = "";
                foreach (var part in parts) {
                    header += App.tags[Convert.ToInt32(part)] + " | ";
                }
                header = header.Remove(header.LastIndexOf('|'), 1).TrimEnd();
                tagItems.Add(new MatchedItems() {
                    Header = header,
                    Items = item.ToList()
                });
            }

            foreach (var item in spellingGroups) {
                string header = item.Key;
                spellItems.Add(new MatchedItems() {
                    Header = header,
                    Items = item.ToList()
                });
            }

            foreach (var item in surahGroups) {
                var header = App.surahs.First(x => x.Id == Convert.ToInt32(item.Key)).Transliteration;
                surahItems.Add(new MatchedItems() {
                    Header = header,
                    Items = item.ToList()
                });
            }

            if (!terminator.IsCancellationRequested) {
                App.Current.Dispatcher.Invoke(() => {
                    foreach (var item in tagItems) {
                        tagTree.Items.Add(new TreeViewItem() {
                            Header = new Tuple<string, string>(item.Header, item.Items.Count.ToString()),
                            ItemsSource = item.Items,
                            HeaderTemplate = new MatchHeaderTemplate(),
                            ItemTemplate = new MatchTemplate()
                        });
                    }
                    foreach (var item in spellItems) {
                        spellingTree.Items.Add(new TreeViewItem() {
                            Header = new Tuple<string, string>(item.Header, item.Items.Count.ToString()),
                            ItemsSource = item.Items,
                            HeaderTemplate = new DataTemplate() {
                                VisualTree = new FrameworkElementFactory(typeof(SpellingGroupTemplate))
                            },
                            ItemTemplate = new MatchTemplate()
                        });
                    }
                    foreach (var item in surahItems) {
                        surahTree.Items.Add(new TreeViewItem() {
                            Header = new Tuple<string, string>(item.Header, item.Items.Count.ToString()),
                            ItemsSource = item.Items,
                            HeaderTemplate = new MatchHeaderTemplate(),
                            ItemTemplate = new MatchTemplate()
                        });
                    }
                    groupNoBlock.Text = tagGroups.Count + " tag | " + spellingGroups.Count + " spelling | " + surahGroups.Count + " surah";
                    progress.IsIndeterminate = false;
                });
            }
        }, terminator.Token);
    }

    void initializeTrees() {
        tagTree = new TreeView() {
            FlowDirection = FlowDirection.LeftToRight,
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = {
                            // if you set HorizontalScrollBarVisibilityProperty here and disable the 
                            // tree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
                            // it will mess up when scrollbar appears and disappears
                            //new Setter(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled),
                            new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()),
                        }
                    }
                }
            }
        };
        tagTree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        tagTree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true); // no default virtualization
        spellingTree = new TreeView() {
            Visibility = Visibility.Hidden,
            FlowDirection = FlowDirection.RightToLeft,
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = { new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()) }
                    }
                }
            }
        };
        spellingTree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        spellingTree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true); // no default virtualization
        surahTree = new TreeView() {
            Visibility = Visibility.Hidden,
            FlowDirection = FlowDirection.LeftToRight,
            Resources = {{
                    typeof(ScrollViewer),
                    new Style() {
                        Setters = { new Setter(ScrollViewer.TemplateProperty, new LedgerScrollTemplate()) }
                    }
                }
            }
        };
        surahTree.SetValue(ScrollViewer.HorizontalScrollBarVisibilityProperty, ScrollBarVisibility.Disabled);
        surahTree.SetValue(VirtualizingPanel.IsVirtualizingProperty, true); // no default virtualization
        Grid.SetRow(tagTree, 2);
        Grid.SetRow(spellingTree, 2);
        Grid.SetRow(surahTree, 2);
    }

    Tuple<string, string> getSpelling(Link item) {
        var lIndex = Convert.ToInt32(item.LemmaIndices);
        var tag = item.Tags.Split('|')[lIndex];
        var segment = App.segments[Convert.ToInt32((item.Segments.Split('|')[lIndex]))];

        if (segment.StartsWith("_#")) segment = segment.Replace("_#", "'"); // Tatweel and HamzaAbove with Hamza
        if (segment.Contains('[')) segment = segment.Replace("[", ""); // SmallHighMeemIsolatedForm
        if (segment.Contains(']')) segment = segment.Replace("]", ""); // SmallLowMeem
        if (segment.ElementAt(1) == '~') segment = segment.Remove(1, 1); // Shadda
        if (segment.EndsWith('F') || // Fathatan
            segment.EndsWith('N') || // Dammatan
            segment.EndsWith('K') || // Kasratan
            segment.EndsWith('a') || // Fatha
            segment.EndsWith('i') || // Kasra
            segment.EndsWith('u')) { // Damma
            segment = segment.Remove(segment.Length - 1);
        }
        return new Tuple<string, string>(tag, segment.toArabic());
    }

    void onGroupStateChanged(object? sender, EventArgs e) {
        if (groupState.State == 0) {
            surahTree.Visibility = Visibility.Hidden;
            tagTree.Visibility = Visibility.Visible;
        }
        else if (groupState.State == 1) {
            tagTree.Visibility = Visibility.Hidden;
            spellingTree.Visibility = Visibility.Visible;
        }
        else {
            spellingTree.Visibility = Visibility.Hidden;
            surahTree.Visibility = Visibility.Visible;
        }
    }

    void onDoubleLick(object sender, MouseButtonEventArgs e) {
        if (e.ChangedButton != MouseButton.Left) return;

        Match match;
        if (groupState.State == 0) {
            if (tagTree.SelectedItem == null) return;
            if (tagTree.SelectedItem is not Match) return;
            match = (Match)tagTree.SelectedItem;
        }
        else if(groupState.State == 1) {
            if (spellingTree.SelectedItem == null) return;
            if (spellingTree.SelectedItem is not Match) return;
            match = (Match)spellingTree.SelectedItem;
        }
        else {
            if (surahTree.SelectedItem == null) return;
            if (surahTree.SelectedItem is not Match) return;
            match = (Match)surahTree.SelectedItem;
        }
        ((App)Application.Current).Pages.addSurahPage(match.Reference);
    }

    protected override void unload() {
        tagTree.MouseDoubleClick -= onDoubleLick;
        spellingTree.MouseDoubleClick -= onDoubleLick;
        surahTree.MouseDoubleClick -= onDoubleLick;
        groupStateDescriptor.RemoveValueChanged(groupState, onGroupStateChanged);
        terminator.Cancel();
        terminator.Dispose();
        base.unload();
    }
}
