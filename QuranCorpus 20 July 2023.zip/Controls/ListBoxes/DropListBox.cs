﻿class DropListBox : ListBox {
    Type sourceType;
    ListBoxItem dropTarget;

    public Action<object, IList> DropAction { get; set; }

    public DropListBox(Type sourceType) {
        AllowDrop = true;
        this.sourceType = sourceType;
    }

    protected override void OnDrop(DragEventArgs e) {
        base.OnDrop(e);

        var dataObj = e.Data as DataObject;
        var dragged = dataObj.GetData(typeof(IList)) as IList;

        DropAction?.Invoke(dropTarget.DataContext, dragged);
    }

    protected override void OnDragOver(DragEventArgs e) {
        base.OnDragOver(e);
        bool canBeDropped = true;
        var source = e.Data.GetData("source");
        if (source.GetType() != sourceType) canBeDropped = false;

        var dataObj = e.Data as DataObject;
        var dragged = dataObj.GetData(typeof(IList)) as IList;
        if (dragged is null) canBeDropped = false;
        else {
            dropTarget = e.OriginalSource is Run ?
                Helper.FindParentOfType<ListBoxItem>(((Run)e.OriginalSource).Parent) :
                Helper.FindParentOfType<ListBoxItem>((DependencyObject)e.OriginalSource);

            if (dropTarget is null) canBeDropped = false;
        }
        if (canBeDropped) e.Effects = DragDropEffects.Move;
        else {
            e.Effects = DragDropEffects.None;
            e.Handled = true;
        }
    }
}
