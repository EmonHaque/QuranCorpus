﻿class MainView : View {
    public override string Icon => Icons.Home;
    public override FrameworkElement container => grid;
    Grid grid;

    public MainView() : base() {
        var tab = new TabView() { Margin = new Thickness(0,0,-5,0)};
        var side = new ViewContainer(NavPosition.TopLeftVertical) {
            Children = {
                new SurahView(),
                new LemmaView(),
                new RootLemmaLessView(),
                new TagView(),
                new SettingsView()
            }
        };
        Grid.SetColumn(side, 1);
        grid = new Grid() {
            ColumnDefinitions = {
                    new ColumnDefinition(){Width = new GridLength(3, GridUnitType.Star)},
                    new ColumnDefinition(){Width = new GridLength(1, GridUnitType.Star)},
                },
            Children = { tab, side }
        };
        AddVisualChild(grid);
    }
}
