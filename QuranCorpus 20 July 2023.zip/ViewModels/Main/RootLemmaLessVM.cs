﻿class RootLemmaLessVM : Notifiable {
    RootLemmaFree selected;
    public RootLemmaFree Selected {
        get { return selected; }
        set {
            if (value is null) return;
            if (!value.Equals(selected)) {
                selected = value;
            }
            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (((App)Application.Current).Pages.SelectedPage is LemmaLessPage page) {
                page.setContent(value);
            }
        }
    }
    public bool WasRightClicked { get; set; }
    public string Count { get; set; }
    public ObservableCollection<RootLemmaFree> Items { get; set; }

    public RootLemmaLessVM() {
        Items = new ObservableCollection<RootLemmaFree>();

        Task.Run(() => {
            var list = App.links
                .Where(x => string.IsNullOrEmpty(x.Root) && string.IsNullOrEmpty(x.Lemmas))
                .ToList();

            var newList = new List<Link>();
            foreach (var item in list) {
                var segments = item.Segments.Split('|');
                var first = App.segments[Convert.ToInt32(segments[0])];
                if (first.ElementAt(1) == '~') first = first.Remove(1, 1);
                if(segments.Length == 1) {
                    if (first.EndsWith("mu")) first = first.Remove(first.Length - 1);
                }
                first = first.toArabic();
                int length = segments.Length - 1;
                for (int i = 1; i < length; i++) {
                    first += App.segments[Convert.ToInt32(segments[i])].toArabic();
                }
                if(segments.Length > 1) {
                    var last = App.segments[Convert.ToInt32(segments[segments.Length - 1])];
                    if (last.EndsWith("mu")) last = last.Remove(last.Length - 1);
                    first += last = last.toArabic(); ;
                }
                newList.Add(new Link() {
                    Lemmas = first,
                    Reference = item.Reference
                });
            }

            var groups = newList
               .GroupBy(x => x.Lemmas)
               .ToList();

            App.Current.Dispatcher.Invoke(() => {
                foreach (var item in groups) {
                    Items.Add(new RootLemmaFree() {
                        Content = item.Key,
                        References = item.Select(x => x.Reference).ToList(),
                        Count = item.Count()
                    });
                }
                Count = groups.Count.ToString("N0");
                OnPropertyChanged(nameof(Count));
            });
        });
    }
}
