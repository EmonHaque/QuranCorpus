﻿class RootLemmaTemplate : HierarchicalDataTemplate {
    public RootLemmaTemplate() {
        ItemsSource = new Binding(nameof(LemmaHeader.Items));
        ItemTemplate = new LemmaTemplate();
        VisualTree = new FrameworkElementFactory(typeof(GroupGrid));
    }
}

class GroupGrid : Grid {
    TextBlockArabic arabic;
    TextBlockEnglish buckwalter, count;

    public GroupGrid() {
        arabic = new TextBlockArabic();
        buckwalter = new TextBlockEnglish() { 
            Margin = new Thickness(5, 0, 15, 0),
            VerticalAlignment = VerticalAlignment.Center
        };
        count = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center,
            Foreground = Brushes.Gray
        };

        SetColumn(buckwalter, 1);
        SetColumn(count, 2);

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });

        Children.Add(arabic);
        Children.Add(buckwalter);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var header = (LemmaHeader)DataContext;
        int total = 0;
        foreach (Lemma item in header.Items) {
            if (item.Items != null) total += item.Items.Sum(x => x.References.Count);
            else total += item.References.Count;
        }
        count.Text = total.ToString("N0") + " in " + header.Items.Count.ToString("N0");

        if (string.IsNullOrEmpty(header.Root)) buckwalter.Text = "Unknown";
        else {
            string text = "";
            foreach (var character in header.Root) {
                text += (char)Int16.Parse(App.characters.First(x => x.English == character).Arabic, NumberStyles.HexNumber);
            }
            arabic.Text = text;
            buckwalter.Text = header.Root;
        }
    }
}

class LemmaGrid : Grid {
    TextBlockArabic arabic;
    TextBlockEnglish pos, count;

    public LemmaGrid() {
        arabic = new TextBlockArabic();
        pos = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center,
            TextWrapping = TextWrapping.Wrap
        };
        count = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center
        };

        SetColumn(pos, 1);
        SetColumn(count, 2);

        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        ColumnDefinitions.Add(new ColumnDefinition() );
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(70) });

        Children.Add(arabic);
        Children.Add(pos);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var lemma = (Lemma)DataContext;
        if (lemma.Items != null) {
            var cou = lemma.Items.Sum(x => x.References.Count);
            count.Text = cou.ToString("N0") + " in " + lemma.Items.Count.ToString("N0");
            pos.Text = string.Join(" | ", lemma.Items.Select(x => x.POS));
        }
        else {
            count.Text = lemma.References.Count.ToString("N0");
            pos.Text = lemma.POS;
        }
        arabic.Text = lemma.Transcription.toArabic();
    }
}

class LemmaSubGrid : Grid {
    TextBlockArabic arabic;
    TextBlockEnglish pos, count;

    public LemmaSubGrid() {
        arabic = new TextBlockArabic();
        pos = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center
        };
        count = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            VerticalAlignment = VerticalAlignment.Center
        };

        SetColumn(pos, 1);
        SetColumn(count, 2);

        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { Width = GridLength.Auto });
        ColumnDefinitions.Add(new ColumnDefinition() { Width = new GridLength(70) });

        Children.Add(arabic);
        Children.Add(pos);
        Children.Add(count);
    }

    public override void EndInit() {
        base.EndInit();
        var lemma = (Lemma)DataContext;
        count.Text = lemma.References.Count.ToString("N0");
        arabic.Text = lemma.Transcription.toArabic();
        pos.Text = lemma.POS;
    }
}

class LemmaTemplate : HierarchicalDataTemplate {
    public LemmaTemplate() {
        VisualTree = new FrameworkElementFactory(typeof(LemmaGrid));
        ItemsSource = new Binding(nameof(Lemma.Items));
        ItemTemplate = new DataTemplate() {
            VisualTree = new FrameworkElementFactory(typeof(LemmaSubGrid))
        };
    }
}