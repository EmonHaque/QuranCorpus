﻿class SurahName : Grid {
    Run arabic, english, arabicNo, englishNo;

    public SurahName() {
        arabic = new Run();
        english = new Run();
        arabicNo = new Run();
        englishNo = new Run();

        var arabicBlock = new TextBlockArabic() {
            FlowDirection = FlowDirection.RightToLeft,
            Inlines = { arabicNo, new Run(") "), arabic }
        };
        var englishBlock = new TextBlockEnglish() {
            FlowDirection = FlowDirection.LeftToRight,
            Inlines = { englishNo, new Run(") "), english }
        };

        SetRow(englishBlock, 1);
        RowDefinitions.Add(new RowDefinition());
        RowDefinitions.Add(new RowDefinition());
        Children.Add(arabicBlock);
        Children.Add(englishBlock);
    }

    public override void EndInit() {
        base.EndInit();
        var name = (Surah)DataContext;
        var id = name.Id.ToString();
        arabicNo.Text = id.toArabicNo();
        arabic.Text = name.Arabic;
        englishNo.Text = id;
        english.Text = name.Transliteration;
    }
}
class SurahNameTemplate : DataTemplate {
    public SurahNameTemplate() {
        VisualTree = new FrameworkElementFactory(typeof(SurahName));
    }
}
