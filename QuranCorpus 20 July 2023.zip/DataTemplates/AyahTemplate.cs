﻿class AyahTemplate : DataTemplate {

    public AyahTemplate() {
        VisualTree = new FrameworkElementFactory(typeof(Verse));
    }

    class Verse : Grid {
        public Ayah ayah;
        Run englishAyahNo, arabicAyahNo;
        TextBlockEnglish meaning, explanation;
        WrapPanel arabic;
        StackPanel english;
        Grid englishGrid;
        ItemsControl segments;
        Popup pop;

        public Verse() {
            arabicAyahNo = new Run();
            var arabicAyahNoBlock = new TextBlockArabic() {
                Inlines = { arabicAyahNo, new Run(") ") }
            };
            arabic = new WrapPanel();
            Grid.SetColumn(arabic, 1);
            var arabicGrid = new Grid() {
                ColumnDefinitions = {
                new ColumnDefinition() { Width = GridLength.Auto },
                new ColumnDefinition()
            },
                Children = { arabicAyahNoBlock, arabic }
            };

            englishAyahNo = new Run();
            var englishAyahNoBlock = new TextBlockEnglish() {
                Inlines = { englishAyahNo, new Run(") ") }
            };
            english = new StackPanel();
            Grid.SetColumn(english, 1);

            englishGrid = new Grid() {
                FlowDirection = FlowDirection.LeftToRight,
                ColumnDefinitions = {
                new ColumnDefinition(){ Width = GridLength.Auto },
                new ColumnDefinition()
            },
                Children = { englishAyahNoBlock, english }
            };

            Grid.SetRow(englishGrid, 1);
            RowDefinitions.Add(new RowDefinition());
            RowDefinitions.Add(new RowDefinition());
            Children.Add(arabicGrid);
            Children.Add(englishGrid);

            meaning = new TextBlockEnglish() {
                Foreground = Brushes.White,
                FontWeight = FontWeights.Bold
            };
            segments = new ItemsControl() {
                Margin = new Thickness(0, 5, 0, 5),
                Padding = new Thickness(0, 5, 0, 5),
                BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, Constants.BottomLineThickness),
                BorderBrush = Brushes.LightGray,
                ItemTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(PartitionGrid))
                }
            };
            segments.SetValue(Grid.IsSharedSizeScopeProperty, true);
            explanation = new TextBlockEnglish() {
                TextWrapping = TextWrapping.Wrap,
                Foreground = Brushes.White
            };
            Grid.SetRow(segments, 1);
            Grid.SetRow(explanation, 2);

            pop = new Popup() {
                AllowsTransparency = true,
                Placement = PlacementMode.Mouse,
                HorizontalOffset = 20,
                VerticalOffset = 20,
                MinWidth = 200,
                MaxWidth = 300,
                Child = new Border() {
                    Padding = new Thickness(10),
                    CornerRadius = new CornerRadius(5),
                    BorderBrush = Brushes.LightGray,
                    BorderThickness = new Thickness(Constants.BottomLineThickness),
                    Background = Constants.Background,
                    Child = new Grid() {
                        RowDefinitions = {
                        new RowDefinition(){ Height = GridLength.Auto},
                        new RowDefinition(){ Height = GridLength.Auto},
                        new RowDefinition()
                    },
                        Children = {
                        meaning,
                        segments,
                        explanation
                    }
                    }
                }
            };

            Loaded += onLoaded;
            Unloaded += onUnloaded;
        }

        public override void EndInit() {
            base.EndInit();
            ayah = (Ayah)DataContext;

            englishAyahNo.Text = ayah.AyahNo;
            arabicAyahNo.Text = ayah.AyahNo.toArabicNo();

            StringBuilder builder = new();
            foreach (var word in ayah.Words) {
                int pronCount, otherCount;
                pronCount = otherCount = 0;
                string lastPos = "";

                var block = new TextBlockArabic() {
                    Padding = new Thickness(5, 0, 5, 0),
                    Tag = word
                };
                
                if (word.IsHighlighted) block.Background = Brushes.Brown;

                var segments = word.Segments.Split('|');
                var tags = word.Tags.Split('|');
                int index = 0;
                foreach (var segment in segments) {
                    segment.toArabic(segments, builder);
                    var run = new Run(builder.ToString());
                    builder.Clear();

                    var tag = App.tags[Convert.ToInt32(tags[index])];
                    switch (tag) {
                        case "DET": run.Foreground = Foregrounds.DET_Brush; break;
                        case "V": run.Foreground = Foregrounds.V_Brush; break;
                        case "N":
                        case "PN":
                        case "ADJ": run.Foreground = Foregrounds.N_PN_ADJ_Brush; break;
                        case "REL":
                        case "DEM": run.Foreground = Foregrounds.DEM_REL_Brush; break;
                        case "P": run.Foreground = Foregrounds.P_Brush; break;
                        case "CONJ": run.Foreground = Foregrounds.CONJ_Brush; break;
                        case "INTG": run.Foreground = Foregrounds.INTG_Brush; break;
                        case "NEG": run.Foreground = Foregrounds.NEG_Brush; break;
                        case "PRON":
                            if (lastPos.Equals("PRON")) pronCount++;
                            if (pronCount == 1) run.Foreground = Foregrounds.PRON1_Brush;
                            else if (pronCount == 2) run.Foreground = Foregrounds.PRON2_Brush;
                            else run.Foreground = Foregrounds.PRON3_Brush;
                            break;
                        default:
                            if (!Foregrounds.Defined.Contains(lastPos)) otherCount++;
                            if (otherCount == 1) run.Foreground = Foregrounds.OTHER1_Brush;
                            else if (otherCount == 2) run.Foreground = Foregrounds.OTHER2_Brush;
                            else run.Foreground = Foregrounds.OTHER3_Brush;
                            break;
                    }
                    lastPos = tag;
                    block.Inlines.Add(run);
                    index++;
                }
                arabic.Children.Add(block);
            }
            addTranslation();
        }

        void onLoaded(object sender, RoutedEventArgs e) {

            foreach (TextBlockArabic item in arabic.Children) {
                item.MouseEnter += onMouseEnter;
                item.MouseLeave += onMouseLeave;
                item.PreviewMouseLeftButtonDown += onLeftButtonDown;
            }
            ayah.PropertyChanged += onTranslationChange;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            foreach (TextBlockArabic item in arabic.Children) {
                item.MouseEnter -= onMouseEnter;
                item.MouseLeave -= onMouseLeave;
                item.PreviewMouseLeftButtonDown -= onLeftButtonDown;
            }
            ayah.PropertyChanged -= onTranslationChange;
            pop.IsOpen = false;
        }

        void addTranslation() {
            var list = App.global.TranslationDictionary.Keys.ToList();

            if (ayah.Translations is null) {
                englishGrid.Visibility = Visibility.Collapsed;
            }
            else {
                englishGrid.Visibility = Visibility.Visible;
                if (ayah.Translations.Length == 1) {
                    english.Children.Add(new TextBlockEnglish() {
                        TextWrapping = TextWrapping.Wrap,
                        Margin = new Thickness(0, 0, 0, 10),
                        Text = ayah.Translations[0].Content
                    });
                }
                else {
                    foreach (var item in ayah.Translations) {
                        var name = new Run(list[item.TranslatorId] + ": ") {
                            FontWeight = FontWeights.Bold,
                            Foreground = Brushes.Gray
                        };
                        var content = new Run(item.Content);

                        english.Children.Add(new TextBlockEnglish() {
                            TextWrapping = TextWrapping.Wrap,
                            Margin = new Thickness(0, 0, 0, 10),
                            Inlines = { name, content }
                        });
                    }
                }
            }
        }

        void onTranslationChange(object? sender, PropertyChangedEventArgs e) {
            english.Children.Clear();
            addTranslation();
        }

        void onMouseLeave(object sender, MouseEventArgs e) {
            var block = (TextBlockArabic)sender;
            var word = (Word)block.Tag;
            block.Background = word.IsHighlighted ? Brushes.Brown : null;
            block.Opacity = 1;
            if (pop.IsOpen) pop.IsOpen = false;
        }

        void onMouseEnter(object sender, MouseEventArgs e) {
            var block = (TextBlockArabic)sender;
            block.Background = Constants.Background;

            var word = (Word)block.Tag;
            List<Partitions> partitions = new();
            var parts = word.Segments.Split('|');
            var tags = word.Tags.Split('|');
            var lemmas = word.Lemmas.Split('|');
            var lemmaIndices = word.LemmaIndices.Split('|');

            for (int i = 0; i < parts.Length; i++) {
                var part = new Partitions() { Tag = App.tags[Convert.ToInt32(tags[i])] };
                string lemma = "";
                bool hasLemma = false;
                for (int j = 0; j < lemmaIndices.Length; j++) {
                    if (string.IsNullOrEmpty(lemmaIndices[j])) continue;
                    if (Convert.ToInt32(lemmaIndices[j]) != i) continue;
                    lemma = App.lemmas[Convert.ToInt32(lemmas[j])];
                    hasLemma = true;
                    break;
                }

                if (hasLemma) part.Lemma = lemma.toArabic();
                part.Transcription = App.segments[Convert.ToInt32(parts[i])].toArabic();
                partitions.Add(part);
            }

            parts = word.Reference.Split(':');
            string wordNo = parts[2] switch {
                "1" => "st ",
                "2" => "nd ",
                "3" => "rd",
                _ => "th "
            };

            wordNo = "The " + parts[2] + wordNo + " word";
            string ayah = " of verse " + parts[1];
            string surah = " of chapter " + parts[0] + " ";

            segments.ItemsSource = partitions;
            meaning.Text = word.Transliteration + '\n' + word.Meaning;
            explanation.Text = wordNo + ayah + surah + word.Explanation;
            pop.IsOpen = true;
        }

        void onLeftButtonDown(object sender, MouseButtonEventArgs e) {
            if (e.ClickCount != 2) return;
            e.Handled = true;
            if (pop.IsOpen) pop.IsOpen = false;

            var block = (TextBlockArabic)sender;
            var word = (Word)block.Tag;
            block.Background = word.IsHighlighted ? Brushes.Brown : null;
            block.Opacity = 1;

            ((App)Application.Current).Pages.addMatchPage(word);
        }
    }
}

class AyahTemplateDragDrop : DataTemplate {
    public AyahTemplateDragDrop() {
        VisualTree = new FrameworkElementFactory(typeof(Verse));
    }

    class Verse : Grid {
        public Ayah ayah;
        Run englishAyahNo, arabicAyahNo;
        TextBlockEnglish meaning, explanation;
        WrapPanel arabic;
        StackPanel english;
        Grid englishGrid;
        ItemsControl segments;
        Popup pop;
        Border dragTop, dragBottom;

        public Verse() {
            arabicAyahNo = new Run();
            var arabicAyahNoBlock = new TextBlockArabic() {
                Inlines = { arabicAyahNo, new Run(") ") }
            };
            arabic = new WrapPanel();
            Grid.SetColumn(arabic, 1);
            var arabicGrid = new Grid() {
                FlowDirection = FlowDirection.RightToLeft,
                ColumnDefinitions = {
                    new ColumnDefinition() { Width = GridLength.Auto },
                    new ColumnDefinition()
                },
                Children = { arabicAyahNoBlock, arabic }
            };

            englishAyahNo = new Run();
            var englishAyahNoBlock = new TextBlockEnglish() {
                Inlines = { englishAyahNo, new Run(") ") }
            };
            english = new StackPanel();
            Grid.SetColumn(english, 1);

            englishGrid = new Grid() {
                FlowDirection = FlowDirection.LeftToRight,
                ColumnDefinitions = {
                    new ColumnDefinition(){ Width = GridLength.Auto },
                    new ColumnDefinition()
                },
                Children = { englishAyahNoBlock, english }
            };

            dragTop = new Border();
            dragBottom = new Border();

            SetRow(arabicGrid, 1);
            SetRow(englishGrid, 2);
            SetRow(dragBottom, 3);

            RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1.5) });
            RowDefinitions.Add(new RowDefinition());
            RowDefinitions.Add(new RowDefinition());
            RowDefinitions.Add(new RowDefinition() { Height = new GridLength(1.5) });

            Children.Add(dragTop);
            Children.Add(arabicGrid);
            Children.Add(englishGrid);
            Children.Add(dragBottom);

            meaning = new TextBlockEnglish() {
                Foreground = Brushes.White,
                FontWeight = FontWeights.Bold
            };
            segments = new ItemsControl() {
                Margin = new Thickness(0, 5, 0, 5),
                Padding = new Thickness(0, 5, 0, 5),
                BorderThickness = new Thickness(0, Constants.BottomLineThickness, 0, Constants.BottomLineThickness),
                BorderBrush = Brushes.LightGray,
                ItemTemplate = new DataTemplate() {
                    VisualTree = new FrameworkElementFactory(typeof(PartitionGrid))
                }
            };
            segments.SetValue(Grid.IsSharedSizeScopeProperty, true);
            explanation = new TextBlockEnglish() {
                TextWrapping = TextWrapping.Wrap,
                Foreground = Brushes.White
            };
            Grid.SetRow(segments, 1);
            Grid.SetRow(explanation, 2);

            pop = new Popup() {
                AllowsTransparency = true,
                Placement = PlacementMode.Mouse,
                HorizontalOffset = 20,
                VerticalOffset = 20,
                MinWidth = 200,
                MaxWidth = 300,
                Child = new Border() {
                    Padding = new Thickness(10),
                    CornerRadius = new CornerRadius(5),
                    BorderBrush = Brushes.LightGray,
                    BorderThickness = new Thickness(Constants.BottomLineThickness),
                    Background = Constants.Background,
                    Child = new Grid() {
                        RowDefinitions = {
                        new RowDefinition(){ Height = GridLength.Auto},
                        new RowDefinition(){ Height = GridLength.Auto},
                        new RowDefinition()
                    },
                        Children = {
                        meaning,
                        segments,
                        explanation
                    }
                    }
                }
            };

            Loaded += onLoaded;
            Unloaded += onUnloaded;
        }

        public override void EndInit() {
            base.EndInit();
            ayah = (Ayah)DataContext;

            englishAyahNo.Text = ayah.SurahNo + ":" + ayah.AyahNo;
            arabicAyahNo.Text = ayah.SurahNo.toArabicNo() + ":" + ayah.AyahNo.toArabicNo();

            StringBuilder builder = new();

            foreach (var word in ayah.Words) {
                int pronCount, otherCount;
                pronCount = otherCount = 0;
                string lastPos = "";

                var block = new TextBlockArabic() {
                    Padding = new Thickness(5, 0, 5, 0),
                    Tag = word
                };
                if (word.IsHighlighted) block.Background = Brushes.Brown;
                
                var segments = word.Segments.Split('|');
                var tags = word.Tags.Split('|');
                int index = 0;

                foreach (var segment in segments) {
                    segment.toArabic(segments, builder);
                    var run = new Run(builder.ToString());
                    builder.Clear();

                    var tag = App.tags[Convert.ToInt32(tags[index])];
                    switch (tag) {
                        case "DET": run.Foreground = Foregrounds.DET_Brush; break;
                        case "V": run.Foreground = Foregrounds.V_Brush; break;
                        case "N":
                        case "PN":
                        case "ADJ": run.Foreground = Foregrounds.N_PN_ADJ_Brush; break;
                        case "REL":
                        case "DEM": run.Foreground = Foregrounds.DEM_REL_Brush; break;
                        case "P": run.Foreground = Foregrounds.P_Brush; break;
                        case "CONJ": run.Foreground = Foregrounds.CONJ_Brush; break;
                        case "INTG": run.Foreground = Foregrounds.INTG_Brush; break;
                        case "NEG": run.Foreground = Foregrounds.NEG_Brush; break;
                        case "PRON":
                            if (lastPos.Equals("PRON")) pronCount++;
                            if (pronCount == 1) run.Foreground = Foregrounds.PRON1_Brush;
                            else if (pronCount == 2) run.Foreground = Foregrounds.PRON2_Brush;
                            else run.Foreground = Foregrounds.PRON3_Brush;
                            break;
                        default:
                            if (!Foregrounds.Defined.Contains(lastPos)) otherCount++;
                            if (otherCount == 1) run.Foreground = Foregrounds.OTHER1_Brush;
                            else if (otherCount == 2) run.Foreground = Foregrounds.OTHER2_Brush;
                            else run.Foreground = Foregrounds.OTHER3_Brush;
                            break;
                    }
                    lastPos = tag;
                    block.Inlines.Add(run);
                    index++;
                }
                arabic.Children.Add(block);
            }
            addTranslation();
        }

        void onLoaded(object sender, RoutedEventArgs e) {

            foreach (TextBlockArabic item in arabic.Children) {
                item.MouseEnter += onMouseEnter;
                item.MouseLeave += onMouseLeave;
                item.PreviewMouseLeftButtonDown += onLeftButtonDown;
            }
            ayah.PropertyChanged += onTranslationChange;
        }

        void onUnloaded(object sender, RoutedEventArgs e) {
            foreach (TextBlockArabic item in arabic.Children) {
                item.MouseEnter -= onMouseEnter;
                item.MouseLeave -= onMouseLeave;
                item.PreviewMouseLeftButtonDown -= onLeftButtonDown;
            }
            ayah.PropertyChanged -= onTranslationChange;
            pop.IsOpen = false;
        }

        void addTranslation() {
            var list = App.global.TranslationDictionary.Keys.ToList();

            if (ayah.Translations is null) {
                englishGrid.Visibility = Visibility.Collapsed;
            }
            else {
                englishGrid.Visibility = Visibility.Visible;
                if (ayah.Translations.Length == 1) {
                    english.Children.Add(new TextBlockEnglish() {
                        TextWrapping = TextWrapping.Wrap,
                        Margin = new Thickness(0, 0, 0, 10),
                        Text = ayah.Translations[0].Content
                    });
                }
                else {
                    foreach (var item in ayah.Translations) {
                        var name = new Run(list[item.TranslatorId] + ": ") {
                            FontWeight = FontWeights.Bold,
                            Foreground = Brushes.Gray
                        };
                        var content = new Run(item.Content);

                        english.Children.Add(new TextBlockEnglish() {
                            TextWrapping = TextWrapping.Wrap,
                            Margin = new Thickness(0, 0, 0, 10),
                            Inlines = { name, content }
                        });
                    }
                }
            }
        }

        void onTranslationChange(object? sender, PropertyChangedEventArgs e) {
            english.Children.Clear();
            addTranslation();
        }

        void onMouseLeave(object sender, MouseEventArgs e) {
            var block = (TextBlockArabic)sender;
            var word = (Word)block.Tag;
            block.Background = word.IsHighlighted ? Brushes.Brown : null;
            block.Opacity = 1;
            if (pop.IsOpen) pop.IsOpen = false;
        }

        void onMouseEnter(object sender, MouseEventArgs e) {
            var block = (TextBlockArabic)sender;
            block.Background = Constants.Background;

            var word = (Word)block.Tag;
            List<Partitions> partitions = new();
            var parts = word.Segments.Split('|');
            var tags = word.Tags.Split('|');
            var lemmas = word.Lemmas.Split('|');
            var lemmaIndices = word.LemmaIndices.Split('|');

            for (int i = 0; i < parts.Length; i++) {
                var part = new Partitions() { Tag = App.tags[Convert.ToInt32(tags[i])] };
                string lemma = "";
                bool hasLemma = false;
                for (int j = 0; j < lemmaIndices.Length; j++) {
                    if (string.IsNullOrEmpty(lemmaIndices[j])) continue;
                    if (Convert.ToInt32(lemmaIndices[j]) != i) continue;
                    lemma = App.lemmas[Convert.ToInt32(lemmas[j])];
                    hasLemma = true;
                    break;
                }

                if (hasLemma) part.Lemma = lemma.toArabic();
                part.Transcription = App.segments[Convert.ToInt32(parts[i])].toArabic();
                partitions.Add(part);
            }

            parts = word.Reference.Split(':');
            string wordNo = parts[2] switch {
                "1" => "st ",
                "2" => "nd ",
                "3" => "rd",
                _ => "th "
            };

            wordNo = "The " + parts[2] + wordNo + " word";
            string ayah = " of verse " + parts[1];
            string surah = " of chapter " + parts[0] + " ";

            segments.ItemsSource = partitions;
            meaning.Text = word.Transliteration + '\n' + word.Meaning;
            explanation.Text = wordNo + ayah + surah + word.Explanation;
            pop.IsOpen = true;
        }

        void onLeftButtonDown(object sender, MouseButtonEventArgs e) {
            if (e.ClickCount != 2) return;
            e.Handled = true;
            if (pop.IsOpen) pop.IsOpen = false;

            var block = (TextBlockArabic)sender;
            var word = (Word)block.Tag;
            block.Background = word.IsHighlighted ? Brushes.Brown : null;
            block.Opacity = 1;

            ((App)Application.Current).Pages.addMatchPage(word);
        }

        protected override void OnDragEnter(DragEventArgs e) {
            base.OnDragEnter(e);
            Background = Brushes.Black;
            Opacity = 0.5;
        }

        protected override void OnDragOver(DragEventArgs e) {
            base.OnDragOver(e);
            // handle if it's fired for this;
            var point = e.GetPosition(this);
            var mid = ActualHeight / 2;

            if (point.Y < mid) {
                dragBottom.Background = null;
                dragTop.Background = Brushes.Red;
            }
            else {
                dragTop.Background = null;
                dragBottom.Background = Brushes.Red;
            }
        }

        protected override void OnDragLeave(DragEventArgs e) {
            base.OnDragLeave(e);
            Background = null;
            Opacity = 1;
            dragTop.Background = null;
            dragBottom.Background = null;
        }

        protected override void OnDrop(DragEventArgs e) {
            base.OnDragOver(e);
            Background = null;
            Opacity = 1;
        }
    }
}

class Partitions {
    public string Transcription { get; set; }
    public string Lemma { get; set; }
    public string Tag { get; set; }
}

class PartitionGrid : Grid {
    TextBlockArabic transcript, lemma;
    TextBlock tag;
    public PartitionGrid() {
        transcript = new TextBlockArabic() {
            Margin = new Thickness(20, 0, 20, 0)
        };
        lemma = new TextBlockArabic();
        tag = new TextBlock() { VerticalAlignment = VerticalAlignment.Center };

        Grid.SetColumn(transcript, 1);
        Grid.SetColumn(tag, 2);
        ColumnDefinitions.Add(new ColumnDefinition());
        ColumnDefinitions.Add(new ColumnDefinition() { SharedSizeGroup = "col2" });
        ColumnDefinitions.Add(new ColumnDefinition());
        Children.Add(lemma);
        Children.Add(transcript);
        Children.Add(tag);

        transcript.SetBinding(TextBlockArabic.TextProperty, new Binding(nameof(Partitions.Transcription)));
        lemma.SetBinding(TextBlockArabic.TextProperty, new Binding(nameof(Partitions.Lemma)));
        tag.SetBinding(TextBlock.TextProperty, new Binding(nameof(Partitions.Tag)));
    }
}
