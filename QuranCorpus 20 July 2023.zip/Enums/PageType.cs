﻿enum PageType {
    Surah,
    Match,
    Lemma,
    LemmaLess,
    Tag,
    Search
}

