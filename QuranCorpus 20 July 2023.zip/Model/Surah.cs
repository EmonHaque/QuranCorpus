﻿public class Surah
{
    public int Id { get; set; }
    public string Arabic { get; set; }
    public string Transliteration { get; set; }
    public string English { get; set; }
    public string Verses { get; set; }
    public string Place { get; set; }
}
