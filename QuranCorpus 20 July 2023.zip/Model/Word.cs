﻿class Word {
    public string Reference { get; set; }
    public string Transliteration { get; set; }
    public string Tags { get; set; }
    public string Segments { get; set; }
    public string Lemmas { get; set; }
    public string LemmaIndices { get; set; }
    public string Meaning { get; set; }
    public string Explanation { get; set; }
    public bool IsHighlighted { get; set; }
}
