﻿class Lemma {
    public string POS { get; set; }
    public string Root { get; set; }
    public string Transcription { get; set; }
    public List<string> References { get; set; }
    public List<Lemma> Items { get; set; }

    public Lemma() {

    }
    public Lemma(Lemma other) {
        Root = other.Transcription;
        Transcription = other.Transcription;
        References = other.References;
        POS = other.POS;
    }
}
