﻿class TagVM : Notifiable {
    string tagPath;
    ObservableCollection<TagItem> tags;
    string query;
    public string Query {
        get { return query; }
        set { query = value; Tags.Refresh(); }
    }
    TagItem selectedTag;
    public TagItem SelectedTag {
        get { return selectedTag; }
        set {
            if (value is null) return;
            if (!value.Equals(selectedTag)) {
                selectedTag = value;
            }
            if (WasRightClicked) {
                WasRightClicked = false;
                return;
            }
            if (value.Count == 0) return;
            if (((App)Application.Current).Pages.SelectedPage is TagPage page) {
                page.setContent(value);
            }
        }
    }
    public ICollectionView Tags { get; set; }
    public bool WasRightClicked { get; set; }
    public bool IsInProgress { get; set; }
    public string TagName { get; set; }
    public string Error { get; set; }

    public static event Action<string> Tagged;

    public TagVM() {
        tagPath = "Resources/Tags/";
        Error = "add a tag, drop ayah from surah or lemma pages";
        tags = new ObservableCollection<TagItem>();
        Tags = CollectionViewSource.GetDefaultView(tags);
        Tags.Filter = filter;
        if (System.IO.Directory.Exists(tagPath)) {
            var files = System.IO.Directory.EnumerateFiles(tagPath);
            foreach (var file in files) {
                var count = System.IO.File.ReadAllLines(file).Count();
                var name = file.Substring(file.IndexOf('\\') + 1);
                tags.Add(new TagItem() {
                    Name = name.Substring(0, name.LastIndexOf('.')),
                    Count = count
                });
            }
        }
    }

    public void addTag() {
        if (string.IsNullOrWhiteSpace(TagName)) {
            Error = "Name cannot be empty";
            OnPropertyChanged(nameof(Error));
            return;
        }
        if (!System.IO.Directory.Exists(tagPath)) {
            System.IO.Directory.CreateDirectory(tagPath);
        }
        var file = "Resources/Tags/" + TagName + ".txt";
        if (System.IO.File.Exists(file)) {
            Error = "Tag exists";
            OnPropertyChanged(nameof(Error));
            return;
        }
        System.IO.File.Create(file);

        tags.Add(new TagItem() {
            Name = TagName,
            Count = 0
        });
        TagName = "";
        OnPropertyChanged(nameof(TagName));
        if (!string.IsNullOrEmpty(Error)) {
            Error = "";
            OnPropertyChanged(nameof(Error));
        }
    }

    public void onDrop(object on, IList items) {
        IsInProgress = true;
        OnPropertyChanged(nameof(IsInProgress));

        Task.Run(() => {
            var tag = (TagItem)on;
            var file = tagPath + tag.Name + ".txt";
            var lines = System.IO.File.ReadAllLines(file).ToList();

            if (items[0] is Ayah) {
                foreach (var item in items) {
                    var ayah = (Ayah)item;
                    lines.Add(ayah.SurahNo + ":" + ayah.AyahNo);
                }
            }
            else {
                foreach (var item in items) {
                    var ayah = (Match)item;
                    lines.Add(ayah.Reference.Substring(0, ayah.Reference.LastIndexOf(':')));
                }
            }

            lines = lines.Distinct().ToList();
            System.IO.File.WriteAllLines(file, lines);
            tag.Count = lines.Count;

            App.Current.Dispatcher.Invoke(() => {
                IsInProgress = false;
                tag.OnPropertyChanged(nameof(TagItem.Count));
                OnPropertyChanged(nameof(IsInProgress));
                Tagged?.Invoke(tag.Name);
            });
        });
    }

    bool filter(object o) {
        if (string.IsNullOrWhiteSpace(Query)) return true;
        var tag = (TagItem)o;
        return tag.Name.Contains(Query, StringComparison.InvariantCultureIgnoreCase);
    }

    //void watchTags() {
    //    var watcher = new System.IO.FileSystemWatcher() {
    //        Path = tagPath,
    //        Filter = "*.txt",
    //        EnableRaisingEvents = true,
    //        NotifyFilter = 
    //            System.IO.NotifyFilters.LastAccess |
    //            System.IO.NotifyFilters.LastWrite |
    //            System.IO.NotifyFilters.FileName
    //    };
    //    //watcher.Changed += new FileSystemEventHandler(Changed);
    //    watcher.Created += new System.IO.FileSystemEventHandler(onFileCreated);
    //    watcher.Deleted += new System.IO.FileSystemEventHandler(onDeleted);
    //    watcher.Renamed += new System.IO.RenamedEventHandler(onRenamed);
    //}
}
