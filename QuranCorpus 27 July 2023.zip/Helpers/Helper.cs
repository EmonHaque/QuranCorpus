﻿public class Helper
{
    public static Path getIcon(string data, Brush fill = null) => new Path() {
        Data = Geometry.Parse(data),
        Fill = fill == null ? Brushes.Black : fill,
        Width = 12,
        Height = 12,
        Stretch = Stretch.Uniform
    };

    public static T FindParentOfType<T>(DependencyObject child) where T : DependencyObject {
        DependencyObject parentDepObj = child;
        do {
            parentDepObj = VisualTreeHelper.GetParent(parentDepObj);
            T parent = parentDepObj as T;
            if (parent != null) return parent;
        }
        while (parentDepObj != null);
        return null;
    }

    public static T FindVisualChild<T>(DependencyObject o) where T : DependencyObject {
        for (int i = 0; i < VisualTreeHelper.GetChildrenCount(o); i++) {
            var child = VisualTreeHelper.GetChild(o, i);
            if (child != null && child is T) return (T)child;
            else {
                T grandChild = FindVisualChild<T>(child);
                if (grandChild != null) return grandChild;
            }
        }
        return null;
    }

    public static IEnumerable<T> FindVisualChildren<T>(DependencyObject o) where T : DependencyObject {
        if (o != null) {
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(o); i++) {
                DependencyObject child = VisualTreeHelper.GetChild(o, i);
                if (child != null && child is T) {
                    yield return (T)child;
                }

                foreach (T childOfChild in FindVisualChildren<T>(child)) {
                    yield return childOfChild;
                }
            }
        }
    }

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    internal static extern bool GetCursorPos(ref Win32Point pt);

    [StructLayout(LayoutKind.Sequential)]
    internal struct Win32Point {
        public Int32 X;
        public Int32 Y;
    };
    public static Point GetMousePosition() {
        var w32Mouse = new Win32Point();
        GetCursorPos(ref w32Mouse);

        return new Point(w32Mouse.X, w32Mouse.Y);
    }
}

